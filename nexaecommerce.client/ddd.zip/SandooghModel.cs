﻿namespace MVCSandoogh
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using Models;

    public partial class SandooghModel : DbContext
    {
        public SandooghModel()
            : base("name=SandooghModel1")
        {
        }
        public virtual DbSet<bitpayorder> bitpayorders { get; set; }

        public virtual DbSet<T_HadaksarAfzayeshChangeDate> T_HadaksarAfzayeshChangeDate { get; set; }
        public virtual DbSet<T_AfzayeshSarmayeh> T_AfzayeshSarmayeh { get; set; }
        //چک
        public virtual DbSet<T_BankAccount> T_BankAccount { get; set; }
        public virtual DbSet<T_Cheq> T_Cheq { get; set; }
        public virtual DbSet<T_orders> T_orders { get; set; }
        public virtual DbSet<T_CheqMasraf> T_CheqMasraf { get; set; }
        //اتوماسیون
        public virtual DbSet<Atomation_Girande> Atomation_Girande { get; set; }
        public virtual DbSet<Automation_Letter> Automation_Letter { get; set; }
        public virtual DbSet<Automation_LetterScanDB> Automation_LetterScanDB { get; set; }
        public virtual DbSet<Automation_LetterType> Automation_LetterType { get; set; }
        public virtual DbSet<Automation_Refer> Automation_Refer { get; set; }
        //حسابداری
        public virtual DbSet<Acc_Group_F> Acc_Group_F { get; set; }
        public virtual DbSet<T_Log> T_Log { get; set; }
        public virtual DbSet<Acc_Kol> Acc_Kol { get; set; }
        public virtual DbSet<Acc_Moein> Acc_Moein { get; set; }
        public virtual DbSet<Acc_Tafsil1> Acc_Tafsil1 { get; set; }
        public virtual DbSet<Acc_Tafsili2> Acc_Tafsili2 { get; set; }
        public virtual DbSet<T_AccountType> T_AccountType { get; set; }
        public virtual DbSet<T_Mahiat> T_Mahiat { get; set; }
        public virtual DbSet<AccSanad_B> AccSanad_B { get; set; }
        //سیستم وام
        public virtual DbSet<Option_T> Option_T { get; set; }
        public virtual DbSet<CityCode> CityCodes { get; set; }
        public virtual DbSet<MemberRegistration> MemberRegistrations { get; set; }
        public virtual DbSet<Nahveh_P> Nahveh_P { get; set; }
        public virtual DbSet<Nahveh_PTasvie> Nahveh_PTasvie { get; set; }
        public virtual DbSet<T_Contactus> T_Contactus { get; set; }
        public virtual DbSet<T_Jensiat> T_Jensiat { get; set; }
        public virtual DbSet<T_Look> T_Look { get; set; }
        public virtual DbSet<T_OzvCode> T_OzvCode { get; set; }
        public virtual DbSet<T_User> T_User { get; set; }
        public virtual DbSet<T_VamCode> T_VamCode { get; set; }
        public virtual DbSet<Taahol> Taahols { get; set; }
        public virtual DbSet<Vam> Vams { get; set; }
        public virtual DbSet<G_M_Pays> G_M_Pays { get; set; }
        public virtual DbSet<G_M_Payswait> G_M_Payswait { get; set; }

        public virtual DbSet<ScanDB> ScanDB { get; set; }
        public virtual DbSet<T_ScanType> T_ScanType { get; set; }
        public virtual DbSet<Tasvieh> Tasviehs { get; set; }
        public virtual DbSet<Acc_Year> Acc_Years { get; set; }
        public virtual DbSet<VamNobat> VamNobats { get; set; }
        public virtual DbSet<VamScanDB> VamScanDBs { get; set; }
        public virtual DbSet<VamTemp> VamTemps { get; set; }
        public virtual DbSet<VamZaman> VamZamen { get; set; }
        public virtual DbSet<T_MostamaryMablagh> T_MostamaryMablagh { get; set; }
        public virtual DbSet<VamPolicySetting> VamPolicySettings { get; set; }
        public virtual DbSet<T_VamQueueSetting> VamQueueSettings { get; set; }
        public virtual DbSet<T_VamKhoshHesabiSetting>
    T_VamKhoshHesabiSettings
        { get; set; }
        public virtual DbSet<T_MinMostamari>
  T_MinMostamaries
        { get; set; }
        
        public virtual DbSet<MinimumPensionSetting> MinimumPensionSettings { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<T_OzvCode>()
            .HasMany(e => e.T_AfzayeshSarmayeh)
            .WithOptional(e => e.T_OzvCode)
            .HasForeignKey(e => e.AfzayeshSarmayeh_Idrefozvcode);
            //چک
            modelBuilder.Entity<T_BankAccount>()
               .HasMany(e => e.T_Cheq)
               .WithOptional(e => e.T_BankAccount)
               .HasForeignKey(e => e.Cheq_Hesab);

            modelBuilder.Entity<T_CheqMasraf>()
                .HasMany(e => e.T_Cheq)
                .WithOptional(e => e.T_CheqMasraf)
                .HasForeignKey(e => e.Cheq_Masarf);

            modelBuilder.Entity<T_OzvCode>()
                .Property(e => e.SeriSh)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<T_OzvCode>()
                .Property(e => e.SerialSh)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<T_OzvCode>()
                .HasMany(e => e.T_Cheq)
                .WithOptional(e => e.T_OzvCode)
                .HasForeignKey(e => e.Cheq_Member);
            //اتوماسیون
            modelBuilder.Entity<Automation_Letter>()
               .HasMany(e => e.Automation_LetterScanDB_MainLetter)
               .WithOptional(e => e.Automation_Letter_MainLetter)
               .HasForeignKey(e => e.Letter_Id);

            modelBuilder.Entity<Automation_Letter>()
                .HasMany(e => e.Automation_LetterScanDB_Mortabet)
                .WithOptional(e => e.Automation_Letter_Mortabet)
                .HasForeignKey(e => e.Letter_Mortabet);
            modelBuilder.Entity<Automation_Letter>()
               .Property(e => e.Letter_Comment)
               .IsFixedLength();

            modelBuilder.Entity<Automation_Letter>()
                .HasMany(e => e.Atomation_Girande)
                .WithOptional(e => e.Automation_Letter)
                .HasForeignKey(e => e.Girande_Letter);

            modelBuilder.Entity<Automation_Letter>()
                .HasMany(e => e.Automation_Refer)
                .WithOptional(e => e.Automation_Letter)
                .HasForeignKey(e => e.Refer_letter);

            modelBuilder.Entity<Automation_LetterType>()
                .HasMany(e => e.Automation_Letter)
                .WithOptional(e => e.Automation_LetterType)
                .HasForeignKey(e => e.Letter_Type);



            modelBuilder.Entity<T_User>()
                .HasMany(e => e.Atomation_Girande)
                .WithOptional(e => e.T_User)
                .HasForeignKey(e => e.Girande_User);
            modelBuilder.Entity<T_User>()
               .HasMany(e => e.Automation_Letter2)
               .WithOptional(e => e.T_User_TaeidKonande)
               .HasForeignKey(e => e.Letter_TaeidKonande);
            modelBuilder.Entity<T_User>()
                .HasMany(e => e.Automation_Letter)
                .WithOptional(e => e.T_User_Ferestandeh)
                .HasForeignKey(e => e.Letter_Ferestandeh);

            modelBuilder.Entity<T_User>()
                .HasMany(e => e.Automation_Letter1)
                .WithOptional(e => e.T_User_Gyrandeh)
                .HasForeignKey(e => e.Letter_Gyrandeh);

            modelBuilder.Entity<T_User>()
                .HasMany(e => e.Automation_Refer)
                .WithOptional(e => e.T_User_ErjaDahande)
                .HasForeignKey(e => e.Refer_ErjaDahande);

            modelBuilder.Entity<T_User>()
                .HasMany(e => e.Automation_Refer1)
                .WithOptional(e => e.T_UserErjaGirandeh)
                .HasForeignKey(e => e.Refer_ErjaGirande);
            //
            modelBuilder.Entity<T_ScanType>()
                 .HasMany(e => e.ScanDB)
                 .WithOptional(e => e.T_ScanType)
                 .HasForeignKey(e => e.Scan_ScanType);
            modelBuilder.Entity<CityCode>()
                .HasMany(e => e.T_OzvCode)
                .WithOptional(e => e.CityCode)
                .HasForeignKey(e => e.OzvCode_TavalodCity);

            modelBuilder.Entity<CityCode>()
                .HasMany(e => e.T_OzvCode1)
                .WithOptional(e => e.CityCode1)
                .HasForeignKey(e => e.OzvCode_ShCity);


            modelBuilder.Entity<Nahveh_P>()
                .HasMany(e => e.G_M_Pays)
                .WithOptional(e => e.Nahveh_P1)
                .HasForeignKey(e => e.Nahveh_P);
            modelBuilder.Entity<Nahveh_P>()
              .HasMany(e => e.G_M_Payswait)
              .WithOptional(e => e.Nahveh_P1)
              .HasForeignKey(e => e.Nahveh_P);
            modelBuilder.Entity<Nahveh_PTasvie>()
                .HasMany(e => e.Tasviehs)
                .WithOptional(e => e.Nahveh_PTasvie)
                .HasForeignKey(e => e.Nahveh_P);



            modelBuilder.Entity<T_Jensiat>()
                .Property(e => e.Jensiat)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<T_Jensiat>()
                .HasMany(e => e.T_OzvCode)
                .WithOptional(e => e.T_Jensiat)
                .HasForeignKey(e => e.OzvCode_Jensiat);

            modelBuilder.Entity<T_OzvCode>()
                .Property(e => e.SeriSh)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<T_OzvCode>()
                .Property(e => e.SerialSh)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<T_OzvCode>()
                .HasMany(e => e.T_MostamaryMablagh)
                .WithOptional(e => e.T_OzvCode)
                .HasForeignKey(e => e.MostamaryMablagh_IdRefOzvCode);

            modelBuilder.Entity<T_OzvCode>()
                .HasMany(e => e.G_M_Pays)
                .WithOptional(e => e.T_OzvCode)
                .HasForeignKey(e => e.IdRefOzv);
            modelBuilder.Entity<T_OzvCode>()
             .HasMany(e => e.G_M_Payswait)
             .WithOptional(e => e.T_OzvCode)
             .HasForeignKey(e => e.IdRefOzv);
            modelBuilder.Entity<T_OzvCode>()
                .HasMany(e => e.Tasviehs)
                .WithOptional(e => e.T_OzvCode)
                .HasForeignKey(e => e.IdRefOzv);

            modelBuilder.Entity<T_OzvCode>()
                .HasMany(e => e.VamZamen)
                .WithOptional(e => e.T_OzvCode)
                .HasForeignKey(e => e.IdOzvRef);
            modelBuilder.Entity<T_OzvCode>()
            .HasMany(e => e.Vams)
            .WithOptional(e => e.T_OzvCode)
            .HasForeignKey(e => e.IdRefOzv);

            modelBuilder.Entity<T_User>()
                .HasMany(e => e.T_MostamaryMablagh)
                .WithOptional(e => e.T_User)
                .HasForeignKey(e => e.MostamaryMablagh_ModifiedUser);

            modelBuilder.Entity<T_User>()
                .HasMany(e => e.T_OzvCode)
                .WithOptional(e => e.T_User)
                .HasForeignKey(e => e.ModifiedUser);

            modelBuilder.Entity<T_VamCode>()
                .HasMany(e => e.Vams)
                .WithOptional(e => e.T_VamCode)
                .HasForeignKey(e => e.IdRefNoeVam);

            modelBuilder.Entity<T_OzvCode>()
               .HasMany(e => e.VamNobats)
               .WithOptional(e => e.T_OzvCode)
               .HasForeignKey(e => e.IdRefOzv);
            modelBuilder.Entity<T_VamCode>()
                .HasMany(e => e.VamNobats)
                .WithOptional(e => e.T_VamCode)
                .HasForeignKey(e => e.IdRefNoeVam);

            modelBuilder.Entity<Taahol>()
                .Property(e => e.Taahol_Name)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<Taahol>()
                .HasMany(e => e.T_OzvCode)
                .WithOptional(e => e.Taahol)
                .HasForeignKey(e => e.ozvcode_Taahol);

            modelBuilder.Entity<Vam>()
                .HasMany(e => e.G_M_Pays)
                .WithOptional(e => e.Vam)
                .HasForeignKey(e => e.IdRefVam);
            modelBuilder.Entity<Vam>()
              .HasMany(e => e.G_M_Payswait)
              .WithOptional(e => e.Vam)
              .HasForeignKey(e => e.IdRefVam);

            modelBuilder.Entity<Vam>()
                .HasMany(e => e.VamNobats)
                .WithOptional(e => e.Vam)
                .HasForeignKey(e => e.IdRefVam);

            modelBuilder.Entity<Vam>()
                .HasMany(e => e.VamZamen)
                .WithOptional(e => e.Vam)
                .HasForeignKey(e => e.IdVamRef);

            modelBuilder.Entity<Acc_Group_F>()
                      .HasMany(e => e.Acc_Kol)
                      .WithRequired(e => e.Acc_Group_F)
                      .HasForeignKey(e => e.Code_Group)
                      .WillCascadeOnDelete(false);

            modelBuilder.Entity<Acc_Kol>()
                .HasMany(e => e.Acc_Moein)
                .WithOptional(e => e.Acc_Kol)
                .HasForeignKey(e => e.Moein_KolId);



            modelBuilder.Entity<T_OzvCode>()
              .HasMany(e => e.User)
              .WithOptional(e => e.OzvCode)
              .HasForeignKey(e => e.User_OzvCdoe);

            /* modelBuilder.Entity<Acc_Moein>()
                 .HasMany(e => e.Acc_Tafsil1)
                 .WithOptional(e => e.Acc_Moein)
                 .HasForeignKey(e => e.Tafsil1_Moein);*/
            modelBuilder.Entity<T_Mahiat>()
                          .HasMany(e => e.Acc_Tafsili2)
                          .WithOptional(e => e.T_Mahiat)
                          .HasForeignKey(e => e.Tafsili2_Mahiat);
            modelBuilder.Entity<Acc_Tafsil1>()
                .HasMany(e => e.Acc_Tafsili2)
                .WithOptional(e => e.Acc_Tafsil1)
                .HasForeignKey(e => e.Tafsili2_Tafsili1);

            modelBuilder.Entity<Acc_Tafsil1>()
                .HasMany(e => e.AccSanad_B)
                .WithOptional(e => e.Acc_Tafsil1)
                .HasForeignKey(e => e.Sanad_Tafsili1);

            modelBuilder.Entity<T_AccountType>()
                .HasMany(e => e.Acc_Group_F)
                .WithRequired(e => e.T_AccountType)
                .HasForeignKey(e => e.NoHesab)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<T_Mahiat>()
                .HasMany(e => e.Acc_Kol)
                .WithOptional(e => e.T_Mahiat)
                .HasForeignKey(e => e.Mahiat);
            modelBuilder.Entity<T_Mahiat>()
           .HasMany(e => e.Acc_Moein)
           .WithOptional(e => e.T_Mahiat)
           .HasForeignKey(e => e.Mahiat);

            modelBuilder.Entity<T_OzvCode>()
             .HasMany(e => e.ScanDBs)
             .WithOptional(e => e.T_OzvCode)
             .HasForeignKey(e => e.IdRef);

            modelBuilder.Entity<T_User>()
                .HasMany(e => e.ScanDB)
                .WithOptional(e => e.T_User)
                .HasForeignKey(e => e.SendedUser);


        }
    }
}

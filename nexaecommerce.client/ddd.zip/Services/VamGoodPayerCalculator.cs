using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using MVCSandoogh.Models;

namespace MVCSandoogh.Services
{
    /// <summary>
    /// خروجی ارزیابی خوش‌حسابی. این محاسبه مستقل از امتیاز منفی ورود به نوبت وام است.
    /// </summary>
    public sealed class GoodPayerAssessment
    {
        public int InstallmentNegativeScore { get; set; }
        public bool HasSettledLoan { get; set; }
        public int PensionNegativeScore { get; set; }

        public int TotalNegativeScore { get; set; }

        public int DelayedInstallments { get; set; }

        public int DelayedPensionMonths { get; set; }

        public decimal FeePercent { get; set; }

        public bool IsGoodPayer { get; set; }

        public int N { get; set; }

        public int M { get; set; }
    }
    /// <summary>
    /// قاعده مشترک تشخیص تسویه قسط با در نظر گرفتن تلورانس.
    /// مبالغ بر اساس ریال هستند.
    /// </summary>
    public static class VamInstallmentPaymentRules
    {
        // سقف تلورانس: ۱۰۰ هزار تومان
        public const decimal MaxInstallmentTolerance = 1000000m;

        // تلورانس نسبی: ۱۰ درصد مبلغ قسط
        public const decimal InstallmentToleranceRatio = 0.1m;

        /// <summary>
        /// بررسی می‌کند آیا مبلغ پرداخت‌شده با احتساب تلورانس
        /// برای تسویه قسط کافی است یا خیر.
        /// </summary>
        public static bool IsSettled(
            decimal installmentAmount,
            decimal paidAmount)
        {
            if (installmentAmount <= 0m || paidAmount <= 0m)
                return false;

            if (paidAmount >= installmentAmount)
                return true;

            decimal shortfall =
                installmentAmount - paidAmount;

            decimal effectiveTolerance = Math.Min(
                MaxInstallmentTolerance,
                installmentAmount * InstallmentToleranceRatio
            );

            return shortfall > 0m &&
                   shortfall <= effectiveTolerance;
        }
    }
    /// <summary>
    /// محاسبه تعداد موارد تأخیر برای تعیین درصد کارمزد.
    /// توجه: این کلاس CalculateMostamariNegativeScore و CalculateVamNegativeScore
    /// را صدا نمی‌زند و در امتیاز منفی ورود به نوبت دخالتی ندارد.
    /// </summary>
    public static class VamGoodPayerCalculator
    {
        private sealed class Obligation
        {
            public DateTime DueDate { get; set; }
            public decimal Amount { get; set; }
            public decimal PaidAmount { get; set; }
            public DateTime? PaidDate { get; set; }
        }
        private sealed class DelayScoreResult
        {
            public int DelayedMonths { get; set; }

            public int NegativeScore { get; set; }
        }


        private static int CalculateTwoMonthDelayScore(
            DateTime dueDate,
            DateTime? fullPaidDate,
            DateTime today)
        {
            DateTime effectiveDate =
                (fullPaidDate ?? today).Date;

            dueDate = dueDate.Date;

            if (effectiveDate <= dueDate)
                return 0;

            PersianCalendar pc = new PersianCalendar();

            int negativeScore = 0;

            // اولین امتیاز: دو ماه و یک روز پس از سررسید
            // امتیاز بعدی: چهار ماه و یک روز
            // امتیاز بعدی: شش ماه و یک روز و ...
            for (int period = 1; period <= 600; period++)
            {
                DateTime thresholdDate =
                    pc.AddMonths(dueDate, period * 2)
                      .Date
                      .AddDays(1);

                if (effectiveDate < thresholdDate)
                    break;

                negativeScore++;
            }

            return -negativeScore;
        }

        private static DelayScoreResult CalculateDelayScore(
            List<Obligation> obligations,
            DateTime asOfDate)
        {
            int delayedCount = 0;
            int totalNegativeScore = 0;

            DateTime? rangeStart = null;
            DateTime? rangeEndPaidDate = null;

            foreach (var item in obligations)
            {
                bool isLate =
                    item.DueDate.Date < asOfDate.Date &&
                    (
                        item.PaidAmount < item.Amount ||
                        (
                            item.PaidDate.HasValue &&
                            item.PaidDate.Value.Date > item.DueDate.Date
                        )
                    );

                if (isLate)
                {
                    delayedCount++;

                    if (!rangeStart.HasValue)
                        rangeStart = item.DueDate.Date;

                    rangeEndPaidDate = item.PaidDate;
                }
                else if (rangeStart.HasValue)
                {
                    totalNegativeScore += CalculateTwoMonthDelayScore(
                        rangeStart.Value,
                        rangeEndPaidDate,
                        asOfDate
                    );

                    rangeStart = null;
                    rangeEndPaidDate = null;
                }
            }

            // محاسبه آخرین بازه‌ای که هنوز ادامه دارد.
            if (rangeStart.HasValue)
            {
                totalNegativeScore += CalculateTwoMonthDelayScore(
                    rangeStart.Value,
                    rangeEndPaidDate,
                    asOfDate
                );
            }

            return new DelayScoreResult
            {
                DelayedMonths = delayedCount,
                NegativeScore = totalNegativeScore
            };
        }


        public static GoodPayerAssessment Evaluate(
            int memberId,
            SandooghModel db,
            DateTime asOfDate)
        {
            if (db == null)
                throw new ArgumentNullException("db");

            asOfDate = asOfDate.Date;

            var member = db.T_OzvCode
                .FirstOrDefault(x => x.Id == memberId);

            if (member == null)
            {
                throw new InvalidOperationException(
                    "عضو مورد نظر یافت نشد."
                );
            }

            var policy = db.VamPolicySettings
                .FirstOrDefault(x => x.Id == 1);

            var lastSettledLoan = db.Vams
                .Where(x =>
                    x.IdRefOzv == memberId &&
                    x.EtmamVam == true)
                .OrderByDescending(x => x.VamDate)
                .ThenByDescending(x => x.Vam_Id)
                .FirstOrDefault();

            var installmentPayments =
                new List<G_M_Pays>();

            var pensionPayments =
                new List<G_M_Pays>();

            var baseChanges =
                new List<T_MostamaryMablagh>();

            var minimumSettings =
                new List<MinimumPensionSetting>();

            if (lastSettledLoan != null)
            {
                DateTime endOfDay =
                    asOfDate.AddDays(1).AddTicks(-1);

                // پرداخت‌های اقساط آخرین وام
                if (lastSettledLoan.AvlinGestDate.HasValue &&
                    lastSettledLoan.TedadAgsat.HasValue &&
                    lastSettledLoan.TedadAgsat.Value > 0 &&
                    lastSettledLoan.GestMablag.HasValue &&
                    lastSettledLoan.GestMablag.Value > 0)
                {
                    installmentPayments = db.G_M_Pays
                        .Where(x =>
                            x.IdRefVam == lastSettledLoan.Vam_Id &&
                            x.TotGestMablag > 0 &&
                            x.PayDate.HasValue &&
                            x.PayDate <= endOfDay)
                        .OrderBy(x => x.PayDate)
                        .ThenBy(x => x.Id)
                        .ToList();
                }

                // شروع محاسبه مستمری
                DateTime pensionStartDate =
                    lastSettledLoan.VamDate ??
                    lastSettledLoan.AvlinGestDate ??
                    member.OzvDate;

                if (pensionStartDate.Date <= asOfDate.Date)
                {
                    PersianCalendar pc = new PersianCalendar();

                    DateTime firstMonthStart =
                        GetNextPersianMonthStart(
                            pensionStartDate,
                            pc
                        );

                    DateTime currentMonthStart =
                        GetPersianMonthStart(
                            asOfDate,
                            pc
                        );

                    if (firstMonthStart <= currentMonthStart)
                    {
                        minimumSettings = db.MinimumPensionSettings
                            .Where(x =>
                                x.EffectiveFrom <= asOfDate)
                            .OrderBy(x => x.EffectiveFrom)
                            .ToList();

                        baseChanges = db.T_MostamaryMablagh
                            .Where(x =>
                                x.MostamaryMablagh_IdRefOzvCode == member.Id &&
                                x.MostamaryMablagh_DateStart.HasValue)
                            .OrderBy(x =>
                                x.MostamaryMablagh_DateStart)
                            .ToList();

                        pensionPayments = db.G_M_Pays
                            .Where(x =>
                                x.IdRefOzv == member.Id &&
                                x.MostamariMablag > 0 &&
                                (x.IsAfzayesh == null ||
                                 x.IsAfzayesh != true) &&
                                x.PayDate.HasValue &&
                                x.PayDate >= firstMonthStart &&
                                x.PayDate <= endOfDay)
                            .OrderBy(x => x.PayDate)
                            .ThenBy(x => x.Id)
                            .ToList();
                    }
                }
            }

            return EvaluatePrepared(
                member,
                lastSettledLoan,
                policy,
                installmentPayments,
                baseChanges,
                pensionPayments,
                minimumSettings,
                asOfDate
            );
        }

        internal static GoodPayerAssessment EvaluatePrepared(
            T_OzvCode member,
            Vam lastSettledLoan,
            VamPolicySetting policy,
            IList<G_M_Pays> installmentPayments,
            IList<T_MostamaryMablagh> baseChanges,
            IList<G_M_Pays> pensionPayments,
            IList<MinimumPensionSetting> minimumSettings,
            DateTime asOfDate)
        {
            if (member == null)
                throw new ArgumentNullException("member");

            decimal goodFee = policy == null
                ? 3m
                : policy.K_GoodPayerFeePercent;

            decimal normalFee = policy == null
                ? 5m
                : policy.J_OtherPayerFeePercent;

            int installmentThreshold = policy == null
                ? 3
                : policy.N_DelayedInstallments;

            int pensionThreshold = policy == null
                ? 3
                : policy.M_DelayedPensions;

            if (goodFee < 0m || goodFee > 100m ||
                normalFee < 0m || normalFee > 100m)
            {
                throw new InvalidOperationException(
                    "درصدهای کارمزد در تنظیمات معتبر نیستند."
                );
            }

            if (installmentThreshold < 1 ||
                installmentThreshold > 120 ||
                pensionThreshold < 1 ||
                pensionThreshold > 120)
            {
                throw new InvalidOperationException(
                    "آستانه‌های خوش‌حسابی اقساط و مستمری معتبر نیستند."
                );
            }

            // عضو بدون وام تسویه‌شده، خوش‌حساب محسوب نمی‌شود.
            if (lastSettledLoan == null)
            {
                return new GoodPayerAssessment
                {
                    InstallmentNegativeScore = 0,
                    PensionNegativeScore = 0,
                    TotalNegativeScore = 0,
                    HasSettledLoan = false,
                    DelayedInstallments = 0,
                    DelayedPensionMonths = 0,
                    IsGoodPayer = false,
                    FeePercent = normalFee,
                    N = installmentThreshold,
                    M = pensionThreshold
                };
            }

            var installmentResult =
                CalculateInstallmentScore(
                    lastSettledLoan,
                    installmentPayments,
                    asOfDate.Date
                );

            var pensionResult =
                CalculatePensionScore(
                    member,
                    lastSettledLoan,
                    baseChanges,
                    pensionPayments,
                    minimumSettings,
                    asOfDate.Date
                );

            int installmentScore =
                installmentResult.NegativeScore;

            int pensionScore =
                pensionResult.NegativeScore;

            // اقساط و مستمری مستقل ارزیابی می‌شوند.
            // جمع امتیازها ملاک تشخیص بدحسابی نیست.
            bool isGood =
                installmentScore > -installmentThreshold &&
                pensionScore > -pensionThreshold;

            return new GoodPayerAssessment
            {
                InstallmentNegativeScore = installmentScore,
                HasSettledLoan = true,
                PensionNegativeScore = pensionScore,

                TotalNegativeScore =
                    installmentScore + pensionScore,

                DelayedInstallments =
                    installmentResult.DelayedMonths,

                DelayedPensionMonths =
                    pensionResult.DelayedMonths,

                IsGoodPayer = isGood,

                FeePercent = isGood
                    ? goodFee
                    : normalFee,

                N = installmentThreshold,
                M = pensionThreshold
            };
        }


        private static DelayScoreResult CalculateInstallmentScore(
      Vam loan,
      IEnumerable<G_M_Pays> paymentsSource,
      DateTime asOfDate)
        {
            if (loan == null ||
                !loan.AvlinGestDate.HasValue ||
                !loan.TedadAgsat.HasValue ||
                loan.TedadAgsat.Value <= 0 ||
                !loan.GestMablag.HasValue ||
                loan.GestMablag.Value <= 0)
            {
                return new DelayScoreResult();
            }

            DateTime firstDueDate =
                loan.AvlinGestDate.Value.Date;

            int installmentCount =
                loan.TedadAgsat.Value;

            decimal installmentAmount =
                Convert.ToDecimal(loan.GestMablag.Value);

            PersianCalendar pc = new PersianCalendar();

            var installments = new List<Obligation>();

            // ساخت برنامه اقساط
            for (int i = 0; i < installmentCount; i++)
            {
                installments.Add(new Obligation
                {
                    DueDate = pc.AddMonths(firstDueDate, i).Date,
                    Amount = installmentAmount,
                    PaidAmount = 0m,
                    PaidDate = null
                });
            }

            DateTime endOfDay =
                asOfDate.Date.AddDays(1).AddTicks(-1);

            // پرداخت‌های آخرین وام تسویه‌شده
            var payments = (paymentsSource ?? Enumerable.Empty<G_M_Pays>())
       .Where(x =>
           x.IdRefVam == loan.Vam_Id &&
           x.TotGestMablag > 0 &&
           x.PayDate.HasValue &&
           x.PayDate <= endOfDay)
       .OrderBy(x => x.PayDate)
       .ThenBy(x => x.Id)
       .ToList();

            // تخصیص پرداخت‌ها به قدیمی‌ترین قسط تسویه‌نشده
            // با حرکت پیوسته روی فهرست اقساط

            int installmentIndex = 0;

            foreach (var payment in payments)
            {
                decimal remaining =
                    Convert.ToDecimal(payment.TotGestMablag.Value);

                if (remaining <= 0m)
                    continue;

                while (
                    remaining > 0m &&
                    installmentIndex < installments.Count)
                {
                    var installment =
                        installments[installmentIndex];

                    decimal need =
                        installment.Amount -
                        installment.PaidAmount;

                    if (need <= 0m)
                    {
                        installmentIndex++;
                        continue;
                    }

                    decimal applied =
                        Math.Min(remaining, need);

                    installment.PaidAmount += applied;

                    remaining -= applied;

                    // بررسی تسویه با همان قاعده تلورانس قبلی
                    if (VamInstallmentPaymentRules.IsSettled(
                        installment.Amount,
                        installment.PaidAmount))
                    {
                        installment.PaidAmount =
                            installment.Amount;

                        if (!installment.PaidDate.HasValue)
                        {
                            installment.PaidDate =
                                payment.PayDate.Value.Date;
                        }

                        // رفتن به قسط بعدی
                        installmentIndex++;
                    }
                }
            }

            return CalculateDelayScore(
                installments,
                asOfDate
            );
        }
        private static DelayScoreResult CalculatePensionScore(
      T_OzvCode member,
      Vam lastSettledLoan,
      IEnumerable<T_MostamaryMablagh> baseChangesSource,
      IEnumerable<G_M_Pays> paymentsSource,
      IEnumerable<MinimumPensionSetting> minimumSettingsSource,
      DateTime asOfDate)
        {
            if (member == null || lastSettledLoan == null)
                return new DelayScoreResult();

            // شروع محاسبه از تاریخ آخرین وام تسویه‌شده
            DateTime startDate =
                lastSettledLoan.VamDate ??
                lastSettledLoan.AvlinGestDate ??
                member.OzvDate;

            if (startDate.Date > asOfDate.Date)
                return new DelayScoreResult();

            PersianCalendar pc = new PersianCalendar();

            // شروع بررسی از ماه بعد از تاریخ آخرین وام
            DateTime firstMonthStart =
                GetNextPersianMonthStart(startDate, pc);

            DateTime currentMonthStart =
                GetPersianMonthStart(asOfDate, pc);

            var minimumSettings =
     (minimumSettingsSource ??
      Enumerable.Empty<MinimumPensionSetting>())
     .Where(x => x.EffectiveFrom <= asOfDate)
     .OrderByDescending(x => x.EffectiveFrom)
     .ToList();

            var baseChanges =
                (baseChangesSource ??
                 Enumerable.Empty<T_MostamaryMablagh>())
                .Where(x =>
                    x.MostamaryMablagh_IdRefOzvCode == member.Id &&
                    x.MostamaryMablagh_DateStart.HasValue)
                .OrderByDescending(x =>
                    x.MostamaryMablagh_DateStart)
                .ToList();

            var obligations = new List<Obligation>();

            DateTime monthStart = firstMonthStart;

            while (monthStart <= currentMonthStart)
            {
                DateTime nextMonthStart =
                    GetNextPersianMonthStart(monthStart, pc);

                // موعد مستمری، پایان ماه شمسی است.
                DateTime dueDate =
                    nextMonthStart.AddDays(-1).Date;

                decimal expected =
      MVCSandoogh.VamPolicyHelper.GetDefaultMinimumPension(
          monthStart
      );

                var minimum = minimumSettings
      .FirstOrDefault(x =>
          x.EffectiveFrom.Date <= monthStart.Date &&
          (!x.EffectiveTo.HasValue ||
           x.EffectiveTo.Value.Date >= monthStart.Date));

                if (minimum != null)
                {
                    expected =
                        Convert.ToDecimal(minimum.MinimumAmount);
                }

                var baseForMonth = baseChanges
      .FirstOrDefault(x =>
          x.MostamaryMablagh_DateStart.Value.Date
          <= monthStart.Date);
                if (baseForMonth != null &&
                    baseForMonth.MostamaryMablagh_Mablagh.HasValue)
                {
                    expected = Math.Max(
                        expected,
                        Convert.ToDecimal(
                            baseForMonth.MostamaryMablagh_Mablagh.Value
                        )
                    );
                }

                if (expected > 0m)
                {
                    obligations.Add(new Obligation
                    {
                        DueDate = dueDate,
                        Amount = expected,
                        PaidAmount = 0m,
                        PaidDate = null
                    });
                }

                monthStart = nextMonthStart;
            }

            if (obligations.Count == 0)
                return new DelayScoreResult();

            DateTime endOfDay =
                asOfDate.Date.AddDays(1).AddTicks(-1);

            // نکته مهم:
            // پرداخت‌ها باید از ابتدای بازه محاسبه خوانده شوند.
            // استفاده از monthStart پس از حلقه، پرداخت‌های قبلی را حذف می‌کرد.
            var payments =
     (paymentsSource ?? Enumerable.Empty<G_M_Pays>())
     .Where(x =>
         x.IdRefOzv == member.Id &&
         x.MostamariMablag > 0 &&
         (x.IsAfzayesh == null ||
          x.IsAfzayesh != true) &&
         x.PayDate.HasValue &&
         x.PayDate >= firstMonthStart &&
         x.PayDate <= endOfDay)
     .OrderBy(x => x.PayDate)
     .ThenBy(x => x.Id)
     .ToList();

            // تخصیص پرداخت‌ها به قدیمی‌ترین ماه تسویه‌نشده
            // با حرکت پیوسته روی تعهدات

            int obligationIndex = 0;

            foreach (var payment in payments)
            {
                decimal remaining =
                    Convert.ToDecimal(payment.MostamariMablag.Value);

                if (remaining <= 0m)
                    continue;

                while (
                    remaining > 0m &&
                    obligationIndex < obligations.Count)
                {
                    var obligation =
                        obligations[obligationIndex];

                    decimal need =
                        obligation.Amount -
                        obligation.PaidAmount;

                    if (need <= 0m)
                    {
                        obligationIndex++;
                        continue;
                    }

                    decimal applied =
                        Math.Min(remaining, need);

                    obligation.PaidAmount += applied;

                    remaining -= applied;

                    if (obligation.PaidAmount >= obligation.Amount &&
                        !obligation.PaidDate.HasValue)
                    {
                        obligation.PaidDate =
                            payment.PayDate.Value.Date;
                    }

                    if (obligation.PaidAmount >= obligation.Amount)
                    {
                        obligationIndex++;
                    }
                }
            }
            return CalculateDelayScore(
                obligations,
                asOfDate
            );
        }
        internal static DateTime GetPersianMonthStart(
     DateTime date,
     PersianCalendar pc)
        {
            return pc.ToDateTime(pc.GetYear(date), pc.GetMonth(date), 1, 0, 0, 0, 0);
        }

        internal static DateTime GetNextPersianMonthStart(
     DateTime monthStart,
     PersianCalendar pc)
        {
            int year = pc.GetYear(monthStart);
            int month = pc.GetMonth(monthStart) + 1;
            if (month > 12) { month = 1; year++; }
            return pc.ToDateTime(year, month, 1, 0, 0, 0, 0);
        }
    }
}

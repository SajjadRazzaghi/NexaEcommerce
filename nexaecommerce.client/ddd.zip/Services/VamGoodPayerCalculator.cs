using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using MVCSandoogh.Models;

namespace MVCSandoogh.Services
{
    /// <summary>
    /// خروجی ارزیابی خوش‌حسابی. این محاسبه مستقل از امتیاز منفی ورود به نوبت وام است.
    /// </summary>
    public sealed class GoodPayerAssessment
    {
        public int InstallmentNegativeScore { get; set; }

        public int PensionNegativeScore { get; set; }

        public int TotalNegativeScore { get; set; }

        public int DelayedInstallments { get; set; }

        public int DelayedPensionMonths { get; set; }

        public decimal FeePercent { get; set; }

        public bool IsGoodPayer { get; set; }

        public int N { get; set; }

        public int M { get; set; }
    }

    /// <summary>
    /// محاسبه تعداد موارد تأخیر برای تعیین درصد کارمزد.
    /// توجه: این کلاس CalculateMostamariNegativeScore و CalculateVamNegativeScore
    /// را صدا نمی‌زند و در امتیاز منفی ورود به نوبت دخالتی ندارد.
    /// </summary>
    public static class VamGoodPayerCalculator
    {
        private sealed class Obligation
        {
            public DateTime DueDate { get; set; }
            public decimal Amount { get; set; }
            public decimal PaidAmount { get; set; }
            public DateTime? PaidDate { get; set; }
        }
        private sealed class DelayScoreResult
        {
            public int DelayedMonths { get; set; }

            public int NegativeScore { get; set; }
        }
        private static int CalculateTwoMonthDelayScore(
      DateTime dueDate,
      DateTime? fullPaidDate,
      DateTime today)
        {
            DateTime effectiveDate =
                (fullPaidDate ?? today).Date;

            dueDate = dueDate.Date;

            if (effectiveDate <= dueDate)
                return 0;

            int delayMonths =
                (effectiveDate.Year - dueDate.Year) * 12 +
                (effectiveDate.Month - dueDate.Month);

            if (effectiveDate.Day <= dueDate.Day)
                delayMonths--;

            // تا دو ماه کامل، جریمه‌ای وجود ندارد.
            if (delayMonths < 2)
                return 0;

            // هر دو ماه تأخیر، یک امتیاز منفی.
            return -(delayMonths / 2);
        }
        private static DelayScoreResult CalculateDelayScore(
            List<Obligation> obligations,
            DateTime asOfDate)
        {
            int delayedCount = 0;
            int totalNegativeScore = 0;

            DateTime? rangeStart = null;
            DateTime? rangeEndPaidDate = null;

            foreach (var item in obligations.OrderBy(x => x.DueDate))
            {
                bool isLate =
                    item.DueDate.Date < asOfDate.Date &&
                    (
                        item.PaidAmount < item.Amount ||
                        (
                            item.PaidDate.HasValue &&
                            item.PaidDate.Value.Date > item.DueDate.Date
                        )
                    );

                if (isLate)
                {
                    delayedCount++;

                    if (!rangeStart.HasValue)
                        rangeStart = item.DueDate.Date;

                    rangeEndPaidDate = item.PaidDate;
                }
                else if (rangeStart.HasValue)
                {
                    totalNegativeScore += CalculateTwoMonthDelayScore(
                        rangeStart.Value,
                        rangeEndPaidDate,
                        asOfDate
                    );

                    rangeStart = null;
                    rangeEndPaidDate = null;
                }
            }

            // محاسبه آخرین بازه‌ای که هنوز ادامه دارد.
            if (rangeStart.HasValue)
            {
                totalNegativeScore += CalculateTwoMonthDelayScore(
                    rangeStart.Value,
                    rangeEndPaidDate,
                    asOfDate
                );
            }

            return new DelayScoreResult
            {
                DelayedMonths = delayedCount,
                NegativeScore = totalNegativeScore
            };
        }
        public static GoodPayerAssessment Evaluate(
       int memberId,
       SandooghModel db,
       DateTime asOfDate)
        {
            if (db == null)
                throw new ArgumentNullException("db");

            var member = db.T_OzvCode
                .FirstOrDefault(x => x.Id == memberId);

            if (member == null)
                throw new InvalidOperationException(
                    "عضو مورد نظر یافت نشد."
                );

            var policy = db.VamPolicySettings
                .FirstOrDefault(x => x.Id == 1);

            decimal goodFee = policy == null
                ? 3m
                : policy.K_GoodPayerFeePercent;

            decimal normalFee = policy == null
                ? 5m
                : policy.J_OtherPayerFeePercent;

            if (goodFee < 0m || goodFee > 100m ||
                normalFee < 0m || normalFee > 100m)
            {
                throw new InvalidOperationException(
                    "درصدهای کارمزد در تنظیمات معتبر نیستند."
                );
            }

            // فقط آخرین وام تسویه‌شده مبنای ارزیابی است.
            var lastSettledLoan = db.Vams
                .Where(x =>
                    x.IdRefOzv == memberId &&
                    x.EtmamVam == true)
                .OrderByDescending(x => x.VamDate)
                .ThenByDescending(x => x.Vam_Id)
                .FirstOrDefault();

            // عضو بدون سابقه وام تسویه‌شده، بدحساب محسوب نمی‌شود.
            if (lastSettledLoan == null)
            {
                return new GoodPayerAssessment
                {
                    InstallmentNegativeScore = 0,
                    PensionNegativeScore = 0,
                    TotalNegativeScore = 0,

                    DelayedInstallments = 0,
                    DelayedPensionMonths = 0,

                    IsGoodPayer = true,
                    FeePercent = goodFee,

                    N = 3,
                    M = 3
                };
            }

            // امتیاز تأخیر اقساط آخرین وام تسویه‌شده
            var installmentResult = CalculateInstallmentScore(
                lastSettledLoan,
                db,
                asOfDate.Date
            );

            // امتیاز تأخیر مستمری در بازه مربوط به همان وام
            var pensionResult = CalculatePensionScore(
                member,
                lastSettledLoan,
                db,
                asOfDate.Date
            );

            int installmentScore =
                installmentResult.NegativeScore;

            int pensionScore =
                pensionResult.NegativeScore;

            // قسط و مستمری مستقل ارزیابی می‌شوند.
            // جمع دو امتیاز، معیار تشخیص بدحسابی نیست.
            bool isGood =
                installmentScore > -3 &&
                pensionScore > -3;

            return new GoodPayerAssessment
            {
                InstallmentNegativeScore = installmentScore,

                PensionNegativeScore = pensionScore,

                TotalNegativeScore =
                    installmentScore + pensionScore,

                DelayedInstallments =
                    installmentResult.DelayedMonths,

                DelayedPensionMonths =
                    pensionResult.DelayedMonths,

                IsGoodPayer = isGood,

                FeePercent = isGood
                    ? goodFee
                    : normalFee,

                N = 3,
                M = 3
            };
        }
        private static DelayScoreResult CalculateInstallmentScore(
        Vam loan,
        SandooghModel db,
        DateTime asOfDate)
        {
            if (loan == null ||
                !loan.AvlinGestDate.HasValue ||
                !loan.TedadAgsat.HasValue ||
                loan.TedadAgsat.Value <= 0 ||
                !loan.GestMablag.HasValue ||
                loan.GestMablag.Value <= 0)
            {
                return new DelayScoreResult();
            }

            DateTime firstDueDate =
                loan.AvlinGestDate.Value.Date;

            int installmentCount =
                loan.TedadAgsat.Value;

            decimal installmentAmount =
                Convert.ToDecimal(loan.GestMablag.Value);

            PersianCalendar pc = new PersianCalendar();

            var installments = new List<Obligation>();

            // ساخت برنامه اقساط
            for (int i = 0; i < installmentCount; i++)
            {
                installments.Add(new Obligation
                {
                    DueDate = pc.AddMonths(firstDueDate, i).Date,
                    Amount = installmentAmount,
                    PaidAmount = 0m,
                    PaidDate = null
                });
            }

            DateTime endOfDay =
                asOfDate.Date.AddDays(1).AddTicks(-1);

            // پرداخت‌های آخرین وام تسویه‌شده
            var payments = db.G_M_Pays
                .Where(x =>
                    x.IdRefVam == loan.Vam_Id &&
                    x.TotGestMablag > 0 &&
                    x.PayDate.HasValue &&
                    x.PayDate <= endOfDay)
                .OrderBy(x => x.PayDate)
                .ThenBy(x => x.Id)
                .ToList();

            // تخصیص پرداخت‌ها به قدیمی‌ترین قسط تسویه‌نشده
            foreach (var payment in payments)
            {
                decimal remaining =
                    Convert.ToDecimal(payment.TotGestMablag.Value);

                if (remaining <= 0m)
                    continue;

                foreach (var installment in installments)
                {
                    if (remaining <= 0m)
                        break;

                    decimal need =
                        installment.Amount - installment.PaidAmount;

                    if (need <= 0m)
                        continue;

                    decimal applied =
                        Math.Min(remaining, need);

                    installment.PaidAmount += applied;
                    remaining -= applied;

                    // تاریخ پرداخت کامل قسط
                    if (installment.PaidAmount >= installment.Amount &&
                        !installment.PaidDate.HasValue)
                    {
                        installment.PaidDate =
                            payment.PayDate.Value.Date;
                    }
                }
            }

            return CalculateDelayScore(
                installments,
                asOfDate
            );
        }
        private static DelayScoreResult CalculatePensionScore(
     T_OzvCode member,
     Vam lastSettledLoan,
     SandooghModel db,
     DateTime asOfDate)
        {
            if (member == null || lastSettledLoan == null)
                return new DelayScoreResult();

            // شروع محاسبه از تاریخ آخرین وام تسویه‌شده
            DateTime startDate =
                lastSettledLoan.VamDate ??
                lastSettledLoan.AvlinGestDate ??
                member.OzvDate;

            if (startDate.Date > asOfDate.Date)
                return new DelayScoreResult();

            PersianCalendar pc = new PersianCalendar();

            // شروع بررسی از ماه بعد از تاریخ آخرین وام
            DateTime firstMonthStart =
                GetNextPersianMonthStart(startDate, pc);

            DateTime currentMonthStart =
                GetPersianMonthStart(asOfDate, pc);

            var minimumSettings = db.MinimumPensionSettings
                .Where(x => x.EffectiveFrom <= asOfDate)
                .OrderBy(x => x.EffectiveFrom)
                .ToList();

            var baseChanges = db.T_MostamaryMablagh
                .Where(x =>
                    x.MostamaryMablagh_IdRefOzvCode == member.Id &&
                    x.MostamaryMablagh_DateStart.HasValue)
                .OrderBy(x => x.MostamaryMablagh_DateStart)
                .ToList();

            var obligations = new List<Obligation>();

            DateTime monthStart = firstMonthStart;

            while (monthStart <= currentMonthStart)
            {
                DateTime nextMonthStart =
                    GetNextPersianMonthStart(monthStart, pc);

                // موعد مستمری، پایان ماه شمسی است.
                DateTime dueDate =
                    nextMonthStart.AddDays(-1).Date;

                decimal expected = 500000m;

                var minimum = minimumSettings
                    .Where(x =>
                        x.EffectiveFrom.Date <= monthStart.Date)
                    .OrderByDescending(x => x.EffectiveFrom)
                    .FirstOrDefault();

                if (minimum != null)
                {
                    expected =
                        Convert.ToDecimal(minimum.MinimumAmount);
                }

                var baseForMonth = baseChanges
                    .Where(x =>
                        x.MostamaryMablagh_DateStart.Value.Date
                        <= monthStart.Date)
                    .OrderByDescending(x =>
                        x.MostamaryMablagh_DateStart)
                    .FirstOrDefault();

                if (baseForMonth != null &&
                    baseForMonth.MostamaryMablagh_Mablagh.HasValue)
                {
                    expected = Math.Max(
                        expected,
                        Convert.ToDecimal(
                            baseForMonth.MostamaryMablagh_Mablagh.Value
                        )
                    );
                }

                if (expected > 0m)
                {
                    obligations.Add(new Obligation
                    {
                        DueDate = dueDate,
                        Amount = expected,
                        PaidAmount = 0m,
                        PaidDate = null
                    });
                }

                monthStart = nextMonthStart;
            }

            if (obligations.Count == 0)
                return new DelayScoreResult();

            DateTime endOfDay =
                asOfDate.Date.AddDays(1).AddTicks(-1);

            // نکته مهم:
            // پرداخت‌ها باید از ابتدای بازه محاسبه خوانده شوند.
            // استفاده از monthStart پس از حلقه، پرداخت‌های قبلی را حذف می‌کرد.
            var payments = db.G_M_Pays
                .Where(x =>
                    x.IdRefOzv == member.Id &&
                    x.MostamariMablag > 0 &&
                    (x.IsAfzayesh == null || x.IsAfzayesh != true) &&
                    x.PayDate.HasValue &&
                    x.PayDate >= firstMonthStart &&
                    x.PayDate <= endOfDay)
                .OrderBy(x => x.PayDate)
                .ThenBy(x => x.Id)
                .ToList();

            // تخصیص پرداخت‌ها به قدیمی‌ترین ماه تسویه‌نشده
            foreach (var payment in payments)
            {
                decimal remaining =
                    Convert.ToDecimal(payment.MostamariMablag.Value);

                if (remaining <= 0m)
                    continue;

                foreach (var obligation in obligations)
                {
                    if (remaining <= 0m)
                        break;

                    decimal need =
                        obligation.Amount - obligation.PaidAmount;

                    if (need <= 0m)
                        continue;

                    decimal applied =
                        Math.Min(remaining, need);

                    obligation.PaidAmount += applied;
                    remaining -= applied;

                    if (obligation.PaidAmount >= obligation.Amount &&
                        !obligation.PaidDate.HasValue)
                    {
                        obligation.PaidDate =
                            payment.PayDate.Value.Date;
                    }
                }
            }

            return CalculateDelayScore(
                obligations,
                asOfDate
            );
        }
        private static DateTime GetPersianMonthStart(DateTime date, PersianCalendar pc)
        {
            return pc.ToDateTime(pc.GetYear(date), pc.GetMonth(date), 1, 0, 0, 0, 0);
        }

        private static DateTime GetNextPersianMonthStart(DateTime monthStart, PersianCalendar pc)
        {
            int year = pc.GetYear(monthStart);
            int month = pc.GetMonth(monthStart) + 1;
            if (month > 12) { month = 1; year++; }
            return pc.ToDateTime(year, month, 1, 0, 0, 0, 0);
        }
    }
}

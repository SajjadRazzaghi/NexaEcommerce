using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using MVCSandoogh.Models;

namespace MVCSandoogh.Services
{
    /// <summary>
    /// خروجی ارزیابی خوش‌حسابی. این محاسبه مستقل از امتیاز منفی ورود به نوبت وام است.
    /// </summary>
    public sealed class GoodPayerAssessment
    {
        public int InstallmentNegativeScore { get; set; }

        public bool HasSettledLoan { get; set; }

        public int PensionNegativeScore { get; set; }

        // مجموع فقط برای نمایش است و در تشخیص بدحسابی استفاده نمی‌شود.
        public int TotalNegativeScore { get; set; }

        // تعداد اقساطی که حداقل یک امتیاز منفی گرفته‌اند.
        public int DelayedInstallments { get; set; }

        // تعداد ماه‌های مستمری که حداقل یک امتیاز منفی گرفته‌اند.
        public int DelayedPensionMonths { get; set; }

        public decimal FeePercent { get; set; }

        public bool IsGoodPayer { get; set; }

        // P: فاصله محاسبه امتیاز منفی اقساط
        public int P { get; set; }

        // Q: فاصله محاسبه امتیاز منفی مستمری
        public int Q { get; set; }

        // R: حداکثر امتیاز منفی مجاز اقساط
        public int R { get; set; }

        // T: حداکثر امتیاز منفی مجاز مستمری
        public int T { get; set; }
    }
    /// <summary>
    /// قاعده مشترک تشخیص تسویه قسط با در نظر گرفتن تلورانس.
    /// مبالغ بر اساس ریال هستند.
    /// </summary>
    public static class VamInstallmentPaymentRules
    {
        // سقف تلورانس: ۱۰۰ هزار تومان
        public const decimal MaxInstallmentTolerance = 1000000m;

        // تلورانس نسبی: ۱۰ درصد مبلغ قسط
        public const decimal InstallmentToleranceRatio = 0.1m;

        /// <summary>
        /// بررسی می‌کند آیا مبلغ پرداخت‌شده با احتساب تلورانس
        /// برای تسویه قسط کافی است یا خیر.
        /// </summary>
        public static bool IsSettled(
            decimal installmentAmount,
            decimal paidAmount)
        {
            if (installmentAmount <= 0m || paidAmount <= 0m)
                return false;

            if (paidAmount >= installmentAmount)
                return true;

            decimal shortfall =
                installmentAmount - paidAmount;

            decimal effectiveTolerance = Math.Min(
                MaxInstallmentTolerance,
                installmentAmount * InstallmentToleranceRatio
            );

            return shortfall > 0m &&
                   shortfall <= effectiveTolerance;
        }
    }
    /// <summary>
    /// محاسبه تعداد موارد تأخیر برای تعیین درصد کارمزد.
    /// توجه: این کلاس CalculateMostamariNegativeScore و CalculateVamNegativeScore
    /// را صدا نمی‌زند و در امتیاز منفی ورود به نوبت دخالتی ندارد.
    /// </summary>
    public static class VamGoodPayerCalculator
    {
        private sealed class Obligation
        {
            public DateTime DueDate { get; set; }
            public decimal Amount { get; set; }
            public decimal PaidAmount { get; set; }
            public DateTime? PaidDate { get; set; }
        }
        private sealed class DelayScoreResult
        {
            public int DelayedMonths { get; set; }

            public int NegativeScore { get; set; }
        }


        private static int CalculatePeriodicDelayScore(
         DateTime dueDate,
         DateTime? fullPaidDate,
         DateTime today,
         int intervalMonths)
        {
            if (intervalMonths < 1 || intervalMonths > 120)
            {
                throw new ArgumentOutOfRangeException(
                    "intervalMonths",
                    "فاصله محاسبه امتیاز باید بین ۱ تا ۱۲۰ ماه باشد."
                );
            }

            DateTime effectiveDate =
                (fullPaidDate ?? today).Date;

            dueDate = dueDate.Date;

            if (effectiveDate <= dueDate)
                return 0;

            PersianCalendar pc = new PersianCalendar();

            int negativeScore = 0;

            // به ازای هر بازه P یا Q ماه و یک روز،
            // یک امتیاز منفی اضافه می‌شود.
            for (int period = 1; period <= 600; period++)
            {
                int totalMonths = period * intervalMonths;

                DateTime thresholdDate =
                    pc.AddMonths(dueDate, totalMonths)
                      .Date
                      .AddDays(1);

                if (effectiveDate < thresholdDate)
                    break;

                negativeScore++;
            }

            return -negativeScore;
        }

        private static DelayScoreResult CalculateDelayScore(
     List<Obligation> obligations,
     DateTime asOfDate,
     int intervalMonths)
        {
            int delayedCount = 0;
            int totalNegativeScore = 0;

            if (obligations == null)
                obligations = new List<Obligation>();

            asOfDate = asOfDate.Date;

            // هر قسط یا ماه مستمری به صورت مستقل بررسی می‌شود.
            foreach (var item in obligations)
            {
                if (item == null)
                    continue;

                // اگر مبلغ کامل پرداخت شده باشد، تاریخ تسویه ملاک است.
                // در غیر این صورت، تاریخ امروز ملاک محاسبه خواهد بود.
                bool isFullyPaid =
                    item.Amount > 0m &&
                    item.PaidAmount >= item.Amount &&
                    item.PaidDate.HasValue;

                DateTime effectiveDate =
                    isFullyPaid
                        ? item.PaidDate.Value.Date
                        : asOfDate;

                int itemScore = CalculatePeriodicDelayScore(
                    item.DueDate,
                    effectiveDate,
                    asOfDate,
                    intervalMonths
                );

                // فقط تعهداتی که واقعاً امتیاز منفی گرفته‌اند
                // در شمارنده تأخیر قرار می‌گیرند.
                if (itemScore < 0)
                {
                    delayedCount++;

                    totalNegativeScore += itemScore;
                }
            }

            return new DelayScoreResult
            {
                DelayedMonths = delayedCount,
                NegativeScore = totalNegativeScore
            };
        }

        public static GoodPayerAssessment Evaluate(
            int memberId,
            SandooghModel db,
            DateTime asOfDate)
        {
            if (db == null)
                throw new ArgumentNullException("db");

            asOfDate = asOfDate.Date;

            var member = db.T_OzvCode
                .FirstOrDefault(x => x.Id == memberId);

            if (member == null)
            {
                throw new InvalidOperationException(
                    "عضو مورد نظر یافت نشد."
                );
            }

            var policy = db.VamPolicySettings
                .FirstOrDefault(x => x.Id == 1);

            var lastSettledLoan = db.Vams
                .Where(x =>
                    x.IdRefOzv == memberId &&
                    x.EtmamVam == true)
                .OrderByDescending(x => x.VamDate)
                .ThenByDescending(x => x.Vam_Id)
                .FirstOrDefault();

            var installmentPayments =
                new List<G_M_Pays>();

            var pensionPayments =
                new List<G_M_Pays>();

            var baseChanges =
                new List<T_MostamaryMablagh>();

            var minimumSettings =
                new List<MinimumPensionSetting>();

            if (lastSettledLoan != null)
            {
                DateTime endOfDay =
                    asOfDate.AddDays(1).AddTicks(-1);

                // پرداخت‌های اقساط آخرین وام
                if (lastSettledLoan.AvlinGestDate.HasValue &&
                    lastSettledLoan.TedadAgsat.HasValue &&
                    lastSettledLoan.TedadAgsat.Value > 0 &&
                    lastSettledLoan.GestMablag.HasValue &&
                    lastSettledLoan.GestMablag.Value > 0)
                {
                    installmentPayments = db.G_M_Pays
                        .Where(x =>
                            x.IdRefVam == lastSettledLoan.Vam_Id &&
                            x.TotGestMablag > 0 &&
                            x.PayDate.HasValue &&
                            x.PayDate <= endOfDay)
                        .OrderBy(x => x.PayDate)
                        .ThenBy(x => x.Id)
                        .ToList();
                }

                // شروع محاسبه مستمری
                DateTime pensionStartDate =
                    lastSettledLoan.VamDate ??
                    lastSettledLoan.AvlinGestDate ??
                    member.OzvDate;

                if (pensionStartDate.Date <= asOfDate.Date)
                {
                    PersianCalendar pc = new PersianCalendar();

                    DateTime firstMonthStart =
                        GetNextPersianMonthStart(
                            pensionStartDate,
                            pc
                        );

                    DateTime currentMonthStart =
                        GetPersianMonthStart(
                            asOfDate,
                            pc
                        );

                    if (firstMonthStart <= currentMonthStart)
                    {
                        minimumSettings = db.MinimumPensionSettings
                            .Where(x =>
                                x.EffectiveFrom <= asOfDate)
                            .OrderBy(x => x.EffectiveFrom)
                            .ToList();

                        baseChanges = db.T_MostamaryMablagh
                            .Where(x =>
                                x.MostamaryMablagh_IdRefOzvCode == member.Id &&
                                x.MostamaryMablagh_DateStart.HasValue)
                            .OrderBy(x =>
                                x.MostamaryMablagh_DateStart)
                            .ToList();

                        pensionPayments = db.G_M_Pays
                            .Where(x =>
                                x.IdRefOzv == member.Id &&
                                x.MostamariMablag > 0 &&
                                (x.IsAfzayesh == null ||
                                 x.IsAfzayesh != true) &&
                                x.PayDate.HasValue &&
                                x.PayDate >= firstMonthStart &&
                                x.PayDate <= endOfDay)
                            .OrderBy(x => x.PayDate)
                            .ThenBy(x => x.Id)
                            .ToList();
                    }
                }
            }

            return EvaluatePrepared(
                member,
                lastSettledLoan,
                policy,
                installmentPayments,
                baseChanges,
                pensionPayments,
                minimumSettings,
                asOfDate
            );
        }

        internal static GoodPayerAssessment EvaluatePrepared(
            T_OzvCode member,
            Vam lastSettledLoan,
            VamPolicySetting policy,
            IList<G_M_Pays> installmentPayments,
            IList<T_MostamaryMablagh> baseChanges,
            IList<G_M_Pays> pensionPayments,
            IList<MinimumPensionSetting> minimumSettings,
            DateTime asOfDate)
        {
            if (member == null)
                throw new ArgumentNullException("member");

            // درصدهای کارمزد
            decimal goodFee = policy == null
                ? 3m
                : policy.K_GoodPayerFeePercent;

            decimal normalFee = policy == null
                ? 5m
                : policy.J_OtherPayerFeePercent;

            // P: فاصله امتیاز منفی اقساط
            int pInterval = policy == null
                ? 2
                : policy.P_InstallmentDelayUnitMonths;

            // Q: فاصله امتیاز منفی مستمری
            int qInterval = policy == null
                ? 2
                : policy.Q_PensionDelayUnitMonths;

            // R: سقف امتیاز منفی مجاز اقساط
            int rThreshold = policy == null
                ? 3
                : policy.R_MaxInstallmentNegativeScore;

            // T: سقف امتیاز منفی مجاز مستمری
            int tThreshold = policy == null
                ? 3
                : policy.T_MaxPensionNegativeScore;

            // اعتبارسنجی کارمزدها
            if (goodFee < 0m || goodFee > 100m ||
                normalFee < 0m || normalFee > 100m)
            {
                throw new InvalidOperationException(
                    "درصدهای کارمزد در تنظیمات معتبر نیستند."
                );
            }

            // اعتبارسنجی فاصله‌های P و Q
            if (pInterval < 1 || pInterval > 120 ||
                qInterval < 1 || qInterval > 120)
            {
                throw new InvalidOperationException(
                    "فاصله محاسبه امتیاز خوش‌حسابی معتبر نیست."
                );
            }

            // اعتبارسنجی سقف‌های R و T
            if (rThreshold < 0 || rThreshold > 120 ||
                tThreshold < 0 || tThreshold > 120)
            {
                throw new InvalidOperationException(
                    "حداکثر امتیاز منفی مجاز معتبر نیست."
                );
            }

            // عضو بدون وام تسویه‌شده، خوش‌حساب محسوب نمی‌شود.
            if (lastSettledLoan == null)
            {
                return new GoodPayerAssessment
                {
                    InstallmentNegativeScore = 0,
                    PensionNegativeScore = 0,
                    TotalNegativeScore = 0,

                    HasSettledLoan = false,

                    DelayedInstallments = 0,
                    DelayedPensionMonths = 0,

                    IsGoodPayer = false,
                    FeePercent = normalFee,

                    P = pInterval,
                    Q = qInterval,
                    R = rThreshold,
                    T = tThreshold
                };
            }

            // محاسبه مستقل امتیاز اقساط
            var installmentResult =
                CalculateInstallmentScore(
                    lastSettledLoan,
                    installmentPayments,
                    asOfDate.Date,
                    pInterval
                );

            // محاسبه مستقل امتیاز مستمری
            var pensionResult =
                CalculatePensionScore(
                    member,
                    lastSettledLoan,
                    baseChanges,
                    pensionPayments,
                    minimumSettings,
                    asOfDate.Date,
                    qInterval
                );

            int installmentScore =
                installmentResult.NegativeScore;

            int pensionScore =
                pensionResult.NegativeScore;

            // تشخیص بدحسابی با قدر مطلق هر محور
            // مساوی بودن با R یا T همچنان مجاز است.
            bool installmentIsAcceptable =
                Math.Abs((long)installmentScore) <= rThreshold;

            bool pensionIsAcceptable =
                Math.Abs((long)pensionScore) <= tThreshold;

            // شرط خوش‌حسابی:
            // هر دو محور باید در محدوده مجاز باشند.
            bool isGood =
                installmentIsAcceptable &&
                pensionIsAcceptable;

            return new GoodPayerAssessment
            {
                InstallmentNegativeScore = installmentScore,

                HasSettledLoan = true,

                PensionNegativeScore = pensionScore,

                // مجموع فقط برای گزارش و نمایش
                TotalNegativeScore =
                    installmentScore + pensionScore,

                DelayedInstallments =
                    installmentResult.DelayedMonths,

                DelayedPensionMonths =
                    pensionResult.DelayedMonths,

                IsGoodPayer = isGood,

                FeePercent = isGood
                    ? goodFee
                    : normalFee,

                P = pInterval,
                Q = qInterval,
                R = rThreshold,
                T = tThreshold
            };
        }


        private static DelayScoreResult CalculateInstallmentScore(
        Vam loan,
        IEnumerable<G_M_Pays> paymentsSource,
        DateTime asOfDate,
        int intervalMonths)
        {
            if (loan == null ||
                !loan.AvlinGestDate.HasValue ||
                !loan.TedadAgsat.HasValue ||
                loan.TedadAgsat.Value <= 0 ||
                !loan.GestMablag.HasValue ||
                loan.GestMablag.Value <= 0)
            {
                return new DelayScoreResult();
            }

            DateTime firstDueDate =
                loan.AvlinGestDate.Value.Date;

            int installmentCount =
                loan.TedadAgsat.Value;

            decimal installmentAmount =
                Convert.ToDecimal(loan.GestMablag.Value);

            PersianCalendar pc = new PersianCalendar();

            var installments = new List<Obligation>();

            // ساخت برنامه اقساط
            for (int i = 0; i < installmentCount; i++)
            {
                installments.Add(new Obligation
                {
                    DueDate = pc.AddMonths(firstDueDate, i).Date,
                    Amount = installmentAmount,
                    PaidAmount = 0m,
                    PaidDate = null
                });
            }

            DateTime endOfDay =
                asOfDate.Date.AddDays(1).AddTicks(-1);

            // پرداخت‌های آخرین وام تسویه‌شده
            var payments = (paymentsSource ?? Enumerable.Empty<G_M_Pays>())
       .Where(x =>
           x.IdRefVam == loan.Vam_Id &&
           x.TotGestMablag > 0 &&
           x.PayDate.HasValue &&
           x.PayDate <= endOfDay)
       .OrderBy(x => x.PayDate)
       .ThenBy(x => x.Id)
       .ToList();

            // تخصیص پرداخت‌ها به قدیمی‌ترین قسط تسویه‌نشده
            // با حرکت پیوسته روی فهرست اقساط

            int installmentIndex = 0;

            foreach (var payment in payments)
            {
                decimal remaining =
                    Convert.ToDecimal(payment.TotGestMablag.Value);

                if (remaining <= 0m)
                    continue;

                while (
                    remaining > 0m &&
                    installmentIndex < installments.Count)
                {
                    var installment =
                        installments[installmentIndex];

                    decimal need =
                        installment.Amount -
                        installment.PaidAmount;

                    if (need <= 0m)
                    {
                        installmentIndex++;
                        continue;
                    }

                    decimal applied =
                        Math.Min(remaining, need);

                    installment.PaidAmount += applied;

                    remaining -= applied;

                    // بررسی تسویه با همان قاعده تلورانس قبلی
                    if (VamInstallmentPaymentRules.IsSettled(
                        installment.Amount,
                        installment.PaidAmount))
                    {
                        installment.PaidAmount =
                            installment.Amount;

                        if (!installment.PaidDate.HasValue)
                        {
                            installment.PaidDate =
                                payment.PayDate.Value.Date;
                        }

                        // رفتن به قسط بعدی
                        installmentIndex++;
                    }
                }
            }

            return CalculateDelayScore(
     installments,
     asOfDate,
     intervalMonths
 );
        }
        private static DelayScoreResult CalculatePensionScore(
      T_OzvCode member,
      Vam lastSettledLoan,
      IEnumerable<T_MostamaryMablagh> baseChangesSource,
      IEnumerable<G_M_Pays> paymentsSource,
      IEnumerable<MinimumPensionSetting> minimumSettingsSource,
      DateTime asOfDate,
      int intervalMonths)
        {
            if (member == null || lastSettledLoan == null)
                return new DelayScoreResult();

            // شروع محاسبه از تاریخ آخرین وام تسویه‌شده
            DateTime startDate =
                lastSettledLoan.VamDate ??
                lastSettledLoan.AvlinGestDate ??
                member.OzvDate;

            if (startDate.Date > asOfDate.Date)
                return new DelayScoreResult();

            PersianCalendar pc = new PersianCalendar();

            // شروع بررسی از ماه بعد از تاریخ آخرین وام
            DateTime firstMonthStart =
                GetNextPersianMonthStart(startDate, pc);

            DateTime currentMonthStart =
                GetPersianMonthStart(asOfDate, pc);

            var minimumSettings =
     (minimumSettingsSource ??
      Enumerable.Empty<MinimumPensionSetting>())
     .Where(x => x.EffectiveFrom <= asOfDate)
     .OrderByDescending(x => x.EffectiveFrom)
     .ToList();

            var baseChanges =
                (baseChangesSource ??
                 Enumerable.Empty<T_MostamaryMablagh>())
                .Where(x =>
                    x.MostamaryMablagh_IdRefOzvCode == member.Id &&
                    x.MostamaryMablagh_DateStart.HasValue)
                .OrderByDescending(x =>
                    x.MostamaryMablagh_DateStart)
                .ToList();

            var obligations = new List<Obligation>();

            DateTime monthStart = firstMonthStart;

            while (monthStart <= currentMonthStart)
            {
                DateTime nextMonthStart =
                    GetNextPersianMonthStart(monthStart, pc);

                // موعد مستمری، پایان ماه شمسی است.
                DateTime dueDate =
                    nextMonthStart.AddDays(-1).Date;

                decimal expected =
      MVCSandoogh.VamPolicyHelper.GetDefaultMinimumPension(
          monthStart
      );

                var minimum = minimumSettings
      .FirstOrDefault(x =>
          x.EffectiveFrom.Date <= monthStart.Date &&
          (!x.EffectiveTo.HasValue ||
           x.EffectiveTo.Value.Date >= monthStart.Date));

                if (minimum != null)
                {
                    expected =
                        Convert.ToDecimal(minimum.MinimumAmount);
                }

                var baseForMonth = baseChanges
      .FirstOrDefault(x =>
          x.MostamaryMablagh_DateStart.Value.Date
          <= monthStart.Date);
                if (baseForMonth != null &&
                    baseForMonth.MostamaryMablagh_Mablagh.HasValue)
                {
                    expected = Math.Max(
                        expected,
                        Convert.ToDecimal(
                            baseForMonth.MostamaryMablagh_Mablagh.Value
                        )
                    );
                }

                if (expected > 0m)
                {
                    obligations.Add(new Obligation
                    {
                        DueDate = dueDate,
                        Amount = expected,
                        PaidAmount = 0m,
                        PaidDate = null
                    });
                }

                monthStart = nextMonthStart;
            }

            if (obligations.Count == 0)
                return new DelayScoreResult();

            DateTime endOfDay =
                asOfDate.Date.AddDays(1).AddTicks(-1);

            // نکته مهم:
            // پرداخت‌ها باید از ابتدای بازه محاسبه خوانده شوند.
            // استفاده از monthStart پس از حلقه، پرداخت‌های قبلی را حذف می‌کرد.
            var payments =
     (paymentsSource ?? Enumerable.Empty<G_M_Pays>())
     .Where(x =>
         x.IdRefOzv == member.Id &&
         x.MostamariMablag > 0 &&
         (x.IsAfzayesh == null ||
          x.IsAfzayesh != true) &&
         x.PayDate.HasValue &&
         x.PayDate >= firstMonthStart &&
         x.PayDate <= endOfDay)
     .OrderBy(x => x.PayDate)
     .ThenBy(x => x.Id)
     .ToList();

            // تخصیص پرداخت‌ها به قدیمی‌ترین ماه تسویه‌نشده
            // با حرکت پیوسته روی تعهدات

            int obligationIndex = 0;

            foreach (var payment in payments)
            {
                decimal remaining =
                    Convert.ToDecimal(payment.MostamariMablag.Value);

                if (remaining <= 0m)
                    continue;

                while (
                    remaining > 0m &&
                    obligationIndex < obligations.Count)
                {
                    var obligation =
                        obligations[obligationIndex];

                    decimal need =
                        obligation.Amount -
                        obligation.PaidAmount;

                    if (need <= 0m)
                    {
                        obligationIndex++;
                        continue;
                    }

                    decimal applied =
                        Math.Min(remaining, need);

                    obligation.PaidAmount += applied;

                    remaining -= applied;

                    if (obligation.PaidAmount >= obligation.Amount &&
                        !obligation.PaidDate.HasValue)
                    {
                        obligation.PaidDate =
                            payment.PayDate.Value.Date;
                    }

                    if (obligation.PaidAmount >= obligation.Amount)
                    {
                        obligationIndex++;
                    }
                }
            }
            return CalculateDelayScore(
      obligations,
      asOfDate,
      intervalMonths
  );
        }
        internal static DateTime GetPersianMonthStart(
     DateTime date,
     PersianCalendar pc)
        {
            return pc.ToDateTime(pc.GetYear(date), pc.GetMonth(date), 1, 0, 0, 0, 0);
        }

        internal static DateTime GetNextPersianMonthStart(
     DateTime monthStart,
     PersianCalendar pc)
        {
            int year = pc.GetYear(monthStart);
            int month = pc.GetMonth(monthStart) + 1;
            if (month > 12) { month = 1; year++; }
            return pc.ToDateTime(year, month, 1, 0, 0, 0, 0);
        }
    }
}

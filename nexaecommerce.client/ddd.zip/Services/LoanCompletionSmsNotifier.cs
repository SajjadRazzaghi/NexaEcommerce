﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using MVCSandoogh.Models;

namespace MVCSandoogh.Services
{
    public static class LoanCompletionSmsNotifier
    {
        private const byte NotSent = 0;
        private const byte Pending = 1;
        private const byte Sent = 2;
        private const byte Failed = 3;

        private const string SmsMessage =
            "عضو محترم، با توجه به تسویه کامل وام، " +
            "سفته‌های ضمانت شما ابطال گردیده‌اند. " +
            "جهت دریافت سفته‌ها به دفتر صندوق مراجعه فرمایید.";

        public static void TrySend(
            SandooghModel db,
            long? loanId,
            Func<string[], string, Task> sendSms)
        {
            if (db == null ||
                !loanId.HasValue ||
                sendSms == null)
            {
                return;
            }

            try
            {
                // ------------------------------------------------
                // 1. دریافت اطلاعات وام
                // ------------------------------------------------

                var loan = db.Vams
                    .AsNoTracking()
                    .Where(x => x.Vam_Id == loanId.Value)
                    .Select(x => new
                    {
                        x.Vam_Id,
                        x.IdRefOzv,
                        x.EtmamVam,
                        x.VamMablagKhales,
                        x.Karmozd,
                        x.FinalGuaranteeSmsStatus
                    })
                    .FirstOrDefault();

                if (loan == null ||
                    !loan.EtmamVam ||
                    !loan.IdRefOzv.HasValue)
                {
                    return;
                }

                // قبلاً ارسال شده یا ارسال دیگری در جریان است.
                if (loan.FinalGuaranteeSmsStatus == Sent ||
                    loan.FinalGuaranteeSmsStatus == Pending)
                {
                    return;
                }

                // ------------------------------------------------
                // 2. کنترل مبلغ واقعی پرداختی
                // ------------------------------------------------

                decimal totalLoanAmount =
                    Convert.ToDecimal(
                        loan.VamMablagKhales ?? 0d) +
                    Convert.ToDecimal(
                        loan.Karmozd ?? 0d);

                if (totalLoanAmount <= 0m)
                    return;

                double? paidAmountResult =
                    db.G_M_Pays
                        .AsNoTracking()
                        .Where(p =>
                            p.IdRefVam == loan.Vam_Id &&
                            p.TotGestMablag > 0)
                        .Select(p =>
                            (double?)p.TotGestMablag)
                        .Sum();

                decimal totalPaidAmount =
                    Convert.ToDecimal(
                        paidAmountResult ?? 0d);

                // تلورانس کوچک برای خطای احتمالی محاسبات double
                if (totalPaidAmount + 0.01m <
                    totalLoanAmount)
                {
                    return;
                }

                // ------------------------------------------------
                // 3. دریافت شماره موبایل عضو
                // ------------------------------------------------

                string mobile = db.T_OzvCode
                    .AsNoTracking()
                    .Where(x => x.Id == loan.IdRefOzv.Value)
                    .Select(x => x.Mobile)
                    .FirstOrDefault();

                if (string.IsNullOrWhiteSpace(mobile))
                {
                    MarkFailed(
                        db,
                        loan.Vam_Id,
                        "شماره موبایل عضو ثبت نشده است."
                    );

                    return;
                }

                // ------------------------------------------------
                // 4. رزرو اتمیک ارسال پیامک
                //
                // فقط یک درخواست می‌تواند وضعیت را از
                // ارسال‌نشده یا ناموفق به در حال ارسال ببرد.
                // ------------------------------------------------

                DateTime now = DateTime.Now;

                int claimed = db.Database.ExecuteSqlCommand(
                    @"
                    UPDATE [dbo].[Vam]
                    SET
                        [FinalGuaranteeSmsStatus] = 1,
                        [FinalGuaranteeSmsUpdatedAt] = @p1,
                        [FinalGuaranteeSmsLastError] = NULL
                    WHERE
                        [Vam_Id] = @p0
                        AND [EtmamVam] = 1
                        AND [FinalGuaranteeSmsStatus] IN (0, 3)
                    ",
                    loan.Vam_Id,
                    now
                );

                if (claimed != 1)
                    return;

                // ------------------------------------------------
                // 5. ارسال پیامک از سرویس پیامکی فعلی صندوق
                // ------------------------------------------------

                try
                {
                    Task smsTask = sendSms(
                        new[] { mobile.Trim() },
                        SmsMessage
                    );

                    if (smsTask == null)
                    {
                        throw new InvalidOperationException(
                            "سرویس پیامک هیچ عملیات ارسالی برنگرداند."
                        );
                    }

                    // منتظر پایان عملیات سرویس پیامک می‌مانیم.
                    smsTask.GetAwaiter().GetResult();
                }
                catch (Exception smsException)
                {
                    MarkFailed(
                        db,
                        loan.Vam_Id,
                        smsException.Message
                    );

                    return;
                }

                // ------------------------------------------------
                // 6. ثبت موفقیت ارسال
                // ------------------------------------------------

                try
                {
                    db.Database.ExecuteSqlCommand(
                        @"
                        UPDATE [dbo].[Vam]
                        SET
                            [FinalGuaranteeSmsStatus] = 2,
                            [FinalGuaranteeSmsUpdatedAt] = @p1,
                            [FinalGuaranteeSmsSentAt] = @p1,
                            [FinalGuaranteeSmsLastError] = NULL
                        WHERE
                            [Vam_Id] = @p0
                            AND [FinalGuaranteeSmsStatus] = 1
                        ",
                        loan.Vam_Id,
                        DateTime.Now
                    );
                }
                catch (Exception statusException)
                {
                    // در صورت خطا در ثبت نتیجه، وضعیت Pending
                    // باقی می‌ماند تا ارسال مجدد خودکار رخ ندهد.
                    System.Diagnostics.Trace.TraceError(
                        "ثبت وضعیت پیامک اتمام وام {0} ناموفق بود: {1}",
                        loan.Vam_Id,
                        statusException
                    );
                }
            }
            catch (Exception ex)
            {
                // خطای پیامک نباید عملیات موفق ثبت پرداخت را
                // ناموفق اعلام کند.
                System.Diagnostics.Trace.TraceError(
                    "LoanCompletionSmsNotifier: {0}",
                    ex
                );
            }
        }

        private static void MarkFailed(
            SandooghModel db,
            long loanId,
            string error)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(error))
                    error = "خطای نامشخص در ارسال پیامک";

                if (error.Length > 1000)
                    error = error.Substring(0, 1000);

                db.Database.ExecuteSqlCommand(
                    @"
                    UPDATE [dbo].[Vam]
                    SET
                        [FinalGuaranteeSmsStatus] = 3,
                        [FinalGuaranteeSmsUpdatedAt] = @p1,
                        [FinalGuaranteeSmsLastError] = @p2
                    WHERE
                        [Vam_Id] = @p0
                        AND [FinalGuaranteeSmsStatus] IN (0, 1, 3)
                    ",
                    loanId,
                    DateTime.Now,
                    error
                );
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(
                    "ثبت خطای پیامک اتمام وام ناموفق بود: {0}",
                    ex
                );
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using MVCSandoogh.Models;

namespace MVCSandoogh.Services
{
    public sealed class GoodPayerBatchResult
    {
        public Dictionary<int, GoodPayerAssessment>
    Assessments { get; private set; }
    public Dictionary<int, string>
        Errors { get; private set; }

        public GoodPayerBatchResult()
        {
        Assessments = new Dictionary<int, GoodPayerAssessment>
            ();
            Errors = new Dictionary<int, string>
                ();
                }
                }

                public static class GoodPayerBatchEvaluator
                {
                // برای جلوگیری از عبور تعداد پارامترهای SQL Server از محدودیت مجاز
                private const int BatchSize = 400;

                private static IEnumerable<List<T>> Chunks<T>(
            IList<T> items,
            int size)
        {
            for (int i = 0; i < items.Count; i += size)
            {
                yield return items
                    .Skip(i)
                    .Take(size)
                    .ToList();
            }
        }

        public static GoodPayerBatchResult Evaluate(
            SandooghModel db,
            IList<T_OzvCode> members,
            DateTime asOfDate)
        {
            if (db == null)
                throw new ArgumentNullException("db");

            if (members == null)
                throw new ArgumentNullException("members");

            asOfDate = asOfDate.Date;

            var result = new GoodPayerBatchResult();

            var distinctMembers = members
                .Where(x => x != null)
                .GroupBy(x => x.Id)
                .Select(x => x.First())
                .ToList();

            if (distinctMembers.Count == 0)
                return result;

            var memberIds = distinctMembers
                .Select(x => x.Id)
                .Distinct()
                .ToList();

            var membersById = distinctMembers
                .ToDictionary(x => x.Id, x => x);

            // تنظیمات مشترک فقط یک بار خوانده می‌شوند.
            var policy = db.VamPolicySettings
                .AsNoTracking()
                .FirstOrDefault(x => x.Id == 1);

            // -------------------------------------------------
            // 1. دریافت وام‌های تسویه‌شده همه اعضا
            // -------------------------------------------------

            var allSettledLoans = new List<Vam>();

            foreach (var idChunk in Chunks(memberIds, BatchSize))
            {
                var loans = db.Vams
                    .AsNoTracking()
                    .Where(x =>
                        x.IdRefOzv.HasValue &&
                        idChunk.Contains(x.IdRefOzv.Value) &&
                        x.EtmamVam == true)
                    .Select(x => new Vam
                    {
                        Vam_Id = x.Vam_Id,
                        IdRefOzv = x.IdRefOzv,
                        VamDate = x.VamDate,
                        AvlinGestDate = x.AvlinGestDate,
                        TedadAgsat = x.TedadAgsat,
                        GestMablag = x.GestMablag,
                        EtmamVam = x.EtmamVam
                    })
                    .ToList();

                allSettledLoans.AddRange(loans);
            }

            // آخرین وام تسویه‌شده هر عضو:
            // اولویت با تاریخ وام و سپس شماره وام است.
            var lastLoanByMember = allSettledLoans
                .Where(x => x.IdRefOzv.HasValue)
                .GroupBy(x => x.IdRefOzv.Value)
                .ToDictionary(
                    x => x.Key,
                    x => x
                        .OrderByDescending(v => v.VamDate)
                        .ThenByDescending(v => v.Vam_Id)
                        .First()
                );

            // -------------------------------------------------
            // 2. دریافت پرداخت اقساط وام‌ها
            // -------------------------------------------------

            var validInstallmentLoanIds = lastLoanByMember.Values
                .Where(x =>
                    x.AvlinGestDate.HasValue &&
                    x.TedadAgsat.HasValue &&
                    x.TedadAgsat.Value > 0 &&
                    x.GestMablag.HasValue &&
                    x.GestMablag.Value > 0)
                .Select(x => x.Vam_Id)
                .Distinct()
                .ToList();

            var installmentPayments = new List<G_M_Pays>();

            DateTime endOfDay =
                asOfDate.AddDays(1).AddTicks(-1);

            foreach (var loanChunk in Chunks(
                validInstallmentLoanIds,
                BatchSize))
            {
                var payments = db.G_M_Pays
                    .AsNoTracking()
                    .Where(x =>
                        x.IdRefVam.HasValue &&
                        loanChunk.Contains(x.IdRefVam.Value) &&
                        x.TotGestMablag > 0 &&
                        x.PayDate.HasValue &&
                        x.PayDate <= endOfDay)
                    .Select(x => new G_M_Pays
                    {
                        Id = x.Id,
                        IdRefVam = x.IdRefVam,
                        TotGestMablag = x.TotGestMablag,
                        PayDate = x.PayDate
                    })
                    .ToList();

                installmentPayments.AddRange(payments);
            }

            var installmentPaymentsByLoan = installmentPayments
                .Where(x => x.IdRefVam.HasValue)
                .GroupBy(x => x.IdRefVam.Value)
                .ToDictionary(
                    x => x.Key,
                    x => x
                        .OrderBy(p => p.PayDate)
                        .ThenBy(p => p.Id)
                        .ToList()
                );

            // -------------------------------------------------
            // 3. تعیین بازه محاسبه مستمری هر عضو
            // -------------------------------------------------

            PersianCalendar pc = new PersianCalendar();

            DateTime currentMonthStart =
                VamGoodPayerCalculator.GetPersianMonthStart(
                    asOfDate,
                    pc
                );

            var pensionFirstMonthByMember =
                new Dictionary<int, DateTime>();

            foreach (var member in distinctMembers)
            {
                Vam loan;

                if (!lastLoanByMember.TryGetValue(
                    member.Id,
                    out loan))
                {
                    continue;
                }

                DateTime startDate =
                    loan.VamDate ??
                    loan.AvlinGestDate ??
                    member.OzvDate;

                if (startDate.Date > asOfDate.Date)
                    continue;

                DateTime firstMonth =
                    VamGoodPayerCalculator.GetNextPersianMonthStart(
                        startDate,
                        pc
                    );

                if (firstMonth <= currentMonthStart)
                {
                    pensionFirstMonthByMember[member.Id] =
                        firstMonth;
                }
            }

            var pensionMemberIds =
                pensionFirstMonthByMember.Keys.ToList();

            // -------------------------------------------------
            // 4. دریافت تغییرات مبلغ مستمری
            // -------------------------------------------------

            var pensionBaseChanges =
                new List<T_MostamaryMablagh>();

            foreach (var idChunk in Chunks(
                pensionMemberIds,
                BatchSize))
            {
                var changes = db.T_MostamaryMablagh
                    .AsNoTracking()
                    .Where(x =>
                        x.MostamaryMablagh_IdRefOzvCode.HasValue &&
                        idChunk.Contains(
                            x.MostamaryMablagh_IdRefOzvCode.Value) &&
                        x.MostamaryMablagh_DateStart.HasValue)
                    .Select(x => new T_MostamaryMablagh
                    {
                        MostamaryMablagh_ID =
                            x.MostamaryMablagh_ID,

                        MostamaryMablagh_IdRefOzvCode =
                            x.MostamaryMablagh_IdRefOzvCode,

                        MostamaryMablagh_DateStart =
                            x.MostamaryMablagh_DateStart,

                        MostamaryMablagh_Mablagh =
                            x.MostamaryMablagh_Mablagh
                    })
                    .ToList();

                pensionBaseChanges.AddRange(changes);
            }

            // -------------------------------------------------
            // 5. تنظیمات حداقل مستمری فقط یک بار
            // -------------------------------------------------

            var minimumSettings =
                new List<MinimumPensionSetting>();

            if (pensionMemberIds.Count > 0)
            {
                minimumSettings = db.MinimumPensionSettings
                    .AsNoTracking()
                    .Where(x => x.EffectiveFrom <= asOfDate)
                    .OrderBy(x => x.EffectiveFrom)
                    .ToList();
            }

            // -------------------------------------------------
            // 6. دریافت پرداخت‌های مستمری به صورت گروهی
            // -------------------------------------------------

            var pensionPayments = new List<G_M_Pays>();

            foreach (var idChunk in Chunks(
                pensionMemberIds,
                BatchSize))
            {
                DateTime chunkStartDate = idChunk
                    .Select(id => pensionFirstMonthByMember[id])
                    .Min();

                var payments = db.G_M_Pays
                    .AsNoTracking()
                    .Where(x =>
                        x.IdRefOzv.HasValue &&
                        idChunk.Contains(x.IdRefOzv.Value) &&
                        x.MostamariMablag > 0 &&
                        (x.IsAfzayesh == null ||
                         x.IsAfzayesh != true) &&
                        x.PayDate.HasValue &&
                        x.PayDate >= chunkStartDate &&
                        x.PayDate <= endOfDay)
                    .Select(x => new G_M_Pays
                    {
                        Id = x.Id,
                        IdRefOzv = x.IdRefOzv,
                        MostamariMablag = x.MostamariMablag,
                        IsAfzayesh = x.IsAfzayesh,
                        PayDate = x.PayDate
                    })
                    .ToList();

                pensionPayments.AddRange(payments);
            }

            var pensionPaymentsByMember = pensionPayments
                .Where(x => x.IdRefOzv.HasValue)
                .GroupBy(x => x.IdRefOzv.Value)
                .ToDictionary(
                    x => x.Key,
                    x => x
                        .OrderBy(p => p.PayDate)
                        .ThenBy(p => p.Id)
                        .ToList()
                );

            var baseChangesByMember = pensionBaseChanges
                .Where(x =>
                    x.MostamaryMablagh_IdRefOzvCode.HasValue)
                .GroupBy(x =>
                    x.MostamaryMablagh_IdRefOzvCode.Value)
                .ToDictionary(
                    x => x.Key,
                    x => x
                        .OrderBy(p =>
                            p.MostamaryMablagh_DateStart)
                        .ToList()
                );

            // -------------------------------------------------
            // 7. محاسبه نهایی در حافظه
            // -------------------------------------------------

            var emptyPayments = new List<G_M_Pays>();
            var emptyChanges = new List<T_MostamaryMablagh>();

            foreach (var member in distinctMembers)
            {
                try
                {
                    Vam loan;
                    lastLoanByMember.TryGetValue(
                        member.Id,
                        out loan
                    );

                    IList<G_M_Pays> memberInstallments =
                        emptyPayments;

                    IList<G_M_Pays> memberPensions =
                        emptyPayments;

                    IList<T_MostamaryMablagh> memberChanges =
                        emptyChanges;

                    if (loan != null)
                    {
                        List<G_M_Pays> foundInstallments;

                        if (installmentPaymentsByLoan.TryGetValue(
                            loan.Vam_Id,
                            out foundInstallments))
                        {
                            memberInstallments = foundInstallments;
                        }

                        List<G_M_Pays> foundPensions;

                        if (pensionPaymentsByMember.TryGetValue(
                            member.Id,
                            out foundPensions))
                        {
                            memberPensions = foundPensions;
                        }

                        List<T_MostamaryMablagh> foundChanges;

                        if (baseChangesByMember.TryGetValue(
                            member.Id,
                            out foundChanges))
                        {
                            memberChanges = foundChanges;
                        }
                    }

                    result.Assessments[member.Id] =
                        VamGoodPayerCalculator.EvaluatePrepared(
                            member,
                            loan,
                            policy,
                            memberInstallments,
                            memberChanges,
                            memberPensions,
                            minimumSettings,
                            asOfDate
                        );
                }
                catch (Exception ex)
                {
                    // خطای یک عضو نباید محاسبه سایر اعضا را متوقف کند.
                    result.Errors[member.Id] = ex.Message;
                }
            }

            return result;
        }
    }
}

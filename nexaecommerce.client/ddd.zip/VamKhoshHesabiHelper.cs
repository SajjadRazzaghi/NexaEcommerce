﻿using System;
using MVCSandoogh.Models;

namespace MVCSandoogh
{
    public class VamKhoshHesabiResult
    {
        public bool IsGoodPayer { get; set; }

        public int DelayedInstallmentCount { get; set; }

        public int DelayedPensionCount { get; set; }

        public decimal FeePercent { get; set; }
    }

    public static class VamKhoshHesabiHelper
    {
        public static VamKhoshHesabiResult Calculate(
            int delayedInstallmentCount,
            int delayedPensionCount,
            T_VamKhoshHesabiSetting setting)
        {
            if (setting == null || !setting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات خوش‌حسابی هنوز توسط مدیر سیستم تکمیل نشده است."
                );
            }

            if (delayedInstallmentCount < 0 ||
                delayedPensionCount < 0)
            {
                throw new ArgumentException(
                    "تعداد موارد دارای تأخیر نمی‌تواند منفی باشد."
                );
            }

            bool isGood =
                delayedInstallmentCount <= setting.MaxDelayedInstallments &&
                delayedPensionCount <= setting.MaxDelayedPensions;

            return new VamKhoshHesabiResult
            {
                IsGoodPayer = isGood,

                DelayedInstallmentCount =
                    delayedInstallmentCount,

                DelayedPensionCount =
                    delayedPensionCount,

                FeePercent = isGood
                    ? setting.GoodPayerFeePercent
                    : setting.NormalPayerFeePercent
            };
        }
    }
}
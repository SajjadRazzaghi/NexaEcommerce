using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using MVCSandoogh.Models;

namespace MVCSandoogh.Services
{
    /// <summary>
    /// خروجی ارزیابی خوش‌حسابی. این محاسبه مستقل از امتیاز منفی ورود به نوبت وام است.
    /// </summary>
    public sealed class GoodPayerAssessment
    {
        public int InstallmentNegativeScore { get; set; }
        public int PensionNegativeScore { get; set; }
        public int TotalNegativeScore { get; set; }

        public decimal FeePercent { get; set; }
        public bool IsGoodPayer { get; set; }
        public int N { get; set; }
        public int M { get; set; }
        public decimal FeePercent { get; set; }
        public bool IsGoodPayer { get; set; }
    }

    /// <summary>
    /// محاسبه تعداد موارد تأخیر برای تعیین درصد کارمزد.
    /// توجه: این کلاس CalculateMostamariNegativeScore و CalculateVamNegativeScore
    /// را صدا نمی‌زند و در امتیاز منفی ورود به نوبت دخالتی ندارد.
    /// </summary>
    public static class VamGoodPayerCalculator
    {
        private sealed class Obligation
        {
            public DateTime DueDate { get; set; }
            public decimal Amount { get; set; }
            public decimal PaidAmount { get; set; }
            public DateTime? PaidDate { get; set; }
        }

        private static int CalculateTwoMonthDelayScore(
            DateTime dueDate,
            DateTime? fullPaidDate,
            DateTime today)
        {
            DateTime effectiveDate =
                (fullPaidDate ?? today).Date;

            dueDate = dueDate.Date;

            if (effectiveDate <= dueDate)
                return 0;

            int delayMonths =
                (effectiveDate.Year - dueDate.Year) * 12 +
                (effectiveDate.Month - dueDate.Month);

            if (effectiveDate.Day <= dueDate.Day)
                delayMonths--;

            if (delayMonths <= 2)
                return 0;

            return -(delayMonths / 2);
        }

        public static GoodPayerAssessment Evaluate(int memberId, SandooghModel db, DateTime asOfDate)
        {
            if (db == null) throw new ArgumentNullException("db");

            var member = db.T_OzvCode.FirstOrDefault(x => x.Id == memberId);
            if (member == null) throw new InvalidOperationException("عضو مورد نظر یافت نشد.");

            var policy = db.VamPolicySettings.FirstOrDefault(x => x.Id == 1);
            int n = policy == null ? 0 : Math.Max(0, policy.N_DelayedInstallments);
            int m = policy == null ? 0 : Math.Max(0, policy.M_DelayedPensions);
            decimal k = policy == null ? 3m : policy.K_GoodPayerFeePercent;
            decimal j = policy == null ? 5m : policy.J_OtherPayerFeePercent;

            if (k < 0m || k > 100m || j < 0m || j > 100m)
                throw new InvalidOperationException("درصدهای کارمزد در تنظیمات معتبر نیستند.");

            int delayedInstallments = CountDelayedInstallments(memberId, db, asOfDate.Date);
            int delayedPensions = CountDelayedPensionMonths(member, db, asOfDate.Date);

            bool isGood = delayedInstallments <= n && delayedPensions <= m;
            return new GoodPayerAssessment
            {
                DelayedInstallments = delayedInstallments,
                DelayedPensionMonths = delayedPensions,
                N = n,
                M = m,
                FeePercent = isGood ? k : j,
                IsGoodPayer = isGood
            };
        }

        private static int CountDelayedInstallments(int memberId, SandooghModel db, DateTime asOfDate)
        {
            // مطابق منطق فعلی پروژه، فقط آخرین وام تسویه‌شده مبنا قرار می‌گیرد.
            var loan = db.Vams
                .Where(x => x.IdRefOzv == memberId && x.EtmamVam)
                .OrderByDescending(x => x.Vam_Id)
                .FirstOrDefault();

            if (loan == null || !loan.AvlinGestDate.HasValue ||
                !loan.TedadAgsat.HasValue || loan.TedadAgsat.Value <= 0 ||
                !loan.GestMablag.HasValue || loan.GestMablag.Value <= 0)
                return 0;

            var firstDueDate = loan.AvlinGestDate.Value.Date;
            int installmentCount = loan.TedadAgsat.Value;
            decimal installmentAmount = Convert.ToDecimal(loan.GestMablag.Value);

            var installments = new List<Obligation>();
            PersianCalendar pc = new PersianCalendar();
            for (int i = 0; i < installmentCount; i++)
            {
                installments.Add(new Obligation
                {
                    DueDate = pc.AddMonths(firstDueDate, i).Date,
                    Amount = installmentAmount,
                    PaidAmount = 0m,
                    PaidDate = null
                });
            }

            DateTime endOfDay = asOfDate.Date.AddDays(1).AddTicks(-1);
            var payments = db.G_M_Pays
                .Where(x => x.IdRefVam == loan.Vam_Id &&
                            x.TotGestMablag > 0 && x.PayDate.HasValue &&
                            x.PayDate <= endOfDay)
                .OrderBy(x => x.PayDate)
                .ThenBy(x => x.Id)
                .ToList();

            // پرداخت‌های ناقص روی همان قسط جمع می‌شوند؛ فقط تکمیل کل مبلغ، قسط را تسویه می‌کند.
            foreach (var payment in payments)
            {
                decimal remaining = Convert.ToDecimal(payment.TotGestMablag.Value);
                foreach (var installment in installments)
                {
                    if (remaining <= 0m) break;
                    decimal due = installment.Amount - installment.PaidAmount;
                    if (due <= 0m) continue;

                    decimal applied = Math.Min(remaining, due);
                    installment.PaidAmount += applied;
                    remaining -= applied;

                    if (installment.PaidAmount >= installment.Amount && !installment.PaidDate.HasValue)
                        installment.PaidDate = payment.PayDate.Value.Date;
                }
            }

            // سررسید امروز هنوز تأخیر نیست؛ از فردای سررسید، حتی یک روز، یک مورد تأخیر محسوب می‌شود.
            return installments.Count(x =>
                x.DueDate < asOfDate &&
                (x.PaidAmount < x.Amount || (x.PaidDate.HasValue && x.PaidDate.Value.Date > x.DueDate)));
        }

        private static int CountDelayedPensionMonths(T_OzvCode member, SandooghModel db, DateTime asOfDate)
        {
            // اعضای فاقد سابقه وام: شمارش از یک ماه بعد از عضویت.
            // اعضای دارای سابقه وام: شمارش از تاریخ اعطای آخرین وام.
            var latestLoan = db.Vams
                .Where(x => x.IdRefOzv == member.Id)
                .OrderByDescending(x => x.VamDate)
                .ThenByDescending(x => x.Vam_Id)
                .FirstOrDefault();

            DateTime startDate = latestLoan != null && latestLoan.VamDate.HasValue
                ? latestLoan.VamDate.Value.Date
                : member.OzvDate.AddMonths(1).Date;

            if (startDate > asOfDate) return 0;

            PersianCalendar pc = new PersianCalendar();
            DateTime startMonth = GetPersianMonthStart(startDate, pc);
            // مانند CalculateMostamariNegativeScore، ماه ناقصِ شروع محاسبه کنار گذاشته می‌شود.
            DateTime monthStart = startDate.Date == startMonth.Date
                ? startMonth
                : GetNextPersianMonthStart(startMonth, pc);
            DateTime currentMonthStart = GetPersianMonthStart(asOfDate, pc);

            var minimumSettings = db.MinimumPensionSettings
                .Where(x => x.EffectiveFrom <= asOfDate)
                .OrderBy(x => x.EffectiveFrom)
                .ToList();

            var baseChanges = db.T_MostamaryMablagh
                .Where(x => x.MostamaryMablagh_IdRefOzvCode == member.Id &&
                            x.MostamaryMablagh_DateStart.HasValue)
                .OrderBy(x => x.MostamaryMablagh_DateStart)
                .ToList();

            var obligations = new List<Obligation>();
            while (monthStart <= currentMonthStart)
            {
                DateTime nextMonthStart = GetNextPersianMonthStart(monthStart, pc);
                DateTime dueDate = nextMonthStart.AddDays(-1).Date;

                // ماه جاری نیز برای تخصیص پرداخت‌های همان ماه ساخته می‌شود؛
                // اما تا پایان ماه در شمارش تأخیر وارد نخواهد شد.
                decimal expected = 500000m;
                var minimum = minimumSettings
                    .Where(x => x.EffectiveFrom.Date <= monthStart.Date)
                    .OrderByDescending(x => x.EffectiveFrom)
                    .FirstOrDefault();
                if (minimum != null) expected = Convert.ToDecimal(minimum.MinimumAmount);

                var baseForMonth = baseChanges
                    .Where(x => x.MostamaryMablagh_DateStart.Value.Date <= monthStart.Date)
                    .OrderByDescending(x => x.MostamaryMablagh_DateStart)
                    .FirstOrDefault();
                if (baseForMonth != null && baseForMonth.MostamaryMablagh_Mablagh.HasValue)
                    expected = Math.Max(expected, Convert.ToDecimal(baseForMonth.MostamaryMablagh_Mablagh.Value));

                if (expected > 0m)
                {
                    obligations.Add(new Obligation
                    {
                        DueDate = dueDate,
                        Amount = expected,
                        PaidAmount = 0m,
                        PaidDate = null
                    });
                }

                monthStart = nextMonthStart;
            }

            if (obligations.Count == 0) return 0;

            DateTime paymentStart = monthStart.Date;
            DateTime endOfDay = asOfDate.Date.AddDays(1).AddTicks(-1);
            var payments = db.G_M_Pays
                .Where(x => x.IdRefOzv == member.Id &&
                            x.MostamariMablag > 0 &&
                            (x.IsAfzayesh == null || x.IsAfzayesh != true) &&
                            x.PayDate.HasValue && x.PayDate >= paymentStart && x.PayDate <= endOfDay)
                .OrderBy(x => x.PayDate)
                .ThenBy(x => x.Id)
                .ToList();

            // چون جدول پرداخت، ماهِ مورد پوشش را جداگانه نگهداری نمی‌کند، پرداخت‌ها
            // به ترتیب تاریخ به قدیمی‌ترین ماهِ تسویه‌نشده تخصیص داده می‌شوند.
            foreach (var payment in payments)
            {
                decimal remaining = Convert.ToDecimal(payment.MostamariMablag.Value);
                foreach (var month in obligations)
                {
                    if (remaining <= 0m) break;
                    decimal due = month.Amount - month.PaidAmount;
                    if (due <= 0m) continue;

                    decimal applied = Math.Min(remaining, due);
                    month.PaidAmount += applied;
                    remaining -= applied;

                    if (month.PaidAmount >= month.Amount && !month.PaidDate.HasValue)
                        month.PaidDate = payment.PayDate.Value.Date;
                }
            }

            return obligations.Count(x =>
                x.DueDate < asOfDate &&
                (x.PaidAmount < x.Amount || (x.PaidDate.HasValue && x.PaidDate.Value.Date > x.DueDate)));
        }

        private static DateTime GetPersianMonthStart(DateTime date, PersianCalendar pc)
        {
            return pc.ToDateTime(pc.GetYear(date), pc.GetMonth(date), 1, 0, 0, 0, 0);
        }

        private static DateTime GetNextPersianMonthStart(DateTime monthStart, PersianCalendar pc)
        {
            int year = pc.GetYear(monthStart);
            int month = pc.GetMonth(monthStart) + 1;
            if (month > 12) { month = 1; year++; }
            return pc.ToDateTime(year, month, 1, 0, 0, 0, 0);
        }
    }
}

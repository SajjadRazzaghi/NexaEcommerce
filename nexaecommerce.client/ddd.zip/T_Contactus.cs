namespace MVCSandoogh
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_Contactus
    {
        [Key]
        public long Contactus_ID { get; set; }

        [StringLength(4000)]
        public string Contactus_Text { get; set; }

        [StringLength(300)]
        public string Contactus_FName { get; set; }

        [StringLength(300)]
        public string Contactus_LName { get; set; }

        [StringLength(1000)]
        public string Contactus_Mobile { get; set; }

        [StringLength(1000)]
        public string Contactus_Email { get; set; }

        public DateTime? Contactus_Date { get; set; }
    }
}

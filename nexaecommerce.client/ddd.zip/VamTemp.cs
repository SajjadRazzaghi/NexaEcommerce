namespace MVCSandoogh
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("VamTemp")]
    public partial class VamTemp
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        public int? IdRefNoeVam { get; set; }

        public int? IdRefOzv { get; set; }

        [StringLength(10)]
        public string VamDate { get; set; }

        public double? VamMablag { get; set; }

        public double? VamMablagKhales { get; set; }

        public double? Karmozd { get; set; }

        public int? TedadAgsat { get; set; }

        [StringLength(10)]
        public string AvlinGestDate { get; set; }

        public double? GestMablag { get; set; }

        public int? SanadNo { get; set; }

        public int? SanadOkNo { get; set; }

        [Key]
        [Column(Order = 1)]
        public bool EtmamVam { get; set; }

        [StringLength(50)]
        public string LName { get; set; }

        [StringLength(50)]
        public string FName { get; set; }

        [StringLength(50)]
        public string FatherName { get; set; }

        [StringLength(12)]
        public string MelliCode { get; set; }

        [StringLength(250)]
        public string Comment { get; set; }

        [StringLength(50)]
        public string CheckOzv { get; set; }

        [StringLength(50)]
        public string HesabNo { get; set; }

        [StringLength(50)]
        public string BankName { get; set; }

        [StringLength(50)]
        public string CheckVam { get; set; }

        [StringLength(50)]
        public string HesabNoVam { get; set; }
    }
}

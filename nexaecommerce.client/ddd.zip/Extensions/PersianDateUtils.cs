﻿using BitPayDll;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;

using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Web.Security;
using MVCSandoogh.SmsEspir;
using System.Data;
using System.Collections;
using PIDCoSmsPackage;
using PIDCoSmsPackage.Model;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using System.Net;
using System.Text;
using System.IO;

namespace MVCSandoogh.Extensions
{
    public class Employee
    {
        public string idGet { get; set; }
        public string transId { get; set; }
        public string amount { get; set; }
        public string date { get; set; }

        public double? factor { get; set; }
        public string ghest { get; set; }

    }

    public class Root
    {
        public List<Employee> employees { get; set; }
    }
   

    public static class PersianDateUtils
    {
        public static string inconsistency(string api, string kipa)
        {
            string URI = "https://bitpay.ir/payment/inconsistency";
            WebRequest webRequest = WebRequest.Create(URI);

            webRequest.Method = "POST";
            webRequest.ContentType = "application/x-www-form-urlencoded";

            string parameters = "api=" + api + "&kipa=" + kipa;
            byte[] bytes = Encoding.UTF8.GetBytes(parameters);

            webRequest.ContentLength = bytes.Length;
            Stream dataStream = webRequest.GetRequestStream();
            dataStream.Write(bytes, 0, bytes.Length);
            dataStream.Close();

            WebResponse webResponse = webRequest.GetResponse();
            dataStream = webResponse.GetResponseStream();
            StreamReader reader = new StreamReader(dataStream);
            string responseFields = reader.ReadToEnd();
            reader.Close();

            string result = "-1";

            try
            {
                result = responseFields.ToString();

            }
            catch
            {
                return "-1";
            }

            return result;
        }
        public static List<Employee> GetMoghaieratBitpay(string data="")
        {
            SandooghModel db = new SandooghModel();
            string api = "7d99b-eab22-ed6ac-724d5-c7e816bbb3a391068d53a88c8df3";
            string kipa = "843004";


            // string myJsonResponse = @"{'employees':[{'idGet':'15832411','transId':'15837733','amount':'8083333','date':'2023\/ 02\/ 19 08:29:17'},{'idGet':'15832567','transId':'15837889','amount':'2000000','date':'2023\/ 02\/ 19 08:59:37'},{'idGet':'15833197','transId':'15838519','amount':'4000000','date':'2023\/ 02\/ 19 10:20:21'},{'idGet':'15833271','transId':'15838593','amount':'32475000','date':'2023\/ 02\/ 19 10:28:24'},{'idGet':'15833295','transId':'15838617','amount':'22500000','date':'2023\/ 02\/ 19 10:30:16'},{'idGet':'15833361','transId':'15838683','amount':'4124998','date':'2023\/ 02\/ 19 10:35:04'},{'idGet':'15833391','transId':'15838713','amount':'500000','date':'2023\/ 02\/ 19 10:37:16'},{'idGet':'15833417','transId':'15838739','amount':'4500000','date':'2023\/ 02\/ 19 10:39:01'},{'idGet':'15833647','transId':'15838969','amount':'1000000','date':'2023\/ 02\/ 19 10:57:08'},{'idGet':'15833731','transId':'15839053','amount':'2000000','date':'2023\/ 02\/ 19 11:03:44'},{'idGet':'15833859','transId':'15839181','amount':'15250000','date':'2023\/ 02\/ 19 11:12:52'},{'idGet':'15834403','transId':'15839725','amount':'1000000','date':'2023\/ 02\/ 19 11:46:46'},{'idGet':'15834733','transId':'15840055','amount':'3875000','date':'2023\/ 02\/ 19 12:10:51'},{'idGet':'15835235','transId':'15840557','amount':'2100000','date':'2023\/ 02\/ 19 12:51:30'},{'idGet':'15835445','transId':'15840767','amount':'4000000','date':'2023\/ 02\/ 19 13:08:27'},{'idGet':'15836235','transId':'15841557','amount':'5916666','date':'2023\/ 02\/ 19 14:18:06'},{'idGet':'15836249','transId':'15841571','amount':'5583333','date':'2023\/ 02\/ 19 14:19:55'},{'idGet':'15837551','transId':'15842873','amount':'2725000','date':'2023\/ 02\/ 19 16:29:56'},{'idGet':'15838139','transId':'15843461','amount':'1000000','date':'2023\/ 02\/ 19 17:30:10'},{'idGet':'15839307','transId':'15844629','amount':'6066666','date':'2023\/ 02\/ 19 19:04:57'},{'idGet':'15839689','transId':'15845011','amount':'2000000','date':'2023\/ 02\/ 19 19:34:41'},{'idGet':'15839875','transId':'15845197','amount':'6750000','date':'2023\/ 02\/ 19 19:50:19'},{'idGet':'15840201','transId':'15845523','amount':'4000000','date':'2023\/ 02\/ 19 20:21:29'},{'idGet':'15840431','transId':'15845753','amount':'2000000','date':'2023\/ 02\/ 19 20:44:30'},{'idGet':'15840807','transId':'15846129','amount':'1000000','date':'2023\/ 02\/ 19 21:15:13'},{'idGet':'15841413','transId':'15846735','amount':'2333333','date':'2023\/ 02\/ 19 22:03:04'},{'idGet':'15841441','transId':'15846763','amount':'2333333','date':'2023\/ 02\/ 19 22:06:08'},{'idGet':'15841699','transId':'15847021','amount':'500000','date':'2023\/ 02\/ 19 22:24:36'},{'idGet':'15842469','transId':'15847791','amount':'2777777','date':'2023\/ 02\/ 19 23:22:41'},{'idGet':'15842863','transId':'15848185','amount':'2000000','date':'2023\/ 02\/ 19 23:51:14'},{'idGet':'15844375','transId':'15849697','amount':'2000000','date':'2023\/ 02\/ 20 07:13:22'},{'idGet':'15844757','transId':'15850079','amount':'2000000','date':'2023\/ 02\/ 20 08:42:22'},{'idGet':'15844773','transId':'15850095','amount':'2000000','date':'2023\/ 02\/ 20 08:43:00'},{'idGet':'15844907','transId':'15850229','amount':'2000000','date':'2023\/ 02\/ 20 09:02:15'},{'idGet':'15844947','transId':'15850269','amount':'5266664','date':'2023\/ 02\/ 20 09:08:01'},{'idGet':'15845231','transId':'15850553','amount':'500000','date':'2023\/ 02\/ 20 09:45:18'},{'idGet':'15845625','transId':'15850947','amount':'2000000','date':'2023\/ 02\/ 20 10:32:43'},{'idGet':'15846175','transId':'15851497','amount':'2000000','date':'2023\/ 02\/ 20 11:22:03'},{'idGet':'15846455','transId':'15851777','amount':'6375000','date':'2023\/ 02\/ 20 11:47:06'},{'idGet':'15847127','transId':'15852449','amount':'2750000','date':'2023\/ 02\/ 20 12:48:39'},{'idGet':'15847181','transId':'15852503','amount':'5841666','date':'2023\/ 02\/ 20 12:51:46'},{'idGet':'15847219','transId':'15852541','amount':'1000000','date':'2023\/ 02\/ 20 12:55:49'},{'idGet':'15847253','transId':'15852575','amount':'2000000','date':'2023\/ 02\/ 20 12:59:09'},{'idGet':'15847299','transId':'15852621','amount':'1000000','date':'2023\/ 02\/ 20 13:01:59'},{'idGet':'15847875','transId':'15853197','amount':'1000000','date':'2023\/ 02\/ 20 13:50:40'},{'idGet':'15847889','transId':'15853211','amount':'2000000','date':'2023\/ 02\/ 20 13:52:20'},{'idGet':'15848293','transId':'15853615','amount':'6750000','date':'2023\/ 02\/ 20 14:23:53'},{'idGet':'15848507','transId':'15853829','amount':'4000000','date':'2023\/ 02\/ 20 14:38:01'},{'idGet':'15848773','transId':'15854095','amount':'8000000','date':'2023\/ 02\/ 20 15:06:56'},{'idGet':'15849217','transId':'15854539','amount':'2000000','date':'2023\/ 02\/ 20 15:45:21'},{'idGet':'15851915','transId':'15857237','amount':'8583333','date':'2023\/ 02\/ 20 20:16:12'},{'idGet':'15852087','transId':'15857409','amount':'8125000','date':'2023\/ 02\/ 20 20:30:47'},{'idGet':'15852123','transId':'15857445','amount':'2000000','date':'2023\/ 02\/ 20 20:34:15'},{'idGet':'15853555','transId':'15858877','amount':'5500000','date':'2023\/ 02\/ 20 22:30:17'},{'idGet':'15853833','transId':'15859155','amount':'2000000','date':'2023\/ 02\/ 20 22:57:09'},{'idGet':'15856235','transId':'15861557','amount':'2000000','date':'2023\/ 02\/ 21 07:54:57'},{'idGet':'15856949','transId':'15862271','amount':'4000000','date':'2023\/ 02\/ 21 09:38:58'},{'idGet':'15857047','transId':'15862369','amount':'2500000','date':'2023\/ 02\/ 21 09:51:19'},{'idGet':'15857323','transId':'15862645','amount':'9769166','date':'2023\/ 02\/ 21 10:20:16'},{'idGet':'15864385','transId':'15869707','amount':'2000000','date':'2023\/ 02\/ 21 21:27:27'},{'idGet':'15864459','transId':'15869781','amount':'2000000','date':'2023\/ 02\/ 21 21:32:59'},{'idGet':'15864689','transId':'15870011','amount':'2000000','date':'2023\/ 02\/ 21 21:51:34'},{'idGet':'15865181','transId':'15870503','amount':'2000000','date':'2023\/ 02\/ 21 22:37:02'},{'idGet':'15868057','transId':'15873379','amount':'5400000','date':'2023\/ 02\/ 22 09:05:08'},{'idGet':'15868139','transId':'15873461','amount':'2000000','date':'2023\/ 02\/ 22 09:21:42'},{'idGet':'15868525','transId':'15873847','amount':'11062500','date':'2023\/ 02\/ 22 10:05:40'},{'idGet':'15868771','transId':'15874093','amount':'8195000','date':'2023\/ 02\/ 22 10:33:26'},{'idGet':'15868799','transId':'15874121','amount':'2000000','date':'2023\/ 02\/ 22 10:37:16'}]}";
            string myJsonResponse = inconsistency(api,kipa);
            // Object json1 = JObject.Parse(myJsonResponse);
            try
            {
                myJsonResponse = @"{'employees':" + myJsonResponse + "}";
                var myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
                var orders = new List<Employee>();
                foreach (var k in myDeserializedClass.employees)
                {
                    BitPay bitpay = new BitPay();
                    float trans = float.Parse(k.transId);
                   /* double? factorid = (from e in db.bitpayorders where e.tranaction == trans ||e.date==k.date select e.factor).FirstOrDefault();
                    long orderid = (long)factorid;*/
                    var orderrr= (from e in db.T_orders where e.id_get.ToString() == k.idGet select e).FirstOrDefault();
                    var isghest = orderrr.isghest;
                    k.factor = orderrr.Orderid;
                    Employee em = new Employee();
                    if (isghest) em.ghest = "1"; else em.ghest = "0";
                    em.date = k.date;
                    em.factor = k.factor;
                    em.amount = k.amount;
                    em.idGet = k.idGet;
                    em.transId = k.transId;
                    orders.Add(em);

                }


                return orders;
            }
            catch
            {
                return null;
            }

        }

        public static string ToPersianDate (this DateTime date)
        {
            var dateTime = new DateTime(date.Year, date.Month, date.Day, new GregorianCalendar());
            var persianCalendar = new PersianCalendar();
            return persianCalendar.GetYear(dateTime) + "/" +
                   persianCalendar.GetMonth(dateTime).ToString("00") + "/" +
                   persianCalendar.GetDayOfMonth(dateTime).ToString("00");
        }

        public static DateTime? ToMilady(this string PersianDate)
        {
            try
            {
                var persianCalendar = new PersianCalendar();
             
                return new DateTime(int.Parse(PersianDate.Split(new char[] {'/'})[0]),int.Parse( PersianDate.Split(new char[] { '/' })[1]),int.Parse( PersianDate.Split(new char[] { '/' })[2]), persianCalendar);
            }
            catch
            {
                return null;
            }
          
        }
        public static DateTime? ToOneYearBeforeMilady(this string PersianDate)
        {
            try
            {
                var persianCalendar = new PersianCalendar();

                return new DateTime(int.Parse(PersianDate.Split(new char[] { '/' })[0])-1, int.Parse(PersianDate.Split(new char[] { '/' })[1]), int.Parse(PersianDate.Split(new char[] { '/' })[2]), persianCalendar);
            }
            catch
            {
                return null;
            }

        }


    }
}
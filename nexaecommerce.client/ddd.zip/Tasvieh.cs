namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Tasvieh")]
    public partial class Tasvieh
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? IdRefOzv { get; set; }

     

        public double? MostamariMablag { get; set; }

        public int? Nahveh_P { get; set; }

        [StringLength(200)]
        public string Fish_No { get; set; }


        public int? SanadNo { get; set; }

        public int? SanadOkNo { get; set; }

      


        [StringLength(500)]
        public string Comment { get; set; }

        public DateTime? PayDate { get; set; }

        public string Sanads { get; set; }
        public virtual Nahveh_PTasvie Nahveh_PTasvie { get; set; }

        public virtual T_OzvCode T_OzvCode { get; set; }
    }
}

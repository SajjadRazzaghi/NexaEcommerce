﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Web.Services;

namespace MVCSandoogh.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AccountingController : Controller
    {
        // GET: Accounting
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Years()
        {
            return View();
        }
        public ActionResult SelectYear()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetYears(string sidx, string sord)
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Years.ToList();

         
            var totalRecords = list.Count;
       

            var productsQuery = list.AsQueryable();
          
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                          
                                            .ToList();
            var productsData = new JqGridData
            {
               
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Year_ID,
                    RowCells = new List<object>
                               {
                      product.Year_ID.ToString(),product.Year_Name,product.Year_startdate!=null?((DateTime)product.Year_startdate).ToPersianDate():"",
                      product.Year_Enddate!=null?((DateTime)product.Year_Enddate).ToPersianDate():"",
                      product. Year_Close!=null?product. Year_Close.ToString():"False",product.Year_Isactive!=null?product.Year_Isactive.ToString():"False" }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GenerateStartSanad(string id)
        {

            SandooghModel db = new SandooghModel();
            if (id == null)
                return Json(false);
            int idd = -1;
            try
            {
                idd = int.Parse(id);
            }
            catch
            {

            }
            var postData = (from e in db.Acc_Years where e.Year_ID == idd select e).FirstOrDefault();

            if (postData.Year_Close == false && (postData.ShSanadEftetahie == null||postData.ShSanadEftetahie== ""))
            {
                int beforyear = int.Parse(postData.Year_Name) - 1;
                string bfy = beforyear.ToString();
                var BeforYear = (from e in db.Acc_Years where e.Year_Name == bfy select e).FirstOrDefault();
                var beforekhtetamie = BeforYear.ShSanadEkhtetamieh;
                if (beforekhtetamie != null && beforekhtetamie.ToString() != "")
                {
                    int year = beforyear;
                    string startyear = year + "/01/01";
                    string endyear = (year + 1) + "/01/01";
                    DateTime datestart = (DateTime)startyear.ToMilady();
                    DateTime dateend = (DateTime)endyear.ToMilady();
                    if (beforekhtetamie.ToString() == "" || beforekhtetamie == null)
                    {
                        return Json(-1, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {

                        long s1 = long.Parse(beforekhtetamie);
                        var list = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).ToList();
                        list = (from s in list where s.Sanad_No == s1 select s).ToList();

                        string startyear1 = postData.Year_Name + "/01/01";
                        string endyear1 = ((int.Parse(postData.Year_Name)) + 1) + "/01/01";
                        DateTime datestart1 = (DateTime)startyear1.ToMilady();
                        DateTime dateend1 = (DateTime)endyear1.ToMilady();
                        var maxValue = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart1) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend1) select e).Max(x => x.Sanad_No);
                        maxValue = maxValue + 1;
                        if (maxValue == null)
                            maxValue = 1;
                        foreach (AccSanad_B san in list)
                        {



                            AccSanad_B NewSanad = new AccSanad_B();
                            NewSanad.Sanad_No = maxValue;
                            NewSanad.Articl_Comment = "سند افتتاحیه سال  " + postData.Year_Name;
                            NewSanad.Bedhkar = san.Bestankar;
                            NewSanad.Bestankar = san.Bedhkar;
                            NewSanad.Date_S = datestart1;
                            NewSanad.Group = san.Group;
                            NewSanad.Sanad_Tafsili1 = san.Sanad_Tafsili1;

                            NewSanad.Tafsili = san.Tafsili;
                            NewSanad.Moein = san.Moein;
                            NewSanad.Kol = san.Kol;
                            db.AccSanad_B.Add(NewSanad);
                        }
                        db.SaveChanges();

                        postData.ShSanadEftetahie = maxValue.ToString();
                        postData.Year_Close = false;
                        postData.Year_startdate = DateTime.Now;

                        db.Entry(postData).State = EntityState.Modified;
                        db.SaveChanges();
                        return Json(true);
                    }
                }
            }
            return Json(-1, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GenerateEndinationSanad(string id)
        {

            try
            {

                string command = @"update
            AccSanad_B
            set Sanad_Tafsili1 = 2
            WHERE([Group] = N'3') AND(Kol = N'311')  and Sanad_Tafsili1 is null

            update
            AccSanad_B

            set Sanad_Tafsili1 = 1
            WHERE(([Group] = N'1') AND(Kol = N'111') ) and Sanad_Tafsili1 is null

            update
            AccSanad_B

            set Sanad_Tafsili1 = 4
             WHERE([Group] = N'7') AND(Kol = N'713') AND(Moein = N'312')   and Sanad_Tafsili1 is null

           update
            AccSanad_B
          set Sanad_Tafsili1 = 2
             WHERE([Group] = N'1') AND(Kol = N'112') AND((Moein = N'001') or(Moein = N'002') )  and Sanad_Tafsili1 is null

 update
            AccSanad_B

            set Sanad_Tafsili1 = 1
WHERE([Group] = N'3') AND(Kol = N'314') AND(Moein = N'20') and Sanad_Tafsili1 is null


  update
            AccSanad_B

            set Sanad_Tafsili1 = 8
WHERE([Group] = N'5') AND(Kol = N'512')  and Sanad_Tafsili1 is null


    update
            AccSanad_B

            set Sanad_Tafsili1 = 4
WHERE([Group] = N'7') AND(Kol = N'715')  and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 8
WHERE([Group] = N'6') AND((Kol = N'613') or(kol = N'611'))  and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 4
WHERE([Group] = N'7') AND(Kol = N'711') and((Moein = N'124') or(Moein = N'119') ) and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 4
WHERE([Group] = N'7') AND(Kol = N'735') and(Moein = N'598') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 7
WHERE([Group] = N'2') AND(Kol = N'215') and(Moein = N'516') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 11
WHERE([Group] = N'7') AND(Kol = N'711') and(Moein = N'128') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 10
WHERE([Group] = N'7') AND(Kol = N'711') and(Moein = N'121') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 12
WHERE([Group] = N'7') AND(Kol = N'711') and(Moein = N'126') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 4
WHERE([Group] = N'7') AND(Kol = N'711') and(Moein = N'127') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 4
WHERE([Group] = N'7') AND(Kol = N'736') and(Moein = N'001') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 8
WHERE([Group] = N'6') AND(Kol = N'620') and(Moein = N'001') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 7
WHERE([Group] = N'2') AND(Kol = N'211') and(Moein = N'116') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 4
WHERE([Group] = N'1') AND(Kol = N'114') and(Moein = N'001') and Sanad_Tafsili1 is null

update
            AccSanad_B

            set Sanad_Tafsili1 = 7
            WHERE([Group] = N'2') AND(Kol = N'211') and(Moein = N'154') and Sanad_Tafsili1 is null";
                DataGatheration gath = new DataGatheration();
                gath.ExecuteNonQueryWithComand(command);

            }
            catch
            {

            }
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (id == null)
                return Json(false);
            int idd = -1;
            try
            {
                idd = int.Parse(id);
            }
            catch
            {

            }
            var postData = (from e in db.Acc_Years where e.Year_ID == idd select e).FirstOrDefault();

            if (postData.ShSanadEkhtetamieh == null || postData.ShSanadEkhtetamieh == "")
            {
                //تولید تراز تفصیلی

                string startyear = postData.Year_Name + "/01/01";
                string endyear = (int.Parse(postData.Year_Name) + 1) + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();

                //تولید شماره سند
                DateTime dateend_1 = dateend.AddDays(-1);

                var maxValue = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).Max(x => x.Sanad_No);
                maxValue = maxValue + 1;


                //بانکها
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol=="111" && e.Moein!="111" && e.Moein != "115" select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }




                //وام عادی
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "112" && e.Moein == "001"  select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                //وام ازدواج
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "112" && e.Moein == "002" select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                //وام اظطراری
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "112" && e.Moein == "003" select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                // دارایی
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "211" && ( e.Moein == "116"||e.Moein=="154") select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                //دارائی های نامشهود
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "215"  select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                //مستمری
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "311" && (e.Moein == "003"||e.Moein=="002") select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                //حقوق صاحبان سهام
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "511" && e.Moein == "111" select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                //مجامع
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "314" && e.Moein == "21"&&e.Tafsili=="10014" select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                //ذخایر
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Kol == "512" && (e.Moein == "212"|| e.Moein == "213" || e.Moein == "214") select e);

                    var list2 = sanad
                    .GroupBy(l => l.Kol + "_" + l.Moein + "_" + l.Tafsili + "_" + l.Group + "_" + l.Sanad_Tafsili1)
                    .Select(cl => new
                    {
                        code = cl.Key,
                        bed = cl.Sum(c => c.Bedhkar),
                        bes = cl.Sum(c => c.Bestankar)

                    }).ToList();
                    var list = (from l in list2
                                join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                                select new
                                {
                                    id = k.Tafsili2_Id,
                                    tafsili1 = l.code.Split('_')[4],
                                    codegroup = l.code.Split('_')[3],
                                    codekol = l.code.Split('_')[0],
                                    codemoein = l.code.Split('_')[1],
                                    codetafsili = l.code.Split('_')[2],
                                    bedehkar = l.bed,
                                    bestankar = l.bes,
                                    kolname = k.Tafsili2_Comment,
                                    mandebedehkar = l.bed - l.bes > 0 ? (l.bed - l.bes) : 0,
                                    mandebestankar = l.bes - l.bed > 0 ? (l.bes - l.bed) : 0
                                }).ToList();



                    list = (from e in list where e.mandebedehkar > 0 || e.mandebestankar > 0 select e).ToList();

                    var productsQuery = list.AsQueryable().OrderBy("codemoein asc,codetafsili asc");

                    var productsList = productsQuery.ToList();



                    ////////////



                    var finallist = productsList.ToList();

                    foreach (var tafsili in finallist)
                    {
                        AccSanad_B NewSanad = new AccSanad_B();
                        NewSanad.Sanad_No = maxValue;
                        NewSanad.Articl_Comment = "سند اختتامیه سال  " + postData.Year_Name;
                        NewSanad.Bedhkar = tafsili.mandebestankar;
                        NewSanad.Bestankar = tafsili.mandebedehkar;
                        NewSanad.Date_S = dateend_1;
                        NewSanad.Group = tafsili.codegroup;
                        try
                        {
                            NewSanad.Sanad_Tafsili1 = int.Parse(tafsili.tafsili1);
                        }
                        catch
                        {

                        }
                        NewSanad.Tafsili = tafsili.codetafsili;
                        NewSanad.Moein = tafsili.codemoein;
                        NewSanad.Kol = tafsili.codekol;
                        db.AccSanad_B.Add(NewSanad);
                    }
                    db.SaveChanges();
                }

                postData.ShSanadEkhtetamieh = maxValue.ToString();
                postData.Year_Close = true;
                postData.Year_Enddate = DateTime.Now;

                db.Entry(postData).State = EntityState.Modified;
                db.SaveChanges();
                return Json(true);
            }
            else//if(shsanadeftetahie ==null)
                return Json(false);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult ActivateYear(string id)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (id == null)
                return Json(false);
            int idd = -1;
            try
            {
                idd = int.Parse(id);
            }
            catch
            {

            }
           
                var list = (from e in db.Acc_Years where e.Year_Isactive == true select e).ToList();
                foreach (var t in list)
                {
                    t.Year_Isactive = false;
                    db.Entry(t).State = EntityState.Modified;
                 
                }
             db.SaveChanges();
            var postData = (from e in db.Acc_Years where e.Year_ID == idd select e).FirstOrDefault();
            postData.Year_Isactive = true;
            db.Entry(postData).State = EntityState.Modified;


            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditYears(Acc_Year postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            db.Entry(postData).State = EntityState.Modified;
            if(postData.Year_Isactive==true)
            {
                var list = (from e in db.Acc_Years where e.Year_Isactive == true && e.Year_ID!=postData.Year_ID select e).ToList();
                foreach(var t in list)
                {
                    t.Year_Isactive = false;
                    db.Entry(t).State = EntityState.Modified;
                    db.SaveChanges();
                }
            }
            
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddYear(Acc_Year postData)
        {
            SandooghModel db = new SandooghModel();
         
            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            postData.Year_startdate = DateTime.Now;
            db.Acc_Years.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteYear(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.Acc_Years.FirstOrDefault(x => x.Year_ID == idd);
            if (product == null)
                return Json(false);

            db.Acc_Years.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        public ActionResult TarazKol()
        {
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            return View();

        }
        public ActionResult TarazKol2()
        {
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive == true select e.Year_Name).FirstOrDefault();
            return View();

        }
        public ActionResult TarazMoein(string id="",string g="")
        {
            ViewBag.id = id;
            ViewBag.g = g;
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
     

            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
   
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")";
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;
          
            return View();
         

        }
        public ActionResult TarazTafsili(string id="",string g="",string k="")
        {
           

            ViewBag.id = id;
            ViewBag.g = g;
            ViewBag.k = k;


            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
            List<SelectListItem> MoeinList = new List<SelectListItem>();
         
            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
            List<Acc_Moein> moeinList = db.Acc_Moein.ToList();
         
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")";
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;
            foreach (Acc_Moein moein in moeinList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value =moein.Code_Group+moein.Code_Kol+"_"+ moein.Code_Moein;
                sli.Text = moein.Comment + "(" + moein.Code_Moein + ")";
                MoeinList.Add(sli);
            }
            ViewBag.moeins = MoeinList;
         
        
            return View();
        }

        
      public ActionResult DaftarRooznameh()
        {
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive == true select e.Year_Name).FirstOrDefault();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
            List<SelectListItem> MoeinList = new List<SelectListItem>();
            List<SelectListItem> TafsiliList = new List<SelectListItem>();
            List<SelectListItem> TafsiliGroupList = new List<SelectListItem>();

            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
            List<Acc_Moein> moeinList = db.Acc_Moein.ToList();
            List<Acc_Tafsil1> tafsiligroupList = db.Acc_Tafsil1.ToList();
            List<Acc_Tafsili2> tafsiliList = db.Acc_Tafsili2.ToList();
            foreach (Acc_Tafsil1 t1 in tafsiligroupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = t1.Tafsil1_ID.ToString();
                sli.Text = t1.Tafsil1_Comment + "(" + t1.Tafsil1_ID + ")";
                TafsiliGroupList.Add(sli);
            }
            ViewBag.tafsiligroup = TafsiliGroupList;
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")";
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;

            foreach (Acc_Moein moein in moeinList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = moein.Code_Moein;
                sli.Text = moein.Comment + "(" + moein.Code_Moein + ")";
                MoeinList.Add(sli);
            }
            ViewBag.moeins = MoeinList;
            foreach (Acc_Tafsili2 tafsili2 in tafsiliList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = tafsili2.Tafsili2_Code/*.ToString()1212*/;
                sli.Text = tafsili2.Tafsili2_Comment + "(" + tafsili2.Tafsili2_Code + ")";
                TafsiliList.Add(sli);
            }
            ViewBag.tafsilis = TafsiliList;
            return View();
        }

        public ActionResult DaftarKol()
        {
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
           /* List<SelectListItem> MoeinList = new List<SelectListItem>();
            List<SelectListItem> TafsiliList = new List<SelectListItem>();
            List<SelectListItem> TafsiliGroupList = new List<SelectListItem>();*/

            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
         /*   List<Acc_Moein> moeinList = db.Acc_Moein.ToList();
            List<Acc_Tafsil1> tafsiligroupList = db.Acc_Tafsil1.ToList();
            List<Acc_Tafsili2> tafsiliList = db.Acc_Tafsili2.ToList();
            foreach (Acc_Tafsil1 t1 in tafsiligroupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = t1.Tafsil1_ID.ToString();
                sli.Text = t1.Tafsil1_Comment + "(" + t1.Tafsil1_ID + ")";
                TafsiliGroupList.Add(sli);
            }
            ViewBag.tafsiligroup = TafsiliGroupList;*/
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")";
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;
          /*  foreach (Acc_Moein moein in moeinList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = moein.Code_Moein;
                sli.Text = moein.Comment + "(" + moein.Code_Moein + ")";
                MoeinList.Add(sli);
            }
            ViewBag.moeins = MoeinList;
            foreach (Acc_Tafsili2 tafsili2 in tafsiliList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = tafsili2.Tafsili2_Code.ToString();
                sli.Text = tafsili2.Tafsili2_Comment + "(" + tafsili2.Tafsili2_Code + ")";
                TafsiliList.Add(sli);
            }
            ViewBag.tafsilis = TafsiliList;*/
            return View();
        }
        public ActionResult DaftarMoein()
        {
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
            List<SelectListItem> MoeinList = new List<SelectListItem>();
           /*  List<SelectListItem> TafsiliList = new List<SelectListItem>();*/
           
            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
              List<Acc_Moein> moeinList = db.Acc_Moein.ToList();
              /*  List<Acc_Tafsil1> tafsiligroupList = db.Acc_Tafsil1.ToList();
               List<Acc_Tafsili2> tafsiliList = db.Acc_Tafsili2.ToList();
               foreach (Acc_Tafsil1 t1 in tafsiligroupList)
               {
                   SelectListItem sli = new SelectListItem();
                   sli.Value = t1.Tafsil1_ID.ToString();
                   sli.Text = t1.Tafsil1_Comment + "(" + t1.Tafsil1_ID + ")";
                   TafsiliGroupList.Add(sli);
               }
               ViewBag.tafsiligroup = TafsiliGroupList;*/
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")";
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;
              foreach (Acc_Moein moein in moeinList)
              {
                  SelectListItem sli = new SelectListItem();
                  sli.Value = moein.Code_Moein;
                  sli.Text = moein.Comment + "(" + moein.Code_Moein + ")";
                  MoeinList.Add(sli);
              }
              ViewBag.moeins = MoeinList;
           /*   foreach (Acc_Tafsili2 tafsili2 in tafsiliList)
              {
                  SelectListItem sli = new SelectListItem();
                  sli.Value = tafsili2.Tafsili2_Code.ToString();
                  sli.Text = tafsili2.Tafsili2_Comment + "(" + tafsili2.Tafsili2_Code + ")";
                  TafsiliList.Add(sli);
              }
              ViewBag.tafsilis = TafsiliList;*/
            return View();
        }

        public ActionResult DaftarTafsili()
        {
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
            List<SelectListItem> MoeinList = new List<SelectListItem>();
            List<SelectListItem> TafsiliList = new List<SelectListItem>();

            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
            List<Acc_Moein> moeinList = db.Acc_Moein.ToList();
            List<Acc_Tafsili2> tafsiliList = db.Acc_Tafsili2.ToList();
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")";
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;
            foreach (Acc_Moein moein in moeinList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = moein.Code_Moein;
                sli.Text = moein.Comment + "(" + moein.Code_Moein + ")";
                MoeinList.Add(sli);
            }
            ViewBag.moeins = MoeinList;
               foreach (Acc_Tafsili2 tafsili2 in tafsiliList)
               {
                   SelectListItem sli = new SelectListItem();
                 sli.Value = tafsili2.Tafsili2_Code/*.ToString()1212*/;
               

                sli.Text = tafsili2.Tafsili2_Comment + "(" + tafsili2.Tafsili2_Code + ")";
                   TafsiliList.Add(sli);
               }
               ViewBag.tafsilis = TafsiliList;
            return View();
        }
        public ActionResult GetDaftarTafsiliSumbedbes(string codeaz, string codeta, string azdate, string tadate, string codegroup, string codekol, string codemoein,string codetafsili, string year = "")
        {
            SandooghModel db = new SandooghModel();
            if (codemoein.Contains("_")) codemoein = codemoein.Split('_')[1];
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            var list = (from e in sanad where e.Group == codegroup && e.Kol == codekol && e.Moein == codemoein  &&e.Tafsili==codetafsili select e).ToList();

            long az = 0;
            long ta = long.MaxValue;

            try
            {
                az = long.Parse(codeaz);
            }
            catch
            {

            }
            try
            {
                ta = long.Parse(codeta);
            }
            catch
            {

            }

            list = (from e in list where e.ID >= az && e.ID <= ta select e).ToList();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }
            list = (from e in list where e.Date_S.Date >= azdatei.Date && e.Date_S.Date < tadatei.Date select e).ToList();
            /* list=group*/
            var bed = (from e in list select e.Bedhkar).Sum();
            var bes = (from e in list select e.Bestankar).Sum();



            return Json(new { bed = bed, bes = bes }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetDaftarMoeinSumbedbes(string codeaz, string codeta, string azdate, string tadate, string codegroup, string codekol,string codemoein, string year = "")
        {
            SandooghModel db = new SandooghModel();
            if (codemoein.Contains("_")) codemoein = codemoein.Split('_')[1];

            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            var list = (from e in sanad where e.Group == codegroup && e.Kol == codekol && e.Moein==codemoein select e).ToList();

            long az = 0;
            long ta = long.MaxValue;

            try
            {
                az = long.Parse(codeaz);
            }
            catch
            {

            }
            try
            {
                ta = long.Parse(codeta);
            }
            catch
            {

            }

            list = (from e in list where e.ID >= az && e.ID <= ta select e).ToList();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }
            list = (from e in list where e.Date_S.Date >= azdatei.Date && e.Date_S.Date < tadatei.Date select e).ToList();
            /* list=group*/
            var bed = (from e in list select e.Bedhkar).Sum();
            var bes = (from e in list select e.Bestankar).Sum();



            return Json(new { bed = bed, bes = bes }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetDaftarKolSumbedbes(string codeaz, string codeta, string azdate, string tadate, string codegroup, string codekol, string year = "")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            var list = (from e in sanad where e.Group == codegroup && e.Kol == codekol select e).ToList();

            long az = 0;
            long ta = long.MaxValue;

            try
            {
                az = long.Parse(codeaz);
            }
            catch
            {

            }
            try
            {
                ta = long.Parse(codeta);
            }
            catch
            {

            }

            list = (from e in list where e.ID >= az && e.ID <= ta select e).ToList();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }
            list = (from e in list where e.Date_S.Date >= azdatei.Date&& e.Date_S.Date < tadatei.Date select e).ToList();
            /* list=group*/
            var bed = (from e in list select e.Bedhkar).Sum();
            var bes = (from e in list select e.Bestankar).Sum();



            return Json(new{bed=bed,bes=bes }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetDaftarKol(string sidx, string sord, int page, int rows, string codeaz, string codeta,string azdate, string tadate,string codegroup ,string codekol, string year = "")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            sidx = "";
            sord = "Sanad_No asc,ID asc";
         
            var list =(from e in sanad where e.Group==codegroup && e.Kol== codekol select e).ToList();
            
                long az = 0;
                long ta = long.MaxValue;
            
                try
                {
                    az = long.Parse(codeaz);
                }
                catch
                {

                }
                try
                {
                    ta = long.Parse(codeta);
                }
                catch
                {

                }

                list = (from e in list where e.ID >= az && e.ID <= ta select e).ToList();
                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
                }
                catch
                {

                }
                list = (from e in list where e.Date_S.Date>= azdatei.Date && e.Date_S.Date < tadatei.Date select e).ToList();
           /* list=group*/

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);
            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                         
                                            .ToList();
          
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.ID,
                    RowCells = new List<object>
                               {
                                
                    product.Date_S!=null?((DateTime)product.Date_S).ToPersianDate():"","../../Accounting/Asnad?sanad_no="+product.Sanad_No,product.Sanad_No.ToString()
                    ,product.Articl_Comment,product.Bedhkar==0?"":product.Bedhkar.ToString(),product.Bestankar==0?"":product.Bestankar.ToString(),
                        (product.Bedhkar-product.Bestankar)>0?(product.Bedhkar-product.Bestankar).ToString():"",
                    (product.Bestankar-product.Bedhkar)>0?(product.Bestankar-product.Bedhkar).ToString():"","../../Accounting/Asnad?sanad_no="+product.Sanad_No
                                }
                })).ToList()
            };

            for (int i = 0; i < productsData.Rows.Count; i++)
            {
                if (i > 0)
                {
                    if (productsData.Rows[i].RowCells[4].ToString() != "")//گردش بدهکار
                    {

                        if (productsData.Rows[i - 1].RowCells[6].ToString() != "")//قبلی مانده بدهکار داشت
                        {
                            productsData.Rows[i].RowCells[6] = (long.Parse(productsData.Rows[i - 1].RowCells[6].ToString()) +
                                                                                         long.Parse(productsData.Rows[i].RowCells[4].ToString())).ToString();
                            productsData.Rows[i].RowCells[7] = "";

                        }
                        else
                        if (productsData.Rows[i - 1].RowCells[7].ToString() != "")//اگر قبلی مانده بستانکار داشت
                        {
                            long mandebestankarghabli = long.Parse(productsData.Rows[i - 1].RowCells[7].ToString());
                            long bedehkar = long.Parse(productsData.Rows[i].RowCells[4].ToString());
                            if (bedehkar - mandebestankarghabli >= 0)
                            {
                                productsData.Rows[i].RowCells[6] = bedehkar - mandebestankarghabli;
                                productsData.Rows[i].RowCells[7] = "";

                            }
                            else
                            {
                                productsData.Rows[i].RowCells[6] = "";
                                productsData.Rows[i].RowCells[7] = (mandebestankarghabli - bedehkar).ToString();
                            }
                        }
                        else
                        {
                            productsData.Rows[i].RowCells[6] = long.Parse(productsData.Rows[i].RowCells[4].ToString()).ToString();
                            productsData.Rows[i].RowCells[7] = "";
                        }

                    }
                    else
                    if (productsData.Rows[i].RowCells[5].ToString() != "")//گردش بستانکار
                    {

                        if (productsData.Rows[i - 1].RowCells[7].ToString() != "")//قبلی مانده بستانکار داشت
                        {
                            productsData.Rows[i].RowCells[7] = (long.Parse(productsData.Rows[i - 1].RowCells[7].ToString()) +
                                                                                         long.Parse(productsData.Rows[i].RowCells[5].ToString())).ToString();
                            productsData.Rows[i].RowCells[6] = "";

                        }
                        else
                        if (productsData.Rows[i - 1].RowCells[6].ToString() != "")//اگر قبلی مانده بدهکار داشت
                        {
                            long mandebedehkarghabli = long.Parse(productsData.Rows[i - 1].RowCells[6].ToString());
                            long bestankar = long.Parse(productsData.Rows[i].RowCells[5].ToString());
                            if (mandebedehkarghabli - bestankar >= 0)
                            {
                                productsData.Rows[i].RowCells[6] = mandebedehkarghabli - bestankar;
                                productsData.Rows[i].RowCells[7] = "";

                            }
                            else
                            {
                                productsData.Rows[i].RowCells[6] = "";
                                productsData.Rows[i].RowCells[7] = (bestankar - mandebedehkarghabli).ToString();
                            }
                        }
                        else
                        {
                            productsData.Rows[i].RowCells[7] = long.Parse(productsData.Rows[i].RowCells[5].ToString()).ToString();
                            productsData.Rows[i].RowCells[6] = "";
                        }
                    }

                }
            }
          
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public ActionResult GetTarazTafsili(string sidx, string sord, int page, int rows, string azdate, string tadate, string codegroup, string codekol,string codemoein, string year = "")
        {
            SandooghModel db = new SandooghModel();
            if(codemoein.Contains("_"))
            {
                codemoein = codemoein.Split('_')[1];
            }
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);


            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }


            var list1 = (from e in sanad where e.Group == codegroup && e.Kol == codekol &&e.Moein==codemoein && DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(azdatei) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(tadatei)/**&&kkk e.Tafsili=="13049" or e.Tafsili=="13050"**/ select e).ToList();
            var list2 = list1
.GroupBy(l => l.Kol +"_"+ l.Moein+"_"+l.Tafsili)
.Select(cl => new
{
    code = cl.Key,
    bed = cl.Sum(c => c.Bedhkar),
    bes = cl.Sum(c => c.Bestankar)

}).ToList();
            var list = (from l in list2
                        join k in db.Acc_Tafsili2 on l.code.Split('_')[2] equals (k.Tafsili2_Code/*.ToString()1212*/)
                        select new
                        {
                            id = k.Tafsili2_Id,
                            codekol = l.code.Split('_')[0],
                            codemoein= l.code.Split('_')[1],
                            codetafsili= l.code.Split('_')[2],
                            bedehkar = l.bed,
                            bestankar = l.bes,
                            kolname = k.Tafsili2_Comment
                            

                        }).ToList();

           // var kkk = (from e in list2 where e.bed != e.bes select e).ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);
            var productsQuery = list.AsQueryable();

            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.id,
                    RowCells = new List<object>
                               {

                  product.codekol,  product.codemoein,product.codetafsili,
                    product.kolname,product.bedehkar==0?"":product.bedehkar.ToString(),product.bestankar==0?"":product.bestankar.ToString()
                      ,
                      (product.bedehkar-product.bestankar)>0?(product.bedehkar-product.bestankar).ToString():"",
                    (product.bestankar-product.bedehkar)>0?(product.bestankar-product.bedehkar).ToString():""
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetTarazMoein(string sidx, string sord, int page, int rows, string azdate, string tadate,string codegroup,string codekol, string year = "")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);



            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }


            var list1 = (from e in sanad where e.Group == codegroup && e.Kol == codekol &&  DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(azdatei) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(tadatei) select e).ToList();
            var list2 = list1
.GroupBy(l => l.Kol+ l.Moein)
.Select(cl => new
{
    code = cl.Key,
    bed = cl.Sum(c => c.Bedhkar),
    bes = cl.Sum(c => c.Bestankar)

}).ToList();
            var list = (from l in list2
                        join k in db.Acc_Moein on l.code equals (k.Code_Group+ k.Code_Kol + k.Code_Moein)
                        select new
                        {
                            id = k.Moein_ID,
                            codekol = k.Code_Moein,
                            bedehkar = l.bed,
                            bestankar = l.bes,
                            kolname = k.Comment,
                            codegroup,kol= k.Code_Group + k.Code_Kol

                        }).ToList();

            //var kkk = (from e in list2 where e.bed != e.bes select e).ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);
            var productsQuery = list.AsQueryable();

            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.id,
                    RowCells = new List<object>
                               {
                    product.codekol,
                    product.kolname,product.bedehkar==0?"":product.bedehkar.ToString(),product.bestankar==0?"":product.bestankar.ToString()
                    ,
                      (product.bedehkar-product.bestankar)>0?(product.bedehkar-product.bestankar).ToString():"",
                    (product.bestankar-product.bedehkar)>0?(product.bestankar-product.bedehkar).ToString():"",
                    product.codegroup,product.kol
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
       
        public ActionResult GetMultiTarazKoll(int page, int rows, string azdate, string tadate, string sidx = "asc", string sord = "codekol", string year = "")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }


            var list1 = (from e in sanad where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(azdatei) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(tadatei) select e).ToList();
            var list2 = list1
.GroupBy(l => l.Kol)
.Select(cl => new
{
    code = cl.Key,
    bed = cl.Sum(c => c.Bedhkar),
    bes = cl.Sum(c => c.Bestankar)

}).ToList();
            var list = (from l in list2
                        join k in db.Acc_Kol on l.code equals (k.Code_Group + k.Code_Kol)
                        select new
                        {
                            id = k.Kol_Id,
                            codekol = l.code,
                            bedehkar = l.bed,
                            bestankar = l.bes,
                            kolname = k.Comment,
                            k.Code_Group
                        }).ToList();
            //ghabl
            string startyear1 = (int.Parse(year)-1) + "/01/01";
            string endyear1 = year + "/01/01";
            DateTime datestart1 = (DateTime)startyear1.ToMilady();
            DateTime dateend1 = (DateTime)endyear1.ToMilady();
            var sanad1 = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart1) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend1) select e);

            DateTime azdatei1 = DateTime.MinValue;
            DateTime tadatei1 = DateTime.MaxValue;
            try
            {
                azdatei1 = (DateTime)azdate.ToOneYearBeforeMilady();
            }
            catch
            {

            }
            try
            {
                tadatei1 = ((DateTime)tadate.ToOneYearBeforeMilady()).AddDays(1);
            }
            catch
            {

            }


            var list11 = (from e in sanad1 where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(azdatei1) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(tadatei1) select e).ToList();
            var list21 = list11
.GroupBy(l => l.Kol)
.Select(cl => new
{
    code = cl.Key,
    bed = cl.Sum(c => c.Bedhkar),
    bes = cl.Sum(c => c.Bestankar)

}).ToList();
            var list111 = (from l in list21
                        join k in db.Acc_Kol on l.code equals (k.Code_Group + k.Code_Kol)
                        select new
                        {
                            id = k.Kol_Id,
                            codekol = l.code,
                            bedehkar = l.bed,
                            bestankar = l.bes,
                            kolname = k.Comment,
                            k.Code_Group
                        }).ToList();

            var listfinal= (from l in list111
                            join k in list on l.id equals (k.id)
                            select new
                            {
                                id = k.id,
                                codekol = l.codekol,
                                bedehkar = l.bedehkar,
                                bestankar = l.bestankar,
                                bedehkar1 = k.bedehkar,
                                bestankar1 = k.bestankar,
                                kolname = k.kolname,
                                k.Code_Group
                            }).ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = listfinal.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);
            var productsQuery = listfinal.AsQueryable();

            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.id,
                    RowCells = new List<object>
                               {

                    product.codekol,
                    product.kolname,product.bedehkar==0?"":product.bedehkar.ToString(),product.bestankar==0?"":product.bestankar.ToString(),
                      (product.bedehkar-product.bestankar)>0?(product.bedehkar-product.bestankar).ToString():"",
                    (product.bestankar-product.bedehkar)>0?(product.bestankar-product.bedehkar).ToString():"",product.bedehkar1==0?"":product.bedehkar1.ToString(),product.bestankar1==0?"":product.bestankar1.ToString(),
                      (product.bedehkar1-product.bestankar1)>0?(product.bedehkar1-product.bestankar1).ToString():"",
                    (product.bestankar1-product.bedehkar1)>0?(product.bestankar1-product.bedehkar1).ToString():"",product.Code_Group
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public ActionResult GetTarazKol(int page, int rows,  string azdate, string tadate,string sidx= "asc", string sord = "codekol",string year="")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }

          
           var list1 = (from e in sanad where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(azdatei) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(tadatei) /**kkk&& e.Kol=="512"*/ select e).ToList();
            var list2 = list1
.GroupBy(l => l.Kol)
.Select(cl => new
{
  code = cl.Key,
  bed = cl.Sum(c => c.Bedhkar),
  bes = cl.Sum(c => c.Bestankar)
 
}).ToList();
            var list = (from l in list2
                        join k in db.Acc_Kol on l.code equals (k.Code_Group + k.Code_Kol) select new
                        {
                            id=k.Kol_Id,
                            codekol = l.code,
                            bedehkar = l.bed,
                            bestankar = l.bes,
                            kolname = k.Comment,
                            k.Code_Group
                        }).ToList();
          

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);
            var productsQuery = list.AsQueryable();
        
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.id,
                    RowCells = new List<object>
                               {

                    product.codekol,
                    product.kolname,product.bedehkar==0?"":product.bedehkar.ToString(),product.bestankar==0?"":product.bestankar.ToString(),
                      (product.bedehkar-product.bestankar)>0?(product.bedehkar-product.bestankar).ToString():"",
                    (product.bestankar-product.bedehkar)>0?(product.bestankar-product.bedehkar).ToString():"",product.Code_Group
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        public ActionResult GetDaftarTafsili(string sidx, string sord, int page, int rows, string codeaz, string codeta, string azdate, string tadate, string codegroup, string codekol, string codemoein,string codetafsili, string year = "")
        {
            SandooghModel db = new SandooghModel();
            if (codemoein.Contains("_")) codemoein = codemoein.Split('_')[1];

            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            sidx = "";
            sord = "Sanad_No asc,ID asc";
         
            var list = (from e in sanad where e.Group == codegroup && e.Kol == codekol && e.Moein == codemoein &&e.Tafsili==codetafsili select e).ToList();

            long az = 0;
            long ta = long.MaxValue;

            try
            {
                az = long.Parse(codeaz);
            }
            catch
            {

            }
            try
            {
                ta = long.Parse(codeta);
            }
            catch
            {

            }

            list = (from e in list where e.ID >= az && e.ID <= ta select e).ToList();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }
            list = (from e in list where e.Date_S.Date >= azdatei.Date && e.Date_S.Date < tadatei.Date select e).ToList();
            /* list=group*/

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);
            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                          
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.ID,
                    RowCells = new List<object>
                               {
                    product.Date_S!=null?((DateTime)product.Date_S).ToPersianDate():"",product.Sanad_No,product.Sanad_No.ToString()
                    ,product.Articl_Comment/*.Length>20?product.Articl_Comment.Substring(0,20):product.Articl_Comment*/,product.Bedhkar==0?"":product.Bedhkar.ToString(),product.Bestankar==0?"":product.Bestankar.ToString(),
                        (product.Bedhkar-product.Bestankar)>0?(product.Bedhkar-product.Bestankar).ToString():"",
                    (product.Bestankar-product.Bedhkar)>0?(product.Bestankar-product.Bedhkar).ToString():"",product.Sanad_No
                                }
                })).ToList()
            };
            for (int i = 0; i < productsData.Rows.Count; i++)
            {
                try
                {
                    if (i > 0)
                    {

                        if (productsData.Rows[i].RowCells[4].ToString() != "")//گردش بدهکار
                        {

                            if (productsData.Rows[i - 1].RowCells[6].ToString() != "")//قبلی مانده بدهکار داشت
                            {
                                productsData.Rows[i].RowCells[6] = (long.Parse(productsData.Rows[i - 1].RowCells[6].ToString()) +
                                                                                             long.Parse(productsData.Rows[i].RowCells[4].ToString())).ToString();
                                productsData.Rows[i].RowCells[7] = "";

                            }
                            else
                            if (productsData.Rows[i - 1].RowCells[7].ToString() != "")//اگر قبلی مانده بستانکار داشت
                            {
                                long mandebestankarghabli = long.Parse(productsData.Rows[i - 1].RowCells[7].ToString());
                                long bedehkar = long.Parse(productsData.Rows[i].RowCells[4].ToString());
                                if (bedehkar - mandebestankarghabli >= 0)
                                {
                                    productsData.Rows[i].RowCells[6] =( bedehkar - mandebestankarghabli);
                                    productsData.Rows[i].RowCells[7] = "";

                                }
                                else
                                {
                                    productsData.Rows[i].RowCells[6] = "";
                                    productsData.Rows[i].RowCells[7] = (mandebestankarghabli - bedehkar).ToString();
                                }
                            }
                            else
                            {
                                productsData.Rows[i].RowCells[6] = long.Parse(productsData.Rows[i].RowCells[4].ToString());
                                productsData.Rows[i].RowCells[7] = "";
                            }

                        }
                        else
                        if (productsData.Rows[i].RowCells[5].ToString() != "")//گردش بستانکار
                        {

                            if (productsData.Rows[i - 1].RowCells[7].ToString() != "")//قبلی مانده بستانکار داشت
                            {
                                productsData.Rows[i].RowCells[7] = long.Parse(productsData.Rows[i - 1].RowCells[7].ToString()) +
                                                                                             long.Parse(productsData.Rows[i].RowCells[5].ToString());
                                productsData.Rows[i].RowCells[6] = "";

                            }
                            else
                            if (productsData.Rows[i - 1].RowCells[6].ToString() != "")//اگر قبلی مانده بدهکار داشت
                            {
                                long mandebedehkarghabli = long.Parse(productsData.Rows[i - 1].RowCells[6].ToString());
                                long bestankar = long.Parse(productsData.Rows[i].RowCells[5].ToString());
                                if (mandebedehkarghabli - bestankar >= 0)
                                {
                                    productsData.Rows[i].RowCells[6] =( mandebedehkarghabli - bestankar);
                                    productsData.Rows[i].RowCells[7] = "";

                                }
                                else
                                {
                                    productsData.Rows[i].RowCells[6] = "";
                                    productsData.Rows[i].RowCells[7] = (bestankar - mandebedehkarghabli);
                                }
                            }
                            else
                            {
                                productsData.Rows[i].RowCells[7] = long.Parse(productsData.Rows[i].RowCells[5].ToString());
                                productsData.Rows[i].RowCells[6] = "";
                            }
                        }

                    }
                }
                catch
                {

                }
            }
           var d= Json(productsData, JsonRequestBehavior.AllowGet);
            d.MaxJsonLength = int.MaxValue;
            return d;
        }

        [HttpPost]
        public ActionResult GetDaftarMoein(string sidx, string sord, int page, int rows, string codeaz, string codeta, string azdate, string tadate, string codegroup, string codekol,string codemoein, string year = "")
        {
             SandooghModel db = new SandooghModel();
            if (codemoein.Contains("_")) codemoein = codemoein.Split('_')[1];

            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);

            sidx = "";
            sord = "Sanad_No asc,ID asc";
          
            var list = (from e in sanad where e.Group == codegroup && e.Kol == codekol &&e.Moein==codemoein select e).ToList();

            long az = 0;
            long ta = long.MaxValue;

            try
            {
                az = long.Parse(codeaz);
            }
            catch
            {

            }
            try
            {
                ta = long.Parse(codeta);
            }
            catch
            {

            }

            list = (from e in list where e.ID >= az && e.ID <= ta select e).ToList();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = ((DateTime)tadate.ToMilady()).AddDays(1);
            }
            catch
            {

            }
            list = (from e in list where e.Date_S.Date >= azdatei.Date && e.Date_S.Date < tadatei.Date select e).ToList();
            /* list=group*/

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);
            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                           
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.ID,
                    RowCells = new List<object>
                               {
                    product.Date_S!=null?((DateTime)product.Date_S).ToPersianDate():"","../../Accounting/Asnad?sanad_no="+product.Sanad_No,product.Sanad_No.ToString()
                    ,product.Articl_Comment,product.Bedhkar==0?"":product.Bedhkar.ToString(),product.Bestankar==0?"":product.Bestankar.ToString(),
                        (product.Bedhkar-product.Bestankar)>0?(product.Bedhkar-product.Bestankar).ToString():"",
                    (product.Bestankar-product.Bedhkar)>0?(product.Bestankar-product.Bedhkar).ToString():"","../../Accounting/Asnad?sanad_no="+product.Sanad_No
                                }
                })).ToList()
            };

            for (int i = 0; i < productsData.Rows.Count; i++)
            {
                if (i > 0)
                {
                    if (productsData.Rows[i].RowCells[4].ToString() != "")//گردش بدهکار
                    {

                        if (productsData.Rows[i - 1].RowCells[6].ToString() != "")//قبلی مانده بدهکار داشت
                        {
                            productsData.Rows[i].RowCells[6] = (long.Parse(productsData.Rows[i - 1].RowCells[6].ToString()) +
                                                                                         long.Parse(productsData.Rows[i].RowCells[4].ToString())).ToString();
                            productsData.Rows[i].RowCells[7] = "";

                        }
                        else
                        if (productsData.Rows[i - 1].RowCells[7].ToString() != "")//اگر قبلی مانده بستانکار داشت
                        {
                            long mandebestankarghabli = long.Parse(productsData.Rows[i - 1].RowCells[7].ToString());
                            long bedehkar = long.Parse(productsData.Rows[i].RowCells[4].ToString());
                            if (bedehkar - mandebestankarghabli >= 0)
                            {
                                productsData.Rows[i].RowCells[6] = bedehkar - mandebestankarghabli;
                                productsData.Rows[i].RowCells[7] = "";

                            }
                            else
                            {
                                productsData.Rows[i].RowCells[6] = "";
                                productsData.Rows[i].RowCells[7] = (mandebestankarghabli - bedehkar).ToString();
                            }
                        }
                        else
                        {
                            productsData.Rows[i].RowCells[6] = long.Parse(productsData.Rows[i].RowCells[4].ToString()).ToString();
                            productsData.Rows[i].RowCells[7] = "";
                        }

                    }
                    else
                    if (productsData.Rows[i].RowCells[5].ToString() != "")//گردش بستانکار
                    {

                        if (productsData.Rows[i - 1].RowCells[7].ToString() != "")//قبلی مانده بستانکار داشت
                        {
                            productsData.Rows[i].RowCells[7] = (long.Parse(productsData.Rows[i - 1].RowCells[7].ToString()) +
                                                                                         long.Parse(productsData.Rows[i].RowCells[5].ToString())).ToString();
                            productsData.Rows[i].RowCells[6] = "";

                        }
                        else
                        if (productsData.Rows[i - 1].RowCells[6].ToString() != "")//اگر قبلی مانده بدهکار داشت
                        {
                            long mandebedehkarghabli = long.Parse(productsData.Rows[i - 1].RowCells[6].ToString());
                            long bestankar = long.Parse(productsData.Rows[i].RowCells[5].ToString());
                            if (mandebedehkarghabli - bestankar >= 0)
                            {
                                productsData.Rows[i].RowCells[6] = mandebedehkarghabli - bestankar;
                                productsData.Rows[i].RowCells[7] = "";

                            }
                            else
                            {
                                productsData.Rows[i].RowCells[6] = "";
                                productsData.Rows[i].RowCells[7] = (bestankar - mandebedehkarghabli).ToString();
                            }
                        }
                        else
                        {
                            productsData.Rows[i].RowCells[7] = long.Parse(productsData.Rows[i].RowCells[5].ToString()).ToString();
                            productsData.Rows[i].RowCells[6] = "";
                        }
                    }

                }
            }
            var d=Json(productsData, JsonRequestBehavior.AllowGet);
                 d.MaxJsonLength = int.MaxValue;
            return d;
        }

        public ActionResult Tafsili1Accounts()
        {
            return View();
        }
        public ActionResult Tafsili2Accounts()
        {
            return View();
        }
        
             [HttpPost]
        public ActionResult UnLockSanad(string sanadNo, string year = "")
        {
            try
            {

                SandooghModel db = new SandooghModel();
                var sanadno = int.Parse(sanadNo);
                string startyear = year + "/01/01";
                string endyear = int.Parse(year) + 1 + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Sanad_No == sanadno select e).ToList();
                foreach (AccSanad_B san in sanad)
                {
                    san.Lock_Sanad = false;
                    db.Entry(san).State = EntityState.Modified;

                }

                db.SaveChanges();

                return Json(true);
            }
            catch
            {
                return null;
            }

        }
        [HttpPost]
        public ActionResult ChangeSanadNumber(string sanadNo, string year = "",string newsanadnumber="")
        {
            try
            {

                SandooghModel db = new SandooghModel();
                var sanadno = int.Parse(sanadNo);
                var newsanadno = int.Parse(newsanadnumber);
                string startyear = year + "/01/01";
                string endyear = int.Parse(year) + 1 + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                try
                {
                    var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Sanad_No == sanadno select e).ToList();

                    DateTime dates = sanad.FirstOrDefault().Date_S;
                    var sanadNew = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Sanad_No == newsanadno select e).FirstOrDefault();
                    if (sanadNew != null)
                        dates = sanadNew.Date_S;
                    foreach (AccSanad_B san in sanad)
                    {
                        san.Sanad_No = newsanadno;
                        san.Date_S = dates;
                        db.Entry(san).State = EntityState.Modified;

                    }
                    var pays = (from e in db.G_M_Pays where e.PayDate >= dates && e.PayDate <= dateend && e.SanadNo == sanadno select e).ToList();
                    if (pays != null)
                    {
                        try
                        {
                            foreach (G_M_Pays pay in pays)
                            {
                                pay.SanadNo = newsanadno;
                                pay.PayDate = dates;
                                db.Entry(pay).State = EntityState.Modified;

                            }
                        }
                        catch
                        {


                        }
                    }
                    var vams = (from e in db.Vams where e.VamDate >= dates && e.VamDate <= dateend && e.SanadNo == sanadno select e).ToList();
                    if (vams != null)
                    {
                        try
                        {
                            foreach (Vam vam in vams)
                            {
                                vam.SanadNo = newsanadno;
                                vam.VamDate = dates;
                                db.Entry(vam).State = EntityState.Modified;

                            }
                        }
                        catch
                        {


                        }
                    }
                    db.SaveChanges();

                  }
                catch
                {

                }

                return Json(true);
            }
            catch
            {
                return null;
            }

        }
        [HttpPost]
        public ActionResult LockSanad(string sanadNo,string year="")
        {
                try
            {
             
                 SandooghModel db = new SandooghModel();
               var sanadno= int.Parse(sanadNo);
                string startyear = year + "/01/01";
                string endyear = int.Parse(year) + 1 + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Sanad_No==sanadno select e).ToList();
              foreach(AccSanad_B san in sanad )
                {
                    san.Lock_Sanad = true;
                    db.Entry(san).State = EntityState.Modified;
                   
                }

                    db.SaveChanges();

                return Json(true);
            }
            catch
            {
                return null;
            }

        }



        [HttpPost]
        public ActionResult GetSanadNumber(string year)
        {

            try
            {
                SandooghModel db = new SandooghModel();
                string startyear = year + "/01/01";
                string endyear = int.Parse(year) + 1 + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var thisyearssanads = from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e;
                var now = DateTime.Now;
                try
                {
                    var maxValue = thisyearssanads.Max(x => x.Sanad_No);

                    return Json(maxValue+1); 
                }
                catch
                {
                    return Json(1);
                }

               
            }
            catch
            {
                return null;
            }

        }
        [HttpPost]
        public ActionResult GetSanadNumers( string year = "")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            try
            {
            
                var d = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S)>=DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S)<DbFunctions.TruncateTime(dateend) select e.Sanad_No ) ;

              return  Json(d.ToList().Distinct().OrderBy(p => p).ToList());
            }
            catch
            {
                return null;
            }
        
        }

        [HttpPost]
        public ActionResult AddSanad(AccSanad_B postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            if(postData.Moein.Contains("_"))
            {
                postData.Moein = postData.Moein.Split('_')[1];
            }
            if (postData.Bedhkar == null) postData.Bedhkar = 0;
            if (postData.Bestankar == null) postData.Bestankar = 0;

            db.AccSanad_B.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult EditSanad(AccSanad_B postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            if (postData.Bedhkar == null) postData.Bedhkar = 0;
            if (postData.Bestankar == null) postData.Bestankar = 0;
            if (postData.Moein.Contains("_"))
                postData.Moein = postData.Moein.Split('_')[1];
            db.Entry(postData).State = EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult DeleteSanad(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.AccSanad_B.FirstOrDefault(x => x.ID == idd);
            if (product == null)
                return Json(false);

            db.AccSanad_B.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult GetSanadCodeByDate(string datetime)
        {
            SandooghModel db = new SandooghModel();
            
            DateTime date= (DateTime)datetime.ToMilady();
         
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S)==DbFunctions.TruncateTime(date) select e).FirstOrDefault();

            return Json(new
            {
                sanadno = sanad.Sanad_No
            }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetSanadBedBes(int sanadNo,string year="")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var sanad = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e);
            var bed = (from t in sanad where t.Sanad_No == sanadNo select t.Bedhkar).Sum();
            var bes = (from t in sanad where t.Sanad_No == sanadNo select t.Bestankar).Sum();
            return Json(new
            {
                bed = bed, bes = bes, taraz = bed == bes ? "تراز است" : "تراز نیست"
            }, JsonRequestBehavior.AllowGet);
        }

              [HttpPost]
        public ActionResult GetCodeNames(string kolcode, string moeincode, int tafsilicode,string year="")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            var list = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).ToList();
            string tafsili = "";
            try
            {
  tafsili = tafsilicode.ToString();
            }
           
            catch
            {

            }
          
            var kols = db.Acc_Kol.ToList();
            var koltext = from k in kols where k.Code_Group + k.Code_Kol == kolcode select k.Comment;
            var kolbed= (from kk in list where  kk.Kol == kolcode select kk.Bedhkar).Sum();
            var kolbes = (from kk in list where  kk.Kol == kolcode select kk.Bestankar).Sum();
            var moeins = db.Acc_Moein.ToList();
           var moeintext = from m in moeins where m.Code_Group + m.Code_Kol == kolcode && m.Code_Moein == moeincode   select m.Comment;
            var moeinbed = (from m in list where m.Kol == kolcode && m.Moein == moeincode select m.Bedhkar).Sum();
            var moeinbes = (from m in list where  m.Kol == kolcode && m.Moein == moeincode select m.Bestankar).Sum();
            var tafsilis = db.Acc_Tafsili2.ToList();
            string mm14 = tafsilicode.ToString();/*1212*/
            var tafsilitext = from t in tafsilis where t.Tafsili2_Code == mm14 select t.Tafsili2_Comment;
            var tafsilibed = (from t in list where t.Tafsili == tafsili select t.Bedhkar).Sum();
            var tafsilibes = (from t in list where t.Tafsili == tafsili select t.Bestankar).Sum();
         
            System.Globalization.CultureInfo info = System.Globalization.CultureInfo.GetCultureInfo("fa-IR");

            return Json(new { Koltext = koltext.FirstOrDefault(),MoeinText=moeintext.FirstOrDefault(),TafsiliText=tafsilitext.FirstOrDefault()
                ,KolBedBes=kolbed>0? "بد: " + ((double)kolbed).ToString("N0", info) : "بس: " + ((double)kolbes).ToString("N0", info),
            MoeinBedBes= moeinbed > 0 ? "بد: " + ((double)moeinbed).ToString("N0", info) : "بس: " + ((double)moeinbes).ToString("N0", info),
            TafsiliBedBes= tafsilibed > 0 ? "بد: " + ((double)tafsilibed).ToString("N0", info) : "بس: " + ((double)tafsilibes).ToString("N0", info)
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSanadPrintBySanadCode(string sanadcode, string sidx, string sord, int page, int rows,string year="")
        {
           
            if (sanadcode.ToString() == "" || sanadcode == null)
            {
                return Json(-1, JsonRequestBehavior.AllowGet);
            }
            else
            {
                SandooghModel db = new SandooghModel();
                string startyear = year + "/01/01";
                string endyear = int.Parse(year) + 1 + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                int s1 = int.Parse(sanadcode);
                var list = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Sanad_No == s1 select e).ToList();
               
                //بدهکاران
                var TempKol = (from s in list where  s.Bedhkar>0 group s by s.Kol into g /*where g.Key == idd*/ select new {Kol=g.Key,  SumBed = g.Sum(v => v.Bedhkar),SumBes= g.Sum(v => v.Bestankar),Tafsili= (double?)0.0, Moein= (double?)0.0, CodeHesab=g.Key+"       "+"       ",id= g.Key + "       " + "       ", sharh="",TitleHesab="..." });
                var KolList = (from tk in TempKol join k in db.Acc_Kol on tk.Kol equals (k.Code_Group + k.Code_Kol)
                              select new { tk.Kol, tk.SumBed, tk.SumBes, tk.Tafsili, tk.Moein, tk.CodeHesab, tk.sharh, TitleHesab = k.Comment ,id=tk.id, bed = "1" }).ToList();
                var TempMoein = (from s in list
                                 where  s.Bedhkar > 0
                                 group s by s.Kol + "," + s.Moein into g select g).ToList() /*where g.Key == idd*/
                                 .Select(x=>
                                 {
                                     var mm = "";
                                     try {mm = x.Key.Split(',')[1]; } catch { }
                                    
                                     return new
                                     {
                                         Kol = x.Key,
                                         SumBed = (double?)0.0,
                                         SumBes = (double?)0.0,
                                         Tafsili = (double?)0.0,
                                         Moein = x.Sum(v => v.Bedhkar),
                                         CodeHesab = "       " + mm + "       ",
                                         sharh = "",
                                         TitleHesab = "...",
                                         id = x.Key.Replace(",","") + "       "
                                     };
                                 });
var MoeinList = (from tk in TempMoein
                 join k in db.Acc_Moein on tk.Kol equals (k.Code_Group + k.Code_Kol+","+k.Code_Moein)
                 select new { tk.Kol, tk.SumBed, tk.SumBes, tk.Tafsili, tk.Moein, tk.CodeHesab, tk.sharh, TitleHesab = k.Comment, id = tk.id, bed = "1" }).ToList();

                var TempTafsili = (from s in list where s.Bedhkar > 0  /*where g.Key == idd*/ select new { Kol = s.Tafsili, SumBed = (double?)0.0, SumBes = (double?)0.0, Tafsili = s.Bedhkar, Moein = (double?)0.0, CodeHesab = "       " + "       " + s.Tafsili, sharh = s.Articl_Comment, TitleHesab = "...", id = s.Kol+s.Moein + s.Tafsili});
                var TafsiliList = (from tk in TempTafsili
                                   join k in db.Acc_Tafsili2 on tk.Kol equals (k.Tafsili2_Code/*.ToString()1212*/)
                                   select new { tk.Kol, tk.SumBed, tk.SumBes, tk.Tafsili, tk.Moein, tk.CodeHesab, tk.sharh, TitleHesab = k.Tafsili2_Comment, id = tk.id, bed = "1" }).ToList();


                //بستانکاران
                var TempKolbes = (from s in list where s.Bestankar > 0 group s by s.Kol into g /*where g.Key == idd*/ select new { Kol = g.Key, SumBed = g.Sum(v => v.Bedhkar), SumBes = g.Sum(v => v.Bestankar), Tafsili = (double?)0.0, Moein = (double?)0.0, CodeHesab = g.Key + "       " + "       ", id = g.Key + "       " + "       ", sharh = "", TitleHesab = "..." });
                var KolListbes = (from tk in TempKolbes
                               join k in db.Acc_Kol on tk.Kol equals (k.Code_Group + k.Code_Kol)
                               select new { tk.Kol, tk.SumBed, tk.SumBes, tk.Tafsili, tk.Moein, tk.CodeHesab, tk.sharh, TitleHesab = k.Comment, id = tk.id, bed = "0" }).ToList();
                var TempMoeinbes = (from s in list
                                 where  s.Bestankar > 0
                                 group s by s.Kol + "," + s.Moein into g
                                 select g).ToList() /*where g.Key == idd*/
                                 .Select(x =>
                                 {
                                     var mm = "";
                                     try { mm = x.Key.Split(',')[1]; } catch { }

                                     return new
                                     {
                                         Kol = x.Key,
                                         SumBed = (double?)0.0,
                                         SumBes = (double?)0.0,
                                         Tafsili = (double?)0.0,
                                         Moein = x.Sum(v => v.Bestankar),
                                         CodeHesab = "       " + mm + "       ",
                                         sharh = "",
                                         TitleHesab = "...",
                                         id = x.Key.Replace(",", "") + "       "
                                     };
                                 });
                var MoeinListbes = (from tk in TempMoeinbes
                                 join k in db.Acc_Moein on tk.Kol equals (k.Code_Group + k.Code_Kol + "," + k.Code_Moein)
                                 select new { tk.Kol, tk.SumBed, tk.SumBes, tk.Tafsili, tk.Moein, tk.CodeHesab, tk.sharh, TitleHesab = k.Comment, id = tk.id, bed = "0" }).ToList();

                var TempTafsilibes = (from s in list where  s.Bestankar > 0  /*where g.Key == idd*/ select new { Kol = s.Tafsili, SumBed = (double?)0.0, SumBes = (double?)0.0, Tafsili = s.Bestankar, Moein = (double?)0.0, CodeHesab = "       " + "       " + s.Tafsili, sharh = s.Articl_Comment, TitleHesab = "...", id = s.Kol + s.Moein + s.Tafsili });
                var TafsiliListbes = (from tk in TempTafsilibes
                                   join k in db.Acc_Tafsili2 on tk.Kol equals (k.Tafsili2_Code/*.ToString()1212*/)
                                      select new { tk.Kol, tk.SumBed, tk.SumBes, tk.Tafsili, tk.Moein, tk.CodeHesab, tk.sharh, TitleHesab = k.Tafsili2_Comment, id = tk.id, bed = "0" }).ToList();

                var mainlist = KolList.ToList().Union(MoeinList.ToList()).Union(TafsiliList).Union( KolListbes.ToList()).Union(MoeinListbes.ToList()).Union(TafsiliListbes).ToList();

                var raeis = "";
                var hesabdar = "";
                var khazanedar = "";
                var masoolmali = "";
                try
                {
                    var option = (from e in db.Option_T select e).FirstOrDefault();
                    raeis = option.E4;
                    hesabdar = option.E1;
                    masoolmali = option.E2;
                    khazanedar = option.E3;
                }
                catch{

                }

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = mainlist.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = mainlist.AsQueryable();
                var productsList = productsQuery.OrderBy(" bed desc , id asc").ToList();
                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = long.Parse(product.id.Trim()),
                        RowCells = new List<object>
                               {
                      product.CodeHesab ,product.TitleHesab, product.sharh,product.Tafsili,product.Moein,product.SumBed,product.SumBes,raeis,hesabdar,khazanedar,masoolmali
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult GetSanadBydate(string date, string sidx, string sord, int page, int rows, string year = "")
        {
            DateTime datet = (DateTime)date.ToMilady();
            SandooghModel db = new SandooghModel();
          
            if (date == "" || date == null)
            {
                return Json(-1, JsonRequestBehavior.AllowGet);
            }
            else
            {

                 var list = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) == DbFunctions.TruncateTime(datet) select e).ToList();
             
                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list.AsQueryable();
                var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                .Skip(pageIndex * pageSize)
                                                .Take(pageSize)
                                                .ToList();
                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.ID,
                        RowCells = new List<object>
                               {
                       product.ID ,product.Sanad_No, product. Date_S!=null?((DateTime)product.Date_S).ToPersianDate():"",product.Group,product.Kol,product.Moein,product.Sanad_Tafsili1, product.Tafsili,product.Bedhkar
                    ,product.Bestankar,product.Articl_Comment,product.Lock_Sanad,product.Ok_NotOk
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult GetSanadBySanadCode(string sanadcode,string sidx, string sord, int page, int rows,string year="")
        {
            SandooghModel db = new SandooghModel();
            string startyear = year + "/01/01";
            string endyear = int.Parse(year) + 1 + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
                  if (sanadcode.ToString() == "" || sanadcode == null)
            {
             return   Json(-1, JsonRequestBehavior.AllowGet);
            }
            else
            {
              
                int s1 = int.Parse(sanadcode);
                var list = (from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).ToList();
                 list = (from s in list where s.Sanad_No == s1 select s).ToList();

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list.AsQueryable();
                var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                .Skip(pageIndex * pageSize)
                                                .Take(pageSize)
                                                .ToList();
                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.ID,
                        RowCells = new List<object>
                               {
                       product.ID ,product.Sanad_No, product. Date_S!=null?((DateTime)product.Date_S).ToPersianDate():"",product.Group,product.Kol,product.Moein,product.Sanad_Tafsili1, product.Tafsili,product.Bedhkar
                    ,product.Bestankar,product.Articl_Comment,product.Lock_Sanad,product.Ok_NotOk
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public ActionResult GetAsnad(string sidx, string sord, int page, int rows,string sanad_no="",string year="")
        {
            SandooghModel db = new SandooghModel();
            string startyear =year + "/01/01";
            string endyear = int.Parse(year)+1 + "/01/01";
            DateTime datestart =(DateTime) startyear.ToMilady();
            DateTime dateend= (DateTime)endyear.ToMilady();
            var list =(from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S)>=DbFunctions.TruncateTime(datestart)&&DbFunctions.TruncateTime(e.Date_S)<DbFunctions.TruncateTime(dateend) select e).ToList();
            int sanadno = -1;
            try
            {
                sanadno = int.Parse(sanad_no);
            }
            catch
            {

            }
            if (sanad_no != "")
            {
                list = (from e in list where e.Sanad_No == sanadno select e).ToList();
            }
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.ID,
                    RowCells = new List<object>
                               {
                       product.ID ,product.Sanad_No, product. Date_S!=null?((DateTime)product.Date_S).ToPersianDate():"",product.Group,product.Kol,product.Moein,product.Sanad_Tafsili1, product.Tafsili,product.Bedhkar
                    ,product.Bestankar,product.Articl_Comment,product.Lock_Sanad,product.UserLock, product.Ok_NotOk
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MahiatSelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_Mahiat.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.Mahiat_Name,
                Value = x.Mahiat_id.ToString()
            }).ToList();
            return PartialView("../Ozviat/_SelectPartial", suppliers);
        }
        public ActionResult AccGroupSelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Group_F.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.Comment,
                Value = x.Code_Group.ToString()
            }).ToList();
            return PartialView("../Ozviat/_SelectPartial", suppliers);
        }
        public ActionResult AccKolSelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Kol.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.Comment,
                Value = x.Kol_Id.ToString()
            }).ToList();
            return PartialView("../Ozviat/_SelectPartial", suppliers);
        }
        public ActionResult AccTafsili1Select()
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Tafsil1.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.Tafsil1_Comment,
                Value = x.Tafsil1_ID.ToString()
            }).ToList();
            return PartialView("../Ozviat/_SelectPartial", suppliers);
        }
        public ActionResult AccounttypeSelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_AccountType.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.AccountType_Name,
                Value = x.AccountType_ID.ToString(CultureInfo.InvariantCulture)
            }).ToList();
            return PartialView("../Ozviat/_SelectPartial", suppliers);
        }
        public ActionResult AccountTypes()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetBankTafsili2sWithCode()
        {
           
           
            SandooghModel db = new SandooghModel();
            // ابتدا با استفاده از مقایسه رشته‌ای فیلتر کنید
            // مرحله اول: واکشی اولیه با فیلتر رشته‌ای
            var list = db.Acc_Tafsili2
                .Where(e => (e.Tafsili2_Code.CompareTo("10001") >= 0 && e.Tafsili2_Code.CompareTo("10100") <= 0) || e.Tafsili2_Code == "10020")
                .ToList(); // داده‌ها را به حافظه بیاورید


            /*1212*/
            // var list = (from e in db.Acc_Tafsili2 where (e.Tafsili2_Code >= 10001 && e.Tafsili2_Code <= 10100) || (e.Tafsili2_Code == 10020) select e).ToList();

            //var list = (from e in db.Acc_Tafsili2 where (e.Tafsili2_Code >= "10001" && e.Tafsili2_Code <= "10100") ||(e.Tafsili2_Code=="10020")  select e).ToList();
            var result = (from oz in list 

                         select new
                         {
                             name = oz.Tafsili2_Comment + '(' + oz.Tafsili2_Code + ')',
                             comment = oz.Tafsili2_Comment,
                             code = oz.Tafsili2_Code,
                             id = oz.Tafsili2_Id
                         });

            return Json(result.ToList(), JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public JsonResult GetTafsili2sWithCode()
        {
            SandooghModel db = new SandooghModel();
         
                var list = db.Acc_Tafsili2.ToList();
                var result = from oz in list
                           
                             select new
                             {
                                 name = oz.Tafsili2_Comment + '(' + oz.Tafsili2_Code + ')',
                                 comment = oz.Tafsili2_Comment,
                                 code = oz.Tafsili2_Code,
                                 id = oz.Tafsili2_Id
                             };

                return Json(result.ToList(), JsonRequestBehavior.AllowGet);
          
        }
        [HttpGet]
        public JsonResult GetGroup()
        {
            SandooghModel db = new SandooghModel();

            var list = db.Acc_Group_F.ToList();
            var result = from oz in list

                         select new
                         {
                             name = oz.Comment + '(' + oz.Code_Group + ')',
                             comment = oz.Comment,
                             code = oz.Code_Group,
                             id = oz.Group_Id
                         };

            return Json(result.ToList(), JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public JsonResult GetKolByGroup(string group)
        {
            SandooghModel db = new SandooghModel();
            int dd = -1;
            try
            {
                dd = int.Parse(group);

            }
            catch { }
          
            var list = db.Acc_Kol.ToList();
            if (dd == -1)
            {
                var result = from oz in list

                             select new
                             {
                                 name = oz.Comment + "(" + oz.Acc_Group_F.Code_Group + oz.Code_Kol + ")",
                                 comment = oz.Comment,
                                 code = oz.Acc_Group_F.Code_Group + oz.Code_Kol.ToString(),
                                 id = oz.Kol_Id
                             };

                return Json(result.ToList(), JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = from oz in list where oz.Code_Group==dd

                             select new
                             {
                                 name = oz.Comment + "(" + oz.Acc_Group_F.Code_Group + oz.Code_Kol + ")",
                                 comment = oz.Comment,
                                 code = oz.Acc_Group_F.Code_Group + oz.Code_Kol.ToString(),
                                 id = oz.Kol_Id
                             };

                return Json(result.ToList(), JsonRequestBehavior.AllowGet);
            }

        }
        [HttpGet]
        public JsonResult GetMoeinByKol(string kol)
        {
            SandooghModel db = new SandooghModel();

            var list = db.Acc_Moein.ToList();
            if (kol=="")
            {
                var result = from oz in list

                             select new
                             {
                                 name = oz.Comment + '(' + oz.Code_Moein + ')',
                                 comment = oz.Comment,
                                 code = oz.Code_Moein,
                                 id = oz.Moein_ID
                             };

                return Json(result.ToList(), JsonRequestBehavior.AllowGet);
            }
            else
            {
                var result = from oz in list where oz.Code_Group+oz.Code_Kol==kol

                             select new
                             {
                                 name = oz.Comment + '(' + oz.Code_Moein + ')',
                                 comment = oz.Comment,
                                 code = oz.Code_Moein,
                                 id = oz.Moein_ID
                             };

                return Json(result.ToList(), JsonRequestBehavior.AllowGet);
            }

        }
        public ActionResult ReportSanad()
        {
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
            List<SelectListItem> MoeinList = new List<SelectListItem>();
            List<SelectListItem> TafsiliList = new List<SelectListItem>();
            List<SelectListItem> TafsiliGroupList = new List<SelectListItem>();

            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
            List<Acc_Moein> moeinList = db.Acc_Moein.ToList();
            List<Acc_Tafsil1> tafsiligroupList = db.Acc_Tafsil1.ToList();
            List<Acc_Tafsili2> tafsiliList = db.Acc_Tafsili2.ToList();
            foreach (Acc_Tafsil1 t1 in tafsiligroupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = t1.Tafsil1_ID.ToString();
                sli.Text = t1.Tafsil1_Comment + "(" + t1.Tafsil1_ID + ")";
                TafsiliGroupList.Add(sli);
            }
            ViewBag.tafsiligroup = TafsiliGroupList;
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")";
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;

            foreach (Acc_Moein moein in moeinList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = moein.Code_Moein;
                sli.Text = moein.Comment + "(" + moein.Code_Moein + ")";
                MoeinList.Add(sli);
            }
            ViewBag.moeins = MoeinList;
            foreach (Acc_Tafsili2 tafsili2 in tafsiliList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = tafsili2.Tafsili2_Code/*.ToString()1212*/;
                sli.Text = tafsili2.Tafsili2_Comment + "(" + tafsili2.Tafsili2_Code + ")";
                TafsiliList.Add(sli);
            }
            ViewBag.tafsilis = TafsiliList;
            return View();
        }
        public ActionResult Asnad(string sanad_no="1")
        {
            ViewBag.SanadNo = sanad_no;
           
            SandooghModel db = new SandooghModel();
            ViewBag.ActiveYear = (from e in db.Acc_Years where e.Year_Isactive==true select e.Year_Name).FirstOrDefault();
            List < SelectListItem > GroupList = new List<SelectListItem>();
            List<SelectListItem> KolList = new List<SelectListItem>();
            List<SelectListItem> MoeinList = new List<SelectListItem>();
            List<SelectListItem> TafsiliList = new List<SelectListItem>();
            List<SelectListItem> TafsiliGroupList = new List<SelectListItem>();

            List<Acc_Group_F> groupList = db.Acc_Group_F.ToList();
            List<Acc_Kol> kolList = db.Acc_Kol.ToList();
            List<Acc_Moein> moeinList = db.Acc_Moein.ToList();
            List<Acc_Tafsil1> tafsiligroupList = db.Acc_Tafsil1.ToList();
            List<Acc_Tafsili2> tafsiliList = db.Acc_Tafsili2.ToList();
            foreach (Acc_Tafsil1 t1 in tafsiligroupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = t1.Tafsil1_ID.ToString();
                sli.Text = t1.Tafsil1_Comment + "(" + t1.Tafsil1_ID + ")";
                TafsiliGroupList.Add(sli);
            }
            ViewBag.tafsiligroup = TafsiliGroupList;
            foreach (Acc_Group_F group in groupList)
            {
                SelectListItem sli = new SelectListItem();
        sli.Value = group.Code_Group.ToString();
                sli.Text = group.Comment.ToString() + "(" + group.Code_Group + ")" ;
                GroupList.Add(sli);
            }
            ViewBag.groups = GroupList;
            foreach (Acc_Kol kol in kolList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString();
                sli.Text = kol.Comment + "(" + kol.Acc_Group_F.Code_Group + kol.Code_Kol.ToString() + ")";
                KolList.Add(sli);
            }
            ViewBag.kols = KolList;
            foreach (Acc_Moein moein in moeinList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = moein.Code_Group+moein.Code_Kol+"_"+ moein.Code_Moein;
                sli.Text = moein.Comment + "(" + moein.Code_Moein + ")";
                MoeinList.Add(sli);
            }
            ViewBag.moeins = MoeinList;
            foreach (Acc_Tafsili2 tafsili2 in tafsiliList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = tafsili2.Tafsili2_Code/*.ToString()1212*/;
                sli.Text = tafsili2.Tafsili2_Comment + "(" + tafsili2.Tafsili2_Code + ")";
                TafsiliList.Add(sli);
            }
            ViewBag.tafsilis = TafsiliList;
            return View();
        }
        
        public ActionResult KolAccounts()
        {
            return View();
        }
        public ActionResult MoeinAccounts()
        {
            return View();
        }
        public ActionResult AccountingGroups()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetAccountingTypes(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_AccountType.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.AccountType_ID,
                    RowCells = new List<object>
                               {
                     product.AccountType_ID ,product. AccountType_Name
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult AddAccountingTypes(T_AccountType postData)
        {
            SandooghModel db = new SandooghModel();
          
            //todo: Add product to repository
            if (postData == null)
                return Json(false);


            db.T_AccountType.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult GetAccountingGroups(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Group_F.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id =product.Group_Id,
                    RowCells = new List<object>
                               {
                   product.Group_Id,  product.Code_Group ,product. Comment, product.T_AccountType!=null?product.T_AccountType.AccountType_Name:null
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetKol(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Kol.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Kol_Id,
                    RowCells = new List<object>
                               {
                   product.Kol_Id,  product.Code_Group!=null?product.Acc_Group_F.Comment:null , product.Code_Group,product.Code_Kol, product. Comment,product.Mahiat!=null?product.T_Mahiat.Mahiat_Name:null
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetTafsili1(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Tafsil1.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Tafsil1_ID,
                    RowCells = new List<object>
                               {
                   product.Tafsil1_ID,product.Tafsil1_Code, product.Tafsil1_Comment
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        
        [HttpPost]
        public ActionResult GetTafsili2(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Tafsili2.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Tafsili2_Id,
                    RowCells = new List<object>
                               {
                   product.Tafsili2_Id, product.Acc_Tafsil1!=null?product.Acc_Tafsil1.Tafsil1_Comment:null , product.Acc_Tafsil1!=null?product.Acc_Tafsil1.Tafsil1_Code:null  ,product.Tafsili2_Code,product.Tafsili2_MoeinCode, product.Tafsili2_Comment,product.Tafsili2_Mahiat!=null?product.T_Mahiat.Mahiat_Name:null
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetMoein(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.Acc_Moein.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Moein_ID,
                    RowCells = new List<object>
                               {
                   product.Moein_ID, product.Code_Group!=null?product.Acc_Kol.Acc_Group_F.Comment:null ,  product.Moein_KolId!=null?product.Acc_Kol.Comment:null ,product.Code_Group,product.Code_Kol,product.Code_Moein, product. Comment,product.Mahiat!=null?product.T_Mahiat.Mahiat_Name:null
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetKoles(string group)
        {
            SandooghModel db = new SandooghModel();
            int g = int.Parse(group);
            var koles = (from cust in db.Acc_Kol
                          where cust.Code_Group == g
                          select new { kolid = cust.Acc_Group_F.Code_Group + cust.Code_Kol.ToString(), kolname= cust.Comment + "(" + cust.Code_Kol + ")" }).Distinct();

            return Json(koles.ToList(), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetMoeins(string kol)
        {
            SandooghModel db = new SandooghModel();
         
            var moeins = (from cust in db.Acc_Moein
                         where cust.Code_Group+cust.Code_Kol == kol
                         select new { moeinid = kol +"_"+ cust.Code_Moein, moeinname = cust.Comment + "(" + cust.Code_Moein + ")" }).Distinct();

            return Json(moeins.ToList(), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetT2es(string T1)
        {
           
            SandooghModel db = new SandooghModel();
            int g = int.Parse(T1);
            var T2s = (from cust in db.Acc_Tafsili2
                          where cust.Tafsili2_Tafsili1 == g
                          select new { T2id = cust.Tafsili2_Code, T2name = cust.Tafsili2_Comment + "(" + cust.Tafsili2_Code + ")" }).Distinct();

            return Json(T2s.ToList(), JsonRequestBehavior.AllowGet);
        }
        

                 [HttpPost]
        public ActionResult AddTafsili1(Acc_Tafsil1 postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
        
            db.Acc_Tafsil1.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult DeleteTafsili1(string Id)
        {
            long iid = long.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.Acc_Tafsil1.FirstOrDefault(x => x.Tafsil1_ID == iid);
            if (product == null)
                return Json(false);

            db.Acc_Tafsil1.Remove(product);
            db.SaveChanges();
            return Json(true);
        }

        
               [HttpPost]
        public ActionResult AddTafsili2(Acc_Tafsili2 postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
        
            db.Acc_Tafsili2.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult AddMoein(Acc_Moein postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            //  postData.Acc_Group_F = (from e in db.Acc_Group_F where e.Code_Group == postData.Acc_Group_F.Code_Group select e).ToList()[0];
            //  postData.T_Mahiat = (from e in db.T_Mahiat where e.Mahiat_id == postData.T_Mahiat.Mahiat_id select e).ToList()[0];
             
            

var kol = (from e in db.Acc_Kol where e.Kol_Id == postData.Moein_KolId select e).FirstOrDefault();
            postData.Code_Kol = kol.Code_Kol;
            postData.Moein_KolId = kol.Kol_Id;
            postData.Main_Code = postData.Code_Group + kol.Code_Kol + postData.Code_Moein;

            db.Acc_Moein.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult EditTafsili1(Acc_Tafsil1 postData)
        {
            try
            {
                SandooghModel db = new SandooghModel();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
             

                db.Entry(postData).State = EntityState.Modified;
              
                db.SaveChanges();

                  return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }
        
           [HttpPost]
        public ActionResult EditTafsili2(Acc_Tafsili2 postData)
        {
            try
            {
                SandooghModel db = new SandooghModel();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                //postData.Code_Group = postData.Acc_Group_F.Code_Group;
                //postData.Mahiat = postData.T_Mahiat.Mahiat_id;


                db.Entry(postData).State = EntityState.Modified;
             
                // db.T_OzvCode.Add(postData);
                db.SaveChanges();

              
                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }
        [HttpPost]
        public ActionResult EditMoein(Acc_Moein postData)
        {
            try
            {
                SandooghModel db = new SandooghModel();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                //postData.Code_Group = postData.Acc_Group_F.Code_Group;
                //postData.Mahiat = postData.T_Mahiat.Mahiat_id;
              
              
                db.Entry(postData).State = EntityState.Modified;
                postData.Main_Code ="111";
                // db.T_OzvCode.Add(postData);
                db.SaveChanges();

                var data = (from e in db.Acc_Moein where e.Moein_ID == postData.Moein_ID select e).ToList();
                var koll = (from e in db.Acc_Kol where e.Kol_Id == postData.Moein_KolId select e).ToList();
                postData.Main_Code = data.FirstOrDefault().Code_Group + koll.FirstOrDefault().Code_Kol + data.FirstOrDefault().Code_Moein;
                postData.Code_Kol = koll.FirstOrDefault().Code_Kol;

                db.Entry(postData).State = EntityState.Modified;
                // db.T_OzvCode.Add(postData);
                db.SaveChanges();
                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }
        
             [HttpPost]
        public ActionResult DeleteTafsili2(string Id)
        {
            long iid = long.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.Acc_Tafsili2.FirstOrDefault(x => x.Tafsili2_Id == iid);
            if (product == null)
                return Json(false);

            db.Acc_Tafsili2.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult DeleteMoein(string Id)
        {
            long iid = long.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.Acc_Moein.FirstOrDefault(x => x.Moein_ID == iid);
            if (product == null)
                return Json(false);

            db.Acc_Moein.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult AddKol(Acc_Kol postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
          //  postData.Acc_Group_F = (from e in db.Acc_Group_F where e.Code_Group == postData.Acc_Group_F.Code_Group select e).ToList()[0];
          //  postData.T_Mahiat = (from e in db.T_Mahiat where e.Mahiat_id == postData.T_Mahiat.Mahiat_id select e).ToList()[0];

            db.Acc_Kol.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult EditKol(Acc_Kol postData)
        {
            try
            {
                SandooghModel db = new SandooghModel();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                //postData.Code_Group = postData.Acc_Group_F.Code_Group;
                //postData.Mahiat = postData.T_Mahiat.Mahiat_id;
                db.Entry(postData).State = EntityState.Modified;
                // db.T_OzvCode.Add(postData);
                db.SaveChanges();
                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }
        [HttpPost]
        public ActionResult DeleteKol(string Id)
        {
            long iid = long.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.Acc_Kol.FirstOrDefault(x => x.Kol_Id == iid);
            if (product == null)
                return Json(false);

            db.Acc_Kol.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
      
        [HttpPost]
        public ActionResult AddAccountingGroups(Acc_Group_F postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            postData.NoHesab = postData.T_AccountType.AccountType_ID;
            postData.T_AccountType = (from e in db.T_AccountType where e.AccountType_ID == postData.T_AccountType.AccountType_ID select e).ToList()[0];
            db.Acc_Group_F.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult EditAccountingGroup(Acc_Group_F postData)
        {
            try
            {
                SandooghModel db = new SandooghModel();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                postData.NoHesab = postData.T_AccountType.AccountType_ID;
                db.Entry(postData).State = EntityState.Modified;
                // db.T_OzvCode.Add(postData);
                db.SaveChanges();
                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }
        [HttpPost]
        public ActionResult DeleteAccountingGroups(string Id)
        {
            long iid = long.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.Acc_Group_F.FirstOrDefault(x => x.Group_Id == iid);
            if (product == null)
                return Json(false);

            db.Acc_Group_F.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult EditAccountingTypes(T_AccountType postData)
        {
            try
            {
                SandooghModel db = new SandooghModel();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);

                db.Entry(postData).State = EntityState.Modified;
                // db.T_OzvCode.Add(postData);
                db.SaveChanges();
                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }
        [HttpPost]
        public ActionResult DeleteAccountingTypes(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_AccountType.FirstOrDefault(x => x.AccountType_ID == idd);
            if (product == null)
                return Json(false);

            db.T_AccountType.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
    }
}
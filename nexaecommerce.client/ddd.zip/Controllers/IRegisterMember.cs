﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVCSandoogh.Models;

namespace MVCSandoogh.Models
{
    interface IRegisterMember
    {
        int InsertMember(MemberRegistrationDTO objMRDTO);
        IEnumerable<MemberRegistrationDTO> GetMember();
        MemberRegistrationDTO GetMemberById(string MemID);
        int UpdateMember(MemberRegistrationDTO MemID); //U
        void DeleteMember(string MemID); //D
        string GetAmount(string MemID, string WorkTypeID);
    }
}
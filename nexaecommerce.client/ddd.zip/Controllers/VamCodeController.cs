﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Services;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Web.Security;
using System.Data;
using System.Collections;
using PIDCoSmsPackage;
using PIDCoSmsPackage.Model;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using BitPayDll;
using Newtonsoft.Json;
using System.Net;
using MVCSandoogh.GhasedakServiceRefrence;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using System.IO;
using NPOI.XSSF.UserModel;

namespace MVCSandoogh.Controllers
{
    public class VamCodeController : Controller
    {
        private static bool TryParseLoanAmount(string value, out decimal amount)
        {
            amount = 0m;
            if (String.IsNullOrWhiteSpace(value)) return false;

            value = value.Trim()
                .Replace(",", "")
                .Replace("٬", "")
                .Replace("٫", ".")
                .Replace("۰", "0").Replace("۱", "1").Replace("۲", "2")
                .Replace("۳", "3").Replace("۴", "4").Replace("۵", "5")
                .Replace("۶", "6").Replace("۷", "7").Replace("۸", "8")
                .Replace("۹", "9")
                .Replace("٠", "0").Replace("١", "1").Replace("٢", "2")
                .Replace("٣", "3").Replace("٤", "4").Replace("٥", "5")
                .Replace("٦", "6").Replace("٧", "7").Replace("٨", "8")
                .Replace("٩", "9");

            return decimal.TryParse(value, NumberStyles.Number,
                CultureInfo.InvariantCulture, out amount);
        }

        private class CanNobatMemberRow
        {
            public long Id { get; set; }
            public string FName { get; set; }
            public string LName { get; set; }
            public string FatherName { get; set; }
            public DateTime DateNobat { get; set; }
        }

        public ActionResult ReportZamenin()
        {
            return View();
        }
        [Authorize(Roles = "Admin")]
        public ActionResult Logs()
        {
            return View();
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Moghaierat()
        {
            return View();
        }
        [Authorize(Roles = "Admin")]
        public ActionResult Option()
        {
            return View();
        }
        [HttpPost]
        public ActionResult GetPardakhtChartData(string pardakhttype = "")
        {
            int vtype = 1001;
            if (pardakhttype != "")
                vtype = int.Parse(pardakhttype);
            SandooghModel db = new SandooghModel();
            DateTime now = DateTime.Now;
            PersianCalendar pl = new PersianCalendar();
            int nowmonth = pl.GetMonth(now);
            int nowyear = pl.GetYear(now);
            int beforyea = nowyear - 1;
            int beformonth = 1;
            Dictionary<int, long> BeforDic = new Dictionary<int, long>();
            Dictionary<int, long> NowDic = new Dictionary<int, long>();
            for (int i = 1; i <= 12; i++)
            {
                DateTime dateaz = (DateTime)(beforyea + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    beforyea += 1;
                    beformonth = 1;
                }
                else
                {
                    beformonth = i + 1;
                }
                DateTime dateta = (DateTime)(beforyea + "/" + beformonth + "/1").ToMilady();
                if (pardakhttype == "1")
                {
                    long count = 0;
                    try
                    {
                        var f = (from e in db.G_M_Pays where e.TotGestMablag != null && e.PayDate >= dateaz && e.PayDate < dateta select e.TotGestMablag).ToList();
                        count = (long)(from e in db.G_M_Pays where e.TotGestMablag != null && e.PayDate >= dateaz && e.PayDate < dateta select e).Sum(v => v.TotGestMablag);

                        if (count == null) count = 0;
                    }
                    catch
                    {

                    }
                    BeforDic.Add(i, count);
                }
                else
                {
                    long count = 0;
                    try
                    {
                        var f = (from e in db.G_M_Pays where e.MostamariMablag != null && e.PayDate >= dateaz && e.PayDate < dateta select e.MostamariMablag).ToList();
                        count = (long)(from e in db.G_M_Pays where e.MostamariMablag != null && e.PayDate >= dateaz && e.PayDate < dateta select e).Sum(v => v.MostamariMablag);

                        if (count == null) count = 0;
                    }
                    catch
                    {

                    }
                    BeforDic.Add(i, count);
                }

            }

            int nm = 1;
            for (int i = 1; i <= nowmonth; i++)
            {
                DateTime dateaz = (DateTime)(nowyear + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    nowyear += 1;
                    nm = 1;
                }
                else
                {
                    nm = i + 1;
                }
                DateTime dateta = (DateTime)(nowyear + "/" + nm + "/1").ToMilady();
                if (pardakhttype == "1")
                {
                    long count = 0;
                    try
                    {
                        count = (long)(from e in db.G_M_Pays where e.PayDate >= dateaz && e.PayDate < dateta select e.TotGestMablag).Sum();

                        if (count == null) count = 0;
                    }
                    catch
                    {

                    }
                    NowDic.Add(i, count);
                }
                else
                {
                    long count = 0;
                    try
                    {
                        count = (long)(from e in db.G_M_Pays where e.PayDate >= dateaz && e.PayDate < dateta select e.MostamariMablag).Sum();

                        if (count == null) count = 0;
                    }
                    catch
                    {

                    }
                    NowDic.Add(i, count);
                }
            }

            nowyear = pl.GetYear(now);
            beforyea = nowyear - 1;
            Dictionary<string, long> Result = new Dictionary<string, long>();
            for (int k = 0; k < BeforDic.Count; k++)
            {
                switch (BeforDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                }
            }

            for (int k = 0; k < NowDic.Count; k++)
            {
                switch (NowDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                }
            }


            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetVamChartData(string vamtype = "")
        {
            int vtype = 1001;
            if (vamtype != "")
                vtype = int.Parse(vamtype);
            SandooghModel db = new SandooghModel();
            DateTime now = DateTime.Now;
            PersianCalendar pl = new PersianCalendar();
            int nowmonth = pl.GetMonth(now);
            int nowyear = pl.GetYear(now);
            int beforyea = nowyear - 1;
            int beformonth = 1;
            Dictionary<int, int> BeforDic = new Dictionary<int, int>();
            Dictionary<int, int> NowDic = new Dictionary<int, int>();
            for (int i = 1; i <= 12; i++)
            {
                DateTime dateaz = (DateTime)(beforyea + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    beforyea += 1;
                    beformonth = 1;
                }
                else
                {
                    beformonth = i + 1;
                }
                DateTime dateta = (DateTime)(beforyea + "/" + beformonth + "/1").ToMilady();
                int count = (from e in db.Vams where e.IdRefNoeVam == vtype && e.VamDate >= dateaz && e.VamDate < dateta select e.Vam_Id).Count();
                if (count == null) count = 0;
                BeforDic.Add(i, count);

            }

            int nm = 1;
            for (int i = 1; i <= nowmonth; i++)
            {
                DateTime dateaz = (DateTime)(nowyear + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    nowyear += 1;
                    nm = 1;
                }
                else
                {
                    nm = i + 1;
                }
                DateTime dateta = (DateTime)(nowyear + "/" + nm + "/1").ToMilady();
                int count = (from e in db.Vams where e.IdRefNoeVam == vtype && e.VamDate >= dateaz && e.VamDate < dateta select e.Vam_Id).Count();
                if (count == null) count = 0;
                NowDic.Add(i, count);
            }

            nowyear = pl.GetYear(now);
            beforyea = nowyear - 1;
            Dictionary<string, int> Result = new Dictionary<string, int>();
            for (int k = 0; k < BeforDic.Count; k++)
            {
                switch (BeforDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                }
            }

            for (int k = 0; k < NowDic.Count; k++)
            {
                switch (NowDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                }
            }


            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Tasvieh()
        {

            SandooghModel db = new SandooghModel();
            List<SelectListItem> NahvePardakhtList = new List<SelectListItem>();



            List<Nahveh_PTasvie> nahvepardakhtList = db.Nahveh_PTasvie.ToList();


            foreach (Nahveh_PTasvie nahv in nahvepardakhtList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = nahv.Id.ToString();
                sli.Text = nahv.Nahveh_P.ToString();
                NahvePardakhtList.Add(sli);
            }
            ViewBag.Nahvepardakht = NahvePardakhtList;
            return View();
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddTasvieh(Tasvieh postData, string mandevam, string summostamary, string BankTafsilicode, string Sanad = "")
        {


            SandooghModel db = new SandooghModel();


            int UserSanad = 0;
            if (Sanad != "")
            {
                try
                {
                    UserSanad = int.Parse(Sanad);
                }
                catch
                {
                    return Json(false);
                }
            }
            if (UserSanad != 0)
            {
                var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                string startyear = yearrr.Year_Name + "/01/01";
                string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var sd = (from e in db.AccSanad_B where e.Sanad_No == UserSanad && DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).FirstOrDefault();
                if ((((DateTime)postData.PayDate).Date != sd.Date_S.Date && sd.Date_S != DateTime.MinValue) || (sd.Lock_Sanad == true))
                {
                    return Json("SanadError1");
                }
            }
            try
            {

                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                int moeinbank = -1;
                try
                {
                    moeinbank = int.Parse(BankTafsilicode);

                }
                catch
                {
                    return Json(false);
                }

                int Mandevam = 0;
                int SumMostamary = 0;

                try
                {
                    Mandevam = int.Parse(mandevam);

                }
                catch
                {

                }
                try
                {
                    SumMostamary = int.Parse(summostamary);
                }
                catch
                {

                }
                postData.Nahveh_P = 3;


                var TasviehDate = (DateTime)postData.PayDate;
                var maxValue = UserSanad;
                if (UserSanad == 0)
                {
                    var DateOfPay = (DateTime)postData.PayDate;
                    var sanadno = (from e in db.AccSanad_B
                                   where
           e.Date_S.Year == DateOfPay.Year
           && e.Date_S.Month == DateOfPay.Month
           && e.Date_S.Day == DateOfPay.Day
           && (e.Lock_Sanad != true) && (e.UserLock != true)
                                   select e.Sanad_No).Distinct();
                    var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                    string startyear = yearrr.Year_Name + "/01/01";
                    string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                    DateTime datestart = (DateTime)startyear.ToMilady();
                    DateTime dateend = (DateTime)endyear.ToMilady();
                    var thisyearssanads = from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e;

                    var max = thisyearssanads.Max(x => x.Sanad_No);
                    if (sanadno.ToList().Count == 0)
                    {
                        if (DateTime.Now.Date == ((DateTime)postData.PayDate).Date)
                            maxValue = (int)max + 1;
                        else
                            return Json("SanadError1");
                    }
                    else
                        maxValue = (int)sanadno.ToList().Max();
                }


                string sanads = "";

                //حساب مستمری بدهکار
                if (SumMostamary != 0)
                {
                    var ozvname = "";
                    try
                    {
                        ozvname = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e.FName + " " + e.LName).FirstOrDefault();
                    }
                    catch
                    {

                    }
                    postData.Comment += (" " + ozvname);
                    AccSanad_B sanad1 = new AccSanad_B();
                    sanad1.Sanad_No = maxValue;
                    sanad1.Group = "3";
                    sanad1.Kol = "311";
                    //var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == moeinbank select e;
                    string moeincode = "003";
                    //if (bankmoein != null)
                    //    moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;

                    sanad1.Moein = moeincode;
                    sanad1.Tafsili = postData.IdRefOzv.ToString();
                    sanad1.Date_S = (DateTime)postData.PayDate;
                    sanad1.Sanad_Tafsili1 = 2;
                    sanad1.Ok_NotOk = false;
                    sanad1.Lock_Sanad = false;
                    sanad1.Bedhkar = SumMostamary;
                    sanad1.Bestankar = 0;
                    sanad1.Articl_Comment = postData.Comment;
                    db.AccSanad_B.Add(sanad1);

                    db.SaveChanges();
                    sanads += sanad1.ID + ",";
                }
                G_M_Pays pardakht = new G_M_Pays();
                if (Mandevam != 0)
                {
                    var vamnoe = (from e in db.Vams where e.IdRefOzv == postData.IdRefOzv && e.EtmamVam == false select e.IdRefNoeVam).FirstOrDefault();
                    //وام عضو بستانکار
                    AccSanad_B sanad = new AccSanad_B();
                    sanad.Sanad_No = maxValue;
                    sanad.Group = "1";
                    sanad.Kol = "112";
                    switch (vamnoe)
                    {
                        case 1001:
                            sanad.Moein = "001";
                            break;
                        case 1002:
                            sanad.Moein = "003";
                            break;
                        case 1003:
                            sanad.Moein = "002";
                            break;
                    }
                    pardakht.IdRefNoeVam = vamnoe;
                    pardakht.IdRefVam = (from e in db.Vams where e.IdRefOzv == postData.IdRefOzv && e.EtmamVam == false select e.Vam_Id).FirstOrDefault();
                    pardakht.TotGestMablag = Mandevam;

                    Vam vam = (from e in db.Vams where e.Vam_Id == pardakht.IdRefVam select e).FirstOrDefault();
                    vam.EtmamVam = true;
                    db.Entry(vam).State = System.Data.Entity.EntityState.Modified;

                    sanad.Tafsili = postData.IdRefOzv.ToString();
                    sanad.Date_S = (DateTime)postData.PayDate;
                    sanad.Sanad_Tafsili1 = 2;
                    sanad.Ok_NotOk = false;
                    sanad.Lock_Sanad = false;
                    sanad.Bedhkar = 0;
                    sanad.Bestankar = Mandevam;
                    sanad.Articl_Comment = postData.Comment;
                    db.AccSanad_B.Add(sanad);

                    db.SaveChanges();
                    sanads += sanad.ID + ",";
                }
                string gghjhhhhh = moeinbank.ToString();
                var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == gghjhhhhh select e;/*1212*/
                string moeincode1 = "";
                if (bankmoein != null)
                    moeincode1 = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                if (moeincode1 != null)
                {
                    if (postData.MostamariMablag != 0)
                    {
                        //بانک بستانکار
                        AccSanad_B sanad = new AccSanad_B();
                        sanad.Sanad_No = maxValue;
                        sanad.Group = "1";
                        sanad.Kol = "111";
                        sanad.Moein = moeincode1;
                        sanad.Tafsili = BankTafsilicode;
                        sanad.Date_S = (DateTime)postData.PayDate;
                        sanad.Sanad_Tafsili1 = 1;
                        sanad.Ok_NotOk = false;
                        sanad.Lock_Sanad = false;
                        sanad.Bedhkar = 0;
                        sanad.Bestankar = postData.MostamariMablag;
                        sanad.Articl_Comment = postData.Comment;
                        db.AccSanad_B.Add(sanad);


                        db.SaveChanges();
                        sanads += sanad.ID + ",";
                    }
                    pardakht.Comment = "تسویه حساب ";
                    pardakht.IdRefOzv = postData.IdRefOzv;
                    pardakht.MostamariMablag = -1 * (SumMostamary);
                    pardakht.PayDate = postData.PayDate;
                    pardakht.TotMablag = pardakht.MostamariMablag + pardakht.TotGestMablag;


                    db.G_M_Pays.Add(pardakht);
                    db.SaveChanges();
                    //new if
                    if (pardakht.IsAfzayesh == true)
                    {
                        try
                        {

                            T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == pardakht.IdRefOzv select e).FirstOrDefault();
                            ozv.SumAfzayeshMostamary -= (int)pardakht.MostamariMablag;
                            db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                            db.SaveChanges();

                            if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > pardakht.PayDate)
                            {
                                T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                                lastmostpaie.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == lastmostpaie.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)lastmostpaie.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
                                db.Entry(lastmostpaie).State = System.Data.Entity.EntityState.Modified;
                                db.SaveChanges();
                            }

                        }
                        catch
                        {

                        }
                    }
                }



                //todo: Add product to repository
                if (postData == null)
                    return Json(false);



                postData.Sanads = sanads;
                postData.SanadNo = maxValue;
                db.Tasviehs.Add(postData);

                db.SaveChanges();
                //حذف اطلاعات کاربری
                var user = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e).FirstOrDefault();
                user.Faal = false;
                db.Entry(user).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                Membership.GetUser(user.Id).ChangePassword(Membership.GetUser(user.Id).GetPassword(), "@asdwZcv");
                Membership.GetUser(user.Id).IsApproved = false;


                return Json(true);
            }
            catch
            {
                return Json(false);
            }

        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditTasvie(Tasvieh postData, string mandevam, string summostamary, string BankTafsilicode)
        {
            //دووامه:این مانده وام ببینید چجوری میاد

            int moeinbank = -1;
            try
            {
                moeinbank = int.Parse(BankTafsilicode);

            }
            catch
            {
                return Json(false);
            }
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            int Mandevam = 0;
            int SumMostamary = 0;

            try
            {
                Mandevam = int.Parse(mandevam);

            }
            catch
            {

            }
            try
            {
                SumMostamary = int.Parse(summostamary);
            }
            catch
            {

            }
            var now = DateTime.Now.Date;
            var sanadno = (from e in db.AccSanad_B
                           where
                       e.Date_S.Year == now.Year
                       && e.Date_S.Month == now.Month
                       && e.Date_S.Day == now.Day
                       && (e.Lock_Sanad != true) && (e.UserLock != true)
                           select e.Sanad_No).Distinct();
            var maxValue = db.AccSanad_B.Max(x => x.Sanad_No);
            if (sanadno.ToList().Count == 0)
            {

                maxValue = maxValue + 1;
            }
            else
                maxValue = maxValue = (int)sanadno.ToList().Max();

            string Sanads = postData.Sanads;
            if (Sanads != null && Sanads != "")
            {
                string[] SanadsArray = Sanads.Split(',');

                for (int i = SanadsArray.Count() - 1; i >= 0; i--)
                {
                    try
                    {
                        string sanad = SanadsArray[i];
                        int id1 = int.Parse(sanad);
                        AccSanad_B san = (from e in db.AccSanad_B where e.ID == id1 select e).FirstOrDefault();
                        double bed = (double)san.Bedhkar;
                        san.Bedhkar = san.Bestankar;
                        san.Bestankar = bed;
                        san.Date_S = DateTime.Now;
                        san.Sanad_No = maxValue;
                        san.Articl_Comment = " اصلاحیه- ویرایش تسویه-" + san.Articl_Comment;
                        db.AccSanad_B.Add(san);
                        db.SaveChanges();

                    }
                    catch
                    {

                    }

                }
            }
            string sanads = "";

            //حساب مستمری بدهکار
            if (SumMostamary != 0)
            {
                AccSanad_B sanad1 = new AccSanad_B();
                sanad1.Sanad_No = maxValue;
                sanad1.Group = "3";
                sanad1.Kol = "311";
                //var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == moeinbank select e;
                string moeincode = "003";
                //if (bankmoein != null)
                //    moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;

                sanad1.Moein = moeincode;
                sanad1.Tafsili = postData.IdRefOzv.ToString();
                sanad1.Date_S = DateTime.Now;
                sanad1.Sanad_Tafsili1 = 2;
                sanad1.Ok_NotOk = false;
                sanad1.Lock_Sanad = false;
                sanad1.Bedhkar = SumMostamary;
                sanad1.Bestankar = 0;
                sanad1.Articl_Comment = postData.Comment;
                db.AccSanad_B.Add(sanad1);

                db.SaveChanges();
                sanads += sanad1.ID + ",";
            }
            if (Mandevam != 0)
            {
                var vamnoe = (from e in db.Vams where e.IdRefOzv == postData.IdRefOzv && e.EtmamVam == false select e.IdRefNoeVam).FirstOrDefault();
                //وام عضو بستانکار
                AccSanad_B sanad = new AccSanad_B();
                sanad.Sanad_No = maxValue;
                sanad.Group = "1";
                sanad.Kol = "112";
                switch (vamnoe)
                {
                    case 1001:
                        sanad.Moein = "001";
                        break;
                    case 1002:
                        sanad.Moein = "003";
                        break;
                    case 1003:
                        sanad.Moein = "002";
                        break;
                }

                sanad.Tafsili = postData.IdRefOzv.ToString();
                sanad.Date_S = DateTime.Now;
                sanad.Sanad_Tafsili1 = 2;
                sanad.Ok_NotOk = false;
                sanad.Lock_Sanad = false;
                sanad.Bedhkar = 0;
                sanad.Bestankar = Mandevam;
                sanad.Articl_Comment = postData.Comment;
                db.AccSanad_B.Add(sanad);

                db.SaveChanges();
                sanads += sanad.ID + ",";
            }
            string gghhhhhjhh = moeinbank.ToString();
            var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == gghhhhhjhh select e;/*1212*/
            string moeincode1 = "";
            if (bankmoein != null)
                moeincode1 = bankmoein.ToList()[0].Tafsili2_MoeinCode;
            if (moeincode1 != null)
            {
                if (postData.MostamariMablag != 0)
                {
                    //بانک بستانکار
                    AccSanad_B sanad = new AccSanad_B();
                    sanad.Sanad_No = maxValue;
                    sanad.Group = "1";
                    sanad.Kol = "111";
                    sanad.Moein = moeincode1;
                    sanad.Tafsili = BankTafsilicode;
                    sanad.Date_S = DateTime.Now;
                    sanad.Sanad_Tafsili1 = 1;
                    sanad.Ok_NotOk = false;
                    sanad.Lock_Sanad = false;
                    sanad.Bedhkar = 0;
                    sanad.Bestankar = postData.MostamariMablag;
                    sanad.Articl_Comment = postData.Comment;
                    db.AccSanad_B.Add(sanad);
                    db.SaveChanges();
                    sanads += sanad.ID + ",";
                }
            }
            postData.Sanads = sanads;
            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }



        [Authorize(Roles = "Admin")]
        [HttpGet]
        public JsonResult GetTasvieByMemberId(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var ozvwithid = from o in db.T_OzvCode where o.Id == idd select o;
                if (ozvwithid.ToList() != null && ozvwithid.ToList().Count > 0)
                {
                    //دووامه:اگه اکتیو وام دو تا بود چیکار کنیم؟

                    var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                    var activevam = (from w in db.Vams where w.IdRefOzv == idd && w.EtmamVam == false select w.Vam_Id).FirstOrDefault();
                    var mandevam = (double?)0;

                    var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.Vam.EtmamVam == false) select e;
                    var pardakhtVam = (double?)0;

                    try
                    {
                        pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;


                    }
                    catch
                    {

                    }
                    try
                    {
                        mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                        mandevam = mandevam - pardakhtVam;
                    }
                    catch
                    {

                    }
                    if (activevam == 0)
                    {
                        mandevam = 0;
                        pardakhtVam = 0;
                    }

                    var product =
                           from ozv in db.T_OzvCode
                           where ozv.Id.Equals(idd)
                           join
                   most in summostamarises on ozv.Id equals most.Id
                   into ozvmost
                           from ozvmostamary in ozvmost.DefaultIfEmpty()
                           select new
                           {
                               ozv.Id,
                               ozv.FName,
                               ozv.LName,
                               ozvmostamary.SumMostamary,
                               mandemostamary = ozvmostamary.SumMostamary - mandevam,
                               pardakhtVam,
                               mandevam

                           };
                    if (product == null)
                        return Json(false);

                    return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);
                }
                return Json(false);
            }//end try

            catch
            {
                return Json(false);
            }


        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditOption(Option_T postData, int hadaksarghabli = 0)
        {
            SandooghModel db = new SandooghModel();
            postData.id = 1;
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();

            if (hadaksarghabli != (int)postData.HadaksarSarmayeAvvalie)
            {
                try
                {
                    T_HadaksarAfzayeshChangeDate T_HSA = new T_HadaksarAfzayeshChangeDate();
                    T_HSA.HadaksarAfzayeshChangeDate_Datetime = DateTime.Now;
                    T_HSA.HadaksarAfzayeshChangeDate_Ghabli = hadaksarghabli.ToString();
                    T_HSA.HadaksarAfzayeshChangeDate_Jadid = postData.HadaksarSarmayeAvvalie.ToString();
                    T_HSA.HadaksarAfzayeshChangeDate_ModifiedUser = User.Identity.Name;
                    db.T_HadaksarAfzayeshChangeDate.Add(T_HSA);
                    db.SaveChanges();
                }
                catch
                {

                }
                //update all users
                foreach (var ozv in db.T_OzvCode)
                {
                    try
                    {
                        ozv.SumAfzayeshMostamary = ozv.SumAfzayeshMostamary + (postData.HadaksarSarmayeAvvalie - hadaksarghabli);
                        db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                    }
                    catch
                    {

                    }
                }
                db.SaveChanges();


            }

            return Json(true);
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetOptions()
        {
            try
            {


                //todo: Delete product
                SandooghModel db = new SandooghModel();

                var op = (from o in db.Option_T select o);
                // var maxdate = mostamarises.Max(x => x.MostamaryMablagh_DateStart);
                // var mostamary = from v in mostamarises where v.MostamaryMablagh_DateStart == maxdate select v.MostamaryMablagh_Mablagh;

                var product =

                       from ozv in op.DefaultIfEmpty()
                       select new
                       {
                           ozv.id,
                           ozv.C1,
                           ozv.C2,
                           ozv.C3,
                           ozv.C4,
                           ozv.E1,
                           ozv.E2,
                           ozv.E3,
                           ozv.E4,
                           ozv.M1,
                           ozv.M2,
                           ozv.M3,
                           ozv.M4,
                           ozv.HadaksarSarmayeAvvalie,
                           ozv.Hghjalase1,
                           ozv.Hghjalase2

                       };

                // Return the first option record as JSON
                return Json(
                    product.FirstOrDefault(),
                    JsonRequestBehavior.AllowGet
                );

            }//end try

            catch
            {
                return Json(
                    false,
                    JsonRequestBehavior.AllowGet
                );
            }
        }


        [Authorize(Roles = "Admin")]
        public ActionResult VamList(int vamtype = -1, int memberid = -1, int numghest = -1)
        {
            ViewBag.VamType = vamtype;
            ViewBag.NUMGhest = numghest;
            ViewBag.MemberId = memberid;
            SandooghModel db = new SandooghModel();
            List<Vam> FinalNobatlist = new List<Vam>();
            FinalNobatlist = db.Vams.ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();

            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }

            foreach (Vam model in FinalNobatlist)
            {
                model.AllVamTypes = allvamtypes;

            }
            if (FinalNobatlist.Count == 0)
                return null;

            return View(FinalNobatlist);
        }
        [Authorize(Roles = "Admin")]
        public ActionResult NobatVam()
        {
            SandooghModel db = new SandooghModel();
            List<VamNobat> FinalNobatlist = new List<VamNobat>();
            FinalNobatlist = db.VamNobats.ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();

            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }


            ViewBag.AllVamTypes = allvamtypes;



            return View(FinalNobatlist);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult MostamarryFromTo()
        {
            return View();
        }
        [Authorize(Roles = "Admin")]
        public ActionResult AghsatFromTo()
        {
            List<SelectListItem> allvamtypes = new List<SelectListItem>();
            SandooghModel db = new SandooghModel();
            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            SelectListItem sli = new SelectListItem();
            sli.Value = "";
            sli.Text = "همه موارد";
            allvamtypes.Add(sli);
            foreach (T_VamCode vamcode in allvamcodes)
            {
                sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }


            ViewBag.AllVamTypes = allvamtypes;
            return View();
        }


        [Authorize(Roles = "Admin")]
        public ActionResult AllPardakhtReport()
        {
            return View();
        }



        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult SendZamenSms(string num)
        {
            double numaghaboftade = 100000.00;
            try
            {
                numaghaboftade = double.Parse(num);
            }
            catch
            {

            }
            SandooghModel db = new SandooghModel();


            var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam != null && e.Vam.EtmamVam == false && e.T_OzvCode != null && e.T_OzvCode.Faal == true) select e;

            var pardakhtHarVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) });
            var Zeropardakhty = (from v in db.Vams where (v.EtmamVam == false && v.G_M_Pays.Count == 0) select v);

            Zeropardakhty = (from e in Zeropardakhty where e.T_OzvCode != null && e.T_OzvCode.Faal == true select e);


            pardakhtHarVam = pardakhtHarVam.Union(from e in Zeropardakhty select new { Vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });

            var persianCalendar = new System.Globalization.PersianCalendar();
            int nowyear = persianCalendar.GetYear(DateTime.Now);
            int nowmonth = persianCalendar.GetMonth(DateTime.Now);
            int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);

            var MablaghSarresidKolliVam = (from m in db.Vams.ToList()
                                           where (m.EtmamVam == false && m.T_OzvCode != null && m.T_OzvCode.Faal == true)
                                           select new
                                           {
                                               //  Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)),
                                               Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)),

                                               vamid = m.Vam_Id,
                                               mablaghghest = m.GestMablag,
                                               codeozviat = m.T_OzvCode.Id,
                                               fname = m.T_OzvCode.FName,
                                               lname = m.T_OzvCode.LName,
                                               datepardakhtvam = ((DateTime)m.VamDate).ToPersianDate(),
                                               vtype = m.T_VamCode.VamName,
                                               mobile = m.T_OzvCode.Mobile,

                                               ZamenName = (m.VamZamen != null && m.VamZamen.ToList().Count > 0 && m.VamZamen.FirstOrDefault().T_OzvCode != null) ? m.VamZamen.FirstOrDefault().T_OzvCode.FName + " " + m.VamZamen.FirstOrDefault().T_OzvCode.LName : "",
                                               ZamenPhone = (m.VamZamen != null && m.VamZamen.ToList().Count > 0 && m.VamZamen.FirstOrDefault().T_OzvCode != null) ? m.VamZamen.FirstOrDefault().T_OzvCode.Mobile : ""
                                           });
            var product1 =
                               (from vampardakhty in pardakhtHarVam.ToList()
                                join
                        mablaghsarresidkolii in MablaghSarresidKolliVam.ToList() on vampardakhty.Vamid equals mablaghsarresidkolii.vamid

                        into Report
                                from rep in Report.DefaultIfEmpty()
                                select new
                                {
                                    rep.vamid,
                                    rep.fname,
                                    rep.lname,
                                    rep.datepardakhtvam,
                                    rep.mablaghghest,
                                    rep.codeozviat,
                                    rep.Sarresid,
                                    vampardakhty.SumPardakhty,
                                    rep.vtype,
                                    rep.mobile,
                                    tedad = (rep.Sarresid - vampardakhty.SumPardakhty) > 0 ? Math.Round(((double)rep.Sarresid - (double)vampardakhty.SumPardakhty) / (double)rep.mablaghghest) : 0
                                 ,
                                    ZamenName = rep.ZamenName,
                                    ZamenPhone = rep.ZamenPhone


                                }).ToList();




            var productsList = (from e in product1 where e.tedad >= numaghaboftade select e.ZamenPhone).ToList();
            List<string> numbers = new List<string>();
            foreach (string s in productsList)
            {
                int d = 1;
                numbers.Add(s);
                d++;
                if (d == 98)
                {
                    d = 1;
                    SendMsg(numbers.ToArray(), "عضو محترم صنم" +
                        "\n" + " باتوجه به ضمانت شما وعدم پرداخت اقساط توسط وام گیرنده لطفا هرچه سریعترجهت پرداخت اقساط به دفتر صندوق مراجعه فرمایید.درصورت عدم پرداخت از طریق چک یا سفته های ضمانت اقدام خواهد شد");
                    numbers = new List<string>();

                }

            }
            if (numbers.Count > 0)
            {
                SendMsg(numbers.ToArray(), "عضو محترم صنم" +
                       "\n" + " باتوجه به ضمانت شما وعدم پرداخت اقساط توسط وام گیرنده لطفا هرچه سریعترجهت پرداخت اقساط به دفتر صندوق مراجعه فرمایید.درصورت عدم پرداخت از طریق چک یا سفته های ضمانت اقدام خواهد شد");

            }
            return Json(productsList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetAllPardakhtReportmost(string sidx, string sord, int page, int rows, string ozv, string mostdate = "")
        {
            DateTime azdatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)mostdate.ToMilady();
            }
            catch
            {
                azdatei = DateTime.MinValue;
            }

            SandooghModel db = new SandooghModel();
            MVCSmartLibrary.Controllers.OzviatController ozvcontrol = new MVCSmartLibrary.Controllers.OzviatController();
            var persianCalendar = new System.Globalization.PersianCalendar();
            var pays = from e in db.G_M_Pays where e.PayDate > azdatei && e.MostamariMablag > 0 select e.IdRefOzv;
            var ozvs = from e in db.T_OzvCode where !pays.Contains(e.Id) && e.Faal == true select e;
            List<T_OzvCode> varizkarde = new List<T_OzvCode>();
            List<T_OzvCode> variznakarde = new List<T_OzvCode>();

            foreach (T_OzvCode varozv in ozvs)
            {
                var result = ozvcontrol.GeMostamaryMablaghByid(varozv.Id);

                try
                {
                    if (PersianDateUtils.ToMilady(((result.Data as IEnumerable<dynamic>)?.FirstOrDefault()).AkharinVosoliDate) < azdatei)
                    {
                        variznakarde.Add(varozv);
                    }
                    else

                    {
                        varizkarde.Add(varozv);
                    }
                }
                catch
                {
                    //12723
                }
            }
            var product1 = variznakarde.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = product1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = product1.AsQueryable();
            var productsList = productsQuery.OrderBy("id asc," + sidx + " " + sord).Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();


            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                  product.Id
                    ,  product.FName,product.LName ,product.Mobile

                              }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult SendFardmostSms(string num)
        {
            DateTime azdatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)num.ToMilady();
            }
            catch
            {

            }

            SandooghModel db = new SandooghModel();
            var persianCalendar = new System.Globalization.PersianCalendar();
            var pays = from e in db.G_M_Pays where e.PayDate > azdatei && e.MostamariMablag > 0 select e.IdRefOzv;
            var ozvs = from e in db.T_OzvCode where !pays.Contains(e.Id) && e.Faal == true select e;
            List<T_OzvCode> varizkarde = new List<T_OzvCode>();
            List<T_OzvCode> variznakarde = new List<T_OzvCode>();
            MVCSmartLibrary.Controllers.OzviatController ozvcontrol = new MVCSmartLibrary.Controllers.OzviatController();
            foreach (T_OzvCode varozv in ozvs)
            {
                var result = ozvcontrol.GeMostamaryMablaghByid(varozv.Id);

                try
                {
                    if (PersianDateUtils.ToMilady(((result.Data as IEnumerable<dynamic>)?.FirstOrDefault()).AkharinVosoliDate) < azdatei)
                    {
                        variznakarde.Add(varozv);
                    }
                    else

                    {
                        varizkarde.Add(varozv);
                    }
                }
                catch
                {
                    //12723
                }
            }

            var productsList = variznakarde.Select(k => k.Mobile).ToList();
            List<string> numbers = new List<string>();
            int d = 1;
            foreach (string s in productsList)
            {

                numbers.Add(s);
                d++;
                if (d == 98)
                {
                    d = 1;
                    SendMsg(numbers.ToArray(), "عضو محترم صنم" + "\n" +
 "باسلام" + "\n" +
 "لطفا جهت بروز نمودن حساب مستمری خود اقدام فرمائید.");
                    numbers = new List<string>();

                }

            }
            if (numbers.Count > 0)
            {
                SendMsg(numbers.ToArray(), "عضو محترم صنم" + "\n" +
"باسلام" + "\n" +
"لطفا جهت بروز نمودن حساب مستمری خوداقدام فرمائید.");
            }
            return Json(productsList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult SendFardSms(string num)
        {

            double numaghaboftade = 100000.00;
            try
            {
                numaghaboftade = double.Parse(num);
            }
            catch
            {
            }
            SandooghModel db = new SandooghModel();
            var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam != null && e.Vam.EtmamVam == false && e.T_OzvCode != null && e.T_OzvCode.Faal == true) select e;
            var pardakhtHarVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) });
            var Zeropardakhty = (from v in db.Vams where (v.EtmamVam == false && v.G_M_Pays.Count == 0) select v);
            Zeropardakhty = (from e in Zeropardakhty where e.T_OzvCode != null && e.T_OzvCode.Faal == true select e);


            pardakhtHarVam = pardakhtHarVam.Union(from e in Zeropardakhty select new { Vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });

            var persianCalendar = new System.Globalization.PersianCalendar();
            int nowyear = persianCalendar.GetYear(DateTime.Now);
            int nowmonth = persianCalendar.GetMonth(DateTime.Now);
            int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);
            var vams = (from m in db.Vams
                        where (m.EtmamVam == false && m.T_OzvCode != null && m.T_OzvCode.Faal == true)
                        select m).ToList();
            var MablaghSarresidKolliVam = (from m in vams
                                           select new
                                           {
                                               // Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)),
                                               Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)),

                                               vamid = m.Vam_Id,
                                               mablaghghest = m.GestMablag,
                                               codeozviat = m.T_OzvCode.Id,
                                               fname = m.T_OzvCode.FName,
                                               lname = m.T_OzvCode.LName,
                                               datepardakhtvam = ((DateTime)m.VamDate).ToPersianDate(),
                                               vtype = m.T_VamCode.VamName,
                                               mobile = m.T_OzvCode.Mobile,

                                               ZamenName = (m.VamZamen != null && m.VamZamen.ToList().Count > 0 && m.VamZamen.FirstOrDefault().T_OzvCode != null) ? m.VamZamen.FirstOrDefault().T_OzvCode.FName + " " + m.VamZamen.FirstOrDefault().T_OzvCode.LName : "",
                                               ZamenPhone = (m.VamZamen != null && m.VamZamen.ToList().Count > 0 && m.VamZamen.FirstOrDefault().T_OzvCode != null) ? m.VamZamen.FirstOrDefault().T_OzvCode.Mobile : ""
                                           });
            var product1 =
                               (from vampardakhty in pardakhtHarVam.ToList()
                                join
                        mablaghsarresidkolii in MablaghSarresidKolliVam.ToList() on vampardakhty.Vamid equals mablaghsarresidkolii.vamid

                        into Report
                                from rep in Report.DefaultIfEmpty()
                                select new
                                {
                                    rep.vamid,
                                    rep.fname,
                                    rep.lname,
                                    rep.datepardakhtvam,
                                    rep.mablaghghest,
                                    rep.codeozviat,
                                    rep.Sarresid,
                                    vampardakhty.SumPardakhty,
                                    rep.vtype,
                                    rep.mobile,
                                    tedad = (rep.Sarresid - vampardakhty.SumPardakhty) > 0 ? Math.Round(((double)rep.Sarresid - (double)vampardakhty.SumPardakhty) / (double)rep.mablaghghest) : 0
                                 ,
                                    ZamenName = rep.ZamenName,
                                    ZamenPhone = rep.ZamenPhone


                                }).ToList();




            var productsList = (from e in product1 where e.tedad >= numaghaboftade select e.mobile).ToList();
            List<string> numbers = new List<string>();
            int d = 1;
            foreach (string s in productsList)
            {

                numbers.Add(s);
                d++;
                if (d == 98)
                {
                    d = 1;
                    SendMsg(numbers.ToArray(), "عضو محترم صنم" + "\n" +
 "باسلام" + "\n" +
 "پرداخت اقساط ومستمري جنابعالي به تعويق افتاده است،خواهشمند است هرچه سريعتر بدهي خود را تسويه نماييد.");
                    numbers = new List<string>();

                }

            }
            if (numbers.Count > 0)
            {
                SendMsg(numbers.ToArray(), "عضو محترم صنم" + "\n" +
               "باسلام" + "\n" +
               "پرداخت اقساط ومستمري جنابعالي به تعويق افتاده است،خواهشمند است هرچه سريعتر بدهي خود را تسويه نماييد.");

            }
            return Json(productsList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMostamarryReport(string sidx, string sord, int page, int rows, string azdate = "", string tadate = "", bool onlyAfzayesh = false)
        {
            Session["SumMostamarry"] = 0;
            SandooghModel db = new SandooghModel();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            // var list = (from e in db.G_M_Pays where e.MostamariMablag!=null && e.MostamariMablag != 0 && e.PayDate >= azdatei && e.PayDate <= tadatei /*where e.IdRefOzv==10324*/  select  new { e.Id,e.MostamariMablag,e.IdRefOzv}).Distinct().ToList();
            var members = (from e in db.T_OzvCode select e);
            try
            {

                var list1 = (from v in db.G_M_Pays.Where(e => e.PayDate >= azdatei && e.PayDate <= tadatei) group v by v.IdRefOzv into g select new { ozvid = g.Key, SumPardakhty = g.Sum(v => v.MostamariMablag), date = g.Max(x => x.PayDate) });
                if (onlyAfzayesh == true)
                {
                    list1 = (from v in db.G_M_Pays.Where(e => e.PayDate >= azdatei && e.PayDate <= tadatei) where v.IsAfzayesh == true select new { ozvid = v.IdRefOzv, SumPardakhty = v.MostamariMablag, date = v.PayDate });
                }
                //  var list1 = (from v in list group v by v.IdRefOzv into g select new { ozvid = g.Key, SumPardakhty = g.Sum(k => k.MostamariMablag) });




                var product1 = (from pardakhty in list1.ToList()
                                join
                         member in members on pardakhty.ozvid equals member.Id

                         into Report
                                from rep in Report.DefaultIfEmpty()
                                select new
                                {
                                    activevam = rep.Vams.Any(l => l.EtmamVam != true) ? "دارد" : "ندارد",
                                    rep.Id,
                                    rep.FName,
                                    rep.LName,
                                    date = pardakhty.date != null ? ((DateTime)pardakhty.date).ToPersianDate() : "",
                                    rep.Mobile,
                                    most = pardakhty.SumPardakhty
                                }).ToList();


                var sumpardakhty = product1.Sum(x => x.most);
                Session["SumMostamarry"] = sumpardakhty;

                var totalRecords = product1.Count;
                var totalPages = 1;

                var productsQuery = product1.AsQueryable();
                var productsList = productsQuery.OrderBy("Id asc," + sidx + " " + sord)

                                                .ToList();


                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.Id,
                        RowCells = new List<object>
                               {
                 product.Id, product.FName,product.LName
                    , product.date,product.Mobile, product.most,product.activevam
                              }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMostamarrySum(string sidx, string sord, int page, int rows, string azdate = "", string tadate = "", bool onlyafzayesh = false)
        {

            Session["SumMostamarry"] = 0;
            SandooghModel db = new SandooghModel();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            var list = (from e in db.G_M_Pays where e.MostamariMablag != 0 && e.MostamariMablag != null && e.PayDate >= azdatei && e.PayDate <= tadatei select new { e.Id, e.IdRefOzv, e.MostamariMablag }).Distinct().ToList();
            if (onlyafzayesh)
            {
                list = (from e in db.G_M_Pays where e.IsAfzayesh == true && e.MostamariMablag != 0 && e.MostamariMablag != null && e.PayDate >= azdatei && e.PayDate <= tadatei select new { e.Id, e.IdRefOzv, e.MostamariMablag }).Distinct().ToList();

            }
            var members = from e in db.T_OzvCode select e;

            try
            {
                var list1 = (from v in list group v by v.IdRefOzv into g select new { ozvid = g.Key, SumPardakhty = g.Sum(k => k.MostamariMablag) }).Sum(g => g.SumPardakhty);


                var sumpardakhty = list1.Value;
                return Json(sumpardakhty, JsonRequestBehavior.AllowGet);
            }
            catch
            {

            }


            return null;




        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetAghsatReport(string sidx, string sord, int page, int rows, string azdate = "", string tadate = "", string vamcode = "")
        {
            Session["SumPardakhty"] = 0;
            SandooghModel db = new SandooghModel();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            var listkol = (from e in db.G_M_Pays where e.IdRefVam != null && e.IdRefVam != 0 && e.Vam.IdRefNoeVam.ToString().Contains(vamcode) select e).ToList();
            var list = (from e in db.G_M_Pays where e.PayDate >= azdatei && e.PayDate <= tadatei && e.IdRefVam != null && e.IdRefVam != 0 && e.Vam.IdRefNoeVam.ToString().Contains(vamcode) select e).ToList();
            var list1 = (from e in list group e by e.IdRefVam into g select new { vamid = g.Key, SumPardakhty = g.Sum(e => e.TotGestMablag) });
            list1 = list1.Union(from e in db.Vams where e.IdRefNoeVam.ToString().Contains(vamcode) && e.G_M_Pays.Count == 0 select new { vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });
            var list2 = (from v in listkol group v by v.IdRefVam into g select new { vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).Union(from e in db.Vams where e.VamDate >= azdatei && e.VamDate <= tadatei && e.IdRefNoeVam.ToString().Contains(vamcode) && e.G_M_Pays.Count == 0 select new { vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });
            var vams = from e in db.Vams select e;


            var product1 = (from pardakhtykol in list2
                            join p in list1 on pardakhtykol.vamid equals p.vamid

                            join
                    vam in vams on p.vamid equals vam.Vam_Id

                    into Report
                            from rep in Report.DefaultIfEmpty()
                            select new
                            {

                                Id = rep.Vam_Id,
                                Idozv = rep.T_OzvCode.Id,
                                vamdate = ((DateTime)rep.VamDate).ToPersianDate(),
                                rep.T_OzvCode.FName,
                                rep.T_OzvCode.LName,
                                rep.T_VamCode.VamName,
                                mablagh = rep.Karmozd + rep.VamMablagKhales,
                                rep.Karmozd,
                                rep.VamMablagKhales,
                                rep.GestMablag,
                                pardakhtymablagh = p.SumPardakhty,
                                mandevam = (rep.Karmozd + rep.VamMablagKhales) - (pardakhtykol.SumPardakhty)
                            }).ToList();


            var sumpardakhty = product1.Sum(x => x.pardakhtymablagh);
            Session["SumPardakhty"] = sumpardakhty;
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = product1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = product1.AsQueryable();
            var productsList = productsQuery.OrderBy("Idozv asc," + sidx + " " + sord).Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();


            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                         product.Id,
                         product.Idozv,
                        product.vamdate ,
                        product.FName,
                        product.LName,
                        product.VamName,
                       product. mablagh,
                        product.Karmozd,
                        product.VamMablagKhales,
                       product.GestMablag ,
                        product.pardakhtymablagh ,
                        product.mandevam
                    }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetAghsatSum(string sidx, string sord, int page, int rows, string azdate = "", string tadate = "", string vamcode = "")
        {


            SandooghModel db = new SandooghModel();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            var listkol = (from e in db.G_M_Pays where e.IdRefVam != null && e.IdRefVam != 0 && e.Vam.IdRefNoeVam.ToString().Contains(vamcode) select e).ToList();
            var list = (from e in db.G_M_Pays where e.PayDate >= azdatei && e.PayDate <= tadatei && e.IdRefVam != null && e.IdRefVam != 0 && e.Vam.IdRefNoeVam.ToString().Contains(vamcode) select e).ToList();
            var list1 = (from e in list group e by e.IdRefVam into g select new { vamid = g.Key, SumPardakhty = g.Sum(e => e.TotGestMablag) });
            list1 = list1.Union(from e in db.Vams where e.IdRefNoeVam.ToString().Contains(vamcode) && e.G_M_Pays.Count == 0 select new { vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });
            var list2 = (from v in listkol group v by v.IdRefVam into g select new { vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).Union(from e in db.Vams where e.VamDate >= azdatei && e.VamDate <= tadatei && e.IdRefNoeVam.ToString().Contains(vamcode) && e.G_M_Pays.Count == 0 select new { vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });
            var vams = from e in db.Vams select e;


            var product1 = (from pardakhtykol in list2
                            join p in list1 on pardakhtykol.vamid equals p.vamid

                            join
                    vam in vams on p.vamid equals vam.Vam_Id

                    into Report
                            from rep in Report.DefaultIfEmpty()
                            select new
                            {

                                Id = rep.Vam_Id,
                                Idozv = rep.T_OzvCode.Id,
                                vamdate = ((DateTime)rep.VamDate).ToPersianDate(),
                                rep.T_OzvCode.FName,
                                rep.T_OzvCode.LName,
                                rep.T_VamCode.VamName,
                                mablagh = rep.Karmozd + rep.VamMablagKhales,
                                rep.Karmozd,
                                rep.VamMablagKhales,
                                rep.GestMablag,
                                pardakhtymablagh = p.SumPardakhty,
                                mandevam = (rep.Karmozd + rep.VamMablagKhales) - (pardakhtykol.SumPardakhty)
                            }).ToList();


            var sumpardakhty = product1.Sum(x => x.mandevam);


            return Json(sumpardakhty, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetMoavvaghPardakhtChartData()
        {

            SandooghModel db = new SandooghModel();

            Dictionary<long, long> BeforDic = new Dictionary<long, long>();
            for (int i = 1; i <= 11; i++)
            {

                long count = 0;
                try
                {


                    var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam != null && e.Vam.EtmamVam == false) select e;

                    natamampardakhty = (from e in natamampardakhty where e.T_OzvCode != null && e.T_OzvCode.Faal == true select e);
                    var pardakhtHarVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) });

                    var Zeropardakhty = (from v in db.Vams where (v.EtmamVam == false && v.G_M_Pays.Count == 0) select v);

                    Zeropardakhty = (from e in Zeropardakhty where e.T_OzvCode != null && e.T_OzvCode.Faal == true select e);

                    pardakhtHarVam = pardakhtHarVam.Union(from e in Zeropardakhty select new { Vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });
                    var persianCalendar = new System.Globalization.PersianCalendar();
                    int nowyear = persianCalendar.GetYear(DateTime.Now);
                    int nowmonth = persianCalendar.GetMonth(DateTime.Now);
                    int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);
                    var vams = (from m in db.Vams where (m.EtmamVam == false && ((m.T_OzvCode != null && m.T_OzvCode.Faal == true))) select m).ToList();
                    var MablaghSarresidKolliVam = (from m in vams
                                                   select new
                                                   {
                                                       //Sarresid = (m.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate))/*+(nowday>persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate)?1:0)*/)))>(m.Karmozd+m.VamMablagKhales)?m.Karmozd+m.VamMablagKhales : (m.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)) /*+ (nowday > persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate) ? 1 : 0)*/))),
                                                       //Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)) > (m.Karmozd + m.VamMablagKhales) ? m.Karmozd + m.VamMablagKhales : (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)),
                                                       Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)) > (m.Karmozd + m.VamMablagKhales) ? m.Karmozd + m.VamMablagKhales : (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)),
                                                       vamid = m.Vam_Id,
                                                       mablaghghest = m.GestMablag,
                                                       codeozviat = m.T_OzvCode.Id



                                                   });
                    var product1 = (from vampardakhty in pardakhtHarVam.ToList()
                                    join
                            mablaghsarresidkolii in MablaghSarresidKolliVam.ToList() on vampardakhty.Vamid equals mablaghsarresidkolii.vamid

                            into Report
                                    from rep in Report.DefaultIfEmpty()
                                    select new
                                    {



                                        tedad = (rep.Sarresid - vampardakhty.SumPardakhty) > 0 ? Math.Round(((double)rep.Sarresid - (double)vampardakhty.SumPardakhty) / (double)rep.mablaghghest) : 0



                                    }).ToList();
                    try
                    {
                        if (i == 11)
                            product1 = (from e in product1 where e.tedad > 10 select e).ToList();

                        else
                            product1 = (from e in product1 where e.tedad == i select e).ToList();
                    }
                    catch
                    {

                    }


                    count = product1.Count;


                    if (count == null) count = 0;
                }
                catch
                {

                }
                BeforDic.Add(i, count);
            }
            Dictionary<string, long> Result = new Dictionary<string, long>();
            for (int k = 0; k < BeforDic.Count; k++)
            {
                switch (BeforDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("یک قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("دو قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("سه قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("چهار قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("پنج قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شش قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("هفت قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("هشت قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("نه قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("ده قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بیش از ده قسط عقب افتاده", BeforDic.ElementAt(k).Value);
                        break;

                }
            }

            return Json(Result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetAllPardakhtReport(string sidx, string sord, int page, int rows, string ozv, string tedad = "", string mostdate = "")
        {
            SandooghModel db = new SandooghModel();
            int ozzv = -1;
            try
            {
                ozzv = int.Parse(ozv);
            }
            catch
            {

            }

            var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam != null && e.Vam.EtmamVam == false) select e;
            if (ozzv != -1)
            {
                natamampardakhty = (from e in natamampardakhty where e.IdRefOzv == ozzv select e);
            }
            else
                natamampardakhty = (from e in natamampardakhty where e.T_OzvCode != null && e.T_OzvCode.Faal == true select e);
            var pardakhtHarVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) });

            var Zeropardakhty = (from v in db.Vams where (v.EtmamVam == false && v.G_M_Pays.Count == 0) select v);
            if (ozzv != -1)
            {
                Zeropardakhty = (from e in Zeropardakhty where e.IdRefOzv == ozzv select e);
            }
            else
            {
                Zeropardakhty = (from e in Zeropardakhty where e.T_OzvCode != null && e.T_OzvCode.Faal == true select e);
            }

            pardakhtHarVam = pardakhtHarVam.Union(from e in Zeropardakhty select new { Vamid = (long?)e.Vam_Id, SumPardakhty = (double?)0 });
            var persianCalendar = new System.Globalization.PersianCalendar();
            int nowyear = persianCalendar.GetYear(DateTime.Now);
            int nowmonth = persianCalendar.GetMonth(DateTime.Now);
            int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);
            var vams = (from m in db.Vams where (m.EtmamVam == false && ((m.T_OzvCode != null && m.T_OzvCode.Faal == true && ozzv == -1) || m.IdRefOzv == ozzv)) select m).ToList();
            var MablaghSarresidKolliVam = (from m in vams
                                           select new
                                           {
                                               //Sarresid = (m.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate))/*+(nowday>persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate)?1:0)*/)))>(m.Karmozd+m.VamMablagKhales)?m.Karmozd+m.VamMablagKhales : (m.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)) /*+ (nowday > persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate) ? 1 : 0)*/))),
                                               //  Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)) > (m.Karmozd + m.VamMablagKhales) ? m.Karmozd + m.VamMablagKhales : (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)),
                                               Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)) > (m.Karmozd + m.VamMablagKhales) ? m.Karmozd + m.VamMablagKhales : (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)),
                                               vamid = m.Vam_Id,
                                               mablaghghest = m.GestMablag,
                                               codeozviat = m.T_OzvCode.Id,
                                               fname = m.T_OzvCode.FName,
                                               lname = m.T_OzvCode.LName,
                                               datepardakhtvam = ((DateTime)m.VamDate).ToPersianDate(),
                                               vtype = m.T_VamCode.VamName,
                                               mobile = m.T_OzvCode.Mobile,

                                               ZamenName = (m.VamZamen != null && m.VamZamen.ToList().Count > 0 && m.VamZamen.FirstOrDefault().T_OzvCode != null) ? m.VamZamen.FirstOrDefault().T_OzvCode.FName + " " + m.VamZamen.FirstOrDefault().T_OzvCode.LName : "",
                                               ZamenPhone = (m.VamZamen != null && m.VamZamen.ToList().Count > 0 && m.VamZamen.FirstOrDefault().T_OzvCode != null) ? m.VamZamen.FirstOrDefault().T_OzvCode.Mobile : ""
                                                ,
                                               scandb = m.T_OzvCode.ScanDBs != null ? m.T_OzvCode.ScanDBs.Where(a => a.IdRef == m.IdRefOzv && a.Scan_ScanType == 1).ToList().Count > 0 ? m.T_OzvCode.ScanDBs.Where(a => a.IdRef == m.IdRefOzv && a.Scan_ScanType == 1).FirstOrDefault().ScanURL : null : null

                                           });
            var product1 = (from vampardakhty in pardakhtHarVam.ToList()
                            join
                    mablaghsarresidkolii in MablaghSarresidKolliVam.ToList() on vampardakhty.Vamid equals mablaghsarresidkolii.vamid

                    into Report
                            from rep in Report.DefaultIfEmpty()
                            select new
                            {

                                rep.scandb,
                                rep.vamid,
                                rep.fname,
                                rep.lname,
                                rep.datepardakhtvam,
                                rep.mablaghghest,
                                //  mandebed = (((rep.Sarresid - vampardakhty.SumPardakhty) > 0 ? Math.Ceiling(((double)rep.Sarresid - (double)vampardakhty.SumPardakhty) / (double)rep.mablaghghest) : 0) * (rep.mablaghghest))
                                mandebed = (rep.Sarresid - vampardakhty.SumPardakhty) > 0 ? (rep.Sarresid - vampardakhty.SumPardakhty) : 0

                             ,
                                rep.codeozviat,
                                rep.Sarresid,
                                vampardakhty.SumPardakhty,
                                rep.vtype,
                                rep.mobile,
                                tedad = (rep.Sarresid - vampardakhty.SumPardakhty) > 0 ? Math.Round(((double)rep.Sarresid - (double)vampardakhty.SumPardakhty) / (double)rep.mablaghghest) : 0
                             ,
                                ZamenName = rep.ZamenName,
                                ZamenPhone = rep.ZamenPhone


                            }).ToList();
            if (tedad != "")
            {
                try
                {
                    int t1 = int.Parse(tedad);
                    product1 = (from e in product1 where e.tedad >= t1 select e).ToList();
                }
                catch
                {

                }
            }


            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = product1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = product1.AsQueryable();
            var productsList = productsQuery.OrderBy("tedad asc," + sidx + " " + sord).Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();


            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.vamid,
                    RowCells = new List<object>
                               {
                  product.scandb,product.codeozviat
                    , product.vtype, product.fname,product.lname ,product.mobile,product.datepardakhtvam,product.mablaghghest,product.tedad,product.mandebed,
               product.ZamenName!=null?product.ZamenName:"",product.ZamenPhone!=null?product.ZamenPhone:""
                              }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetCanNobat(string sidx, string sord, int page, int rows)
        {
            using (SandooghModel db = new SandooghModel())
            {
                var alreadyInQueue = db.VamNobats
                    .Where(n => n.IdRefVam == null)
                    .Select(n => n.IdRefOzv)
                    .ToList();

                var candidates = db.T_OzvCode
                    .Where(o => o.Faal == true)
                    .Where(o => !alreadyInQueue.Contains(o.Id))
                    .Where(o => !db.Vams.Any(v =>
                        v.IdRefOzv == o.Id && v.EtmamVam == false))
                    .ToList();

                var eligibilityCalculator = new MVCSmartLibrary.Controllers.OzviatController();
                var finalList = new List<CanNobatMemberRow>();

                foreach (var member in candidates)
                {
                    var eligibility = eligibilityCalculator.CalculateQueueEligibilityInfo(member, db);
                    // اگر معوقات مستمری بیش از چهار ماه است
                    // و هنوز تسویه نشده، عضو فعلاً وارد فهرست مجازین نمی‌شود.
                    if (eligibility.RequiresPensionArrearsSettlement)
                        continue;
                    if (eligibility.QueueEligibleDate.Date > DateTime.Today)
                        continue;

                    finalList.Add(new CanNobatMemberRow
                    {
                        Id = member.Id,
                        FName = member.FName ?? "",
                        LName = member.LName ?? "",
                        FatherName = member.FatherName ?? "",
                        DateNobat = eligibility.QueueEligibleDate
                    });
                }

                var sorted = finalList.OrderBy(x => x.DateNobat).ToList();
                int totalRecords = sorted.Count;
                int pageSize = rows > 0 ? rows : 20;
                int pageIndex = page > 0 ? page - 1 : 0;
                int totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);
                var pageItems = sorted.Skip(pageIndex * pageSize).Take(pageSize).ToList();

                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = pageItems.Select(product => new JqGridRowData
                    {
                        Id = product.Id,
                        RowCells = new List<object>
                        {
                            product.Id,
                            product.FName,
                            product.LName,
                            product.FatherName
                        }
                    }).ToList()
                };

                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetNobat(string sidx, string sord, int page, int rows, string IdRefNoeVam)
        {
            SandooghModel db = new SandooghModel();
            int id = int.Parse(IdRefNoeVam);

            var list = (from e in db.VamNobats where e.IdRefNoeVam == id select e).ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                         .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                      (long) product.Id,product.NobatNum ,product.Mokool, product.T_OzvCode.FName.ToString(),product. T_OzvCode.LName,product. NobatDate!=null?((DateTime)product.NobatDate).ToPersianDate():""
                    ,product.DocNo,product.IdRefOzv.ToString(), product.IdRefVam.ToString(),
                product.IdRefNoeVam.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [Authorize(Roles = "Admin")]
        // GET: Pardakht
        public ActionResult check()
        {
            return View();
        }
        [Authorize(Roles = "Admin")]
        // GET: Pardakht
        public ActionResult PardakhtFromExcel()
        {
            SandooghModel db = new SandooghModel();

            List<G_M_Pays> FinalPaylist = new List<G_M_Pays>();
            FinalPaylist = (from e in db.G_M_Pays select e).ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();
            List<SelectListItem> allnahvepardakht = new List<SelectListItem>();
            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }
            List<Nahveh_P> allnahvecodes = db.Nahveh_P.ToList();
            foreach (Nahveh_P nahvecode in allnahvecodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = nahvecode.Id.ToString();
                sli.Text = nahvecode.Nahveh_P1;
                allnahvepardakht.Add(sli);
            }
            foreach (G_M_Pays model in FinalPaylist)
            {
                model.AllVamTypes = allvamtypes;
                model.AllNahvePardakht = allnahvepardakht;
            }

            return View(FinalPaylist);
        }
        [Authorize(Roles = "Admin")]
        // GET: Pardakht
        public ActionResult Pardakht()
        {
            SandooghModel db = new SandooghModel();

            List<G_M_Pays> FinalPaylist = new List<G_M_Pays>();
            FinalPaylist = (from e in db.G_M_Pays select e).ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();
            List<SelectListItem> allnahvepardakht = new List<SelectListItem>();
            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }
            List<Nahveh_P> allnahvecodes = db.Nahveh_P.ToList();
            foreach (Nahveh_P nahvecode in allnahvecodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = nahvecode.Id.ToString();
                sli.Text = nahvecode.Nahveh_P1;
                allnahvepardakht.Add(sli);
            }
            foreach (G_M_Pays model in FinalPaylist)
            {
                model.AllVamTypes = allvamtypes;
                model.AllNahvePardakht = allnahvepardakht;
            }

            return View(FinalPaylist);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Pardakhtywait()
        {
            SandooghModel db = new SandooghModel();

            List<G_M_Payswait> FinalPaylist = new List<G_M_Payswait>();
            FinalPaylist = (from e in db.G_M_Payswait select e).ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();
            List<SelectListItem> allnahvepardakht = new List<SelectListItem>();
            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }
            List<Nahveh_P> allnahvecodes = db.Nahveh_P.ToList();
            foreach (Nahveh_P nahvecode in allnahvecodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = nahvecode.Id.ToString();
                sli.Text = nahvecode.Nahveh_P1;
                allnahvepardakht.Add(sli);
            }
            foreach (G_M_Payswait model in FinalPaylist)
            {
                model.AllVamTypes = allvamtypes;
                model.AllNahvePardakht = allnahvepardakht;
            }
            return View(FinalPaylist);
        }
        [Authorize(Roles = "Admin")]
        public ActionResult PardakhtMostamary()
        {
            SandooghModel db = new SandooghModel();

            List<G_M_Pays> FinalPaylist = new List<G_M_Pays>();
            FinalPaylist = (from e in db.G_M_Pays select e).ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();
            List<SelectListItem> allnahvepardakht = new List<SelectListItem>();
            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }
            List<Nahveh_P> allnahvecodes = db.Nahveh_P.ToList();
            foreach (Nahveh_P nahvecode in allnahvecodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = nahvecode.Id.ToString();
                sli.Text = nahvecode.Nahveh_P1;
                allnahvepardakht.Add(sli);
            }
            foreach (G_M_Pays model in FinalPaylist)
            {
                model.AllVamTypes = allvamtypes;
                model.AllNahvePardakht = allnahvepardakht;
            }
            return View(FinalPaylist);
        }
        [Authorize(Roles = "Admin")]
        public ActionResult MembersMostamary()
        {

            SandooghModel db = new SandooghModel();
            List<G_M_Pays> FinalPaylist = new List<G_M_Pays>();
            FinalPaylist = (from e in db.G_M_Pays select e).ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();
            List<SelectListItem> allnahvepardakht = new List<SelectListItem>();
            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }
            List<Nahveh_P> allnahvecodes = db.Nahveh_P.ToList();
            foreach (Nahveh_P nahvecode in allnahvecodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = nahvecode.Id.ToString();
                sli.Text = nahvecode.Nahveh_P1;
                allnahvepardakht.Add(sli);
            }
            foreach (G_M_Pays model in FinalPaylist)
            {
                model.AllVamTypes = allvamtypes;
                model.AllNahvePardakht = allnahvepardakht;
            }
            return View(FinalPaylist);
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetVamPardakhtyByMemberId(string Id, string vamtype)
        {
            try
            {
                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var ozvwithid = from o in db.T_OzvCode where o.Id == idd select o;
                if (ozvwithid.ToList() != null && ozvwithid.ToList().Count > 0)
                {
                    var vamnatamam = from v in db.Vams where v.EtmamVam != true && v.IdRefOzv == idd select v;

                    if (vamnatamam != null && vamnatamam.ToList().Count > 0)
                    {
                        return Json("-1", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                        // var maxdate = mostamarises.Max(x => x.MostamaryMablagh_DateStart);
                        // var mostamary = from v in mostamarises where v.MostamaryMablagh_DateStart == maxdate select v.MostamaryMablagh_Mablagh;

                        var product =
                               from ozv in db.T_OzvCode
                               where ozv.Id.Equals(idd)
                               join
                       most in summostamarises on ozv.Id equals most.Id
                       into ozvmost
                               from ozvmostamary in ozvmost.DefaultIfEmpty()
                               select new
                               {
                                   ozv.Id,
                                   ozvmostamary.SumMostamary,
                                   ozv.FName,
                                   ozv.LName
                               };
                        var goodPayer = VamGoodPayerCalculator.Evaluate(idd, db, DateTime.Today);
                        var memberInfo = product.FirstOrDefault();
                        if (memberInfo == null)
                            return Json(false, JsonRequestBehavior.AllowGet);
                        return Json(new
                        {
                            memberInfo.Id,
                            memberInfo.SumMostamary,
                            memberInfo.FName,
                            memberInfo.LName,

                            // وضعیت نهایی خوش‌حسابی
                            goodPayer.IsGoodPayer,

                            // تعداد تأخیرها
                            goodPayer.DelayedInstallments,
                            goodPayer.DelayedPensionMonths,

                            // امتیازهای مستقل
                            goodPayer.InstallmentNegativeScore,
                            goodPayer.PensionNegativeScore,

                            // مجموع صرفاً جهت نمایش؛ ملاک بدحسابی نیست
                            goodPayer.TotalNegativeScore,

                            goodPayer.N,
                            goodPayer.M,
                            goodPayer.FeePercent

                        }, JsonRequestBehavior.AllowGet);
                    }

                }
                else
                    return Json(false, JsonRequestBehavior.AllowGet);
            }//end try
            catch
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        [Authorize(Roles = "Admin")]
        public JsonResult UbdateDaftarShomareById(string Id, string daftarnum)
        {
            try
            {
                SandooghModel db = new SandooghModel();

                int idd = int.Parse(Id);
                var row = (from e in db.VamNobats where e.Id == idd select e).FirstOrDefault();
                row.DocNo = daftarnum;
                db.Entry(row).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();

                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetMojavvezPardakhtByMemberId(string Id, string vamtype)
        {
            try
            {

                int idd = int.Parse(Id);

                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var nobs = db.VamNobats.ToList();
                long dtype = long.Parse(vamtype);

                var nobat = (from e in nobs where e.IdRefNoeVam == dtype && e.IdRefOzv == idd select e).OrderBy(k => k.NobatDate).LastOrDefault().DocNo;
                var nobatdate = (from e in nobs where e.IdRefNoeVam == dtype && e.IdRefOzv == idd select e).OrderBy(k => k.NobatDate).LastOrDefault().NobatDate;
                string nobdate = PersianDateUtils.ToPersianDate(nobatdate);
                var ozvwithid = from o in db.T_OzvCode where o.Id == idd select o;
                if (ozvwithid.ToList() != null && ozvwithid.ToList().Count > 0)
                {
                    var vamnatamam = from v in db.Vams where v.EtmamVam != true && v.IdRefOzv == idd select v;
                    var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });

                    if (vamnatamam != null && vamnatamam.ToList().Count > 0)
                    {
                        summostamarises = (from v in db.G_M_Pays where v.PayDate < vamnatamam.FirstOrDefault().VamDate group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                        //  return Json("-1", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                        // var maxdate = mostamarises.Max(x => x.MostamaryMablagh_DateStart);
                        // var mostamary = from v in mostamarises where v.MostamaryMablagh_DateStart == maxdate select v.MostamaryMablagh_Mablagh;
                    }
                    var setting = (from e in db.Option_T select e).FirstOrDefault();
                    var product =
                           from ozv in db.T_OzvCode
                           where ozv.Id.Equals(idd)
                           join
                   most in summostamarises on ozv.Id equals most.Id
                   into ozvmost
                           from ozvmostamary in ozvmost.DefaultIfEmpty()
                           select new
                           {
                               ozv.Id,
                               ozvmostamary.SumMostamary,
                               ozv.FName,
                               ozv.LName,
                               codemelli = ozv.MelliCode,
                               nezamno = ozv.NezamNo,
                               mobile = ozv.Mobile,
                               raeissandoogh = setting.M2,
                               khazanedar = setting.E3,
                               modirmali = setting.M3,
                               father = ozv.FatherName,
                               shsh = ozv.ShNo,
                               address = ozv.Address,
                               phone = ozv.Tel,
                               nobat = nobat,
                               nobdate = nobdate

                           };
                    if (product == null)
                        return Json(false);

                    return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);


                }
                else
                    return Json(false);
            }//end try

            catch
            {
                return Json(false);
            }


        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetSummostamaryByMemberId(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var ozvwithid = from o in db.T_OzvCode where o.Id == idd select o;
                if (ozvwithid.ToList() != null && ozvwithid.ToList().Count > 0)
                {

                    var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });

                    var product =
                           from ozv in db.T_OzvCode
                           where ozv.Id.Equals(idd)
                           join
                   most in summostamarises on ozv.Id equals most.Id
                   into ozvmost
                           from ozvmostamary in ozvmost.DefaultIfEmpty()
                           select new
                           {
                               ozv.Id,
                               ozvmostamary.SumMostamary,
                               ozv.FName,
                               ozv.LName
                           };
                    if (product == null)
                        return Json(false);

                    return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);
                }
                return Json(false);
            }//end try

            catch
            {
                return Json(false);
            }


        }

        public int GetMemBerZamenMotaghabel(string idzamen, string idvam)
        {
            try
            {

                int iddzamen = int.Parse(idzamen);
                int iddvam = int.Parse(idvam);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var girande = (from e in db.Vams where e.Vam_Id == iddvam select e.IdRefOzv).FirstOrDefault();


                var product =
                      from zam in db.VamZamen
                      where zam.IdOzvRef == girande && zam.Vam.EtmamVam == false && zam.Vam.IdRefOzv == iddzamen
                      select new
                      {
                          zam.Id

                      };
                if (product.ToList() == null || product.ToList().Count == 0)
                {
                    return 0;
                }

                return 1;

            }
            catch
            {
                return 0;
            }
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetMemBerZamenCount(string id, string idzamen, string idvam)
        {
            try
            {

                int idd = int.Parse(id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();


                var product =
                       from zam in db.VamZamen
                       where zam.IdOzvRef == idd && zam.Vam.EtmamVam == false
                       select new
                       {
                           zam.Id

                       };
                if (product == null)
                {
                    if (GetMemBerZamenMotaghabel(idzamen, idvam) == 0)
                        return Json(0, JsonRequestBehavior.AllowGet);
                    else
                        return Json(1000, JsonRequestBehavior.AllowGet);
                }
                else
                if (GetMemBerZamenMotaghabel(idzamen, idvam) == 0)
                    return Json(product.ToList().Count(), JsonRequestBehavior.AllowGet);
                else
                    return Json(1000, JsonRequestBehavior.AllowGet);


            }
            catch
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public JsonResult GetZamenByZemanatId(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();


                var product =
                       from zam in db.VamZamen
                       where zam.Id == idd
                       select new
                       {
                           zam.Id,
                           zam.IdOzvRef,
                           zam.T_OzvCode.FName,
                           zam.T_OzvCode.LName,
                           zam.Mablag,
                           zam.CheckNo,
                           zam.HesabNo,
                           zam.BankName,
                           zam.Comment,
                           mellicode = zam.T_OzvCode.MelliCode,
                           nezamno = zam.T_OzvCode.NezamNo,
                           mobile = zam.T_OzvCode.Mobile,
                           karmozd = zam.Vam.Karmozd

                       };
                if (product == null)
                    return Json(false);

                return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(false);
            }

        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetVamByvamId(string VamId)
        {
            try
            {

                int idd = int.Parse(VamId);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var vam = from o in db.Vams
                          where o.Vam_Id == idd
                          select new
                          {
                              vam_id1 = o.Vam_Id,
                              fname1 = o.T_OzvCode.FName,
                              lname1 = o.T_OzvCode.LName,
                              fathername1 = o.T_OzvCode.FatherName,
                              mellicode1 = o.T_OzvCode.MelliCode,
                              vamname1 = o.T_VamCode.VamName,
                              vamdate1 = o.VamDate,
                              vammablaghkhales1 = o.VamMablagKhales,
                              mablaghzemanat = o.VamMablagKhales + o.Karmozd
                          };

                var result = vam.FirstOrDefault();
                var MyDictionary = new Dictionary<string, object>();
                MyDictionary.Add("vam_id1", result.vam_id1);
                MyDictionary.Add("fname1", result.fname1);
                MyDictionary.Add("lname1", result.lname1); MyDictionary.Add("fathername1", result.fathername1);
                MyDictionary.Add("mellicode1", result.mellicode1);
                MyDictionary.Add("vamname1", result.vamname1);
                MyDictionary.Add("vamdate1", ((DateTime)result.vamdate1).ToPersianDate());
                MyDictionary.Add("vammablaghkhales1", result.vammablaghkhales1);
                MyDictionary.Add("mablaghzemanat", result.mablaghzemanat);

                return Json(MyDictionary, JsonRequestBehavior.AllowGet);
            }//end try

            catch
            {
                return Json(false);
            }


        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetScanUrlByMemberId(string Id)
        {
            if (Id.Length >= 5)
            {
                try
                {
                    SandooghModel db = new SandooghModel();
                    var ozv = (from e in db.T_OzvCode where e.Id.ToString() == Id select e).FirstOrDefault();
                    var scan = ozv.ScanDBs != null ? ozv.ScanDBs.Where(a => a.IdRef == ozv.Id && a.Scan_ScanType == 1).ToList().Count > 0 ? ozv.ScanDBs.Where(a => a.IdRef == ozv.Id && a.Scan_ScanType == 1).FirstOrDefault().ScanURL : null : null;
                    if (scan != null && scan.ToList() != null)
                        return Json(scan, JsonRequestBehavior.AllowGet);
                    else return Json(false, JsonRequestBehavior.AllowGet);
                }
                catch
                {
                    return Json(false, JsonRequestBehavior.AllowGet);
                }
            }
            else
                return Json(false, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetVamByMemberId(string Id)
        {
            if (Id.Length >= 5)
            {
                try
                {

                    int idd = int.Parse(Id);
                    //todo: Delete product
                    SandooghModel db = new SandooghModel();
                    var user = (from e in db.T_OzvCode where idd == e.Id && e.Faal == true select e).ToList();
                    if (user != null && user.Count > 0)
                    {
                        var vamnatamam = from v in db.Vams where v.EtmamVam != true select v;
                        var mostamarises = from v in db.T_MostamaryMablagh where v.MostamaryMablagh_IdRefOzvCode == idd select v;

                        var mostamary = mostamarises.OrderByDescending(k => k.MostamaryMablagh_ID).FirstOrDefault().MostamaryMablagh_Mablagh;
                        var maxberuzdate = mostamarises.Max(x => x.MostamaryMablagh_CurrentBeruzDate);
                        var mandatakonoon = 0.00;
                        var pardakhtakonoon = 0.00;
                        var activevam = (from w in db.Vams where w.IdRefOzv == idd && w.EtmamVam == false select w).FirstOrDefault();

                        var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam.Vam_Id && e.Vam.EtmamVam == false) select e;

                        try
                        {
                            pardakhtakonoon = (double)(from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;
                        }
                        catch
                        {

                        }

                        try
                        {
                            var persianCalendar = new System.Globalization.PersianCalendar();
                            int nowyear = persianCalendar.GetYear(DateTime.Now);
                            int nowmonth = persianCalendar.GetMonth(DateTime.Now);
                            int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);

                            var MablaghSarresidKolliVam = (from m in db.Vams.ToList()
                                                           where (m.EtmamVam == false && m.IdRefOzv == idd)
                                                           select new
                                                           {
                                                               //  Sarresid = (m.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate))))),
                                                               // Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)),
                                                               Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)),


                                                           }).FirstOrDefault();
                            if (pardakhtakonoon < (double)MablaghSarresidKolliVam.Sarresid)
                                mandatakonoon = (double)MablaghSarresidKolliVam.Sarresid - pardakhtakonoon;
                            else
                                mandatakonoon = 0.0;

                            if (mandatakonoon < 0) mandatakonoon = 0.00;

                        }
                        catch { }

                        var product =
                               from ozv in db.T_OzvCode
                               where ozv.Id.Equals(idd)
                               join
                       vam in vamnatamam on ozv.Id equals vam.IdRefOzv
                       into ozvvams
                               from ozvvam in ozvvams.DefaultIfEmpty()
                               select new
                               {
                                   ozv.Id,
                                   ozvvam.IdRefNoeVam,
                                   ozv.FName,
                                   ozv.LName,
                                   IdRefVam = (ozvvam == null ? 0 : ozvvam.Vam_Id),
                                   MablaghharGhest = (ozvvam == null ? 0 : ozvvam.GestMablag),
                                   MablaghHarMostamary = mostamary,
                                   BedehitaEmrooz = mandatakonoon,
                               };
                        if (product == null)
                            return Json(false, JsonRequestBehavior.AllowGet);

                        return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);
                    }
                    else
                        return Json(false);
                }
                catch
                {
                    return Json(false);
                }
            }
            else
                return Json(false);


        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetMandeVamByMemberId(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var vamnatamam = from v in db.Vams where v.EtmamVam != true select v;



                var mandatakonoon = 0.00;
                var pardakhtakonoon = 0.00;
                var activevam = (from w in db.Vams where w.IdRefOzv == idd && w.EtmamVam == false select w).FirstOrDefault();

                var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam.Vam_Id && e.Vam.EtmamVam == false) select e;

                try
                {
                    pardakhtakonoon = (double)(from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;
                }
                catch
                {

                }

                try
                {
                    mandatakonoon = (double)activevam.VamMablagKhales + (double)activevam.Karmozd - pardakhtakonoon;
                }
                catch
                {
                }



                return Json(mandatakonoon, JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(false);
            }

        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetMandeBedByMemberId(string Id)
        {
            try
            {
                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var vamnatamam = from v in db.Vams where v.EtmamVam != true select v;



                var mandatakonoon = 0.00;
                var pardakhtakonoon = 0.00;
                var activevam = (from w in db.Vams where w.IdRefOzv == idd && w.EtmamVam == false select w).FirstOrDefault();

                var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam.Vam_Id && e.Vam.EtmamVam == false) select e;

                try
                {
                    pardakhtakonoon = (double)(from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;
                }
                catch
                {

                }

                try
                {
                    var persianCalendar = new System.Globalization.PersianCalendar();
                    int nowyear = persianCalendar.GetYear(DateTime.Now);
                    int nowmonth = persianCalendar.GetMonth(DateTime.Now);
                    int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);
                    var MablaghSarresidKolliVam = (from m in db.Vams.ToList()
                                                   where (m.EtmamVam == false && m.IdRefOzv == idd)
                                                   select new
                                                   {
                                                       // Sarresid = (m.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate))))),
                                                       // Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)31)),
                                                       Sarresid = (m.GestMablag * Math.Ceiling((double)((((nowyear - persianCalendar.GetYear((DateTime)m.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)m.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)m.AvlinGestDate))) / (double)30)),

                                                   }).FirstOrDefault();
                    if (pardakhtakonoon < (double)MablaghSarresidKolliVam.Sarresid)
                        mandatakonoon = (double)MablaghSarresidKolliVam.Sarresid - pardakhtakonoon;
                    else
                        mandatakonoon = 0.0;

                    if (mandatakonoon < 0) mandatakonoon = 0.00;

                }
                catch { }



                return Json(mandatakonoon, JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(false);
            }

        }
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Zamenin()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetZamenMotazamen(int page, int rows, string RefozvID, string sidx = "Id", string sord = "asc")
        {
            long idrefozv = -1;
            if (RefozvID != null && RefozvID.Length > 0) idrefozv = long.Parse(RefozvID);
            SandooghModel db = new SandooghModel();
            var list = (from k in db.VamZamen select k).ToList();
            if (idrefozv != -1)
                list = (from k in db.VamZamen where (k.IdOzvRef == idrefozv || k.Vam.IdRefOzv == idrefozv) select k).ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            if (sidx.ToUpper() == "FNAME")
                sidx = "T_OzvCode.FName";
            if (sidx.ToUpper() == "LNAME")
                sidx = "T_OzvCode.LName";
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();//کل داده ها را مرتب شده برمیگرداند و دو پارامتر اولی هیچ تاثیری ندارند.
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {

                    Id = (long)product.Id,
                    RowCells = new List<object>
                               {
                         product.Id,product.Vam.EtmamVam==true?"تسویه شده":"",
                        product.T_OzvCode!=null? product.T_OzvCode.FName:"",product.T_OzvCode!=null?product.T_OzvCode.LName:"",product.Vam.T_OzvCode.FName,product.Vam.T_OzvCode.LName,
                                    product.BankName,product.HesabNo,product.CheckNo,product.Mablag
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize(Roles = "Admin,User")]
        public ActionResult GetSearchZamen(int page, int rows, string IdVamRef, string sidx = "Id", string sord = "asc")
        {
            long idvamref = long.Parse(IdVamRef);
            SandooghModel db = new SandooghModel();
            var list = (from k in db.VamZamen where k.IdVamRef == idvamref select k).ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            if (sidx.ToUpper() == "FNAME")
                sidx = "T_OzvCode.FName";
            if (sidx.ToUpper() == "LNAME")
                sidx = "T_OzvCode.LName";
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();//کل داده ها را مرتب شده برمیگرداند و دو پارامتر اولی هیچ تاثیری ندارند.
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {

                    Id = (long)product.Id,
                    RowCells = new List<object>
                               {
                                     product.Id,product.IdOzvRef,
                                     product.T_OzvCode. FName,product.T_OzvCode.LName
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetMostamaryByMemberId(string Id)
        {
            if (Id.Length >= 5)
            {
                try
                {

                    int idd = int.Parse(Id);
                    //todo: Delete product
                    SandooghModel db = new SandooghModel();
                    var user = (from e in db.T_OzvCode where idd == e.Id && e.Faal == true select e).ToList();
                    if (user != null && user.Count > 0)
                    {
                        var mostamarises = from v in db.T_MostamaryMablagh where v.MostamaryMablagh_IdRefOzvCode == idd select v;

                        var mostamary = (from v in mostamarises select v).OrderByDescending(k => k.MostamaryMablagh_ID).FirstOrDefault().MostamaryMablagh_Mablagh;
                        var maxberuzdate = mostamarises.Max(x => x.MostamaryMablagh_CurrentBeruzDate);


                        var product =
                               from ozv in db.T_OzvCode
                               where ozv.Id.Equals(idd)
                               select new
                               {
                                   ozv.Id,
                                   ozv.FName,
                                   ozv.LName,
                                   MablaghHarMostamary = mostamary
                               };
                        if (product == null)
                            return Json(false);

                        return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);
                    }
                    else return Json(false);

                }
                catch
                {
                    return Json(false);
                }
            }
            else
                return Json(false);


        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GetMemberById(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var product =
                    from ozv in db.T_OzvCode
                    where ozv.Id.Equals(idd)
                    select new
                    {
                        ozv.Id,
                        ozv.FName,
                        ozv.LName,

                    };
                if (product == null)
                    return Json(false);

                return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(false);
            }

        }


        // GET: Ozviat
        [Authorize(Roles = "Admin , User,sadmin")]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetVamCodes(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_VamCode.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            if (sidx.ToUpper() == "FNAME" || (sidx.ToUpper() == "LNAME"))
            {
                sidx = "T_Ozvcode." + sidx;
            }
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                      product.GUID.ToString(), product.Id ,product. VamName,product. DarsadKarmozd.ToString(),product. TedadAgsat.ToString(),product. TedadZamen.ToString(),product. ModatEntezar.ToString(),
                      product. NobatMojadad.ToString(),product. AlarmTakhir.ToString(),product. MablagVam.ToString(),product. SagfVam.ToString(),product. EtebarDate!=null?((DateTime)product.EtebarDate).ToPersianDate():"",
                      product. KasreKarmozd!=null?product. KasreKarmozd.ToString():"False",product. Faal!=null?product. Faal.ToString():"False",product.VamBedGroup,product. VamBedKol,product. VamBedMoein,
                      product. VamBesGroup,product. VamBesKol,product. VamBesMoein,product. VamBesTafsili,product. GestBedGroup,product. GestBedKol,product. GestBedMoein,product. GestBedTafsili,product. GestBesGroup,product. GestBesKol,product.
                      GestBesMoein,product. KarmozdBesGroup,product. KarmozdBesKol,product. KarmozdBesMoein,product. KarmozdBesTafsili,product. DirkardBedGroup,product.
                      DirkardBedKol,product. DirkardBedMoein,product. DirkardBedTafsili,product. DirkardBesGroup,product. DirkardBesKol,product. DirkardBesMoein,product. DirkardBesTafsili
                      /*product.Taahol!=null?product.Taahol.Taahol_Name:null,*/
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMostamaryPardakhty(string IdRefOzv, string PayDateaz, string PayDateta, string sidx = "id", string sord = "desc", int page = 1, int rows = 100000)
        {
            int idrefozv = 0;
            try
            {
                idrefozv = int.Parse(IdRefOzv);
            }
            catch
            {

            }
            try
            {
                SandooghModel db = new SandooghModel();
                DateTime dateaz = (DateTime)(PayDateaz.ToMilady() == null ? DateTime.MinValue : PayDateaz.ToMilady());
                DateTime dateta = (DateTime)(PayDateta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)PayDateta.ToMilady()).AddDays(1));
                var mostamaries = from v in db.G_M_Pays where (v.IdRefOzv == idrefozv && v.MostamariMablag != null && v.PayDate >= dateaz && v.PayDate <= dateta) select v;
                var summostamary = (from v in db.G_M_Pays where v.IdRefOzv == idrefozv group v by v.IdRefOzv into g select g.Sum(v => v.MostamariMablag)).FirstOrDefault().Value;
                var list = mostamaries.ToList();

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list.AsQueryable();
                var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                .Skip(pageIndex * pageSize)
                                                .Take(pageSize)
                                                .ToList();
                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.Id,
                        RowCells = new List<object>
                               {
                       product.Id ,product.T_OzvCode.FName.ToString(),product. T_OzvCode.LName,product. PayDate!=null?((DateTime)product.PayDate).ToPersianDate():"",
                       product.MostamariMablag, product.IdRefOzv.ToString(),product.TedadMostamari.ToString(),product.MablaghHarMostamary.ToString(),product.Nahveh_P.ToString(),
                  product.Fish_No,product.Comment,summostamary,product.IsAfzayesh==true?"افزایش سرمایه":""
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetTasvieh(string sidx, string sord, int page, int rows, string Code, string fname, string lname, string azdate, string tadate)
        {
            SandooghModel db = new SandooghModel();
            var list = db.Tasviehs.ToList();

            long code = 0;

            try
            {
                code = long.Parse(Code);
            }
            catch
            {

            }

            if (code != 0)
                list = (from e in list where e.T_OzvCode.Id == code select e).ToList();
            if (fname.Length > 0)
                list = (from e in list where e.T_OzvCode.FName.Contains(fname) select e).ToList();
            if (lname.Length > 0)
                list = (from e in list where e.T_OzvCode.LName.Contains(lname) select e).ToList();
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            if (tadatei != DateTime.MaxValue)
                list = (from e in list where e.PayDate >= azdatei && e.PayDate < tadatei.AddDays(1) select e).ToList();
            else
                list = (from e in list where e.PayDate >= azdatei && e.PayDate < tadatei select e).ToList();

            foreach (var p in list)
            {
                var d = (from e in db.AccSanad_B where e.Kol == "311" && e.Moein == "003" && e.Tafsili == p.IdRefOzv.ToString() && e.Sanad_No != 1 select e).ToList().LastOrDefault();
                if (d != null)
                    p.Comment = "تاریخ سند: " + d.Date_S.ToPersianDate() + "---" + p.Comment;
            }


            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                       product.Id ,product.T_OzvCode.FName,product. T_OzvCode.LName,product. PayDate!=null?((DateTime)product.PayDate).ToPersianDate():"",product.MostamariMablag,product.Fish_No
                    ,product.IdRefOzv.ToString(),product.Nahveh_P!=null?product.Nahveh_PTasvie.Nahveh_P:"",product.Comment,product.Sanads,product.SanadNo
                                }
                })).ToList()
            };

            return Json(productsData, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetPardakhtywait(string sidx = "id", string sord = "desc", int page = 1, int rows = 100000, string type = "ge", string azdate = "", string tadate = "", bool filter = false, string idrefvam = "", string idrefozv = "-1", string waitorno = "w")
        {
            int idvam = -1;
            try
            {
                if (idrefvam != "")
                {
                    idvam = int.Parse(idrefvam);
                }
            }
            catch
            {

            }
            if (azdate == "")
                azdate = DateTime.MinValue.ToString();
            if (tadate == "")
            {
                tadate = DateTime.MaxValue.ToString();
            }
            SandooghModel db = new SandooghModel();
            var list1 = db.G_M_Payswait;
            var list = (from e in list1 select e).ToList();
            if (idrefozv != "-1")
            {
                try
                {
                    long usercode = long.Parse(idrefozv);
                    list = (from e in list where e.IdRefOzv == usercode select e).ToList();
                }

                catch
                {

                }
            }
            if (waitorno == "w")
                list = (from e in list where e.IsTaeid == false && e.statuse != 1 select e).ToList();
            if (waitorno == "nw")
                list = (from e in list where e.IsTaeid == true && e.statuse != 1 select e).ToList();
            if (waitorno == "na")
                list = (from e in list where e.statuse == 1 && e.IsTaeid == false select e).ToList();//تایید نشده و رد شده
            if (filter)
            {


                if (type == "m")
                    list = (from e in list where e.MostamariMablag > 0 select e).ToList();
                if (type == "ge")
                    list = (from e in list where e.TotGestMablag > 0 select e).ToList();

                if (idvam != -1)
                    list = (from e in list where e.IdRefVam == idvam select e).ToList();
                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = (DateTime)tadate.ToMilady();
                }
                catch
                {

                }
                list = (from e in list where e.PayDate >= azdatei && e.PayDate <= tadatei select e).ToList();

            }

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                       product.Id ,product.T_OzvCode.FName.ToString(),product. T_OzvCode.LName,product.IsAfzayesh==true?"افزایش سرمایه":"", product. PayDate!=null?((DateTime)product.PayDate).ToPersianDate():"",
                        product.TotMablag.ToString()
                    ,product.IdRefOzv.ToString(),product.Vam!=null?product.Vam.T_VamCode.VamName:"",product.TotGestMablag.ToString(),product.MablaghharGhest.ToString(),product.MablaghHarMostamary.ToString(),product.TakhirMablag.ToString(),product.MostamariMablag.ToString(),product.AfzayeshMablagh, product.Nahveh_P1!=null?product.Nahveh_P1.Nahveh_P1:"",
                  product.Fish_No,product.Comment,product.IdRefNoeVam.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetPardakhty(string sidx, string sord, int page, int rows, string codeaz, string codeta, string fname, string lname, string azdate, string tadate, string type, bool filter = false)
        {
            SandooghModel db = new SandooghModel();
            var list = from e in db.G_M_Pays select e;
            if (filter)
            {
                long az = 0;
                long ta = long.MaxValue;
                long vamtype = -1;
                try
                {
                    az = long.Parse(codeaz);
                }
                catch
                {

                }
                try
                {
                    ta = long.Parse(codeta);
                }
                catch
                {

                }
                if (az != 0 && ta == long.MaxValue) ta = az;

                list = (from e in list where e.T_OzvCode.Id >= az && e.T_OzvCode.Id <= ta select e);
                if (fname.Length > 0)
                    list = (from e in list where e.T_OzvCode.FName.Contains(fname) select e);
                if (lname.Length > 0)
                    list = (from e in list where e.T_OzvCode.LName.Contains(lname) select e);
                if (vamtype != -1)
                    list = (from e in list where e.IdRefNoeVam == vamtype select e);
                if (type == "m")
                    list = (from e in list where e.MostamariMablag != 0 select e);
                if (type == "ge")
                    list = (from e in list where e.TotGestMablag > 0 select e);

                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = (DateTime)tadate.ToMilady();
                }
                catch
                {

                }
                list = (from e in list where e.PayDate >= azdatei && e.PayDate <= tadatei select e);

            }
            var list1 = list.ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list1.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                       product.Id ,product.T_OzvCode.FName.ToString(),product. T_OzvCode.LName,product.IsAfzayesh==true?"افزایش سرمایه":"", product. PayDate!=null?((DateTime)product.PayDate).ToPersianDate():"",product.TotMablag.ToString()
                    ,product.IdRefOzv.ToString(),product.IdRefVam.ToString(),product.TedadGest.ToString(),product.TedadMostamari.ToString(),product.TotGestMablag.ToString(),product.MablaghharGhest.ToString(),product.MablaghHarMostamary.ToString(),product.TakhirMablag.ToString(),product.MostamariMablag.ToString(),product.Nahveh_P.ToString(),
                  product.Fish_No,product.Comment,product.IdRefNoeVam.ToString(),product.Sanads,product.SanadNo,  product.T_OzvCode.ScanDBs!=null? product.T_OzvCode.ScanDBs.Where(a => a.IdRef==product.IdRefOzv && a.Scan_ScanType==1).ToList().Count>0? product.T_OzvCode.ScanDBs.Where(a => a.IdRef==product.IdRefOzv && a.Scan_ScanType==1).FirstOrDefault().ScanURL:null:null
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetLogList(string sidx, string sord, int page, int rows, string fname, string lname, string azdate, string tadate, string type, bool filter = false)
        {
            SandooghModel db = new SandooghModel();
            var list = from e in db.T_Log select e;
            if (filter)
            {



                if (fname.Length > 0)
                    list = (from e in list where e.Log_Description.Contains(fname) select e);
                if (lname.Length > 0)
                    list = (from e in list where e.Log_Description.Contains(lname) select e);
                if (type != "")
                    list = (from e in list where e.Log_Type == type select e);


                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = (DateTime)tadate.ToMilady();
                }
                catch
                {

                }
                list = (from e in list where e.Log_Date >= azdatei && e.Log_Date <= tadatei select e);

            }
            var list1 = list.ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list1.AsQueryable();

            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize);

            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Log_Id,
                    RowCells = new List<object>
                               {
                      product.Log_Id,product.Log_Date!=null?((DateTime)product.Log_Date).ToPersianDate():"", (product.Log_Description.Substring(0,product.Log_Description.Length>150?150:product.Log_Description.Length)+"...").Replace("<br/>","_") ,product.Log_Name,
                      product.Log_Type,product.Log_User,product.Log_Description.Replace("<br/>","\n")}
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MoghaieratBitpay()
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            return View();
        }



        //       [HttpPost]

        //       public ActionResult GetMoghaieratBitpay()
        //       {
        //           SandooghModel db = new SandooghModel();
        //             string api = "7d99b-eab22-ed6ac-724d5-c7e816bbb3a391068d53a88c8df3";


        //string myJsonResponse= @"{'employees':[{'idGet':'15832411','transId':'15837733','amount':'8083333','date':'2023\/ 02\/ 19 08:29:17'},{'idGet':'15832567','transId':'15837889','amount':'2000000','date':'2023\/ 02\/ 19 08:59:37'},{'idGet':'15833197','transId':'15838519','amount':'4000000','date':'2023\/ 02\/ 19 10:20:21'},{'idGet':'15833271','transId':'15838593','amount':'32475000','date':'2023\/ 02\/ 19 10:28:24'},{'idGet':'15833295','transId':'15838617','amount':'22500000','date':'2023\/ 02\/ 19 10:30:16'},{'idGet':'15833361','transId':'15838683','amount':'4124998','date':'2023\/ 02\/ 19 10:35:04'},{'idGet':'15833391','transId':'15838713','amount':'500000','date':'2023\/ 02\/ 19 10:37:16'},{'idGet':'15833417','transId':'15838739','amount':'4500000','date':'2023\/ 02\/ 19 10:39:01'},{'idGet':'15833647','transId':'15838969','amount':'1000000','date':'2023\/ 02\/ 19 10:57:08'},{'idGet':'15833731','transId':'15839053','amount':'2000000','date':'2023\/ 02\/ 19 11:03:44'},{'idGet':'15833859','transId':'15839181','amount':'15250000','date':'2023\/ 02\/ 19 11:12:52'},{'idGet':'15834403','transId':'15839725','amount':'1000000','date':'2023\/ 02\/ 19 11:46:46'},{'idGet':'15834733','transId':'15840055','amount':'3875000','date':'2023\/ 02\/ 19 12:10:51'},{'idGet':'15835235','transId':'15840557','amount':'2100000','date':'2023\/ 02\/ 19 12:51:30'},{'idGet':'15835445','transId':'15840767','amount':'4000000','date':'2023\/ 02\/ 19 13:08:27'},{'idGet':'15836235','transId':'15841557','amount':'5916666','date':'2023\/ 02\/ 19 14:18:06'},{'idGet':'15836249','transId':'15841571','amount':'5583333','date':'2023\/ 02\/ 19 14:19:55'},{'idGet':'15837551','transId':'15842873','amount':'2725000','date':'2023\/ 02\/ 19 16:29:56'},{'idGet':'15838139','transId':'15843461','amount':'1000000','date':'2023\/ 02\/ 19 17:30:10'},{'idGet':'15839307','transId':'15844629','amount':'6066666','date':'2023\/ 02\/ 19 19:04:57'},{'idGet':'15839689','transId':'15845011','amount':'2000000','date':'2023\/ 02\/ 19 19:34:41'},{'idGet':'15839875','transId':'15845197','amount':'6750000','date':'2023\/ 02\/ 19 19:50:19'},{'idGet':'15840201','transId':'15845523','amount':'4000000','date':'2023\/ 02\/ 19 20:21:29'},{'idGet':'15840431','transId':'15845753','amount':'2000000','date':'2023\/ 02\/ 19 20:44:30'},{'idGet':'15840807','transId':'15846129','amount':'1000000','date':'2023\/ 02\/ 19 21:15:13'},{'idGet':'15841413','transId':'15846735','amount':'2333333','date':'2023\/ 02\/ 19 22:03:04'},{'idGet':'15841441','transId':'15846763','amount':'2333333','date':'2023\/ 02\/ 19 22:06:08'},{'idGet':'15841699','transId':'15847021','amount':'500000','date':'2023\/ 02\/ 19 22:24:36'},{'idGet':'15842469','transId':'15847791','amount':'2777777','date':'2023\/ 02\/ 19 23:22:41'},{'idGet':'15842863','transId':'15848185','amount':'2000000','date':'2023\/ 02\/ 19 23:51:14'},{'idGet':'15844375','transId':'15849697','amount':'2000000','date':'2023\/ 02\/ 20 07:13:22'},{'idGet':'15844757','transId':'15850079','amount':'2000000','date':'2023\/ 02\/ 20 08:42:22'},{'idGet':'15844773','transId':'15850095','amount':'2000000','date':'2023\/ 02\/ 20 08:43:00'},{'idGet':'15844907','transId':'15850229','amount':'2000000','date':'2023\/ 02\/ 20 09:02:15'},{'idGet':'15844947','transId':'15850269','amount':'5266664','date':'2023\/ 02\/ 20 09:08:01'},{'idGet':'15845231','transId':'15850553','amount':'500000','date':'2023\/ 02\/ 20 09:45:18'},{'idGet':'15845625','transId':'15850947','amount':'2000000','date':'2023\/ 02\/ 20 10:32:43'},{'idGet':'15846175','transId':'15851497','amount':'2000000','date':'2023\/ 02\/ 20 11:22:03'},{'idGet':'15846455','transId':'15851777','amount':'6375000','date':'2023\/ 02\/ 20 11:47:06'},{'idGet':'15847127','transId':'15852449','amount':'2750000','date':'2023\/ 02\/ 20 12:48:39'},{'idGet':'15847181','transId':'15852503','amount':'5841666','date':'2023\/ 02\/ 20 12:51:46'},{'idGet':'15847219','transId':'15852541','amount':'1000000','date':'2023\/ 02\/ 20 12:55:49'},{'idGet':'15847253','transId':'15852575','amount':'2000000','date':'2023\/ 02\/ 20 12:59:09'},{'idGet':'15847299','transId':'15852621','amount':'1000000','date':'2023\/ 02\/ 20 13:01:59'},{'idGet':'15847875','transId':'15853197','amount':'1000000','date':'2023\/ 02\/ 20 13:50:40'},{'idGet':'15847889','transId':'15853211','amount':'2000000','date':'2023\/ 02\/ 20 13:52:20'},{'idGet':'15848293','transId':'15853615','amount':'6750000','date':'2023\/ 02\/ 20 14:23:53'},{'idGet':'15848507','transId':'15853829','amount':'4000000','date':'2023\/ 02\/ 20 14:38:01'},{'idGet':'15848773','transId':'15854095','amount':'8000000','date':'2023\/ 02\/ 20 15:06:56'},{'idGet':'15849217','transId':'15854539','amount':'2000000','date':'2023\/ 02\/ 20 15:45:21'},{'idGet':'15851915','transId':'15857237','amount':'8583333','date':'2023\/ 02\/ 20 20:16:12'},{'idGet':'15852087','transId':'15857409','amount':'8125000','date':'2023\/ 02\/ 20 20:30:47'},{'idGet':'15852123','transId':'15857445','amount':'2000000','date':'2023\/ 02\/ 20 20:34:15'},{'idGet':'15853555','transId':'15858877','amount':'5500000','date':'2023\/ 02\/ 20 22:30:17'},{'idGet':'15853833','transId':'15859155','amount':'2000000','date':'2023\/ 02\/ 20 22:57:09'},{'idGet':'15856235','transId':'15861557','amount':'2000000','date':'2023\/ 02\/ 21 07:54:57'},{'idGet':'15856949','transId':'15862271','amount':'4000000','date':'2023\/ 02\/ 21 09:38:58'},{'idGet':'15857047','transId':'15862369','amount':'2500000','date':'2023\/ 02\/ 21 09:51:19'},{'idGet':'15857323','transId':'15862645','amount':'9769166','date':'2023\/ 02\/ 21 10:20:16'},{'idGet':'15864385','transId':'15869707','amount':'2000000','date':'2023\/ 02\/ 21 21:27:27'},{'idGet':'15864459','transId':'15869781','amount':'2000000','date':'2023\/ 02\/ 21 21:32:59'},{'idGet':'15864689','transId':'15870011','amount':'2000000','date':'2023\/ 02\/ 21 21:51:34'},{'idGet':'15865181','transId':'15870503','amount':'2000000','date':'2023\/ 02\/ 21 22:37:02'},{'idGet':'15868057','transId':'15873379','amount':'5400000','date':'2023\/ 02\/ 22 09:05:08'},{'idGet':'15868139','transId':'15873461','amount':'2000000','date':'2023\/ 02\/ 22 09:21:42'},{'idGet':'15868525','transId':'15873847','amount':'11062500','date':'2023\/ 02\/ 22 10:05:40'},{'idGet':'15868771','transId':'15874093','amount':'8195000','date':'2023\/ 02\/ 22 10:33:26'},{'idGet':'15868799','transId':'15874121','amount':'2000000','date':'2023\/ 02\/ 22 10:37:16'}]}";

        //          // Object json1 = JObject.Parse(myJsonResponse);
        //          var myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
        //           var orders = new List<Employee>();
        //           foreach ( var k in myDeserializedClass.employees)
        //           {
        //               BitPay bitpay = new BitPay();
        //               float trans = float.Parse(k.transId);
        //               var factorid = (from e in db.bitpayorders where e.tranaction == trans select e.factor).FirstOrDefault();
        //               Employee em = new Employee();
        //               em.date = k.date;
        //               em.factor = factorid;
        //               em.amount = k.amount;
        //               em.idGet = k.idGet;
        //               em.transId = k.transId;
        //               orders.Add(em);

        //           }


        //           return Json(orders, JsonRequestBehavior.AllowGet);


        //       }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMoghaieratcount()
        {
            int count = 0;
            try
            {
                SandooghModel db = new SandooghModel();
                var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                string startyear = yearrr.Year_Name + "/01/01";
                string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                DateTime startdate = (DateTime)(from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Sanad_No == 1 select e.Date_S).FirstOrDefault();


                string commandvam = @"select N'وام' as Expr1, a.Tafsili, a.hes, b.pard, b.IdRefOzv,a.hes-b.pard as Expr2 from ( SELECT        Tafsili, SUM(Bestankar)-sum(Bedhkar) + (SELECT        VamMablagKhales + Karmozd AS Expr1
                                                          FROM            Vam
                                                          WHERE        (IdRefOzv = Tafsili) and EtmamVam=0 and vamdate>'" + startdate + @"'
														  union 
														  select 0 as Expr1  from vam where  (IdRefOzv = Tafsili) and EtmamVam=0 and vamdate<='" + startdate + @"'
														  
														  
														  ) AS hes
FROM            AccSanad_B
WHERE      ((moein=002) or (Moein = 001)or (Moein = 003)) AND (Kol = 112) AND (Date_S > '" + startdate + @"')
GROUP BY Tafsili)a , 


(SELECT        SUM(TotGestMablag) AS pard, IdRefOzv 
FROM            G_M_Pays
WHERE          (PayDate > '" + startdate + @"')
GROUP BY IdRefOzv)b where a.Tafsili=b.IdRefOzv and a.hes<>b.pard  
union 
select N'مستمری' as Expr1, a.Tafsili, a.hes, b.pard, b.IdRefOzv,a.hes-b.pard as Expr2 from ( SELECT        Tafsili, SUM(Bestankar)-sum(Bedhkar) AS hes
FROM            AccSanad_B
WHERE      ( (Moein = 003)) AND (Kol = 311) AND (Date_S > '" + startdate + @"')
GROUP BY Tafsili)a , 


(SELECT        SUM(MostamariMablag) AS pard, IdRefOzv 
FROM            G_M_Pays
WHERE        (MostamariMablag != 0) AND (PayDate > '" + startdate + @"')
GROUP BY IdRefOzv)b where a.Tafsili=b.IdRefOzv and a.hes<>b.pard ";

                commandvam = "select  Expr1, Tafsili, hes, pard,IdRefOzv, Expr2,FName,LName from (" + commandvam + ")d,T_OzvCode as b where b.Id=d.IdRefOzv ";
                DataGatheration gath = new DataGatheration();
                DataTable Table = gath.GetSqlTableWithComand(commandvam);

                return Json(Table.Rows.Count, JsonRequestBehavior.AllowGet);

            }

            catch
            {

            }
            return Json(count);

        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMoghaieratList(string sidx, string sord, int page, int rows, string type, bool filter = false)
        {
            SandooghModel db = new SandooghModel();
            var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
            string startyear = yearrr.Year_Name + "/01/01";
            string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
            DateTime datestart = (DateTime)startyear.ToMilady();
            DateTime dateend = (DateTime)endyear.ToMilady();
            DateTime startdate = (DateTime)(from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) && e.Sanad_No == 1 select e.Date_S).FirstOrDefault();




            string commandvam = @"select N'وام' as Expr1, a.Tafsili, a.hes, b.pard, b.IdRefOzv,a.hes-b.pard as Expr2 from ( SELECT        Tafsili, SUM(Bestankar)-sum(Bedhkar) + (SELECT        VamMablagKhales + Karmozd AS Expr1
                                                          FROM            Vam
                                                          WHERE        (IdRefOzv = Tafsili) and EtmamVam=0 and vamdate>'" + startdate + @"'
														  union 
														  select 0 as Expr1  from vam where  (IdRefOzv = Tafsili) and EtmamVam=0 and vamdate<='" + startdate + @"'
														  
														  
														  ) AS hes
FROM            AccSanad_B
WHERE      ((moein=002) or (Moein = 001)or (Moein = 003)) AND (Kol = 112) AND (Date_S > '" + startdate + @"')
GROUP BY Tafsili)a , 


(SELECT        SUM(TotGestMablag) AS pard, IdRefOzv 
FROM            G_M_Pays
WHERE        (PayDate > '" + startdate + @"')
GROUP BY IdRefOzv)b where a.Tafsili=b.IdRefOzv and a.hes<>b.pard  
union 
select N'مستمری' as Expr1, a.Tafsili, a.hes, b.pard, b.IdRefOzv,a.hes-b.pard as Expr2 from ( SELECT        Tafsili, SUM(Bestankar)-sum(Bedhkar) AS hes
FROM            AccSanad_B
WHERE      ( (Moein = 003)) AND (Kol = 311) AND (Date_S > '" + startdate + @"')
GROUP BY Tafsili)a , 


(SELECT        SUM(MostamariMablag) AS pard, IdRefOzv 
FROM            G_M_Pays
WHERE        (MostamariMablag != 0) AND (PayDate > '" + startdate + @"')
GROUP BY IdRefOzv)b where a.Tafsili=b.IdRefOzv and a.hes<>b.pard ";
            if (type == "مستمری")
            {
                commandvam = @"
select N'مستمری' as Expr1, a.Tafsili, a.hes, b.pard, b.IdRefOzv,a.hes-b.pard as Expr2 from ( SELECT        Tafsili, SUM(Bestankar)-sum(Bedhkar)  AS hes
FROM            AccSanad_B
WHERE      ( (Moein = 003)) AND (Kol = 311) AND (Date_S >'" + startdate + @"')
GROUP BY Tafsili)a , 


(SELECT        SUM(MostamariMablag) AS pard, IdRefOzv 
FROM            G_M_Pays
WHERE        (MostamariMablag != 0) AND (PayDate > '" + startdate + @"')
GROUP BY IdRefOzv)b where a.Tafsili=b.IdRefOzv and a.hes<>b.pard  ";
            }
            if (type == "وام")
            {
                commandvam = @"select N'وام' as Expr1, a.Tafsili, a.hes, b.pard, b.IdRefOzv,a.hes-b.pard as Expr2 from ( SELECT        Tafsili, SUM(Bestankar)-sum(Bedhkar)+ (SELECT        VamMablagKhales + Karmozd AS Expr1
                                                          FROM            Vam
                                                          WHERE        (IdRefOzv = Tafsili) and EtmamVam=0 and vamdate>'" + startdate + @"'
														  union 
														  select 0 as Expr1  from vam where  (IdRefOzv = Tafsili) and EtmamVam=0 and vamdate<='" + startdate + @"'
														  
														  
														  ) AS hes
FROM            AccSanad_B
WHERE      ((moein=002) or (Moein = 001)or (Moein = 003)) AND (Kol = 112) AND (Date_S > '" + startdate + @"')
GROUP BY Tafsili)a , 


(SELECT        SUM(TotGestMablag) AS pard, IdRefOzv 
FROM            G_M_Pays
WHERE        (PayDate > '" + startdate + @"')
GROUP BY IdRefOzv)b  where a.Tafsili=b.IdRefOzv and a.hes<>b.pard  
";
            }
            commandvam = "select  Expr1, Tafsili, hes, pard,IdRefOzv, Expr2,FName,LName from (" + commandvam + ")d,T_OzvCode as b where b.Id=d.IdRefOzv ";
            DataGatheration gath = new DataGatheration();
            DataTable Table = gath.GetSqlTableWithComand(commandvam);

            var list = Table.AsEnumerable().AsQueryable();

            var list1 = list.ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list1.AsQueryable();
            var productsList = productsQuery;

            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = long.Parse(product.ItemArray[1].ToString()),
                    RowCells = new List<object>
                               {
                     product.ItemArray[6],  product.ItemArray[7],  product.ItemArray[1], product.ItemArray[5],  product.ItemArray[2],product.ItemArray[3], product.ItemArray[4],product.ItemArray[0]}
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetsanadListMghaierat(string sidx, string sord, int page, int rows, long idrefozv, bool filter = false, string type = "وام")
        {
            try
            {
                SandooghModel db = new SandooghModel();
                string commandvam = "";
                if (type == "وام")
                    commandvam = @" SELECT      ID,Sanad_No, Date_S,Bedhkar, Bestankar,   Articl_Comment,   [Group], Kol, Moein, Tafsili
FROM            AccSanad_B
WHERE           ((moein=002) or (Moein = 001)or (Moein = 003)) AND (Kol = 112)  AND (Tafsili = " + idrefozv + ") ORDER BY ID desc";
                else
                    commandvam = @" SELECT      ID,Sanad_No, Date_S,Bedhkar, Bestankar,   Articl_Comment,   [Group], Kol, Moein, Tafsili
FROM            AccSanad_B
WHERE          ( (Moein = 003)) AND (Kol = 311)  AND (Tafsili = " + idrefozv + ") ORDER BY ID desc";

                DataGatheration gath = new DataGatheration();
                DataTable Table = gath.GetSqlTableWithComand(commandvam);

                var list = Table.AsEnumerable().AsQueryable();

                var list1 = list.ToList();
                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list1.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list1.AsQueryable();

                var productsList = productsQuery;

                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = long.Parse(product.ItemArray[0].ToString()),
                        RowCells = new List<object>
                               {
                     product.ItemArray[0], product.ItemArray[1], product.ItemArray[2]!=null?((DateTime)product.ItemArray[2]).ToPersianDate():"",product.ItemArray[3],product.ItemArray[4],
                     product.ItemArray[5],product.ItemArray[6],product.ItemArray[7],product.ItemArray[8],product.ItemArray[9]
                               }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetPardakhtListMghaierat(string sidx, string sord, int page, int rows, long idrefozv, bool filter = false, string type = "")
        {
            try
            {
                SandooghModel db = new SandooghModel();
                string commandvam = "";
                if (type == "وام")
                    commandvam = @"SELECT       Id,SanadNo, TotMablag,  TotGestMablag, MostamariMablag, PayDate,  Comment, IdRefOzv, IdRefVam, Fish_No, Sanads
FROM            G_M_Pays
WHERE        (IdRefOzv = " + idrefozv + ")ORDER BY Id desc";
                else
                    commandvam = @"SELECT       Id,SanadNo, TotMablag,  TotGestMablag, MostamariMablag, PayDate,  Comment, IdRefOzv, IdRefVam, Fish_No, Sanads
FROM            G_M_Pays
WHERE        (MostamariMablag != 0) AND (IdRefOzv = " + idrefozv + ")ORDER BY Id desc";

                DataGatheration gath = new DataGatheration();
                DataTable Table = gath.GetSqlTableWithComand(commandvam);

                var list = Table.AsEnumerable().AsQueryable();

                var list1 = list.ToList();
                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list1.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list1.AsQueryable();

                var productsList = productsQuery;

                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = long.Parse(product.ItemArray[0].ToString()),
                        RowCells = new List<object>
                               {
                     product.ItemArray[0], product.ItemArray[1], product.ItemArray[2],product.ItemArray[3],product.ItemArray[4],
                     product.ItemArray[5]!=null?((DateTime)product.ItemArray[5]).ToPersianDate():"",product.ItemArray[6],product.ItemArray[7],product.ItemArray[8],product.ItemArray[9],product.ItemArray[10]
                               }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetVamList(string sidx, string sord, int page, int rows, string codeaz, string codeta, string fname, string lname, string noevam, string azdate, string tadate, string type, bool filter = false)
        {
            SandooghModel db = new SandooghModel();
            var list = from e in db.Vams select e;
            if (filter)
            {
                long az = 0;
                long ta = long.MaxValue;
                long vamtype = -1;
                try
                {
                    az = long.Parse(codeaz);
                }
                catch
                {

                }
                try
                {
                    if (codeta == "" && az != 0)
                        ta = az;
                    else
                        ta = long.Parse(codeta);
                }
                catch
                {
                    if (az != 0)
                        ta = az;
                }
                try
                {
                    vamtype = long.Parse(noevam);
                }
                catch
                {
                    vamtype = -1;
                }
                list = (from e in list where e.T_OzvCode.Id >= az && e.T_OzvCode.Id <= ta select e);
                if (fname.Length > 0)
                    list = (from e in list where e.T_OzvCode.FName.Contains(fname) select e);
                if (lname.Length > 0)
                    list = (from e in list where e.T_OzvCode.LName.Contains(lname) select e);
                if (vamtype != -1)
                    list = (from e in list where e.IdRefNoeVam == vamtype select e);
                if (type == "t")
                    list = (from e in list where e.EtmamVam == true select e);
                if (type == "tn")
                    list = (from e in list where e.EtmamVam == false select e);

                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = (DateTime)tadate.ToMilady();
                }
                catch
                {

                }
                list = (from e in list where e.VamDate >= azdatei && e.VamDate <= tadatei select e);

            }
            var list1 = list.ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list1.AsQueryable();
            if (sidx.ToUpper() == "FNAME")
                sidx = "T_OzvCode.FName";
            if (sidx.ToUpper() == "LNAME")
                sidx = "T_OzvCode.LName";
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize);

            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Vam_Id,
                    RowCells = new List<object>
                               {
                   product.T_OzvCode.G_M_Pays.Where(a => a.PayDate<=product.VamDate )
                    .Sum(a => a.MostamariMablag),   product.IdRefNoeVam,product.T_VamCode.VamName, product.Vam_Id ,product.T_OzvCode.FName.ToString(),product.T_OzvCode.LName ,product.IdRefOzv,product.VamDate!=null?((DateTime)product.VamDate).ToPersianDate():"", product.Karmozd,product.VamMablagKhales.ToString()
                   ,product.TedadAgsat,product.AvlinGestDate!=null?((DateTime)product.AvlinGestDate).ToPersianDate():"",product.GestMablag,product.CheckVam,product.HesabNoVam,product.CheckOzv,product.HesabNo,product.BankName,
                 product.Comment,product.EtmamVam,product.Sanads,product.SanadNo,product.T_OzvCode.Mobile,product.T_OzvCode.Tel
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        private string GetPayDescriptionForLog(G_M_Pays PD, string moeinbank)
        {
            string description = "";
            description += "شناسه پرداخت:" + PD.Id + "<br/>";
            description += "کد پرداخت کننده:" + PD.IdRefOzv + "<br/>";
            description += "نام عضو:" + PD.T_OzvCode.FName + " " + PD.T_OzvCode.LName + "<br/>";
            description += PD.IdRefVam != null ? ("کد وام:" + PD.IdRefVam + "<br/>") : "";
            description += PD.Vam != null ? ("نوع وام:" + PD.Vam.T_VamCode.VamName + "<br/>") : "";
            description += "تاریخ واریز:" + PersianDateUtils.ToPersianDate((DateTime)PD.PayDate) + "<br/>";
            description += PD.MablaghharGhest != null ? ("مبلغ هر قسط:" + PD.MablaghharGhest + "<br/>") : "";
            description += PD.TedadGest != null ? ("تعدادقسط:" + PD.TedadGest + "<br/>") : "";
            description += PD.TotGestMablag != null && PD.TotGestMablag != 0 ? ("جمع قسط واریزی:" + PD.TotGestMablag + "<br/>") : "";
            description += PD.TakhirMablag != null && PD.TakhirMablag != 0 ? ("مبلغ دیرکرد:" + PD.TakhirMablag + "<br/>") : "";
            description += PD.MablaghHarMostamary != null && PD.MablaghHarMostamary != 0 ? ("مستمری ماهانه:" + PD.MablaghHarMostamary + "<br/>") : "";
            description += PD.TedadMostamari != null && PD.TedadMostamari != 0 ? ("تعداد مستمری:" + PD.TedadMostamari + "<br/>") : "";
            description += PD.MostamariMablag != null && PD.MostamariMablag != 0 ? ("مستمری واریزی :" + PD.MostamariMablag + "<br/>") : "";
            description += PD.Nahveh_P1 != null ? ("نحوه پرداخت:" + PD.Nahveh_P1.Nahveh_P1 + "<br/>") : "";
            description += "شماره فیش:" + PD.Fish_No + "<br/>";
            description += "بانک:" + moeinbank + "<br/>";
            description += "جمع واریزی:" + PD.TotMablag + "<br/>";
            description += "توضیحات:" + PD.Comment + "<br/>";
            description += "شماره سند:" + PD.SanadNo + "<br/>";
            description += "ردیف سند:" + PD.Sanads + "<br/>";
            description += PD.Vam != null ? ("تاریخ وام:" + PersianDateUtils.ToPersianDate((DateTime)PD.Vam.VamDate) + "<br/>") : "";
            description += PD.Vam != null ? ("مبلغ وام:" + PD.Vam.VamMablagKhales + "<br/>") : "";
            return description;

        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddPardakhty(G_M_Pays postData, string BankTafsilicode, string Sanad = "")
        {

            SandooghModel db = new SandooghModel();
            string comment1 = "";
            try
            {
                if (postData.Comment.Contains("پیگیری واریز"))
                    comment1 = postData.Comment.Split(new string[] { "پیگیری واریز" }, StringSplitOptions.None)[1];
            }
            catch
            {

            }
            int UserSanad = 0;
            if (Sanad != "")
            {
                try
                {
                    UserSanad = int.Parse(Sanad);
                }
                catch
                {
                    return Json(false);
                }
            }
            if (UserSanad != 0)
            {
                var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                string startyear = yearrr.Year_Name + "/01/01";
                string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var sd = (from e in db.AccSanad_B where e.Sanad_No == UserSanad && DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).FirstOrDefault();
                if ((((DateTime)postData.PayDate).Date != sd.Date_S.Date && sd.Date_S != DateTime.MinValue) || (sd.Lock_Sanad == true))
                {
                    return Json("SanadError1");
                }
            }
            try
            {

                //todo: Add product to repository
                if (postData == null)
                    return Json(false);

                string noevam = "";
                string ozvnam = "";
                try
                {
                    noevam = (from e in db.Vams where e.Vam_Id == postData.IdRefVam select e.T_VamCode.VamName).FirstOrDefault();
                }
                catch
                {

                }
                try
                {
                    ozvnam = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e.FName + " " + e.LName).FirstOrDefault();
                }
                catch
                {

                }
                if (postData.MostamariMablag != null && postData.MostamariMablag > 0)
                {
                    var lastvam = (from v in db.Vams
                                   where (v.IdRefOzv == postData.IdRefOzv)
                                   orderby v.VamDate descending
                                   select v).Take(1);

                    //آخرین مستمری پرداختی قبل از ثبت این مستمری
                    var lastmostamarry = (from v in db.G_M_Pays
                                          where (v.IdRefOzv == postData.IdRefOzv && v.MostamariMablag != null && v.MostamariMablag != 0)
                                          orderby v.PayDate descending
                                          select v).Take(1);
                    if (lastmostamarry != null && lastmostamarry.ToList().Count > 0)
                    {
                        //اگر قبلا مستمری پرداخت کرده است
                        var persianCalendar = new System.Globalization.PersianCalendar();
                        var lastpay = (DateTime)lastmostamarry.ToList()[0].PayDate;
                        int emtiaz = 0;
                        while (postData.PayDate >= persianCalendar.AddMonths(lastpay, 3).AddDays(1))
                        {
                            emtiaz++;
                            lastpay = persianCalendar.AddMonths(lastpay, 3).AddDays(1);
                        }
                        postData.Emtiaz = emtiaz;

                    }
                }
                int moeinbank = -1;
                try
                {
                    moeinbank = int.Parse(BankTafsilicode);

                }
                catch
                {

                }


                var maxValue = UserSanad;
                if (UserSanad == 0)
                {
                    var DateOfPay = (DateTime)postData.PayDate;
                    var sanadno = (from e in db.AccSanad_B
                                   where
           e.Date_S.Year == DateOfPay.Year
           && e.Date_S.Month == DateOfPay.Month
           && e.Date_S.Day == DateOfPay.Day
           && (e.Lock_Sanad != true) && (e.UserLock != true)
                                   select e.Sanad_No).Distinct();
                    var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                    string startyear = yearrr.Year_Name + "/01/01";
                    string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                    DateTime datestart = (DateTime)startyear.ToMilady();
                    DateTime dateend = (DateTime)endyear.ToMilady();
                    var thisyearssanads = from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e;

                    var max = thisyearssanads.Max(x => x.Sanad_No);
                    if (sanadno.ToList().Count == 0)
                    {

                        if (DateTime.Now.Date == ((DateTime)postData.PayDate).Date)
                            maxValue = (int)max + 1;
                        else
                            return Json("SanadError1");
                    }
                    else
                        maxValue = (int)sanadno.ToList().Max();
                }

                var sanads = "";

                if (postData.TotMablag > 0)
                {
                    //حساب بانک بدهکار
                    AccSanad_B sanad1 = new AccSanad_B();
                    sanad1.Sanad_No = maxValue;
                    sanad1.Group = "1";
                    sanad1.Kol = "111";
                    string jjhhgg = moeinbank.ToString();
                    var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == jjhhgg select e;/*1212*/
                    string moeincode = "";
                    if (bankmoein != null)
                        moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                    if (moeincode != null)
                    {
                        sanad1.Moein = moeincode;
                        sanad1.Tafsili = BankTafsilicode;
                        sanad1.Date_S = (DateTime)postData.PayDate;
                        sanad1.Sanad_Tafsili1 = 1;
                        sanad1.Ok_NotOk = false;
                        sanad1.Lock_Sanad = false;
                        sanad1.Bedhkar = postData.TotMablag;
                        sanad1.Bestankar = 0;
                        string comment = "وصول ";
                        if (postData.TotGestMablag > 0)
                            if (postData.MostamariMablag > 0)
                                comment += " قسط و مستمری " + noevam + " ";
                            else
                                comment += " قسط  " + noevam + " ";

                        else
                            if (postData.MostamariMablag > 0)
                        {
                            if (postData.IsAfzayesh == true)
                                comment += "  افزایش سرمایه ";
                            else
                                comment += "  مستمری ماهانه ";
                        }
                        else
                            comment += " ...  ";

                        if (comment1 != "")
                        {
                            sanad1.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + "پیگیری واریز " + comment1;


                        }
                        else

                        {
                            sanad1.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;

                        }
                        db.AccSanad_B.Add(sanad1);

                        db.SaveChanges();
                        postData.SanadNo = sanad1.Sanad_No;
                        sanads += sanad1.ID + ",";
                    }
                    else
                        return Json(false);
                }
                else
                    sanads += ",";
                if (postData.TotGestMablag > 0)//اگر قسط پرداخت میشود
                {
                    //وام عضو بستانکار
                    AccSanad_B sanad = new AccSanad_B();
                    sanad.Sanad_No = maxValue;
                    sanad.Group = "1";
                    sanad.Kol = "112";
                    switch (postData.IdRefNoeVam)
                    {
                        case 1001:
                            sanad.Moein = "001";
                            break;
                        case 1002:
                            sanad.Moein = "003";
                            break;
                        case 1003:
                            sanad.Moein = "002";
                            break;
                    }
                    sanad.Tafsili = postData.IdRefOzv.ToString();
                    sanad.Date_S = (DateTime)postData.PayDate;
                    sanad.Sanad_Tafsili1 = 2;
                    sanad.Ok_NotOk = false;
                    sanad.Lock_Sanad = false;
                    sanad.Bedhkar = 0;
                    sanad.Bestankar = postData.TotGestMablag;
                    string comment = "وصول ";
                    if (postData.TotGestMablag > 0)
                        if (postData.MostamariMablag > 0)
                            comment += " قسط و مستمری " + noevam + " ";
                        else
                            comment += " قسط  " + noevam + " ";

                    else
                    if (postData.MostamariMablag > 0)
                    {
                        if (postData.IsAfzayesh == true)
                            comment += "  افزایش سرمایه ";
                        else
                            comment += "  مستمری ماهانه ";
                    }

                    else
                        comment += " ...  ";
                    if (comment1 != "")
                    {
                        sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + "پیگیری واریز " + comment1;


                    }
                    else

                    {
                        sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;
                    }

                    db.AccSanad_B.Add(sanad);
                    db.SaveChanges();
                    postData.SanadNo = sanad.Sanad_No;
                    sanads += sanad.ID + ",";


                }
                else
                    sanads += ",";
                if (postData.MostamariMablag > 0)//اگر مستمری پرداخت میشود
                {


                    //مستمری عضو بستانکار
                    AccSanad_B sanad = new AccSanad_B();
                    sanad.Sanad_No = maxValue;
                    sanad.Group = "3";
                    sanad.Kol = "311";

                    sanad.Moein = "003";

                    sanad.Tafsili = postData.IdRefOzv.ToString();
                    sanad.Date_S = (DateTime)postData.PayDate;
                    sanad.Sanad_Tafsili1 = 2;
                    sanad.Ok_NotOk = false;
                    sanad.Lock_Sanad = false;
                    sanad.Bedhkar = 0;
                    sanad.Bestankar = postData.MostamariMablag;
                    string comment = "وصول ";
                    if (postData.TotGestMablag > 0)
                        if (postData.MostamariMablag > 0)
                            comment += " قسط و مستمری " + noevam + " ";
                        else
                            comment += " قسط  " + noevam + " ";

                    else
                        if (postData.MostamariMablag > 0)
                    {
                        if (postData.IsAfzayesh == true)
                            comment += "  افزایش سرمایه ";
                        else
                            comment += "  مستمری ماهانه ";

                    }
                    else
                        comment += " ...  ";
                    if (comment1 != "")
                    {
                        sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + "پیگیری واریز " + comment1;


                    }
                    else

                    {
                        sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;
                    }



                    db.AccSanad_B.Add(sanad);
                    db.SaveChanges();
                    postData.SanadNo = sanad.Sanad_No;
                    sanads += sanad.ID + ",";


                }
                else
                    sanads += ",";

                postData.Sanads = sanads;
                //new if
                if (postData.IsAfzayesh == true)
                {
                    try
                    {

                        T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e).FirstOrDefault();
                        ozv.SumAfzayeshMostamary -= (int)postData.MostamariMablag;
                        db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();

                        if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > postData.PayDate)
                        {
                            T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                            lastmostpaie.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == lastmostpaie.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)lastmostpaie.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
                            db.Entry(lastmostpaie).State = System.Data.Entity.EntityState.Modified;
                            db.SaveChanges();
                        }

                    }
                    catch
                    {

                    }
                }
                db.G_M_Pays.Add(postData);
                db.SaveChanges();

                try
                {


                    var PD = (from e in db.G_M_Pays where e.Id == postData.Id select e).FirstOrDefault();
                    PD.T_OzvCode = (from e in db.T_OzvCode where e.Id == PD.IdRefOzv select e).FirstOrDefault();
                    try
                    {
                        PD.Vam = (from e in db.Vams where e.Vam_Id == PD.IdRefVam select e).FirstOrDefault();
                    }
                    catch
                    {

                    }
                    try
                    {
                        PD.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == PD.Nahveh_P select e).FirstOrDefault();
                    }
                    catch
                    {

                    }
                    T_Log log = new T_Log();
                    log.Log_Date = DateTime.Now;
                    log.Log_Description = GetPayDescriptionForLog(PD, moeinbank.ToString());
                    log.Log_Name = "دریافت قسط/مستمری جدید";
                    log.Log_Type = "دریافت/پرداخت";
                    log.Log_User = this.User.Identity.Name;
                    db.T_Log.Add(log);
                    db.SaveChanges();
                }
                catch
                {

                }

                //ارسال اس ام اس

                var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == postData.IdRefOzv select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                var activevam = (double?)0;
                try
                {
                    activevam = (from w in db.Vams where w.IdRefOzv == postData.IdRefOzv && w.EtmamVam == false select w.Vam_Id).FirstOrDefault();
                }
                catch
                {

                }
                var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.Vam.EtmamVam == false && e.IdRefOzv == postData.IdRefOzv) select e;
                var pardakhtVam = (double?)0;
                var mandevam = (double?)0;
                try
                {
                    pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;


                }
                catch
                {

                }
                try
                {
                    if (pardakhtVam == null)
                        pardakhtVam = 0;
                    mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                    mandevam = mandevam - pardakhtVam;
                    if (mandevam <= 0)
                    {
                        var entity2 = db.Vams.Where(c => c.Vam_Id == postData.IdRefVam).AsQueryable().FirstOrDefault();
                        entity2.EtmamVam = true;
                        db.Entry(entity2).CurrentValues.SetValues(entity2);
                        db.SaveChanges();
                    }



                    if (activevam == 0)
                    {
                        natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == postData.IdRefVam && e.IdRefOzv == postData.IdRefOzv) select e;
                        pardakhtVam = (double?)0;
                        mandevam = (double?)0;
                        try
                        {
                            pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;


                        }
                        catch
                        {

                        }
                        mandevam = (from t in db.Vams where t.Vam_Id == postData.IdRefVam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                        mandevam = mandevam - pardakhtVam;
                        if (mandevam <= 0)
                        {
                            var entity2 = db.Vams.Where(c => c.Vam_Id == postData.IdRefVam).AsQueryable().FirstOrDefault();
                            entity2.EtmamVam = true;
                            db.Entry(entity2).CurrentValues.SetValues(entity2);
                            db.SaveChanges();
                        }
                        else
                        {
                            var entity2 = db.Vams.Where(c => c.Vam_Id == postData.IdRefVam).AsQueryable().FirstOrDefault();
                            entity2.EtmamVam = false;
                            db.Entry(entity2).CurrentValues.SetValues(entity2);
                            db.SaveChanges();
                        }

                    }
                }
                catch
                {

                }
                try
                {
                    var ozv = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e).FirstOrDefault();
                    if ((postData.TotGestMablag == null || postData.TotGestMablag <= 0) && (postData.MostamariMablag == null || (postData.MostamariMablag <= 0)))
                    {
                        SendMsg(new string[] { ozv.Mobile }, DateTime.Now.ToPersianDate() +
                        "\n" + postData.Comment + "\n" + @"عضو محترم صنم");
                    }
                    else
                    {

                        SendMsg(new string[] { ozv.Mobile }, DateTime.Now.ToPersianDate() +
                        (postData.TotGestMablag != null ? (postData.TotGestMablag > 0 ? "\n" + @" قسط واريزي: " + postData.TotGestMablag + " ریال" : "") : "") +
                        ((postData.TotGestMablag != null && postData.TotGestMablag > 0) ? ((mandevam != null ? ("\n" + @"مانده وام : " + mandevam.Value.ToString()) : "") + "\n شناسه پرداخت قسط:" + ozv.ghestshenase) /*("\n" + @"جمع اقساط واریزی : " + pardakhtVam + "ریال */: "") +
                                           //(mandevam!=null? ("\n" + @"مانده وام : " + mandevam.Value.ToString()):"") + 
                                           (postData.MostamariMablag != null ? (postData.MostamariMablag != 0 ? "\n" + @" مستمري واريزي : " + postData.MostamariMablag + " ریال \n" + @"جمع مستمری : " + summostamarises.FirstOrDefault().SumMostamary + " ریال" + "\n شناسه پرداخت مستمری:" + ozv.mostammarryshenase : "") : "") +



    "\n" + @"عضو محترم صنم");
                    }
                }
                catch
                {

                    return Json(false);
                }
            }
            catch
            {
                return Json(false);
            }

            return Json(true);
        }
        [NonAction]
        public System.Threading.Tasks.Task<MVCSandoogh.GhasedakServiceRefrence.SendSMSResponse> SendMsg(string[] numbers, string message)
        {


            try
            {
                ArrayOfString senderNumbers = new ArrayOfString();

                senderNumbers.Add("90007081");
                v2SoapClient asc = new v2SoapClient();
                var recivers = new ArrayOfString();
                recivers.AddRange(numbers.ToList());
                var messages = new ArrayOfString();
                messages.AddRange(new string[] { message }.ToList<string>());
                //
                var result = asc.SendSMSAsync("sandogh.1378@gmail.com", "@SA12345@", senderNumbers, recivers, messages, null, null, null);
                return result;
            }
            catch (Exception ex)
            {
                return null;
            }
            //try
            //{

            //    var smsService = new SmsService();
            //    var ssvm = new SendViewModel
            //    {
            //        Password = "S!23@",
            //        Username = "sandoogh",
            //        Folder = "web",
            //        Number = "500010033384311",
            //        ReceiverPhoneNumbers = numbers.ToList(),
            //        SmsText = message
            //    };
            //    var result = Task.Run(() => smsService.Send(ssvm)).Result;
            //    return result;
            //}
            //catch (Exception ex)
            //{

            //    return null;
            //}
            /*  try
              {
                  SMSZoneSoap sso = new SMSZoneSoapClient();
                  ArrayOfString aos = new ArrayOfString();
                  aos.InsertRange(0, numbers);

                  DoSendRequestBody dsrb = new DoSendRequestBody(aos, message, "500010033384311", "sandoogh", "S!23@", true, "webservice");
                  DoSendRequest request = new DoSendRequest(dsrb);
                  sso.DoSend(request);

                  // SendSoap sso = new SendSoapClient();
                  //sso.SendSimpleSMS("nezam0441", "Nez441am@", numbers, "30001220000749", message, false);
              }
              catch
              {

              }*/


        }
        [Authorize(Roles = "Admin")]
        public DataTable ProcessExcelk(HttpPostedFileBase file)
        {

            if (file != null && file.ContentLength > 0)
            {
                try
                {
                    IWorkbook workbook;
                    using (var stream = file.InputStream)
                    {
                        // Use HSSFWorkbook for Excel 97-2003 format (.xls)
                        workbook = new HSSFWorkbook(stream);
                    }

                    // Find the starting row based on column L having a value of 1
                    int startRow = FindStartRowk(workbook);

                    // Read data and populate DataTable
                    var temp = ReadExcelDatak(workbook, startRow);
                    //Id,FName,LName,payid,PayDate,TotMablagh,type,vam,desc
                    readedtable = new DataTable();
                    readedtable.Columns.Add("statusecode");
                    readedtable.Columns.Add("statuse");
                    readedtable.Columns.Add("Id");
                    readedtable.Columns.Add("FName");
                    readedtable.Columns.Add("LName");
                    readedtable.Columns.Add("payid");
                    readedtable.Columns.Add("PayDate");
                    readedtable.Columns.Add("TotMablagh");
                    readedtable.Columns.Add("type");
                    readedtable.Columns.Add("vam");
                    readedtable.Columns.Add("desc");


                    foreach (DataRow row in temp.Rows)
                    {
                        var returnedrow = AddPardakhtyFromExcel(row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString(), row[5].ToString(), row[6].ToString(), row[7].ToString(), row[8].ToString(), row[9].ToString(), row[10].ToString(), row[11].ToString(), "10023");

                        readedtable.Rows.Add(returnedrow.ToArray());

                    }
                    return readedtable;
                }
                catch (Exception ex)
                {
                    return null;

                }
            }

            return null;


        }
        private int FindStartRowk(IWorkbook workbook)
        {
            ISheet sheet = workbook.GetSheetAt(0);

            // Logic to find the starting row
            for (int row = 0; row <= sheet.LastRowNum; row++)
            {
                IRow currentRow = sheet.GetRow(row);
                try
                {
                    if (currentRow != null && currentRow.GetCell(11).NumericCellValue == 1)
                    {
                        return row;
                    }
                }
                catch { }
            }

            return 0; // Default if not found
        }

        private DataTable ReadExcelDatak(IWorkbook workbook, int startRow)
        {
            DataTable dataTable = new DataTable();

            // Add columns to DataTable
            for (int col = 0; col < 12; col++)
            {
                try { dataTable.Columns.Add(workbook.GetSheetAt(0).GetRow(startRow).GetCell(col).StringCellValue); }
                catch
                {
                    dataTable.Columns.Add("");
                }
            }

            // Read data from startRow to the end
            for (int row = startRow; row < workbook.GetSheetAt(0).LastRowNum; row++)
            {
                try
                {
                    IRow currentRow = workbook.GetSheetAt(0).GetRow(row);
                    DataRow dataRow = dataTable.NewRow();
                    bool r = true;
                    for (int col = 0; col < 12; col++)
                    {
                        try
                        {
                            if (currentRow.GetCell(0) == null) { r = false; break; }
                            dataRow[col] = currentRow.GetCell(col).ToString();
                        }
                        catch
                        {
                            dataRow[col] = "";
                        }
                    }
                    if (r)
                        dataTable.Rows.Add(dataRow);
                }
                catch
                {

                }
            }

            return dataTable;
        }

        [Authorize(Roles = "Admin")]
        public DataTable ProcessExcel(HttpPostedFileBase file)
        {
            if (file != null && file.ContentLength > 0)
            {
                try
                {
                    IWorkbook workbook;

                    using (var stream = file.InputStream)
                    {
                        if (Path.GetExtension(file.FileName).ToLower() == ".xlsx")
                            workbook = new XSSFWorkbook(stream);
                        else
                            workbook = new HSSFWorkbook(stream);
                    }

                    int startRow = FindStartRow(workbook);
                    var temp = ReadExcelData(workbook, startRow);

                    readedtable = new DataTable();
                    readedtable.Columns.Add("statusecode");
                    readedtable.Columns.Add("statuse");
                    readedtable.Columns.Add("Id");
                    readedtable.Columns.Add("FName");
                    readedtable.Columns.Add("LName");
                    readedtable.Columns.Add("payid");
                    readedtable.Columns.Add("PayDate");
                    readedtable.Columns.Add("TotMablagh");
                    readedtable.Columns.Add("type");
                    readedtable.Columns.Add("vam");
                    readedtable.Columns.Add("desc");

                    foreach (DataRow row in temp.Rows)
                    {
                        var returnedrow = AddPardakhtyFromExcel(
                            row[3].ToString(),   // توضیحات
                            row[7].ToString(),   // شعبه
                            row[4].ToString(),   // شناسه واریز
                            "",
                            row[2].ToString(),   // موجودی
                            row[10].ToString(),  // واریز
                            row[9].ToString(),   // برداشت
                            row[7].ToString(),   // شعبه
                            row[8].ToString() + "_" + row[2].ToString() + "_" + row[4].ToString() + "_" + row[12].ToString() + "_" + row[11].ToString(),   //شماره سند+موجودی+شناسه واریزتاریخ+زمان
                            row[11].ToString(),  // زمان
                            row[12].ToString(),  // تاریخ
                            row[13].ToString(),   // ردیف
                            "10031"
                        );

                        readedtable.Rows.Add(returnedrow.ToArray());
                    }

                    return readedtable;
                }
                catch
                {
                    return null;
                }
            }

            return null;
        }
        private ArrayList AddPardakhtyFromExcel(string description, string peygiryvariz, string shenasevariz, string name, string mande, string variz, string bardasht, string shobe, string peygiri, string zaman, string tarikh, string radif, string tafsilibank)
        {
            string type = "";
            variz = variz.Replace(",", "").Split('.')[0];
            ArrayList array = new ArrayList();
            for (int i = 0; i <= 10; i++) array.Add("0");
            array[0] = 1;//یک یعنی با موفقیت انجام شد و صفر یعنی قبلا واریز شده و -1 یعنی خطا دارد

            SandooghModel db = new SandooghModel();
            G_M_Pays mypay = new G_M_Pays();
            if (tarikh != "")
            {
                try
                {
                    tarikh = tarikh
                      .Replace("\u202A", "")
                      .Replace("\u202B", "")
                      .Replace("\u202C", "")
                      .Replace("\u202D", "")
                      .Replace("\u202E", "")
                      .Trim();

                    mypay.PayDate = PersianDateUtils.ToMilady(tarikh);
                }
                catch
                {
                    array[0] = -1;
                    array[1] = "تاریخ واریز وارد نشده است";
                    return array;

                }
            }


            long idrefvam = -1;
            int idrefnoevam = -1;
            var MablaghharGhest = 0;
            var MablaghHarMostamary = 0;
            int MostamariMablag = 0;
            int AfzayeshMablagh = 0;
            var BedehitaEmrooz = 0;
            var ozv = (from e in db.T_OzvCode where e.MelliCode == shenasevariz.Substring(0, 10) && e.Faal == true select e).FirstOrDefault();
            bool ispyayed = false;
            try
            {
                var payed = (from e in db.G_M_Pays where e.Fish_No == peygiri && e.IdRefOzv == ozv.Id select e).ToList();
                if (payed.Count > 0) ispyayed = true;
            }
            catch
            {
                ispyayed = false;
            }
            if (!ispyayed)
            {
                if (ozv == null)
                {
                    array[0] = -1;
                    array[1] = "کد ملی در ردیف " + radif + "اشتباه است";
                    return array;
                }
                long TotGestMablag = 0;
                if (shenasevariz.Substring(10, 2) == "02")
                {
                    TotGestMablag = int.Parse(variz.Replace(",", ""));
                    type = "واریز قسط";
                }

                if (shenasevariz.Substring(10, 2) == "01")
                {
                    MostamariMablag = int.Parse(variz.Replace(",", ""));
                    type = "واریز مستمری";

                }
                if (shenasevariz.Substring(10, 2) == "03")
                {
                    AfzayeshMablagh = int.Parse(variz.Replace(",", ""));
                    mypay.IsAfzayesh = true;
                    type = "افزایش سرمایه";
                }
                if (TotGestMablag != 0)
                {
                    try
                    {
                        string json = new JavaScriptSerializer().Serialize(GetVamByMemberId(ozv.Id.ToString()).Data);
                        var result = JObject.Parse(json);

                        idrefnoevam = int.Parse((string)result.SelectToken("IdRefNoeVam"));
                        mypay.IdRefNoeVam = idrefnoevam;

                        idrefvam = long.Parse((string)result.SelectToken("IdRefVam"));
                        mypay.IdRefVam = idrefvam;

                        MablaghharGhest = int.Parse((string)result.SelectToken("MablaghharGhest"));
                        mypay.MablaghharGhest = MablaghharGhest;
                        BedehitaEmrooz = int.Parse((string)result.SelectToken("BedehitaEmrooz"));

                        MablaghHarMostamary = int.Parse((string)result.SelectToken("MablaghHarMostamary"));
                        mypay.MablaghHarMostamary = MablaghHarMostamary;
                    }
                    catch
                    {
                        array[0] = -1;
                        array[1] = "وام فعال ندارید ";
                        return array;
                    }
                }


                mypay.Fish_No = peygiri;

                mypay.MostamariMablag = MostamariMablag;

                mypay.TotGestMablag = TotGestMablag;
                mypay.TotMablag = MostamariMablag + TotGestMablag;
                mypay.IdRefOzv = ozv.Id;
                string noevam = "";
                string ozvnam = "";
                try
                {
                    noevam = (from e in db.T_VamCode where e.Id == mypay.IdRefNoeVam select e.VamName).FirstOrDefault();
                }
                catch
                {

                }
                string comment = "وصول ";
                if (TotGestMablag > 0)
                    if (MostamariMablag > 0)
                        comment += " قسط و مستمری " + noevam + " ";
                    else
                        comment += " قسط  " + noevam + " ";

                else
               if (MostamariMablag > 0 || AfzayeshMablagh > 0)
                {
                    if (mypay.IsAfzayesh == true)
                        comment += "  افزایش سرمایه ";
                    else
                        comment += "  مستمری ماهانه ";
                }

                else
                    comment += " ...  ";

                ozvnam = ozv.FName + " " + ozv.LName;
                mypay.Comment = comment + ozvnam + " پیگیری " + mypay.Fish_No + " پیگیری واریز:" + peygiryvariz;
                // mypay.IsAfzayesh = false;
                mypay.Nahveh_P = 2;//طی فیش


                bool payresult = false;
                if (!ispyayed && (MostamariMablag + TotGestMablag > 0))
                {
                    string json = new JavaScriptSerializer().Serialize(((JsonResult)AddPardakhty(mypay, tafsilibank)).Data);
                    if (json == "true")
                        payresult = true;
                }

                //ثبت افزایش سرمایه
                if (AfzayeshMablagh != 0)
                {
                    var mypay1 = new G_M_Pays();
                    mypay1.IsAfzayesh = true;
                    mypay1.MostamariMablag = AfzayeshMablagh;


                    mypay1.Fish_No = mypay.Fish_No;
                    mypay1.PayDate = mypay.PayDate;


                    mypay1.TotGestMablag = 0;
                    mypay1.TotMablag = AfzayeshMablagh;
                    mypay1.IdRefOzv = ozv.Id;
                    mypay1.Comment = comment;
                    try
                    {
                        mypay1.Comment = comment + ozvnam + " پیگیری " + mypay.Fish_No + " پیگیری واریز:" + peygiryvariz;
                    }
                    catch
                    {

                    }
                    mypay1.Nahveh_P = 2;//طی فیش



                    string json = new JavaScriptSerializer().Serialize(((JsonResult)AddPardakhty(mypay1, tafsilibank)).Data);
                    mypay = mypay1;
                    if (json == "true")
                        payresult = true;


                }
                if (!payresult)
                {
                    array[0] = 0;
                    array[1] = "اشکال در اجرای عملیات";
                }
                else
                {
                    array[0] = 1;
                    array[1] = "باموفقیت واریز شد";

                    array[2] = radif;
                    array[3] = ozv.FName;
                    array[4] = ozv.LName;
                    array[5] = mypay.Id;
                    array[6] = PersianDateUtils.ToPersianDate((DateTime)mypay.PayDate);
                    array[7] = mypay.TotMablag;
                    array[8] = type;
                    try { array[9] = mypay.Vam.T_VamCode.VamName; } catch { array[9] = ""; }
                    array[10] = mypay.Comment;

                }
            }
            else
            {
                array[0] = 0;
                array[1] = "قبلا واریز شده است";
                try { array[2] = radif; } catch { }
                try { array[3] = ozv.FName; } catch { }
                try { array[4] = ozv.LName; } catch { }
                try { array[5] = mypay.Id; } catch { }
                try { array[6] = PersianDateUtils.ToPersianDate((DateTime)mypay.PayDate); } catch { }
                try { array[7] = mypay.TotMablag; } catch { }
                try { array[8] = type; } catch { }
                try { array[9] = mypay.Vam.T_VamCode.VamName; ; } catch { }
                try
                {
                    array[10] = mypay.Comment;
                }
                catch { }
            }


            return array;
        }
        private static DataTable readedtable;
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetPardakhtyexcel()
        {
            SandooghModel db = new SandooghModel();



            var pageSize = readedtable.Rows.Count;
            var totalRecords = pageSize;


            JqGridData data = new JqGridData();
            data.Rows = new List<JqGridRowData>();
            foreach (DataRow row in readedtable.Rows)
            {
                JqGridRowData rowdata = new JqGridRowData();
                rowdata.Id = long.Parse(row[2].ToString());
                rowdata.RowCells = row.ItemArray.ToList();
                data.Rows.Add(rowdata);
            }


            var productsData = new JqGridData
            {
                Total = 1,
                Page = 1,
                Records = totalRecords,
                Rows = data.Rows.ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        private int FindStartRow(IWorkbook workbook)
        {
            ISheet sheet = workbook.GetSheetAt(0);

            for (int row = 0; row <= sheet.LastRowNum; row++)
            {
                IRow currentRow = sheet.GetRow(row);
                try
                {
                    if (currentRow != null &&
                        currentRow.GetCell(13) != null &&
                        currentRow.GetCell(13).ToString() == "1")
                    {
                        return row;
                    }
                }
                catch { }
            }

            return 0;
        }
        private DataTable ReadExcelData(IWorkbook workbook, int startRow)
        {
            DataTable dataTable = new DataTable();
            ISheet sheet = workbook.GetSheetAt(0);

            int columnCount = 14;

            for (int col = 0; col < columnCount; col++)
            {
                dataTable.Columns.Add("");
            }

            for (int row = startRow; row <= sheet.LastRowNum; row++)
            {
                try
                {
                    IRow currentRow = sheet.GetRow(row);
                    if (currentRow == null) continue;

                    if (currentRow.GetCell(0) == null && currentRow.GetCell(4) == null)
                        continue;

                    DataRow dataRow = dataTable.NewRow();

                    for (int col = 0; col < columnCount; col++)
                    {
                        dataRow[col] = currentRow.GetCell(col)?.ToString() ?? "";
                    }

                    dataTable.Rows.Add(dataRow);
                }
                catch { }
            }

            return dataTable;
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult GetDaftarchePardakht(string idrefvariz)
        {
            try
            {
                SandooghModel db = new SandooghModel();

                int idd = int.Parse(idrefvariz);
                var pay = from e in db.G_M_Pays where e.Id == idd select e;

                //todo: Delete product
                var idozv = pay.FirstOrDefault().IdRefOzv;
                var ozvwithid = from o in db.T_OzvCode where o.Id == idozv select o;
                if (ozvwithid.ToList() != null && ozvwithid.ToList().Count > 0)
                {

                    var summostamarisesghabl = (from v in db.G_M_Pays where v.Id < idd && v.IdRefOzv == idozv select v.MostamariMablag).Sum();
                    if (summostamarisesghabl == null) summostamarisesghabl = 0;
                    var summostamarry = summostamarisesghabl + pay.FirstOrDefault().MostamariMablag;
                    var mostamary = pay.FirstOrDefault().MostamariMablag;


                    var pardakhtghabliVam = (double?)0;
                    var mandeghablivam = (double?)0;
                    try
                    {
                        pardakhtghabliVam = (from v in db.G_M_Pays where v.Id < idd && v.IdRefVam == pay.FirstOrDefault().IdRefVam && v.TotGestMablag != 0 select v.TotGestMablag).Sum();


                    }
                    catch
                    {

                    }
                    if (pardakhtghabliVam == null)
                        pardakhtghabliVam = (double?)0;
                    try
                    {
                        mandeghablivam = (from t in db.Vams where t.Vam_Id == pay.FirstOrDefault().IdRefVam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                        mandeghablivam = mandeghablivam - pardakhtghabliVam;
                    }
                    catch
                    {

                    }

                    var ghestvarizy = pay.FirstOrDefault().TotGestMablag;
                    var mandevam = mandeghablivam - ghestvarizy;
                    var jamvarizy = pay.FirstOrDefault().TotMablag;
                    var pardakhtVamTakonoon = pardakhtghabliVam + ghestvarizy;
                    var head = "";
                    if (pay.FirstOrDefault().IdRefVam != null)
                    {
                        var tedadghestpardakhty = (from e in db.Vams
                                                   where e.Vam_Id == pay.FirstOrDefault().IdRefVam
                                                   select
                                                   new
                                                   {
                                                       e.GestMablag,
                                                       e.TedadAgsat
                                                   }).FirstOrDefault();

                        try
                        {
                            head = "قسط " + Math.Ceiling((decimal)pardakhtVamTakonoon / (decimal)tedadghestpardakhty.GestMablag).ToString() + " از " + tedadghestpardakhty.TedadAgsat;

                        }
                        catch
                        {

                        }
                    }

                    var product =
                           new
                           {
                               mandeghablivam,
                               ghestvarizy,
                               mandevam,
                               jamvarizy,
                               summostamarisesghabl,
                               mostamary,
                               summostamarry,
                               pay.FirstOrDefault().Comment,
                               pay.FirstOrDefault().Fish_No,
                               head
                           };
                    if (product == null)
                        return Json(false);

                    return Json(product, JsonRequestBehavior.AllowGet);
                }
                return Json(false);
            }//end try

            catch
            {
                return Json(false);
            }

        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddVam(Vam postData, string BankTafsilicode, string Sanad = "", string VamMablag = "")
        {
            if (postData == null || postData.VamDate == null ||
                !postData.IdRefOzv.HasValue || !postData.IdRefNoeVam.HasValue)
                return Json(new { error = true, message = "اطلاعات وام، نوع وام یا عضو کامل نیست." });

            int UserSanad = 0;
            if (Sanad != "")
            {
                try
                {
                    UserSanad = int.Parse(Sanad);
                }
                catch
                {
                    return Json(false);
                }
            }
            SandooghModel db = new SandooghModel();

            // درصد کارمزد فقط در سمت سرور و بر اساس وضعیت خوش‌حسابی تعیین می‌شود.
            // مقدار ارسالی مرورگر برای کارمزد/خالص قابل اعتماد نیست.
            decimal grossLoanAmount;
            if (!TryParseLoanAmount(VamMablag, out grossLoanAmount) || grossLoanAmount <= 0m)
                return Json(new { error = true, message = "مبلغ ناخالص وام معتبر نیست." });

            try
            {

                var feeAssessment = VamGoodPayerCalculator.Evaluate(
                    postData.IdRefOzv.Value,
                    db,
                    DateTime.Today
                );

                decimal feeAmount = Math.Round(
                    grossLoanAmount * feeAssessment.FeePercent / 100m,
                    0,
                    MidpointRounding.AwayFromZero
                );

                decimal netAmount = grossLoanAmount - feeAmount;

                if (netAmount < 0m)
                {
                    return Json(new
                    {
                        error = true,
                        message = "درصد کارمزد از مبلغ وام بیشتر است."
                    });
                }

                // ثبت مبلغ کارمزد و مبلغ خالص
                postData.Karmozd = (double)feeAmount;
                postData.VamMablagKhales = (double)netAmount;

                // ثبت اطلاعات ارزیابی خوش‌حسابی در زمان اعطای وام
                postData.KarmozdDarsad = feeAssessment.FeePercent;

                postData.TedadGhestTakhir =
                    feeAssessment.DelayedInstallments;

                postData.TedadMostamariTakhir =
                    feeAssessment.DelayedPensionMonths;

                postData.KhoshHesab =
                    feeAssessment.IsGoodPayer;

            }
            catch (Exception feeException)
            {
                return Json(new { error = true, message = "محاسبه کارمزد انجام نشد: " + feeException.Message });
            }

            // وجود وام فعال باید در سمت سرور نیز کنترل شود.
            if (db.Vams.Any(v => v.IdRefOzv == postData.IdRefOzv && v.EtmamVam != true))
                return Json(new { error = true, message = "عضو هنوز وام تسویه‌نشده دارد." });

            if (UserSanad != 0)
            {
                var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                string startyear = yearrr.Year_Name + "/01/01";
                string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var sd = (from e in db.AccSanad_B where e.Sanad_No == UserSanad && DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).FirstOrDefault();
                if (((DateTime)(postData.VamDate)).Date != sd.Date_S.Date || sd.Lock_Sanad == true)
                {
                    return Json("SanadError1");
                }
            }
            string noevam = "";
            string ozvnam = "";
            try
            {
                noevam = (from e in db.T_VamCode where e.Id == postData.IdRefNoeVam select e.VamName).FirstOrDefault();
            }
            catch
            {

            }
            try
            {
                ozvnam = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e.FName + " " + e.LName).FirstOrDefault();
            }
            catch
            {

            }


            int moeinbank = -1;
            try
            {
                moeinbank = int.Parse(BankTafsilicode);

            }
            catch
            {

            }


            var maxValue = UserSanad;
            if (UserSanad == 0)
            {

                var now = (DateTime)postData.VamDate;//اگر تاریخ وام فرق داشته باشد آن تاریخ را در نظر میگیریم
                var sanadno = (from e in db.AccSanad_B
                               where
       e.Date_S.Year == now.Year
       && e.Date_S.Month == now.Month
       && e.Date_S.Day == now.Day
       && (e.Lock_Sanad != true) && (e.UserLock != true)
                               select e.Sanad_No).Distinct();
                var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                string startyear = yearrr.Year_Name + "/01/01";
                string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var thisyearssanads = from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e;

                var max = thisyearssanads.Max(x => x.Sanad_No);
                if (sanadno.ToList().Count == 0)
                {

                    if (DateTime.Now.Date == ((DateTime)postData.VamDate).Date)
                        maxValue = (int)max + 1;
                    else
                        return Json("SanadError1");
                }
                else
                    maxValue = maxValue = (int)sanadno.ToList().Max();
            }
            var sanads = "";

            //حساب دریافتنی - پرداخت وام بدهکار
            AccSanad_B sanad3 = new AccSanad_B();
            sanad3.Sanad_No = maxValue;
            sanad3.Group = "1";
            sanad3.Kol = "112";
            switch (postData.IdRefNoeVam)
            {
                case 1001:
                    sanad3.Moein = "001";
                    break;
                case 1002:
                    sanad3.Moein = "003";
                    break;
                case 1003:
                    sanad3.Moein = "002";
                    break;
            }
            sanad3.Tafsili = postData.IdRefOzv.ToString();
            sanad3.Date_S = (DateTime)postData.VamDate;
            sanad3.Sanad_Tafsili1 = 2;
            sanad3.Ok_NotOk = false;
            sanad3.Lock_Sanad = false;
            sanad3.Bedhkar = postData.VamMablagKhales + postData.Karmozd;
            sanad3.Bestankar = 0;
            sanad3.Articl_Comment = "ناخالص  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
            db.AccSanad_B.Add(sanad3);
            db.SaveChanges();
            postData.SanadNo = sanad3.Sanad_No;
            sanads += sanad3.ID + ",";

            //بانک بستانکار

            AccSanad_B sanad1 = new AccSanad_B();
            sanad1.Sanad_No = maxValue;
            sanad1.Group = "1";
            sanad1.Kol = "111";
            string ghdggdg = moeinbank.ToString();
            var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == ghdggdg select e;/*1212*/
            string moeincode = "";
            if (bankmoein != null)
                moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
            if (moeincode != null)
            {
                sanad1.Moein = moeincode;
                sanad1.Tafsili = BankTafsilicode;
                sanad1.Date_S = (DateTime)postData.VamDate;
                sanad1.Sanad_Tafsili1 = 1;
                sanad1.Ok_NotOk = false;
                sanad1.Lock_Sanad = false;
                sanad1.Bedhkar = 0;
                sanad1.Bestankar = postData.VamMablagKhales;
                sanad1.Articl_Comment = "خالص " + "وام  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
                db.AccSanad_B.Add(sanad1);
                db.SaveChanges();
                postData.SanadNo = sanad1.Sanad_No;
                sanads += sanad1.ID + ",";
            }


            //کارمزد بستانکار
            AccSanad_B sanad = new AccSanad_B();
            sanad.Sanad_No = maxValue;
            sanad.Group = "6";
            sanad.Kol = "611";

            sanad.Moein = "001";

            sanad.Tafsili = "14501";
            sanad.Date_S = (DateTime)postData.VamDate;
            sanad.Sanad_Tafsili1 = 8;
            sanad.Ok_NotOk = false;
            sanad.Lock_Sanad = false;
            sanad.Bedhkar = 0;
            sanad.Bestankar = postData.Karmozd;
            sanad.Articl_Comment = "کارمزد " + "وام  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
            db.AccSanad_B.Add(sanad);
            db.SaveChanges();
            postData.SanadNo = sanad3.Sanad_No;
            sanads += sanad.ID + ",";

            ////	انتقال به ذخيره بيمه از کارمزد  بدهکار
            //AccSanad_B sanad2 = new AccSanad_B();
            //sanad2.Sanad_No = maxValue;
            //sanad2.Group = "6";
            //sanad2.Kol = "611";

            //sanad2.Moein = "001";

            //sanad2.Tafsili = "14501";
            //sanad2.Date_S = (DateTime)postData.VamDate;
            //sanad2.Sanad_Tafsili1 = 8;
            //sanad2.Ok_NotOk = false;
            //sanad2.Lock_Sanad = false;
            //sanad2.Bedhkar = 5*(postData.VamMablagKhales+postData.Karmozd)/1000;
            //sanad2.Bestankar = 0;
            //sanad2.Articl_Comment = "انتقال به ذخيره بيمه از کارمزد  "+" وام  "+ noevam +" پرداختی به "+ ozvnam+" طی چک شماره  "+ postData.CheckVam;
            //db.AccSanad_B.Add(sanad2);
            //db.SaveChanges();
            //postData.SanadNo = sanad2.Sanad_No;
            //sanads += sanad2.ID + ",";

            ////	انتقال به ذخيره بيمه از کارمزد  بستانکار
            //AccSanad_B sanad4 = new AccSanad_B();
            //sanad4.Sanad_No = maxValue;
            //sanad4.Group = "5";
            //sanad4.Kol = "512";

            //sanad4.Moein = "212";

            //sanad4.Tafsili = "14506";
            //sanad4.Date_S = (DateTime)postData.VamDate;
            //sanad4.Sanad_Tafsili1 = 8;
            //sanad4.Ok_NotOk = false;
            //sanad4.Lock_Sanad = false;
            //sanad4.Bedhkar = 0;
            //sanad4.Bestankar = 5 * (postData.VamMablagKhales + postData.Karmozd) / 1000;
            //sanad4.Articl_Comment = "انتقال به ذخيره بيمه از کارمزد  " + "وام  "+ noevam +" پرداختی به "+ ozvnam+" طی چک شماره  "+ postData.CheckVam;
            //db.AccSanad_B.Add(sanad4);
            //db.SaveChanges();
            //postData.SanadNo = sanad4.Sanad_No;
            //sanads += sanad4.ID + ",";

            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            postData.Sanads = sanads;
            db.Vams.Add(postData);
            db.SaveChanges();
            var nobs = db.VamNobats.ToList();

            try
            {
                var nobat = (from e in nobs where e.IdRefNoeVam == postData.IdRefNoeVam && e.IdRefOzv == postData.IdRefOzv select e).OrderBy(k => k.NobatDate).LastOrDefault();
                nobat.IdRefVam = postData.Vam_Id;
                nobat.Mokool = false;
                db.Entry(nobat).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                //if (nobat.NobatNum != 0)
                //{

                //List<VamNobat> y = (from e in db.VamNobats where e.IdRefNoeVam == nobat.IdRefNoeVam && e.NobatNum > nobat.NobatNum select e).ToList();
                //foreach (VamNobat vn in y)
                //{
                //    vn.NobatNum--;
                //    db.Entry(vn).State = System.Data.Entity.EntityState.Modified;
                //}
                //db.SaveChanges();
                //}
                //db.VamNobats.Remove(nobat);
                //    db.SaveChanges();
            }
            catch
            {

            }



            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddVamZamen(VamZaman postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            if (postData.IdOzvRef != null)
            {
                db.VamZamen.Add(postData);
                db.SaveChanges();
                return Json(true);
            }
            else
                return Json(false);
        }
        /*  [HttpPost]
          [Authorize(Roles = "Admin")]
          public ActionResult AddMostamarry(G_M_Pays postData, string BankTafsilicode)
          {
              if (postData == null)
                  return Json(false);
              SandooghModel db = new SandooghModel();
              var lastvam= (from v in db.Vams
                                 where (v.IdRefOzv == postData.IdRefOzv )
                                 orderby v.VamDate descending
                                 select v).Take(1);

              //آخرین مستمری پرداختی قبل از ثبت این مستمری
              var lastmostamarry = (from v in db.G_M_Pays
                                   where (v.IdRefOzv == postData.IdRefOzv && v.MostamariMablag != null && v.MostamariMablag != 0) orderby v.PayDate descending select v).Take(1);
              if (lastmostamarry != null)
              {
                  //اگر قبلا مستمری پرداخت کرده است
                  var persianCalendar = new System.Globalization.PersianCalendar();
                  var lastpay = (DateTime)lastmostamarry.ToList()[0].PayDate;
                  int emtiaz = 0;
                  while (postData.PayDate >= persianCalendar.AddMonths(lastpay, 3).AddDays(1))
                  {
                      emtiaz++;
                      lastpay = persianCalendar.AddMonths(lastpay, 3).AddDays(1);
                  }
                  postData.Emtiaz = emtiaz;

              }



              int moeinbank = -1;
              try
              {
                  moeinbank = int.Parse(BankTafsilicode);

              }
              catch
              {

              }

              var now = DateTime.Now.Date;
              var sanadno = (from e in db.AccSanad_B
                             where
     e.Date_S.Year == now.Year
     && e.Date_S.Month == now.Month
     && e.Date_S.Day == now.Day
     && (e.Lock_Sanad != true) && (e.UserLock != true)
                             select e.Sanad_No);
              var maxValue = db.AccSanad_B.Max(x => x.Sanad_No);
              if (sanadno.ToList().Count == 0)
              {

                  maxValue = maxValue + 1;
              }
              else
                  maxValue = sanadno.ToList()[0].Value;
              var sanads = "";
              if (postData.MostamariMablag > 0)//اگر مستمری پرداخت میشود
              {
                  //حساب بانک بدهکار
                  AccSanad_B sanad1 = new AccSanad_B();
                  sanad1.Sanad_No = maxValue;
                  sanad1.Group = "1";
                  sanad1.Kol = "111";
                  var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == moeinbank select e;
                  string moeincode = "";
                  if (bankmoein != null)
                      moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                  if (moeincode != "")
                  {
                      sanad1.Moein = moeincode;
                      sanad1.Tafsili = BankTafsilicode;
                      sanad1.Date_S = DateTime.Now;
                      sanad1.Sanad_Tafsili1 = 1;
                      sanad1.Ok_NotOk = false;
                      sanad1.Lock_Sanad = false;
                      sanad1.Bedhkar = postData.MostamariMablag;
                      sanad1.Bestankar = 0;
                      sanad1.Articl_Comment = postData.Comment;
                      db.AccSanad_B.Add(sanad1);
                      db.SaveChanges();
                      sanads += sanad1.ID + ",";
                  }
                  else
                      return Json(false);

                  //مستمری عضو بستانکار
                  AccSanad_B sanad = new AccSanad_B();
                  sanad.Sanad_No = maxValue;
                  sanad.Group = "3";
                  sanad.Kol = "311";

                  sanad.Moein = "003";

                  sanad.Tafsili = postData.IdRefOzv.ToString();
                  sanad.Date_S = DateTime.Now;
                  sanad.Sanad_Tafsili1 = 2;
                  sanad.Ok_NotOk = false;
                  sanad.Lock_Sanad = false;
                  sanad.Bedhkar = 0;
                  sanad.Bestankar = postData.MostamariMablag;
                  sanad.Articl_Comment = postData.Comment;

                  db.AccSanad_B.Add(sanad);
                  db.SaveChanges();
                  sanads += sanad.ID + ",";


              }
              postData.Sanads = sanads;
              db.G_M_Pays.Add(postData);
              db.SaveChanges();
              return Json(true);
          }
       */
        /*        [HttpPost]
           [Authorize(Roles = "Admin")]
           public ActionResult EditMostamarry(G_M_Pays postData,string BankTafsilicode)
           {
               if (postData == null)
                   return Json(false);
               SandooghModel db = new SandooghModel();
               var now = DateTime.Now.Date;
               var sanadno = (from e in db.AccSanad_B
                              where
                          e.Date_S.Year == now.Year
                          && e.Date_S.Month == now.Month
                          && e.Date_S.Day == now.Day
                          && (e.Lock_Sanad != true) && (e.UserLock != true)
                              select e.Sanad_No);
               var maxValue = db.AccSanad_B.Max(x => x.Sanad_No);
               if (sanadno.ToList().Count == 0)
               {

                   maxValue = maxValue + 1;
               }
               else
                   maxValue = sanadno.ToList()[0].Value;

               string Sanads = postData.Sanads;
               if (Sanads != null && Sanads != "")
               {
                   string[] SanadsArray = Sanads.Split(',');
                   for (int i = SanadsArray.Count() - 1; i >= 0; i--)
                   {
                       try
                       {
                           string sanad = SanadsArray[i];
                           int id1 = int.Parse(sanad);
                           AccSanad_B san = (from e in db.AccSanad_B where e.ID == id1 select e).FirstOrDefault();
                           double bed = (double)san.Bedhkar;
                           san.Bedhkar = san.Bestankar;
                           san.Bestankar = bed;
                           san.Date_S = DateTime.Now;
                           san.Sanad_No = maxValue;
                           san.Articl_Comment = "اصلاحیه- ویرایش پرداختی -" + san.Articl_Comment;
                           db.AccSanad_B.Add(san);
                           db.SaveChanges();

                       }
                       catch
                       {

                       }

                   }
               }

               int moeinbank = -1;
               try
               {
                   moeinbank = int.Parse(BankTafsilicode);

               }
               catch
               {

               }

               var sanads = "";
               if (postData.MostamariMablag > 0)//اگر مستمری پرداخت میشود
               {
                   //حساب بانک بدهکار
                   AccSanad_B sanad1 = new AccSanad_B();
                   sanad1.Sanad_No = maxValue;
                   sanad1.Group = "1";
                   sanad1.Kol = "111";
                   var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == moeinbank select e;
                   string moeincode = "";
                   if (bankmoein != null)
                       moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                   if (moeincode != "")
                   {
                       sanad1.Moein = moeincode;
                       sanad1.Tafsili = BankTafsilicode;
                       sanad1.Date_S = DateTime.Now;
                       sanad1.Sanad_Tafsili1 = 1;
                       sanad1.Ok_NotOk = false;
                       sanad1.Lock_Sanad = false;
                       sanad1.Bedhkar = postData.MostamariMablag;
                       sanad1.Bestankar = 0;
                       sanad1.Articl_Comment = postData.Comment;
                       db.AccSanad_B.Add(sanad1);
                       db.SaveChanges();
                       sanads += sanad1.ID + ",";
                   }
                   else
                       return Json(false);

                   //مستمری عضو بستانکار
                   AccSanad_B sanad = new AccSanad_B();
                   sanad.Sanad_No = maxValue;
                   sanad.Group = "3";
                   sanad.Kol = "311";

                   sanad.Moein = "003";

                   sanad.Tafsili = postData.IdRefOzv.ToString();
                   sanad.Date_S = DateTime.Now;
                   sanad.Sanad_Tafsili1 = 2;
                   sanad.Ok_NotOk = false;
                   sanad.Lock_Sanad = false;
                   sanad.Bedhkar = 0;
                   sanad.Bestankar = postData.MostamariMablag;
                   sanad.Articl_Comment = postData.Comment;

                   db.AccSanad_B.Add(sanad);
                   db.SaveChanges();
                   sanads += sanad.ID + ",";
               }



               //todo: Add product to repository

               postData.Sanads = sanads;
               db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
               // db.T_OzvCode.Add(postData);
               db.SaveChanges();
               return Json(true);
           }
           */
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditPardakhty(G_M_Pays postData, string BankTafsilicode, string Sanad = "")
        {


            SandooghModel db = new SandooghModel();
            int UserSanad = 0;
            if (Sanad != "")
            {
                try
                {
                    UserSanad = int.Parse(Sanad);
                }
                catch
                {
                    return Json(false);
                }
            }
            if (UserSanad != 0)
            {

                var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                string startyear = yearrr.Year_Name + "/01/01";
                string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                DateTime datestart = (DateTime)startyear.ToMilady();
                DateTime dateend = (DateTime)endyear.ToMilady();
                var sd = (from e in db.AccSanad_B where e.Sanad_No == UserSanad && DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).FirstOrDefault();
                if (((DateTime)postData.PayDate).Date != sd.Date_S.Date || sd.Lock_Sanad == true)
                {
                    return Json("SanadError1");
                }
            }
            string noevam = "";
            string ozvnam = "";
            try
            {
                noevam = (from e in db.T_VamCode where e.Id == postData.IdRefNoeVam select e.VamName).FirstOrDefault();
            }
            catch
            {

            }
            try
            {
                ozvnam = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e.FName + " " + e.LName).FirstOrDefault();
            }
            catch
            {

            }
            G_M_Pays beforData = (from e in db.G_M_Pays where e.Id == postData.Id select e).FirstOrDefault();



            if (postData.MostamariMablag != null && postData.MostamariMablag > 0)
            {
                var lastvam = (from v in db.Vams
                               where (v.IdRefOzv == postData.IdRefOzv)
                               orderby v.VamDate descending
                               select v).Take(1);

                //آخرین مستمری پرداختی قبل از ثبت این مستمری
                var lastmostamarry = (from v in db.G_M_Pays
                                      where (v.IdRefOzv == postData.IdRefOzv && v.MostamariMablag != null && v.MostamariMablag != 0)
                                      orderby v.PayDate descending
                                      select v).Take(1);
                if (lastmostamarry != null && lastmostamarry.ToList().Count != 0)
                {
                    //اگر قبلا مستمری پرداخت کرده است
                    var persianCalendar = new System.Globalization.PersianCalendar();
                    var lastpay = (DateTime)lastmostamarry.ToList()[0].PayDate;
                    int emtiaz = 0;
                    while (postData.PayDate >= persianCalendar.AddMonths(lastpay, 3).AddDays(1))
                    {
                        emtiaz++;
                        lastpay = persianCalendar.AddMonths(lastpay, 3).AddDays(1);
                    }
                    postData.Emtiaz = emtiaz;

                }
            }
            string beformoein = "-1";
            string Sanads = postData.Sanads;
            if (beforData.IdRefOzv != postData.IdRefOzv ||
               beforData.TotGestMablag != postData.TotGestMablag ||
               beforData.MostamariMablag != postData.MostamariMablag ||
               beforData.MablaghHarMostamary != postData.MablaghHarMostamary ||
            beforData.PayDate != postData.PayDate ||
            beforData.TotMablag != postData.TotMablag || postData.SanadNo != beforData.SanadNo
                )
            {
                var maxValue = UserSanad;
                if (UserSanad == 0)
                {
                    var now = DateTime.Now.Date;
                    var sanadno = (from e in db.AccSanad_B
                                   where
           e.Date_S.Year == now.Year
           && e.Date_S.Month == now.Month
           && e.Date_S.Day == now.Day
           && (e.Lock_Sanad != true) && (e.UserLock != true)
                                   select e.Sanad_No).Distinct();

                    var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                    string startyear = yearrr.Year_Name + "/01/01";
                    string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                    DateTime datestart = (DateTime)startyear.ToMilady();
                    DateTime dateend = (DateTime)endyear.ToMilady();
                    var thisyearssanads = from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e;

                    var max = thisyearssanads.Max(x => x.Sanad_No);
                    if (sanadno.ToList().Count == 0)
                    {

                        if (DateTime.Now.Date == ((DateTime)postData.PayDate).Date)
                            maxValue = (int)max + 1;
                        else
                            return Json("SanadError1");
                    }
                    else
                        maxValue = (int)sanadno.ToList().Max();
                }




                var beforsannum = beforData.SanadNo;
                if (Sanads != null && Sanads != "")
                {

                    string[] SanadsArray = Sanads.Split(',');
                    for (int i = SanadsArray.Count() - 1; i >= 0; i--)
                    {
                        try
                        {

                            string sanad = SanadsArray[i];
                            int id1 = int.Parse(sanad);
                            AccSanad_B san = (from e in db.AccSanad_B where e.ID == id1 select e).FirstOrDefault();
                            try
                            {
                                if (i == 0)
                                {
                                    beformoein = san.Tafsili;
                                }
                            }
                            catch
                            {

                            }

                            double bed = (double)san.Bedhkar;
                            san.Bedhkar = san.Bestankar;
                            san.Bestankar = bed;
                            san.Date_S = (postData.SanadNo != beforData.SanadNo) ? (DateTime
                                )beforData.PayDate : (DateTime)postData.PayDate;
                            san.Sanad_No = (postData.SanadNo != beforData.SanadNo) ? beforData.SanadNo : maxValue;
                            san.Articl_Comment = "اصلاحیه- ویرایش پرداختی -" + san.Articl_Comment + "(" + beforsannum + ")";
                            db.AccSanad_B.Add(san);

                            db.SaveChanges();
                            // postData.SanadNo = san.Sanad_No;

                        }
                        catch
                        {

                        }

                    }
                }

                int moeinbank1 = -1;
                try
                {
                    moeinbank1 = int.Parse(BankTafsilicode);

                }
                catch
                {

                }

                var sanads = "";


                if (postData.TotMablag > 0)
                {

                    //حساب بانک بدهکار
                    AccSanad_B sanad1 = new AccSanad_B();
                    sanad1.Sanad_No = maxValue;
                    sanad1.Group = "1";
                    sanad1.Kol = "111";
                    string ghghgffgh = moeinbank1.ToString();
                    var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == ghghgffgh select e;/*1212*/
                    string moeincode = "";
                    if (bankmoein != null)
                        moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                    if (moeincode != null)
                    {
                        sanad1.Moein = moeincode;
                        sanad1.Tafsili = BankTafsilicode;
                        sanad1.Date_S = (DateTime)postData.PayDate;
                        sanad1.Sanad_Tafsili1 = 1;
                        sanad1.Ok_NotOk = false;
                        sanad1.Lock_Sanad = false;
                        sanad1.Bedhkar = postData.TotMablag;
                        sanad1.Bestankar = 0;
                        string comment = "وصول ";
                        if (postData.TotGestMablag > 0)
                            if (postData.MostamariMablag > 0)
                                comment += " قسط و مستمری " + noevam + " ";
                            else
                                comment += " قسط  " + noevam + " ";

                        else
                            if (postData.MostamariMablag > 0)
                            comment += "  مستمری ماهانه ";
                        else
                            comment += " ...  ";


                        sanad1.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;

                        db.AccSanad_B.Add(sanad1);
                        db.SaveChanges();
                        postData.SanadNo = sanad1.Sanad_No;
                        sanads += sanad1.ID + ",";
                    }
                    else
                        return Json(false);
                }
                if (postData.TotGestMablag > 0)//اگر قسط پرداخت میشود
                {


                    //وام عضو بستانکار
                    AccSanad_B sanad = new AccSanad_B();
                    sanad.Sanad_No = maxValue;
                    sanad.Group = "1";
                    sanad.Kol = "112";
                    switch (postData.IdRefNoeVam)
                    {
                        case 1001:
                            sanad.Moein = "001";
                            break;
                        case 1002:
                            sanad.Moein = "003";
                            break;
                        case 1003:
                            sanad.Moein = "002";
                            break;
                    }
                    sanad.Tafsili = postData.IdRefOzv.ToString();
                    sanad.Date_S = (DateTime)postData.PayDate; ;
                    sanad.Sanad_Tafsili1 = 2;
                    sanad.Ok_NotOk = false;
                    sanad.Lock_Sanad = false;
                    sanad.Bedhkar = 0;
                    sanad.Bestankar = postData.TotGestMablag;
                    string comment = "وصول ";
                    if (postData.TotGestMablag > 0)
                        if (postData.MostamariMablag > 0)
                            comment += " قسط و مستمری " + noevam + " ";
                        else
                            comment += " قسط  " + noevam + " ";

                    else
                        if (postData.MostamariMablag > 0)
                        comment += "  مستمری ماهانه ";
                    else
                        comment += " ...  ";


                    sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;

                    db.AccSanad_B.Add(sanad);
                    db.SaveChanges();
                    postData.SanadNo = sanad.Sanad_No;
                    sanads += sanad.ID + ",";


                }
                if (postData.MostamariMablag > 0)//اگر مستمری پرداخت میشود
                {


                    //مستمری عضو بستانکار
                    AccSanad_B sanad = new AccSanad_B();
                    sanad.Sanad_No = maxValue;
                    sanad.Group = "3";
                    sanad.Kol = "311";

                    sanad.Moein = "003";

                    sanad.Tafsili = postData.IdRefOzv.ToString();
                    sanad.Date_S = (DateTime)postData.PayDate; ;
                    sanad.Sanad_Tafsili1 = 2;
                    sanad.Ok_NotOk = false;
                    sanad.Lock_Sanad = false;
                    sanad.Bedhkar = 0;
                    sanad.Bestankar = postData.MostamariMablag;
                    string comment = "وصول ";
                    if (postData.TotGestMablag > 0)
                        if (postData.MostamariMablag > 0)
                            comment += " قسط و مستمری " + noevam + " ";
                        else
                            comment += " قسط  " + noevam + " ";

                    else
                        if (postData.MostamariMablag > 0)
                        comment += "  مستمری ماهانه ";
                    else
                        comment += " ...  ";


                    sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;


                    db.AccSanad_B.Add(sanad);
                    db.SaveChanges();
                    postData.SanadNo = sanad.Sanad_No;
                    sanads += sanad.ID + ",";


                }
                postData.Sanads = sanads;
            }
            else//if only change in sanad
            {
                postData.SanadNo = beforData.SanadNo;
                int moeinbank2 = -1;
                try
                {
                    moeinbank2 = int.Parse(BankTafsilicode);

                }
                catch
                {

                }
                string[] SanadsArray = Sanads.Split(',');
                if (postData.TotMablag > 0)
                {
                    try
                    {
                        int sanad11 = int.Parse(SanadsArray[0]);
                        //حساب بانک بدهکار
                        AccSanad_B sanad1 = (from e in db.AccSanad_B where e.ID == sanad11 select e).FirstOrDefault();
                        beformoein = sanad1.Tafsili;
                        sanad1.Group = "1";
                        sanad1.Kol = "111";
                        string ghghfdf = moeinbank2.ToString();
                        var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == ghghfdf select e;/*1212*/
                        string moeincode = "";
                        if (bankmoein != null)
                            moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                        if (moeincode != null)
                        {
                            sanad1.Moein = moeincode;
                            sanad1.Tafsili = BankTafsilicode;
                            sanad1.Date_S = (DateTime)postData.PayDate;
                            sanad1.Sanad_Tafsili1 = 1;
                            sanad1.Ok_NotOk = false;
                            sanad1.Lock_Sanad = false;
                            sanad1.Bedhkar = postData.TotMablag;
                            sanad1.Bestankar = 0;
                            string comment = "وصول ";
                            if (postData.TotGestMablag > 0)
                                if (postData.MostamariMablag > 0)
                                    comment += " قسط و مستمری " + noevam + " ";
                                else
                                    comment += " قسط  " + noevam + " ";

                            else
                                if (postData.MostamariMablag > 0)
                                comment += "  مستمری ماهانه ";
                            else
                                comment += " ...  ";


                            sanad1.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;

                            var entity1 = db.AccSanad_B.Where(c => c.ID == sanad1.ID).AsQueryable().FirstOrDefault();
                            if (entity1 == null)
                            {
                                db.AccSanad_B.Add(sanad1);
                            }
                            else
                            {
                                db.Entry(entity1).CurrentValues.SetValues(sanad1);
                            }


                            db.SaveChanges();

                        }
                        else
                            return Json(false);
                    }
                    catch
                    {

                    }
                }
                if (postData.TotGestMablag > 0)//اگر قسط پرداخت میشود
                {
                    try
                    {

                        //وام عضو بستانکار
                        int sanad11 = int.Parse(SanadsArray[1]);

                        AccSanad_B sanad = (from e in db.AccSanad_B where e.ID == sanad11 select e).FirstOrDefault();



                        sanad.Group = "1";
                        sanad.Kol = "112";
                        switch (postData.IdRefNoeVam)
                        {
                            case 1001:
                                sanad.Moein = "001";
                                break;
                            case 1002:
                                sanad.Moein = "003";
                                break;
                            case 1003:
                                sanad.Moein = "002";
                                break;
                        }
                        sanad.Tafsili = postData.IdRefOzv.ToString();
                        sanad.Date_S = (DateTime)postData.PayDate;
                        sanad.Sanad_Tafsili1 = 2;
                        sanad.Ok_NotOk = false;
                        sanad.Lock_Sanad = false;
                        sanad.Bedhkar = 0;
                        sanad.Bestankar = postData.TotGestMablag;
                        string comment = "وصول ";
                        if (postData.TotGestMablag > 0)
                            if (postData.MostamariMablag > 0)
                                comment += " قسط و مستمری " + noevam + " ";
                            else
                                comment += " قسط  " + noevam + " ";

                        else
                            if (postData.MostamariMablag > 0)
                            comment += "  مستمری ماهانه ";
                        else
                            comment += " ...  ";


                        sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;

                        var entity2 = db.AccSanad_B.Where(c => c.ID == sanad.ID).AsQueryable().FirstOrDefault();
                        if (entity2 == null)
                        {
                            db.AccSanad_B.Add(sanad);
                        }
                        else
                        {
                            db.Entry(entity2).CurrentValues.SetValues(sanad);
                        }


                        db.SaveChanges();
                    }
                    catch
                    {

                    }


                }
                if (postData.MostamariMablag > 0)//اگر مستمری پرداخت میشود
                {
                    try
                    {

                        //مستمری عضو بستانکار
                        int sanad11 = int.Parse(SanadsArray[2]);

                        AccSanad_B sanad = (from e in db.AccSanad_B where e.ID == sanad11 select e).FirstOrDefault();



                        sanad.Group = "3";
                        sanad.Kol = "311";

                        sanad.Moein = "003";

                        sanad.Tafsili = postData.IdRefOzv.ToString();
                        sanad.Date_S = (DateTime)postData.PayDate; ;
                        sanad.Sanad_Tafsili1 = 2;
                        sanad.Ok_NotOk = false;
                        sanad.Lock_Sanad = false;
                        sanad.Bedhkar = 0;
                        sanad.Bestankar = postData.MostamariMablag;
                        string comment = "وصول ";
                        if (postData.TotGestMablag > 0)
                            if (postData.MostamariMablag > 0)
                                comment += " قسط و مستمری " + noevam + " ";
                            else
                                comment += " قسط  " + noevam + " ";

                        else
                            if (postData.MostamariMablag > 0)
                            comment += "  مستمری ماهانه ";
                        else
                            comment += " ...  ";


                        sanad.Articl_Comment = comment + ozvnam + " طی فیش شماره " + postData.Fish_No + " " + postData.Comment;


                        var entity3 = db.AccSanad_B.Where(c => c.ID == sanad.ID).AsQueryable().FirstOrDefault();
                        if (entity3 == null)
                        {
                            db.AccSanad_B.Add(sanad);
                        }
                        else
                        {
                            db.Entry(entity3).CurrentValues.SetValues(sanad);
                        }


                        db.SaveChanges();
                    }
                    catch
                    {

                    }

                }

            }


            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            var entity = db.G_M_Pays.Where(c => c.Id == postData.Id).AsQueryable().FirstOrDefault();
            if (entity == null)
            {
                db.G_M_Pays.Add(postData);
            }
            else
            {
                db.Entry(entity).CurrentValues.SetValues(postData);
            }
            db.SaveChanges();
            //new if
            if (postData.IsAfzayesh == true)
            {
                try
                {

                    T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e).FirstOrDefault();


                    if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > postData.PayDate)
                    {
                        T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                        lastmostpaie.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == lastmostpaie.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)lastmostpaie.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
                        db.Entry(lastmostpaie).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                    }

                }
                catch
                {

                }
            }
            try
            {
                var PD = (from e in db.G_M_Pays where e.Id == postData.Id select e).FirstOrDefault();
                PD.T_OzvCode = (from e in db.T_OzvCode where e.Id == PD.IdRefOzv select e).FirstOrDefault();
                try
                {
                    PD.Vam = (from e in db.Vams where e.Vam_Id == PD.IdRefVam select e).FirstOrDefault();
                }
                catch
                {

                }
                try
                {
                    PD.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == PD.Nahveh_P select e).FirstOrDefault();
                }
                catch
                {

                }

                beforData.T_OzvCode = (from e in db.T_OzvCode where e.Id == beforData.IdRefOzv select e).FirstOrDefault();
                try
                {
                    beforData.Vam = (from e in db.Vams where e.Vam_Id == beforData.IdRefVam select e).FirstOrDefault();
                }
                catch
                {

                }
                try
                {
                    beforData.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == beforData.Nahveh_P select e).FirstOrDefault();
                }
                catch
                {

                }
                string description = "حالت فعلی:<br/>_________________<br/>" + GetPayDescriptionForLog(PD, BankTafsilicode) + "<br/>";
                description += "حالت قبلی:<br/>_________________<br/>" + GetPayDescriptionForLog(beforData, beformoein) + "<br/>";


                T_Log log = new T_Log();
                log.Log_Date = DateTime.Now;
                log.Log_Description = description;
                log.Log_Name = "ویرایش قسط/مستمری ";
                log.Log_Type = "دریافت/پرداخت";
                log.Log_User = this.User.Identity.Name;
                db.T_Log.Add(log);
                db.SaveChanges();
            }
            catch
            {

            }



            try
            {
                //حذف اتمام وام
                var activevam = (double?)0;
                try
                {
                    activevam = postData.IdRefVam;
                }
                catch
                {

                }
                var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.IdRefOzv == postData.IdRefOzv) select e;
                var pardakhtVam = (double?)0;
                var mandevam = (double?)0;
                try
                {
                    pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;
                }
                catch
                {

                }
                try
                {
                    if (pardakhtVam == null)
                        pardakhtVam = 0;
                    mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                    mandevam = mandevam - pardakhtVam;
                    if (mandevam > 0)
                    {
                        var entity2 = db.Vams.Where(c => c.Vam_Id == postData.IdRefVam).AsQueryable().FirstOrDefault();
                        entity2.EtmamVam = false;
                        db.Entry(entity2).CurrentValues.SetValues(entity2);
                        db.SaveChanges();
                    }
                    else
                    {
                        var entity2 = db.Vams.Where(c => c.Vam_Id == postData.IdRefVam).AsQueryable().FirstOrDefault();
                        entity2.EtmamVam = true;
                        db.Entry(entity2).CurrentValues.SetValues(entity2);
                        db.SaveChanges();
                    }
                }
                catch
                {

                }
            }
            catch
            {

            }

            return Json(true);
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetAvalinGhestDate(Vam postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            DateTime avvalin = (DateTime)(postData.VamDate == null ? DateTime.Now : postData.VamDate);
            var persianCalendar = new PersianCalendar();
            persianCalendar.AddMonths(avvalin, 1);
            return Json(persianCalendar.AddMonths(avvalin, 1).ToPersianDate(), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteVam(string id)
        {
            try
            {
                long idd = long.Parse(id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var product = db.Vams.FirstOrDefault(x => x.Vam_Id == idd);
                if (product == null)
                    return Json(false);

                string Sanads = product.Sanads;
                var now = DateTime.Now.Date;
                var sanadno = product.SanadNo; /* (from e in db.AccSanad_B
                               where
       e.Date_S.Year == now.Year
       && e.Date_S.Month == now.Month
       && e.Date_S.Day == now.Day
       && (e.Lock_Sanad != true) && (e.UserLock != true)
                               select e.Sanad_No).Distinct();
                var maxValue = db.AccSanad_B.Max(x => x.Sanad_No);
                if (sanadno.ToList().Count == 0)
                {

                    maxValue = maxValue + 1;
                }
                else
                    maxValue = maxValue =(int) sanadno.ToList().Max();*/
                var maxValue = sanadno;
                if (Sanads != null && Sanads != "")
                {
                    string[] SanadsArray = Sanads.Split(',');

                    for (int i = SanadsArray.Count() - 1; i >= 0; i--)
                    {
                        try
                        {
                            string sanad = SanadsArray[i];
                            int id1 = int.Parse(sanad);
                            AccSanad_B san = (from e in db.AccSanad_B where e.ID == id1 select e).FirstOrDefault();
                            double bed = (double)san.Bedhkar;
                            san.Bedhkar = san.Bestankar;
                            san.Bestankar = bed;
                            san.Date_S = (DateTime)product.VamDate;
                            san.Sanad_No = maxValue;
                            san.Articl_Comment = "اصلاحیه- حذف وام - " + san.Articl_Comment;
                            db.AccSanad_B.Add(san);
                            db.SaveChanges();

                        }
                        catch
                        {

                        }

                    }

                }
                db.Vams.Remove(product);
                db.SaveChanges();

                var nobat = (from e in db.VamNobats where e.IdRefNoeVam == product.IdRefNoeVam && e.IdRefOzv == product.IdRefOzv select e).OrderBy(k => k.NobatDate).LastOrDefault();
                nobat.IdRefVam = null;
                db.Entry(nobat).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();


                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteVamZamen(string id)
        {
            long idd = long.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.VamZamen.FirstOrDefault(x => x.Id == idd);
            if (product == null)
                return Json(false);

            db.VamZamen.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteTasvie(string id)
        {

            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.Tasviehs.FirstOrDefault(x => x.Id == idd);
            if (product == null)
                return Json(false);

            string Sanads = product.Sanads;

            var now = DateTime.Now.Date;
            var sanadno = (from e in db.AccSanad_B
                           where
   e.Date_S.Year == now.Year
   && e.Date_S.Month == now.Month
   && e.Date_S.Day == now.Day
   && (e.Lock_Sanad != true) && (e.UserLock != true)
                           select e.Sanad_No).Distinct();
            var maxValue = db.AccSanad_B.Max(x => x.Sanad_No);
            if (sanadno.ToList().Count == 0)
            {

                maxValue = maxValue + 1;
            }
            else
                maxValue = maxValue = (int)sanadno.ToList().Max();
            if (Sanads != null && Sanads != "")
            {
                string[] SanadsArray = Sanads.Split(',');
                for (int i = SanadsArray.Count() - 1; i >= 0; i--)
                {
                    try
                    {
                        string sanad = SanadsArray[i];
                        int id1 = int.Parse(sanad);
                        AccSanad_B san = (from e in db.AccSanad_B where e.ID == id1 select e).FirstOrDefault();
                        double bed = (double)san.Bedhkar;
                        san.Bedhkar = san.Bestankar;
                        san.Bestankar = bed;
                        san.Date_S = DateTime.Now;
                        san.Sanad_No = maxValue;
                        san.Articl_Comment = "اصلاحیه- حذف  تسویه-" + san.Articl_Comment;
                        db.AccSanad_B.Add(san);
                        db.SaveChanges();

                    }
                    catch
                    {

                    }

                }
            }



            db.Tasviehs.Remove(product);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult ChangePardakhty(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.G_M_Pays.FirstOrDefault(x => x.Id == idd);

            if (product == null)
                return Json(false);
            bool isafz = (product.IsAfzayesh == null || product.IsAfzayesh == false) ? true : false;
            product.IsAfzayesh = isafz;

            db.Entry(product).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == product.IdRefOzv select e).FirstOrDefault();
            try
            {
                if (isafz == true)
                {
                    ozv.SumAfzayeshMostamary -= (int)product.MostamariMablag;
                    if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > product.PayDate)
                    {
                        T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                        lastmostpaie.MostamaryMablagh_VarizyTaDateStart += (int)product.MostamariMablag;
                        db.Entry(lastmostpaie).State = System.Data.Entity.EntityState.Modified;

                    }
                }
                else
                {
                    ozv.SumAfzayeshMostamary += (int)product.MostamariMablag;
                    if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > product.PayDate)
                    {
                        T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                        lastmostpaie.MostamaryMablagh_VarizyTaDateStart -= (int)product.MostamariMablag;
                        db.Entry(lastmostpaie).State = System.Data.Entity.EntityState.Modified;

                    }
                }



                db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();



            }
            catch
            {

            }
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult ConfirmPardakhty(string id, string paydate)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.G_M_Payswait.FirstOrDefault(x => x.Id == idd);
            if (paydate != "")
            {
                try
                {
                    product.PayDate = PersianDateUtils.ToMilady(paydate);
                }
                catch
                {
                    return Json(-1);

                }
            }
            if (product == null)
                return Json(false);
            G_M_Pays mypay = new G_M_Pays();
            long idrefvam = -1;
            int idrefnoevam = -1;
            var MablaghharGhest = 0;
            var MablaghHarMostamary = 0;
            var BedehitaEmrooz = 0;
            if (product.TotGestMablag != 0)
            {
                string json = new JavaScriptSerializer().Serialize(GetVamByMemberId(product.IdRefOzv.ToString()).Data);
                var result = JObject.Parse(json);
                try
                {
                    idrefnoevam = int.Parse((string)result.SelectToken("IdRefNoeVam"));
                    mypay.IdRefNoeVam = idrefnoevam;

                    idrefvam = long.Parse((string)result.SelectToken("IdRefVam"));
                    mypay.IdRefVam = idrefvam;

                    MablaghharGhest = int.Parse((string)result.SelectToken("MablaghharGhest"));
                    mypay.MablaghharGhest = MablaghharGhest;
                    BedehitaEmrooz = int.Parse((string)result.SelectToken("BedehitaEmrooz"));

                    MablaghHarMostamary = int.Parse((string)result.SelectToken("MablaghHarMostamary"));
                    mypay.MablaghHarMostamary = MablaghHarMostamary;
                }
                catch
                {
                    return Json(-2);
                }
            }



            mypay.Fish_No = product.Fish_No;
            mypay.PayDate = product.PayDate;

            mypay.MostamariMablag = product.MostamariMablag;
            mypay.TotGestMablag = product.TotGestMablag;
            mypay.TotMablag = product.MostamariMablag + product.TotGestMablag;
            mypay.IdRefOzv = product.IdRefOzv;
            mypay.Comment = product.Comment + " تاریخ تایید" + PersianDateUtils.ToPersianDate(DateTime.Now);
            mypay.IsAfzayesh = false;
            mypay.Nahveh_P = 2;//طی فیش
            string tafsilibank = "10020";
            AddPardakhty(mypay, tafsilibank);

            //ثبت افزایش سرمایه
            if (product.AfzayeshMablagh != null && product.AfzayeshMablagh != 0)
            {
                mypay = new G_M_Pays();
                mypay.IsAfzayesh = true;
                mypay.MostamariMablag = product.AfzayeshMablagh;


                mypay.Fish_No = product.Fish_No;
                mypay.PayDate = product.PayDate;


                mypay.TotGestMablag = 0;
                mypay.TotMablag = product.AfzayeshMablagh;
                mypay.IdRefOzv = product.IdRefOzv;
                mypay.Comment = product.Comment + " تاریخ تایید" + PersianDateUtils.ToPersianDate(DateTime.Now);

                mypay.Nahveh_P = 2;//طی فیش
                tafsilibank = "10020";
                AddPardakhty(mypay, tafsilibank);

            }
            product.IsTaeid = true;
            product.TaeidDate = DateTime.Now.Date;
            product.TaeidKonandehUser = User.Identity.Name;
            db.Entry(product).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();

            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult NotApprovePardakhtywait(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.G_M_Payswait.FirstOrDefault(x => x.Id == idd);

            if (product == null)
                return Json(false);


            product.statuse = 1;//عدم تایید
            product.IsTaeid = false;
            product.TaeidDate = DateTime.Now;
            product.TaeidKonandehUser = User.Identity.Name;
            db.Entry(product).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();




            return Json(true);
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeletePardakhty(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.G_M_Pays.FirstOrDefault(x => x.Id == idd);

            if (product == null)
                return Json(false);
            string Sanads = product.Sanads;
            var now = DateTime.Now.Date;
            var sanadno = product.SanadNo; /*(from e in db.AccSanad_B
                           where
   e.Date_S.Year == now.Year
   && e.Date_S.Month == now.Month
   && e.Date_S.Day == now.Day
   && (e.Lock_Sanad != true) && (e.UserLock != true)
                           select e.Sanad_No).Distinct();*/
            var maxValue = sanadno;
            string codebank = "";
            if (Sanads != null && Sanads != "")
            {
                string[] SanadsArray = Sanads.Split(',');

                for (int i = SanadsArray.Count() - 1; i >= 0; i--)
                {
                    try
                    {
                        string sanad = SanadsArray[i];
                        int id1 = int.Parse(sanad);
                        AccSanad_B san = (from e in db.AccSanad_B where e.ID == id1 select e).FirstOrDefault();
                        if (i == 0)
                        {
                            codebank = san.Tafsili;
                        }
                        double bed = (double)san.Bedhkar;
                        san.Bedhkar = san.Bestankar;
                        san.Bestankar = bed;
                        san.Date_S = (DateTime)product.PayDate;
                        san.Sanad_No = maxValue;
                        san.Articl_Comment = "اصلاحیه- حذف پرداختی-" + san.Articl_Comment;
                        db.AccSanad_B.Add(san);
                        db.SaveChanges();

                    }
                    catch
                    {

                    }

                }

            }
            try
            {
                int id1d = int.Parse(id);
                var PD = (from e in db.G_M_Pays where e.Id == id1d select e).FirstOrDefault();

                string description = "مورد حذف شده:<br/>_________________<br/>" + GetPayDescriptionForLog(PD, codebank) + "<br/>";


                T_Log log = new T_Log();
                log.Log_Date = DateTime.Now;
                log.Log_Description = description;
                log.Log_Name = "حذف قسط/مستمری ";
                log.Log_Type = "دریافت/پرداخت";
                log.Log_User = this.User.Identity.Name;
                db.T_Log.Add(log);
                db.SaveChanges();
            }
            catch
            {

            }

            long? vam = product.IdRefVam;
            long? ozv = product.IdRefOzv;
            db.G_M_Pays.Remove(product);
            db.SaveChanges();
            try
            {
                //حذف اتمام وام
                var activevam = (double?)0;
                try
                {
                    activevam = vam;
                }
                catch
                {

                }
                var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.IdRefOzv == ozv) select e;
                var pardakhtVam = (double?)0;
                var mandevam = (double?)0;
                try
                {
                    pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;


                }
                catch
                {

                }
                try
                {
                    if (pardakhtVam == null)
                        pardakhtVam = 0;
                    mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                    mandevam = mandevam - pardakhtVam;
                    if (mandevam > 0)
                    {
                        var entity2 = db.Vams.Where(c => c.Vam_Id == product.IdRefVam).AsQueryable().FirstOrDefault();
                        entity2.EtmamVam = false;
                        db.Entry(entity2).CurrentValues.SetValues(entity2);
                        db.SaveChanges();
                    }
                    else
                    {

                        var entity2 = db.Vams.Where(c => c.Vam_Id == product.IdRefVam).AsQueryable().FirstOrDefault();
                        entity2.EtmamVam = true;
                        db.Entry(entity2).CurrentValues.SetValues(entity2);
                        db.SaveChanges();

                    }
                }
                catch
                {

                }

            }
            catch
            {

            }



            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteNobat(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.VamNobats.FirstOrDefault(x => x.Id == idd);
            if (product.NobatNum != 0)
            {
                List<VamNobat> y = (from e in db.VamNobats where e.IdRefNoeVam == product.IdRefNoeVam && e.NobatNum > product.NobatNum select e).ToList();
                foreach (VamNobat vn in y)
                {
                    vn.NobatNum--;
                    db.Entry(vn).State = System.Data.Entity.EntityState.Modified;
                }
                db.SaveChanges();
            }
            if (product == null)
                return Json(false);

            db.VamNobats.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult Mokool(string id)
        {
            long idd = 0;
            try
            {
                idd = long.Parse(id);
            }
            catch
            {

            }
            SandooghModel db = new SandooghModel();
            var product = db.VamNobats.FirstOrDefault(x => x.Id == idd);
            product.Mokool = true;
            db.Entry(product).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddNobat(string ozvid, string noevamid)
        {
            int memberId;
            int loanTypeId;
            if (!int.TryParse(ozvid, out memberId) || !int.TryParse(noevamid, out loanTypeId))
                return Json(new { success = false, message = "شناسه عضو یا نوع وام معتبر نیست." });

            using (SandooghModel db = new SandooghModel())
            {
                var member = db.T_OzvCode.FirstOrDefault(o => o.Id == memberId && o.Faal == true);
                if (member == null)
                    return Json(new { success = false, message = "عضو فعال یافت نشد." });

                if (!db.T_VamCode.Any(t => t.Id == loanTypeId))
                    return Json(new { success = false, message = "نوع وام انتخاب‌شده معتبر نیست." });

                if (db.VamNobats.Any(n => n.IdRefOzv == memberId && n.IdRefVam == null))
                    return Json(new { success = false, message = "این عضو قبلاً در نوبت وام ثبت شده است." });

                if (db.Vams.Any(v => v.IdRefOzv == memberId && v.EtmamVam == false))
                    return Json(new { success = false, message = "برای این عضو وام تسویه‌نشده ثبت شده است." });

                var eligibilityCalculator = new MVCSmartLibrary.Controllers.OzviatController();
                var eligibility = eligibilityCalculator.CalculateQueueEligibilityInfo(member, db);
                // کنترل قطعی تسویه تمام معوقات مستمری
                if (eligibility.RequiresPensionArrearsSettlement)
                {
                    return Json(new
                    {
                        success = false,

                        message =
                            "به دلیل معوقات مستمری بیش از چهار ماه، ابتدا باید تمام معوقات پرداخت شود. " +
                            "ماه‌های معوق باقی‌مانده: " +
                            eligibility.PensionArrearsOutstandingMonths +
                            " | مبلغ مانده: " +
                            eligibility.OutstandingPensionArrearsAmount.ToString("N0") +
                            " ریال."
                    });
                }
                if (eligibility.QueueEligibleDate.Date > DateTime.Today)
                {
                    var pc = new PersianCalendar();
                    string eligibleDate = string.Format("{0:0000}/{1:00}/{2:00}",
                        pc.GetYear(eligibility.QueueEligibleDate),
                        pc.GetMonth(eligibility.QueueEligibleDate),
                        pc.GetDayOfMonth(eligibility.QueueEligibleDate));
                    return Json(new
                    {
                        success = false,
                        message = "این عضو هنوز مجاز به ورود به نوبت نیست. تاریخ مجاز: " + eligibleDate
                    });
                }

                long lastNumber = db.VamNobats
                    .Where(n => n.IdRefNoeVam == loanTypeId)
                    .Select(n => n.NobatNum)
                    .ToList()
                    .Where(n => n.HasValue)
                    .Select(n => n.Value)
                    .DefaultIfEmpty(0L)
                    .Max();

                long lastDocNo = 0;
                try
                {
                    lastDocNo = db.VamNobats
                        .Where(n => n.DocNo != null)
                        .ToList()
                        .Select(n => long.Parse(n.DocNo))
                        .DefaultIfEmpty(0L)
                        .Max();
                }
                catch
                {
                    lastDocNo = 0;
                }

                var postData = new VamNobat
                {
                    DocNo = (lastDocNo + 1).ToString(),
                    NobatNum = lastNumber + 1,
                    IdRefNoeVam = loanTypeId,
                    IdRefOzv = memberId,
                    NobatDate = DateTime.Now
                };

                db.VamNobats.Add(postData);
                db.SaveChanges();
                return Json(new { success = true, message = "عضو با موفقیت به نوبت وام اضافه شد." });
            }
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteVamCode(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_VamCode.FirstOrDefault(x => x.Id == idd);
            if (product == null)
                return Json(false);

            db.T_VamCode.Remove(product);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddVamCode(T_VamCode postData)
        {
            SandooghModel db = new SandooghModel();
            postData.GUID = Guid.NewGuid();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);


            db.T_VamCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditVamCode(T_VamCode postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditVamZamen(VamZaman postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);

            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditVam(Vam postData, string BankTafsilicode, string Sanad = "")
        {
            int moeinbank = -1;
            try
            {
                moeinbank = int.Parse(BankTafsilicode);

            }
            catch
            {
                return Json(false);
            }
            int UserSanad = 0;
            if (Sanad != "")
            {
                try
                {
                    UserSanad = int.Parse(Sanad);
                }
                catch
                {
                    return Json(false);
                }
            }
            SandooghModel db = new SandooghModel();

            Vam beforData = (from e in db.Vams where e.Vam_Id == postData.Vam_Id select e).FirstOrDefault();
            if (beforData.IdRefOzv != postData.IdRefOzv ||
            beforData.IdRefNoeVam != postData.IdRefNoeVam ||
            beforData.VamDate != postData.VamDate ||
            beforData.VamMablagKhales != postData.VamMablagKhales ||
            beforData.Karmozd != postData.Karmozd ||
            beforData.GestMablag != postData.GestMablag || postData.SanadNo != beforData.SanadNo ||
            beforData.TedadAgsat != postData.TedadAgsat
             )
            {
                if (UserSanad != 0)
                {
                    var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                    string startyear = yearrr.Year_Name + "/01/01";
                    string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                    DateTime datestart = (DateTime)startyear.ToMilady();
                    DateTime dateend = (DateTime)endyear.ToMilady();
                    var sd = (from e in db.AccSanad_B where e.Sanad_No == UserSanad && DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e).FirstOrDefault();
                    if (((DateTime)postData.VamDate).Date != sd.Date_S.Date || sd.Lock_Sanad == true)
                    {
                        return Json("SanadError1");
                    }
                }
                var maxValue = UserSanad;
                if (UserSanad == 0)
                {
                    var now = DateTime.Now.Date;
                    var sanadno = (from e in db.AccSanad_B
                                   where
           e.Date_S.Year == now.Year
           && e.Date_S.Month == now.Month
           && e.Date_S.Day == now.Day
           && (e.Lock_Sanad != true) && (e.UserLock != true)
                                   select e.Sanad_No).Distinct();
                    var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                    string startyear = yearrr.Year_Name + "/01/01";
                    string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                    DateTime datestart = (DateTime)startyear.ToMilady();
                    DateTime dateend = (DateTime)endyear.ToMilady();
                    var thisyearssanads = from e in db.AccSanad_B where DbFunctions.TruncateTime(e.Date_S) >= DbFunctions.TruncateTime(datestart) && DbFunctions.TruncateTime(e.Date_S) < DbFunctions.TruncateTime(dateend) select e;

                    var max = thisyearssanads.Max(x => x.Sanad_No);
                    if (sanadno.ToList().Count == 0)
                    {

                        if (DateTime.Now.Date == ((DateTime)postData.VamDate).Date)
                            maxValue = (int)max + 1;
                        else
                            return Json("SanadError1");
                    }
                    else
                        maxValue = maxValue = (int)sanadno.ToList().Max();
                }
                string Sanads = postData.Sanads;
                if (Sanads != null && Sanads != "")
                {
                    string[] SanadsArray = Sanads.Split(',');
                    for (int i = SanadsArray.Count() - 1; i >= 0; i--)
                    {
                        try
                        {
                            string sanade = SanadsArray[i];
                            int id1 = int.Parse(sanade);
                            AccSanad_B san = (from e in db.AccSanad_B where e.ID == id1 select e).FirstOrDefault();
                            double bed = (double)san.Bedhkar;
                            san.Bedhkar = san.Bestankar;
                            san.Bestankar = bed;
                            san.Date_S = (postData.SanadNo != beforData.SanadNo) ? (DateTime
                                   )beforData.VamDate : (DateTime)postData.VamDate;
                            san.Sanad_No = (postData.SanadNo != beforData.SanadNo) ? beforData.SanadNo : maxValue;
                            san.Articl_Comment = "اصلاحیه- ویرایش وام-" + san.Articl_Comment;
                            db.AccSanad_B.Add(san);
                            db.SaveChanges();

                        }
                        catch
                        {

                        }

                    }
                }
                string noevam = "";
                string ozvnam = "";
                try
                {
                    noevam = (from e in db.T_VamCode where e.Id == postData.IdRefNoeVam select e.VamName).FirstOrDefault();
                }
                catch
                {

                }
                try
                {
                    ozvnam = (from e in db.T_OzvCode where e.Id == postData.IdRefOzv select e.FName + " " + e.LName).FirstOrDefault();
                }
                catch
                {

                }



                var sanads = "";
                //حساب دریافتنی - پرداخت وام بدهکار
                AccSanad_B sanad3 = new AccSanad_B();
                sanad3.Sanad_No = maxValue;
                sanad3.Group = "1";
                sanad3.Kol = "112";
                switch (postData.IdRefNoeVam)
                {
                    case 1001:
                        sanad3.Moein = "001";
                        break;
                    case 1002:
                        sanad3.Moein = "003";
                        break;
                    case 1003:
                        sanad3.Moein = "002";
                        break;
                }
                sanad3.Tafsili = postData.IdRefOzv.ToString();
                sanad3.Date_S = (DateTime)postData.VamDate;
                sanad3.Sanad_Tafsili1 = 2;
                sanad3.Ok_NotOk = false;
                sanad3.Lock_Sanad = false;
                sanad3.Bedhkar = postData.VamMablagKhales + postData.Karmozd;
                sanad3.Bestankar = 0;
                sanad3.Articl_Comment = "ناخالص  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
                db.AccSanad_B.Add(sanad3);
                db.SaveChanges();
                postData.SanadNo = sanad3.Sanad_No;
                sanads += sanad3.ID + ",";

                //بانک بستانکار

                AccSanad_B sanad1 = new AccSanad_B();
                sanad1.Sanad_No = maxValue;
                sanad1.Group = "1";
                sanad1.Kol = "111";
                string ghfrdf = moeinbank.ToString();
                var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == ghfrdf select e;/*1212*/
                string moeincode = "";
                if (bankmoein != null)
                    moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                if (moeincode != null)
                {
                    sanad1.Moein = moeincode;
                    sanad1.Tafsili = BankTafsilicode;
                    sanad1.Date_S = (DateTime)postData.VamDate;
                    sanad1.Sanad_Tafsili1 = 1;
                    sanad1.Ok_NotOk = false;
                    sanad1.Lock_Sanad = false;
                    sanad1.Bedhkar = 0;
                    sanad1.Bestankar = postData.VamMablagKhales;
                    sanad1.Articl_Comment = "خالص " + "وام  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
                    db.AccSanad_B.Add(sanad1);
                    db.SaveChanges();
                    postData.SanadNo = sanad1.Sanad_No;
                    sanads += sanad1.ID + ",";
                }


                //کارمزد بستانکار
                AccSanad_B sanad = new AccSanad_B();
                sanad.Sanad_No = maxValue;
                sanad.Group = "6";
                sanad.Kol = "611";

                sanad.Moein = "001";

                sanad.Tafsili = "14501";
                sanad.Date_S = (DateTime)postData.VamDate;
                sanad.Sanad_Tafsili1 = 8;
                sanad.Ok_NotOk = false;
                sanad.Lock_Sanad = false;
                sanad.Bedhkar = 0;
                sanad.Bestankar = postData.Karmozd;
                sanad.Articl_Comment = "کارمزد " + "وام  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
                db.AccSanad_B.Add(sanad);
                db.SaveChanges();
                postData.SanadNo = sanad.Sanad_No;
                sanads += sanad.ID + ",";

                //	انتقال به ذخيره بيمه از کارمزد  بدهکار
                AccSanad_B sanad2 = new AccSanad_B();
                sanad2.Sanad_No = maxValue;
                sanad2.Group = "6";
                sanad2.Kol = "611";

                sanad2.Moein = "001";

                sanad2.Tafsili = "14501";
                sanad2.Date_S = (DateTime)postData.VamDate;
                sanad2.Sanad_Tafsili1 = 8;
                sanad2.Ok_NotOk = false;
                sanad2.Lock_Sanad = false;
                sanad2.Bedhkar = 5 * (postData.VamMablagKhales + postData.Karmozd) / 1000;
                sanad2.Bestankar = 0;
                sanad2.Articl_Comment = "انتقال به ذخيره بيمه از کارمزد  " + " وام  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
                db.AccSanad_B.Add(sanad2);
                db.SaveChanges();
                postData.SanadNo = sanad2.Sanad_No;
                sanads += sanad2.ID + ",";

                //	انتقال به ذخيره بيمه از کارمزد  بستانکار
                AccSanad_B sanad4 = new AccSanad_B();
                sanad4.Sanad_No = maxValue;
                sanad4.Group = "5";
                sanad4.Kol = "512";

                sanad4.Moein = "212";

                sanad4.Tafsili = "14506";
                sanad4.Date_S = (DateTime)postData.VamDate;
                sanad4.Sanad_Tafsili1 = 8;
                sanad4.Ok_NotOk = false;
                sanad4.Lock_Sanad = false;
                sanad4.Bedhkar = 0;
                sanad4.Bestankar = 5 * (postData.VamMablagKhales + postData.Karmozd) / 1000;
                sanad4.Articl_Comment = "انتقال به ذخيره بيمه از کارمزد  " + "وام  " + noevam + " پرداختی به " + ozvnam + " طی چک شماره  " + postData.CheckVam;
                db.AccSanad_B.Add(sanad4);
                db.SaveChanges();
                postData.SanadNo = sanad4.Sanad_No;
                sanads += sanad4.ID + ",";
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                postData.Sanads = sanads;
            }

            var entity2 = db.Vams.Where(c => c.Vam_Id == postData.Vam_Id).AsQueryable().FirstOrDefault();
            if (entity2 == null)
            {
                db.Vams.Add(postData);
            }
            else
            {
                db.Entry(entity2).CurrentValues.SetValues(postData);
            }


            db.SaveChanges();
            return Json(true);
        }



        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult KhoshHesabiSetting()
        {
            using (SandooghModel db = new SandooghModel())
            {
                var setting = db.VamPolicySettings
                    .FirstOrDefault(x => x.Id == 1);

                if (setting == null)
                {
                    setting = new VamPolicySetting
                    {
                        Id = 1,
                        N_DelayedInstallments = 3,
                        M_DelayedPensions = 3,
                        K_GoodPayerFeePercent = 3m,
                        J_OtherPayerFeePercent = 5m
                    };
                }

                return View(setting);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult KhoshHesabiSetting(
            VamPolicySetting model)
        {
            if (!ModelState.IsValid)
                return View(model);

            using (SandooghModel db = new SandooghModel())
            {
                var setting = db.VamPolicySettings
                    .FirstOrDefault(x => x.Id == 1);

                if (setting == null)
                {
                    setting = new VamPolicySetting
                    {
                        Id = 1
                    };

                    db.VamPolicySettings.Add(setting);
                }

                // ذخیره آستانه اقساط
                setting.N_DelayedInstallments =
                    model.N_DelayedInstallments;

                // ذخیره آستانه مستمری
                setting.M_DelayedPensions =
                    model.M_DelayedPensions;

                // ذخیره کارمزد خوش‌حساب
                setting.K_GoodPayerFeePercent =
                    model.K_GoodPayerFeePercent;

                // ذخیره کارمزد غیرخوش‌حساب
                setting.J_OtherPayerFeePercent =
                    model.J_OtherPayerFeePercent;

                db.SaveChanges();
            }

            TempData["PolicySaved"] =
                "تنظیمات خوش‌حسابی و کارمزد با موفقیت ذخیره شد.";

            return RedirectToAction("KhoshHesabiSetting");
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult QueuePolicySetting()
        {
            using (SandooghModel db = new SandooghModel())
            {
                var setting = db.VamQueueSettings
                    .FirstOrDefault(x => x.Id == 1);

                if (setting == null)
                {
                    setting = new T_VamQueueSetting
                    {
                        Id = 1,
                        MembershipMonthsBeforeDey1402 = 6,
                        MembershipMonthsFromDey1402 = 4,

                        PensionDelayUnitMonths = 4,
                        PensionQueueIncreaseMonths = 1,

                        InstallmentDelayUnitMonths = 3,
                        InstallmentQueueIncreaseMonths = 1
                    };
                }

                return View(setting);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult QueuePolicySetting(T_VamQueueSetting model)
        {
            if (!ModelState.IsValid)
                return View(model);

            using (SandooghModel db = new SandooghModel())
            {
                var setting = db.VamQueueSettings
                    .FirstOrDefault(x => x.Id == 1);

                if (setting == null)
                {
                    setting = new T_VamQueueSetting
                    {
                        Id = 1
                    };

                    db.VamQueueSettings.Add(setting);
                }

                setting.MembershipMonthsBeforeDey1402 =
                    model.MembershipMonthsBeforeDey1402;

                setting.MembershipMonthsFromDey1402 =
                    model.MembershipMonthsFromDey1402;

                setting.PensionDelayUnitMonths =
                    model.PensionDelayUnitMonths;

                setting.PensionQueueIncreaseMonths =
                    model.PensionQueueIncreaseMonths;

                setting.InstallmentDelayUnitMonths =
                    model.InstallmentDelayUnitMonths;

                setting.InstallmentQueueIncreaseMonths =
                    model.InstallmentQueueIncreaseMonths;

                setting.IsConfigured = true;
                setting.ModifiedDate = DateTime.Now;

                db.SaveChanges();
            }

            TempData["QueueSettingSaved"] =
                "تنظیمات نوبت وام با موفقیت ذخیره شد.";

            return RedirectToAction("QueuePolicySetting");
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult MinimumPensionSetting()
        {
            using (SandooghModel db = new SandooghModel())
            {
                ViewBag.Items = db.MinimumPensionSettings
                    .OrderByDescending(x => x.EffectiveFrom)
                    .ToList();

                return View(new MinimumPensionSetting
                {
                    EffectiveFrom = DateTime.Today,
                    MinimumAmount = 1000000m
                });
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult MinimumPensionSetting(MinimumPensionSetting model)
        {
            if (model.EffectiveTo.HasValue &&
                model.EffectiveTo.Value.Date < model.EffectiveFrom.Date)
            {
                ModelState.AddModelError(
                    "EffectiveTo",
                    "تاریخ پایان نمی‌تواند قبل از تاریخ شروع باشد."
                );
            }

            using (SandooghModel db = new SandooghModel())
            {
                if (!ModelState.IsValid)
                {
                    ViewBag.Items = db.MinimumPensionSettings
                        .OrderByDescending(x => x.EffectiveFrom)
                        .ToList();

                    return View(model);
                }

                model.EffectiveFrom = model.EffectiveFrom.Date;

                if (model.EffectiveTo.HasValue)
                    model.EffectiveTo = model.EffectiveTo.Value.Date;

                // رکورد قبلیِ بدون تاریخ پایان را تا روز قبل از شروع
                // تنظیم جدید معتبر نگه می‌داریم.
                var previousOpen = db.MinimumPensionSettings
                    .Where(x =>
                        x.EffectiveFrom < model.EffectiveFrom &&
                        !x.EffectiveTo.HasValue)
                    .OrderByDescending(x => x.EffectiveFrom)
                    .FirstOrDefault();

                if (previousOpen != null)
                {
                    previousOpen.EffectiveTo =
                        model.EffectiveFrom.AddDays(-1);
                }

                DateTime proposedEnd =
                    model.EffectiveTo ?? DateTime.MaxValue;

                bool overlaps = db.MinimumPensionSettings.Any(x =>
                    x.EffectiveFrom <= proposedEnd &&
                    (!x.EffectiveTo.HasValue ||
                     x.EffectiveTo.Value >= model.EffectiveFrom));

                if (overlaps)
                {
                    ModelState.AddModelError(
                        "",
                        "بازه تاریخ انتخاب‌شده با یک تنظیم موجود تداخل دارد."
                    );

                    ViewBag.Items = db.MinimumPensionSettings
                        .OrderByDescending(x => x.EffectiveFrom)
                        .ToList();

                    return View(model);
                }

                db.MinimumPensionSettings.Add(model);
                db.SaveChanges();
            }

            TempData["MinimumPensionSaved"] =
                "حداقل مستمری با موفقیت ثبت شد.";

            return RedirectToAction("MinimumPensionSetting");
        }

    }

}

﻿using MVCSandoogh.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MVCSandoogh.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        {
            objIAccountData = new AccountData();
        }

        IAccountData objIAccountData;
        //    [Authorize(Roles = "User,Admin")]
        public ViewResult Index(string returnUrl="")
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }
        public ViewResult Members()
        {
            return View();
        }
        public ViewResult PaymentHelp()
        {
            return View();
        }

        public PartialViewResult Finde()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return PartialView(new Login());
            }
            return PartialView("Company/index");
        }

        public ActionResult ContactUs()
        {
            return View();
        }
        [NonAction]
        public string GetUserID_By_UserName(string UserName)
        {
            return objIAccountData.GetUserID_By_UserName(UserName);
        }
        [HttpPost]
        [AllowAnonymous]
      //  [ValidateAntiForgeryToken]
        public ActionResult Index(Login login, string returnUrl="")
        {
            SandooghModel db = new SandooghModel();
            if (ModelState.IsValid)
            {
                bool success = Membership.ValidateUser(login.username, login.password);
                string name = this.User.Identity.Name;
                var UserID = GetUserID_By_UserName(login.username);


                //  var LoginType = GetRoleBy_UserID(Convert.ToString(UserID));

                if (success == true)
                {
                    FormsAuthentication.SetAuthCookie(login.username, false);
                    Session["Name"] = login.username;

                    Session["UserID"] = UserID;
                    int u = -1;
                    try
                    {
                        u = int.Parse(UserID);
                        var user = (from e in db.T_User where e.User_ID == u select e);
                        Session["LogesuserName"] = user.FirstOrDefault().User_Firstname + " " + user.FirstOrDefault().User_lastname;
                    }
                    catch
                    {

                    }

                    //     Session["LoginType"] = LoginType;

                    if (returnUrl != null && returnUrl.Length != 0)
                        return Redirect(returnUrl);
                    else
                    if (Roles.IsUserInRole(login.username, "Admin"))
                    {
                        return RedirectToAction("AdminDashBoard", "Dashbord");
                    }
                    else
                    {

                        return RedirectToAction("UserDashboard", "Dashbord");
                    }
                    // }
                }
                else
                {
                    ModelState.AddModelError("Error", "لطفا با نام کاربری و پسورد معتبر وارد شوید ");
                    return View(login);
                }
            }
            else
            {
                ModelState.AddModelError("Error", "Please enter Username and Password And Fill The Captcha");
            }
            return View(login);

        }
        
        [HttpPost]
        public ActionResult DeleteContact(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                DataGatheration gath = new DataGatheration();
                gath.GetTableStoredProcedure("newDeleteContactus", new List<string> { "Contactus_ID" }, new List<object> { id });

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        [Authorize(Roles = "Admin")]
        public ActionResult ContactUsList()
        {
            SandooghModel db = new SandooghModel();
            var Temp = from e in db.T_Contactus orderby e.Contactus_ID select e;
            return View(Temp);

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ContactUs(FormCollection collection)
        {
            if (ModelState.IsValid)
            {
                List<string> parameters = new List<string>(new string[] {

            "Contactus_Text","Contactus_FName","Contactus_LName",
            "Contactus_Mobile","Contactus_Email","Contactus_Date"});
                List<object> values = new List<object>(new object[] {


            collection["Contactus_Text"],collection["Contactus_FName"],collection["Contactus_LName"],
            collection["Contactus_Mobile"],collection["Contactus_Email"],DateTime.Now});
                DataGatheration gath = new DataGatheration();
              DataTable table=  gath.GetTableStoredProcedure("NewInsertContactus", parameters, values);
                try
                {
                    ViewBag.ResultMessage = "کد پیگیری شما " + table.Rows[0][0].ToString() + " می باشد.";
                }
                catch
                {

                }
                return View();

            }
            else
            {
                return View();
            }

        }

        public ActionResult RetrivePass()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RetrivePass(FormCollection collection)
        {
            if (ModelState.IsValid)
            {
             
                try
                {
                string username = collection["User_UserName"].ToString();
               string password=   Membership.GetUser(username).GetPassword();
                    SmtpClient client = new SmtpClient();
                    MailMessage mailMessage = new MailMessage();
                    mailMessage.From = new MailAddress("Companyseller01@gmail.com");
                    mailMessage.To.Add(username);
                    mailMessage.Subject = "اطلاعات کاربری سامانه خرید و فروش شرکتها";
                    mailMessage.Body = "با سلام.\n نام کاربری شما در سامانه خرید و فروش شرکتها: " + username + "\n و رمز عبور شما :" + password + "می باشد\nبا تشکر."; ;

                    client.Send(mailMessage);
                    ViewBag.ResultMessage = "کاربر محترم اطلاعات شما با موفقیت به ایمیل مورد نظر ارسال شد";
                }
                catch
                {
                    ViewBag.ResultMessage = "چنین کاربری در سیستم موجود نیست";
                }
                return View();

            }
            else
            {
                return View();
            }

        }
    }
}

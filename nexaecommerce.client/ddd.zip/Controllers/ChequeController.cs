﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.IO;
using MVCSandoogh.SmsEspir;
using MVCSandoogh;
using MVCSandoogh.Controllers;
using System.Web.Security;


namespace MVCSandoogh.Controllers
{
    public class ChequeController : Controller
    {
        
             public ActionResult DashBoard()
        {
            return View();
        }
        // GET: Cheque
        public ActionResult Index()
        {
            SandooghModel db = new SandooghModel();
            List<T_BankAccount> groupList = db.T_BankAccount.ToList();
            List<T_CheqMasraf> masrafList = db.T_CheqMasraf.ToList();

            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<SelectListItem> MasrafList = new List<SelectListItem>();

            foreach (T_BankAccount group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.BankAccount_ID.ToString();
                sli.Text = group.BankAccount_BranchName.ToString() +" شعبه "+group.BankAccount_BranchName+ "(" + group.BankAccount_SHHesab + ")";
                GroupList.Add(sli);
            }
            ViewBag.hesabs = GroupList;
            foreach (T_CheqMasraf group in masrafList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.CheqMasraf_ID.ToString();
                sli.Text = group.CheqMasraf_Name;
                MasrafList.Add(sli);
            }
            ViewBag.masraf = MasrafList;

            return View();
        }
        public ActionResult BankAccount()
        {
            return View();
        }
        public ActionResult Masaref()
        {
            return View();
        }
        [HttpPost]
        public ActionResult GetBankAccounts(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_BankAccount.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.BankAccount_ID,
                    RowCells = new List<object>
                               {
                                    product.BankAccount_ID,
                                    product.BankAccount_SHHesab.ToString(),
                                    product.BankAccount_BankName.ToString(),
                                    product.BankAccount_BranchName.ToString(),
                                    product.BankAccount_BranchCode.ToString(),
                                     product.BankAccount_Tel.ToString(),
                                    product.BankAccount_Fax.ToString(),
                                    product.BankAccount_BankName.ToString(),
                                    product.BankAccount_Address.ToString()  

                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult EditBankAccount(T_BankAccount postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
       
                [HttpPost]
        public ActionResult DeleteCheque(string Id)
        {
            foreach (string ID in Id.Split(','))
            {
                int idd = int.Parse(ID);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var product = db.T_Cheq.FirstOrDefault(x => x.Cheq_ID == idd);
                if (product == null)
                    return Json(false);

                db.T_Cheq.Remove(product);
                db.SaveChanges();
            }
            return Json(true);
        }

        [HttpPost]
        public ActionResult DeleteMasaref(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_CheqMasraf.FirstOrDefault(x => x.CheqMasraf_ID == idd);
            if (product == null)
                return Json(false);

            db.T_CheqMasraf.Remove(product);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult DeleteBankAccount(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_BankAccount.FirstOrDefault(x => x.BankAccount_ID == idd);
            if (product == null)
                return Json(false);

            db.T_BankAccount.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult AddBankAccount(T_BankAccount postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.T_BankAccount.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult AddMasaref(T_CheqMasraf postData)
        {
            SandooghModel db = new SandooghModel();

            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.T_CheqMasraf.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult GetMasaref(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_CheqMasraf.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.CheqMasraf_ID,
                    RowCells = new List<object>
                               {
                                    product.CheqMasraf_ID,
                                    product.CheqMasraf_Name.ToString(),
                                  
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetCheque(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_Cheq.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Cheq_ID,
                    RowCells = new List<object>
                               {
                                  product.Cheq_ID,
                                  product.T_BankAccount.BankAccount_SHHesab,
                                  product.Cheq_Hesab,
                                  product.Cheq_Number.ToString(),
                                  product.Cheq_Sodoor!=null?((DateTime) product.Cheq_Sodoor).ToPersianDate():"",
                                  product.Cheq_Sarresid!=null?((DateTime) product.Cheq_Sarresid).ToPersianDate():"",
                                  product.Cheq_SarresidHoroof,
                                  product.Cheq_ValueDigit,
                                  product.Cheq_ValueLiteral,
                                  product.Cheq_Vajh,
                                  product.Cheq_Babat,
                                  product.T_CheqMasraf!=null? product.T_CheqMasraf.CheqMasraf_Name:"",
                                  product.Cheq_Masarf,
                                  product.T_OzvCode!=null? product.T_OzvCode.FName + " "+ product.T_OzvCode.LName:"",
                                  product.Cheq_Member,
                                  product.Cheq_Statuse


                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult EditCheqMasaref(T_CheqMasraf postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult EditCheq(T_Cheq postData)
        {
            
            SandooghModel db = new SandooghModel();
        //todo: Add product to repository
            if (postData == null)
                return Json(false);
            var d = (from e in db.T_Cheq where e.Cheq_ID == postData.Cheq_ID select e).FirstOrDefault();
            d.Cheq_Sodoor = postData.Cheq_Sodoor;
            d.Cheq_Sarresid = postData.Cheq_Sarresid;
            d.Cheq_ValueDigit = postData.Cheq_ValueDigit;
            d.Cheq_ValueLiteral = postData.Cheq_ValueLiteral;
            d.Cheq_ValueDigit = postData.Cheq_ValueDigit;
            d.Cheq_Vajh = postData.Cheq_Vajh;
            d.Cheq_Babat = postData.Cheq_Babat;
            d.Cheq_Masarf = postData.Cheq_Masarf;
            d.Cheq_SarresidHoroof = postData.Cheq_SarresidHoroof;
            db.Entry(d).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }


        [HttpPost]
        public ActionResult AddCheque(T_Cheq postData,string az,string ta)
        {
            try
            {
                SandooghModel db = new SandooghModel();

                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                int azx = int.Parse(az);
                int tax = int.Parse(ta);
                var d = postData;
                for (int i = azx; i <= tax; i++)
                {
                    d.Cheq_Number = i;
                    db.T_Cheq.Add(d);
                    db.SaveChanges();
                }
                   
               
                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }


    }
}
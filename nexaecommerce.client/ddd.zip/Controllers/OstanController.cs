﻿using MVCSandoogh.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSandoogh.Controllers
{
    [Authorize(Roles = "Admin")]
    public class OstanController : Controller
    {
        [HttpPost]
        public ActionResult Create(T_Ostan product)
        {
            try
            {
                // TODO: Add insert logic here
                //  string Ostan_ID = collection["Ostan_ID"].ToString();
                string Ostan_Name = product.ostan_name;
                DataGatheration gath = new DataGatheration();
                //              DataTable newtable=  gath.GetSqlTableWithComand(@"SELECT     ostan_name
                //FROM         T_Ostan
                //WHERE(ostan_name LIKE N'"+ Ostan_Name + @"')");
                //                if(newtable!=null&&newtable.Rows!=null&&newtable.Rows.Count>0)
                //                {
                //                    ViewBag.ResultMessage = "این استان قبلا به سیستم اضافه شده است";
                //                }
                //                else
                ApplicationDBContext db = new ApplicationDBContext();
                if (db.T_Ostan.Any(p => p.ostan_name == Ostan_Name))
                {
                    ModelState.AddModelError("DuplicateOstan", "این فیلد قبلا اضافه شده است!");
                    TempData["DuplicateOstan"] = "این فیلد قبلا اضافه شده است!";
                    return RedirectToAction("Index");
                }
                else
                {
                    gath.GetTableStoredProcedure("NewinsertOstan", new List<string> { "Ostan_Name" }, new List<object> { Ostan_Name });
                    return RedirectToAction("Index");
                }
                // 
                //  return Json(product, JsonRequestBehavior.AllowGet);
            }
            catch
            {

            }
            return RedirectToAction("Index");
        }

        public List<T_Ostan> AllOstan;
        public List<T_Ostan> GetAll()
        {
            AllOstan = new List<T_Ostan>();
            DataGatheration gath = new DataGatheration();
            DataTable table = gath.GetTableStoredProcedure("NewSelectOstan", null, null);
            foreach (DataRow row in table.Rows)
            {
                T_Ostan rt = new T_Ostan();
                rt.Ostan_id = long.Parse(row["Ostan_ID"].ToString());
                rt.ostan_name = row["Ostan_Name"].ToString();
                AllOstan.Add(rt);
            }
            return AllOstan;
        }
        // GET: Ostan
        public ActionResult Index()
        {
            if (TempData["DuplicateOstan"] != null)
            {
                ModelState.AddModelError("DuplicateOstan", TempData["DuplicateOstan"].ToString());

            }
           
                var Temp = from e in GetAll() orderby e.Ostan_id select e;
                return View(Temp);
           

        }



        // GET: Ostan/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Ostan/Create
        [HttpGet]
        public PartialViewResult Create()
        {
            return PartialView(new T_Ostan());

        }

        // GET: Ostan/Edit/5
        public ActionResult Edit(int id)
        {
            ApplicationDBContext db = new ApplicationDBContext();
            T_Ostan product = db.T_Ostan.Where(x => x.Ostan_id == id).FirstOrDefault();
            return View(product);
            // return View();
        }

        // POST: Ostan/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, T_Ostan rotbe)
        {
            try
            {
                // TODO: Add update logic here
                DataGatheration gath = new DataGatheration();
                gath.GetTableStoredProcedure("newupdateOstan", new List<string> { "Ostan_ID", "Ostan_Name" }, new List<object> { id, rotbe.ostan_name });

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }




        // POST: Ostan/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                DataGatheration gath = new DataGatheration();
                gath.GetTableStoredProcedure("newDeleteOstan", new List<string> { "Ostan_id" }, new List<object> { id });

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}

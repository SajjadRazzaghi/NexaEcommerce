﻿using PecPGW.Samples.WebApp.MVC.ParsianPGWSalePaymentServices;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.IO;
using PecPGW.Samples.Common;
using PecPGW.Samples.WebApp.MVC.Models;
using MVCSandoogh.Models;
using MVCSandoogh;
using BitPayDll;
using PecPGW.Samples.WebApp.MVC;
using System.Net;

namespace MVCSandoogh.Controllers
{
	public class BitPayPGWSalePaymentController : Controller
	{
		private const string SaleLoginAccountSessionKey = "SaleLoginAccount";
		private const string ConfirmAfterPaymentSessionKey = "ConfirmAfterPayment";
		private const string ConfirmServiceUrlSessionKey = "ConfirmServiceUrl";
		private const string ReversalServiceUrlSessionKey = "ReversalServiceUrl";

		// GET: ParsianPGWSalePayment
		public ActionResult Index()
		{
			return View();
		}

		
		private string GetLoginAccount()
		{
			return Session[SaleLoginAccountSessionKey].ToString();
		}

		//این اکشن برای پرداخت در عملیات خرید استفاده می شود
		//به نمونه کد فراخوانی سرویس پرداخت قبض درگاه پرداخت اینترنتی پارسیان در کنترلر قبلی مراجعه شود
		[HttpPost]
		public ActionResult SalePayment(string mablagh,string additionalData,string Originator,string type="ghest")
		{
            int result = -1;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            long Amount = 0;
            try
            {
                Amount = long.Parse(mablagh.Replace(",",""));
            }
            catch
            {

            }
            if (Amount > 0)
            {
                BitPay bitpay = new BitPay();

                string Url = "http://bitpay.ir/payment/gateway-send";

                string Redirecturl = "";
                if (type == "most" || type == "afz")
                {
                   Redirecturl = ConfigHelper.MostPaymentCallback;
                }
                else
                {
                    Redirecturl= ConfigHelper.SalePaymentCallback;
                }


               string Api = "7d99b-eab22-ed6ac-724d5-c7e816bbb3a391068d53a88c8df3";
               // string Api = "adxcv-zzadq-polkjsad-opp13opoz-1sdf455aadzmck1244567";
                SandooghModel db = new SandooghModel();
                T_orders order = new T_orders();
                order.finished = false;
                order.mablagh = Amount;
                order.userid = (from e in db.T_User
                                where e.User_UserName.ToUpper() == User.Identity.Name.ToUpper()
                                select e).FirstOrDefault().User_ID;
                if (type == "afz")
                    order.isafzayesh = true;
                else
                if (type == "most")
                {
                    order.isghest = false;
                }
                else
                {
                    order.isghest = true;
                }
                try
                {
                    order.regdate = DateTime.Now;
                }
                catch
                {

                }
                db.T_orders.Add(order);
                db.SaveChanges();
            
                result = bitpay.Send(Url, Api, Amount.ToString(), Redirecturl, order.Orderid.ToString(), "", "", "");
                try
                {
                    var myord = (from e in db.T_orders where e.Orderid == order.Orderid select e).FirstOrDefault();
                    myord.id_get = result;
                    db.Entry(myord).State=System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
                catch
                {

                }
                if (result > 0)
                {
                    string go = string.Format("https://bitpay.ir/payment/gateway-{0}-get", result);
                    return Json(new
                    {
                        status = 0,
                        location = go
                    });
                }


               
                 
                }

            return Json(new
            {
                status = result,
                location = "~/user/userpardakht"
            });
        }

		/// <summary>
		/// After user in Parsian IPG has completed payment process, it will be redirected to your CallBackUrl specified in initial Payment Request method call.
		/// You MUST insure of user's payment process status. if you havn't received a callback for payment, you should not deliver requested business product or service to your user.
		/// </summary>
		/// <param name="model">This is the model that Parsian IPg will fill for you after user has completed Payment process on Parsian IPG.
		/// to inform you of results of payment.</param>
		/// <returns></returns>
		/// پس از فراخوانی این اکشن توسط درگاه پرداخت اینترنتی پارسیان، 
		/// //متوجه وضعیت انجام فرآیند پرداخت توسط کاربر در صفحه درگاه پرداخت اینترنتی پارسیان خواهید شد
		/// و در صورت موفق بودن انجام پرداخت، باید تایید پرداخت را به درگاه پرداخت اینترنتی پارسیان اعلام نمایید
		/// //تا تراکنش موفق تلقی شود
		/// درصورتی که سرویس تایید پرداخت فراخوانی نشود، پولی که کاربر در صفحه درگاه پرداخت از کارت خود پرداخت نموده، 
		/// به حساب او برگشت داده می شود و خدماتی از سوی شما به او نباید ارائه شود
		/// بنابراین حتماً به خاطر داشته باشد که در کال بک، باید در صورتی که کد وضعیت تراکنش پرداخت موفق اعلام شد
		/// سرویس تایید تراکنش را با فراهم نمودن پارامتر مطلوب
		/// فراخوانی نمایید
		/// و سپس در صورت موفق بودن تایید تراکنش، نسبت به  ارائه خدمات به کاربر وب سایت خود اقدام نمایید
		/// بنابراین اگر پرداخت در صفحه پرداخت توسطک اربر موفق باشد
		/// اما تایید پرداخت را ارسال ننمایید
		/// خدماتی به کاربر نیز نباید بدهید
		/// اما درصورتی که تایید پرداخت را انجام دادید
		/// و تایید پرداخت موفق بود
		/// حتما باید خدمات را به کاربر ارائه دهید
		[HttpPost]
		public ActionResult PaymentCallback(PaymentCallbackModel model)
		{
			if (model != null)
			{
			
				//save callback info to your database and relate those info to the user's requested service or product.
				//if needed, deliver product or service to the user after ensuring payment.
				//in the case of Bill Payment, no delivery is commonly required.
				//but if a Sale payment is performed, may be a product or service delivery will be needed.

				//if transaction by user is successful, call Confirm service from Parsian PGW to complete the transaction
				//and indicate that you will deliver service or product to your end user.
				//it is better to save callback results into a database.

			
				if (model.status == Constants.ParsianPaymentGateway.Successful && (model.Token ?? 0L) > 0L)
				{
					var shouldConfirmAfterPay = (bool)Session[ConfirmAfterPaymentSessionKey];
					if (shouldConfirmAfterPay)
					{
						//ایجاد یک نمونه از سرویس تایید پرداخت
						using (var confirmSvc = new PecPGW.Samples.WebApp.MVC.ParsianPGWConfirmPaymentServices.ConfirmService())
						{
							confirmSvc.Url = (string)Session[ConfirmServiceUrlSessionKey];

							//ایجاد یک نمونه از نوع پارامتر سرویس تایید پرداخت
							var confirmRequestData = new PecPGW.Samples.WebApp.MVC.ParsianPGWConfirmPaymentServices.ClientConfirmRequestData();

							//شناسه پذیرندگی باید در فراخوانی سرویس تایید تراکنش پرداخت ارائه شود
							confirmRequestData.LoginAccount = GetLoginAccount();

							//توکن باید ارائه شود
							confirmRequestData.Token = model.Token ?? -1;

							//فراخوانی سرویس و دریافت نتیجه فراخوانی
							var confirmResponse = confirmSvc.ConfirmPayment(confirmRequestData);
						
							//کنترل کد وضعیت نتیجه فراخوانی
							//درصورتی که موفق باشد، باید خدمات یا کالا به کاربر پرداخت کننده ارائه شود
							if (confirmResponse.Status == Constants.ParsianPaymentGateway.Successful)
							{
                                //deliver service or product to end user accourding to your business rules.
                                //it is better to save confirm response into a database.
                                UserController uc = new UserController();
                               uc.UserCurrentVamPardakht(model);

                            }
						}
					}

					//بررسی اینکه آیا کاربر باید خدمات یا کالای مورد نظر خود را در قبال وجهی که پرداخت کرده است، دریافت کند
					//یا دریافت نکند.
					//در صورتی که مثلاً کاربر سفارش خود را پس از پرداخت وجه، لغو نماید، برای برگشت وجه پرداخت شده اش به حسابش
					//باید از سرویس برگشت وجه استفاده شود
					//حداکثر زمان مجاز برای فراخوانی سرویس برگشت وجه به حساب مشتری
					//که شروع آن پس از دریافت توکن از سرویس درخواست پرداخت می باشد
					//یک ساعت است

					//if(no service or product will be delivered to the customer)
					//call ReversalService.ReversalRequest() method to indicate return of money to customer.
					//ReversePayment(model.Token ?? 0L);
				}

				return View("~/User/UserCurrentVamPardakht");
			}
			else
			{
				return View("~/User/UserCurrentVamPardakht");
			}
		}
        /*
		//در صورتی که لازم باشد پرداختی که کاربر در صفحه درگاه پرداخت اینترنتی پارسیان انجام داده است
		//به شکلی لغو شود، باید از وب سرویس برگشت وجه استفاده شود
		//این وب سرویس با پاس نمودن توکن درخواستی که پرداخت آن انجام شده است قابل فراخوانی است
		//لطفاً دقت فرمایید که تنها در صورتی باید این سرویس فراخوانی شود که 
		//به عنوان مثال، کاربر درخواست لغو دریافت کالا یا خدمات از وب سایت شما را پس از پرداخت موفق داده باشد
		//فقط بیست دقیقه پس از درخواست اولیه پرداخت که توسط اپلیکیشن داده شده است، فرصت درخواست برگشت وجه پرداخت شده وجود دارد
		[HttpPost]
		public ActionResult ReversePayment(ReversalModel model)
		{
			try
			{
				//ایجاد یک نمونه از سرویس برگشت وجه پرداخت شده
				using (var reversalSvc = new ParsianPGWReversalServices.ReversalService())
				{
					reversalSvc.Url = (string)Session[ReversalServiceUrlSessionKey];

					//ایجاد یک نمونه از نوع پارامتر ورودی متد برگشت وجه
					var requestData = new ParsianPGWReversalServices.ClientReversalRequestData()
					{
						LoginAccount = GetLoginAccount(),
						Token = model.Token
					};

					//فراخوانی متد برگشت وجه از نمونه وب سرویس برگشت وجه
					var response = reversalSvc.ReversalRequest(requestData);

					//کنترل کد وضعیت عملیات درخواست برگشت وجه
					//درصورت موفق بودن، می توانید از ارائه کالا و یا خدمات درخواستی کاربر به او انصراف دهید
					if (response.Status == Constants.ParsianPaymentGateway.Successful)
					{
						//reversal was successful
					}

					var viewModel = new ReversalResponseViewModel()
					{
						Status = response.Status,
						Message = response.Status == 0 ? "Successful" : "Failed!!!"
					};

					return PartialView("_ReverseResponse", viewModel);
				}
			}
			catch (Exception ex)
			{
				logger.Error(new { Method = "Reversal", Exception = ex });
				return PartialView("_ReverseResponse", new ReversalResponseViewModel()
				{
					Message = "Unsuccessful" + Environment.NewLine + ex.ToString()
				});
			}
		}*/
	}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.Threading.Tasks;
using PecPGW.Samples.WebApp.MVC.Models;
using PecPGW.Samples.Common;
using System.Web.Security;

using BitPayDll;
using MVCSandoogh.GhasedakServiceRefrence;
using System.Data;
using EntityState = System.Data.Entity.EntityState;
using Newtonsoft.Json;

namespace MVCSandoogh.Controllers
{
    [Authorize(Roles = "Admin , User,Sadmin,Chairman")]
    public class UserController : Controller
    {
        public string getcontroli(string id)
        {
            string result = "";
            int temp = 0;
            int length = id.Length;
            int counter =length-1;
            for (int i=2;i<=7;i++)
            {
                if (counter <0)
                    break;
                int k = int.Parse(id.Substring(counter, 1));
                temp += (k*i);
                counter --;
                if (i == 7)
                    i = 2;
                
            }
            temp = temp % 11;
            if (temp == 0 || temp == 1)
                return "0";
            else
                temp = 11 - temp;
            result = temp.ToString();
            return result;
        }
      
        public static bool IsCRC3BonyadMaskanSemnanValid(string id)
        {
            int[] iValue = { 15, 14, 13, 12, 11, 10, 9, 1, 2, 3, 4, 5, 6, 7, 8 };
            string sID = id;
            int digitID = 0;
            string tempID;

            if (string.IsNullOrEmpty(sID) || sID.Length > 17)
            {
                return false; // When The Entered Number Is Greater Than Normal Length ID (15 characters) OR That Is Empty This Section Fired Up!
            }

            sID = "00000000000000000" + sID;
            sID = sID.Substring(sID.Length - 17);

            tempID = sID;
            sID = sID.Substring(sID.Length - 17, 15);

            char[] arrID = sID.ToCharArray();
            for (int i = 0; i < iValue.Length; i++)
            {
                digitID += (iValue[i] * (arrID[i] - '0'));
            }

            digitID = int.Parse(("0" + (digitID % 99)).Substring(("0" + (digitID % 99)).Length - 2));

            if (tempID == sID + digitID.ToString())
            {
                return true; // The Entered Digit Number Is Correct
            }

            return false;
        }

        [HttpPost]
        public ActionResult SalePayment(string mablagh, string additionalData, string Originator, string type = "ghest")
        {
         //   int result = -1;
         //string codecontrol=   setcontroli("275564164902");

            
        
            string shenaseghabz = "";
          
          
                SandooghModel db = new SandooghModel();
            var user = (from e in db.T_User where e.User_UserName.ToUpper() == User.Identity.Name.ToUpper() select e).FirstOrDefault();

                 shenaseghabz = (from e in db.T_OzvCode
                                 where e.Id ==user.User_OzvCdoe
                                 select e).FirstOrDefault().MelliCode;

            if (type == "afz")
            {

                shenaseghabz += "03";
            }
            else
            if (type == "most")
            {

                shenaseghabz += "01";
            }
            else
            {

                shenaseghabz += "02";
            }
           // درست کردن شناسه پرداخت

          ////  shenaseghabz += "03";
          //  string controli = setcontroli(shenaseghabz);
            //if(controli=="")
                return Json(new
                {

                    pardakht =""
                    });
          

          
        }
        [HttpGet]
        public ActionResult Ghabz(string ghabz)
        {
            ViewBag.ghabz = ghabz;
           
            return View();
        }
        private int ConfirmPayment(long token)
        {
            using (var confirmSvc = new PecPGW.Samples.WebApp.MVC.ParsianPGWConfirmPaymentServices.ConfirmService())
            {
                var confirmRequestData = new PecPGW.Samples.WebApp.MVC.ParsianPGWConfirmPaymentServices.ClientConfirmRequestData();
                confirmRequestData.Token = token;
                confirmRequestData.LoginAccount = ConfigHelper.LoginAccount;
                var confirmResponse = confirmSvc.ConfirmPayment(confirmRequestData);
                if (confirmResponse.Status ==0)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
        }
      
        [HttpPost]                           
        public ActionResult UserPardakhtwait(string mablaghmost, string mablaghghest,string mablaghafzayesh,string transaction,string dateofpay,string sumpay)
        {
         
         SandooghModel db = new SandooghModel();
            string comment = "درج فیش - ";
            var userid = (from e in db.T_User
                          where e.User_UserName.ToUpper() == User.Identity.Name.ToUpper()
                          select e).FirstOrDefault().User_ID;

         
                    DateTime now = DateTime.Now;
                    G_M_Payswait Pay = new G_M_Payswait();
                    var DateOfPay = DateTime.Now;
            try
            {
                DateOfPay =(DateTime) PersianDateUtils.ToMilady(dateofpay);
            }
            catch
            {
            }
            Pay.PayDate = DateOfPay;
            long mostamary = 0;
            long ghest = 0;
            try
            {
                mostamary = long.Parse(mablaghmost.Replace(",", ""));
            }
            catch
            {
            }
            try
            {
                ghest = long.Parse(mablaghghest.Replace(",", ""));
            }
            catch
            {
            }
            long totalmablagh = 0;
                    try
                    {
                        totalmablagh = long.Parse(sumpay.Replace(",", ""));
                    }
                    catch
                    {
                        totalmablagh = 0;
                        ViewBag.ressulte = "Amount Error";
                        return UserPardakht();
                    }
                    comment += "مبلغ " + totalmablagh + "ریال طی فیش ( " + transaction+")";
                   
                   
                    var list1 = db.Vams;
                   
                    var usercode = (from e in db.T_User where e.User_ID == userid select e).FirstOrDefault();  /* (from e in db.T_User where e.User_UserName == User.Identity.Name select e).ToList()[0];*/
                   

                    Pay.TotMablag = totalmablagh;
            Pay.MostamariMablag = mostamary;
            Pay.TotGestMablag = ghest;
          
                    Pay.IdRefOzv = (int)usercode.User_OzvCdoe;
                    Pay.Comment += comment;
                    Pay.Fish_No = transaction;
                   
                    Pay.IsAfzayesh = false;
            int afzayesh = 0;
            try
            {
                afzayesh = int.Parse(mablaghafzayesh);
            }
            catch
            {

            }
            Pay.AfzayeshMablagh = afzayesh;

            if (afzayesh != 0) Pay.IsAfzayesh = true; else Pay.IsAfzayesh = false;
            
                   
                    try
                    {
                        Pay.MablaghHarMostamary = usercode.OzvCode.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh;
                    }
                    catch
                    {
                        Pay.MablaghHarMostamary = 0;
                    }
                   
                    Pay.Nahveh_P = 2;
                    //Pay.PayDate = now;





                    try
                    {

                       


                        string ozvnam = "";

                        try
                        {
                            ozvnam = usercode.User_Firstname + " " + usercode.User_lastname;
                        }
                        catch
                        {

                        }


                Pay.IsTaeid = false;
                Pay.statuse = 2;              
                        db.G_M_Payswait.Add(Pay);
                        db.SaveChanges();
                        //if (isafzayesh == true)
                        //{
                        //    try
                        //    {

                        //        T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();
                        //        ozv.SumAfzayeshMostamary -= (int)Pay.MostamariMablag;
                        //        db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                        //        db.SaveChanges();

                        //        if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > Pay.PayDate)
                        //        {
                        //            T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                        //            lastmostpaie.MostamaryMablagh_VarizyTaDateStart += (int)Pay.MostamariMablag;
                        //            db.Entry(lastmostpaie).State = EntityState.Modified;
                        //            db.SaveChanges();
                        //        }

                        //    }
                        //    catch
                        //    {

                        //    }
                        //}
                        try
                        {


                            var PD = (from e in db.G_M_Payswait where e.Id == Pay.Id select e).FirstOrDefault();
                            PD.T_OzvCode = (from e in db.T_OzvCode where e.Id == PD.IdRefOzv select e).FirstOrDefault();
                            try
                            {
                                PD.Vam = (from e in db.Vams where e.Vam_Id == PD.IdRefVam select e).FirstOrDefault();
                            }
                            catch
                            {

                            }
                            try
                            {
                                PD.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == PD.Nahveh_P select e).FirstOrDefault();
                            }
                            catch
                            {

                            }

                        }
                        catch
                        {

                        }

                        //ارسال اس ام اس

                       
                        try
                        {
                            var mobile = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault().Mobile;

                            SendMsg(new string[] { Pay.T_OzvCode.Mobile }, @"عضو محترم! واریزی شما با موفقیت ثبت گردید و بعد از تایید نهایی در لیست واریزی ها اعمال خواهد شد" +

                    "\n" + @"صندوق نظام مهندسي");
                        }
                        catch
                        {

                            ViewBag.ressulte = "Error";
                            return UserPardakht();
                        }
                    }
                    catch
                    {
                        ViewBag.ressulte = "Error";
                        return UserPardakht();
                    }

                    ViewBag.ressulte = "با تشکر! پرداخت شما با موفقیت ثبت شدوبعد از تایید در سیستم اعمال خواهد شد";

                     return RedirectToAction("UserPardakht", "User"); 
         


        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult UserCurrentVamPardakht(PaymentCallbackModel postData, string BankTafsilicode="10003")
        {
            var orderid = postData.OrderId;
            //دووامه: اینجا باید وام فعال توسط دراپ داون انتخاب گردد تا بعد اطلاعات آن وام نشان داده شود و انتخاب گردد و پرداخت برای آن صورت گیرد 
            string comment = "پرداخت قسط آنلاین-";
            if (postData.status == 0 && postData.Token > 0)
            {
               
                if (ConfirmPayment((long)postData.Token) >= 0)
                {

                    DateTime now = DateTime.Now;
                    G_M_Pays Pay = new G_M_Pays();
                    var DateOfPay = DateTime.Now;
                    SandooghModel db = new SandooghModel();
                    long totalmablagh = 0;
                    try
                    {
                        totalmablagh = long.Parse(postData.Amount.Replace(",", ""));
                    
                    }
                    catch
                    {
                        totalmablagh = 0;
                        ViewBag.ressulte = "اشکال در اجرای عملیات از طرف پذیرنده صورت گرفته است";
                        return UserVams();
                    }
                    comment += "مبلغ " + totalmablagh + "ریال طی تراکنش شماره " + postData.RRN;

                    try
                    {
                        if (db.G_M_Pays.Where(k => k.Comment.Contains(comment)).Count() > 0)
                        {
                            return UserVams();
                        }
                            }
                    catch
                    {

                    }
                    int UserSanad = 0;

                    var list1 = db.Vams;
                    var userid = (from e in db.T_orders where e.Orderid == orderid select e.userid).FirstOrDefault();
                    var usercode1 = (from e in db.T_User where e.User_ID == userid select e).FirstOrDefault();
                    var usercode = usercode1.User_OzvCdoe;

                    bool success = Membership.ValidateUser(usercode1.User_UserName, usercode1.User_Password);

                    /* var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_OzvCdoe).ToList()[0];*/
                    var list = (from e in list1 where e.IdRefOzv.ToString() == usercode.ToString() && e.EtmamVam == false select e).ToList();
                    if (list != null)
                    {
                        var product = list.LastOrDefault();
                        if (product != null)
                        {
                            Pay.TotMablag = totalmablagh;
                            Pay.IdRefOzv = product.IdRefOzv;
                            Pay.IdRefVam = product.Vam_Id;
                            Pay.Fish_No = postData.RRN.ToString();
                            Pay.IdRefNoeVam = product.IdRefNoeVam;
                            Pay.MablaghharGhest = product.GestMablag;
                            Pay.MostamariMablag = 0;
                            Pay.Comment += comment;
                            try
                            {
                                Pay.MablaghHarMostamary = product.T_OzvCode.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh;
                            }
                            catch
                            {
                                Pay.MablaghHarMostamary = 0;
                            }
                            Pay.MostamariMablag = 0;
                            Pay.Nahveh_P = 3;
                            Pay.PayDate = now;
                            Pay.TotGestMablag = totalmablagh;


                            var vamtype = product.T_VamCode.VamName;

                            try
                            {

                                //todo: Add product to repository
                                if (postData == null)
                                {
                                    ViewBag.ressulte = "Bank Error";
                                    return UserVams();
                                }



                                string ozvnam = "";

                                try
                                {
                                    ozvnam = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e.FName + " " + e.LName).FirstOrDefault();
                                }
                                catch
                                {

                                }
                                if (Pay.MostamariMablag != null && Pay.MostamariMablag > 0)
                                {
                                    var lastvam = (from v in db.Vams
                                                   where (v.IdRefOzv == Pay.IdRefOzv)
                                                   orderby v.VamDate descending
                                                   select v).Take(1);

                                    //آخرین مستمری پرداختی قبل از ثبت این مستمری
                                    var lastmostamarry = (from v in db.G_M_Pays
                                                          where (v.IdRefOzv == Pay.IdRefOzv && v.MostamariMablag != null && v.MostamariMablag != 0)
                                                          orderby v.PayDate descending
                                                          select v).Take(1);
                                    if (lastmostamarry != null && lastmostamarry.ToList().Count > 0)
                                    {
                                        //اگر قبلا مستمری پرداخت کرده است
                                        var persianCalendar = new System.Globalization.PersianCalendar();
                                        var lastpay = (DateTime)lastmostamarry.ToList()[0].PayDate;
                                        int emtiaz = 0;
                                        while (now >= persianCalendar.AddMonths(lastpay, 3).AddDays(1))
                                        {
                                            emtiaz++;
                                            lastpay = persianCalendar.AddMonths(lastpay, 3).AddDays(1);
                                        }
                                        Pay.Emtiaz = emtiaz;

                                    }
                                }
                                int moeinbank = -1;
                                try
                                {
                                    moeinbank = int.Parse(BankTafsilicode);

                                }
                                catch
                                {

                                }


                                var maxValue = UserSanad;
                                if (UserSanad == 0)
                                {

                                    var sanadno = (from e in db.AccSanad_B
                                                   where
                           e.Date_S.Year == DateOfPay.Year
                           && e.Date_S.Month == DateOfPay.Month
                           && e.Date_S.Day == DateOfPay.Day
                           && (e.Lock_Sanad != true) && (e.UserLock != true)
                                                   select e.Sanad_No).Distinct();
                                    var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                                    string startyear = yearrr.Year_Name + "/01/01";
                                    string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                                    DateTime datestart = (DateTime)startyear.ToMilady();
                                    DateTime dateend = (DateTime)endyear.ToMilady();
                                    var thisyearssanads = from e in db.AccSanad_B where e.Date_S >= datestart && e.Date_S < dateend select e;

                                    var max = thisyearssanads.Max(x => x.Sanad_No);
                                    if (sanadno.ToList().Count == 0)
                                    {
                                        if (DateTime.Now.Date == DateOfPay.Date)
                                            maxValue = (int)max + 1;
                                        else
                                        {
                                            ViewBag.ressulte = "Error";
                                            return UserVams();
                                        }

                                    }
                                    else
                                        maxValue = (int)sanadno.ToList().Max();
                                }

                                var sanads = "";

                                if (totalmablagh > 0)
                                {

                                    //حساب بانک بدهکار
                                    AccSanad_B sanad1 = new AccSanad_B();
                                    sanad1.Sanad_No = maxValue;
                                    sanad1.Group = "1";
                                    sanad1.Kol = "111";
                                    string gghh = moeinbank.ToString();/*1212*/
                                    var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == gghh select e;
                                    string moeincode = "";
                                    if (bankmoein != null)
                                        moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                                    if (moeincode != null)
                                    {
                                        sanad1.Moein = moeincode;
                                        sanad1.Tafsili = BankTafsilicode;
                                        sanad1.Date_S = DateOfPay;
                                        sanad1.Sanad_Tafsili1 = 1;
                                        sanad1.Ok_NotOk = false;
                                        sanad1.Lock_Sanad = false;
                                        sanad1.Bedhkar = totalmablagh;
                                        sanad1.Bestankar = 0;
                                        string comment1 = "وصول ";
                                        if (totalmablagh > 0)
                                            if (Pay.MostamariMablag > 0)
                                                comment1 += " قسط و مستمری " + vamtype + " ";
                                            else
                                                comment1 += " قسط  " + vamtype + " ";

                                        else
                                            if (Pay.MostamariMablag > 0)
                                            comment1 += "  مستمری ماهانه ";
                                        else
                                            comment1 += " ...  ";

                                        sanad1.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + postData.RRN + " -پرداخت آنلاین";

                                        db.AccSanad_B.Add(sanad1);

                                        db.SaveChanges();
                                        Pay.SanadNo = sanad1.Sanad_No;
                                        sanads += sanad1.ID + ",";
                                    }
                                    else
                                    {
                                        ViewBag.ressulte = "Error";
                                        return UserVams();
                                    }
                                }
                                else
                                    sanads += ",";

                                if (Pay.TotGestMablag > 0)//اگر قسط پرداخت میشود
                                {
                                    //وام عضو بستانکار
                                    AccSanad_B sanad = new AccSanad_B();
                                    sanad.Sanad_No = maxValue;
                                    sanad.Group = "1";
                                    sanad.Kol = "112";
                                    switch (Pay.IdRefNoeVam)
                                    {
                                        case 1001:
                                            sanad.Moein = "001";
                                            break;
                                        case 1002:
                                            sanad.Moein = "003";
                                            break;
                                        case 1003:
                                            sanad.Moein = "002";
                                            break;
                                    }
                                    sanad.Tafsili = Pay.IdRefOzv.ToString();
                                    sanad.Date_S = now;
                                    sanad.Sanad_Tafsili1 = 2;
                                    sanad.Ok_NotOk = false;
                                    sanad.Lock_Sanad = false;
                                    sanad.Bedhkar = 0;
                                    sanad.Bestankar = Pay.TotGestMablag;
                                    string comment1 = "وصول ";
                                    if (Pay.TotGestMablag > 0)
                                        if (Pay.MostamariMablag > 0)
                                            comment1 += " قسط و مستمری " + vamtype + " ";
                                        else
                                            comment1 += " قسط  " + vamtype + " ";

                                    else
                                        if (Pay.MostamariMablag > 0)
                                        comment1 += "  مستمری ماهانه ";
                                    else
                                        comment1 += " ...  ";
                                    sanad.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + Pay.Fish_No + " ";
                                    db.AccSanad_B.Add(sanad);
                                    db.SaveChanges();
                                    Pay.SanadNo = sanad.Sanad_No;
                                    sanads += sanad.ID + ",";


                                }
                                else
                                    sanads += ",";
                                if (Pay.MostamariMablag > 0)//اگر مستمری پرداخت میشود
                                {


                                    //مستمری عضو بستانکار
                                    AccSanad_B sanad = new AccSanad_B();
                                    sanad.Sanad_No = maxValue;
                                    sanad.Group = "3";
                                    sanad.Kol = "311";

                                    sanad.Moein = "003";

                                    sanad.Tafsili = Pay.IdRefOzv.ToString();
                                    sanad.Date_S = now;
                                    sanad.Sanad_Tafsili1 = 2;
                                    sanad.Ok_NotOk = false;
                                    sanad.Lock_Sanad = false;
                                    sanad.Bedhkar = 0;
                                    sanad.Bestankar = Pay.MostamariMablag;
                                    string comment1 = "وصول ";
                                    if (Pay.TotGestMablag > 0)
                                        if (Pay.MostamariMablag > 0)
                                            comment1 += " قسط و مستمری " + vamtype + " ";
                                        else
                                            comment1 += " قسط  " + vamtype + " ";

                                    else
                                        if (Pay.MostamariMablag > 0)
                                        comment1 += "  مستمری ماهانه ";
                                    else
                                        comment1 += " ...  ";

                                    sanad.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + Pay.Fish_No + " " + "_ پرداخت آنلاین";


                                    db.AccSanad_B.Add(sanad);
                                    db.SaveChanges();
                                    Pay.SanadNo = sanad.Sanad_No;
                                    sanads += sanad.ID + ",";


                                }
                                else
                                    sanads += ",";

                                Pay.Sanads = sanads;
                                db.G_M_Pays.Add(Pay);
                                db.SaveChanges();
                                //new if
                                if (Pay.IsAfzayesh == true)
                                {
                                    try
                                    {

                                        T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();
                                        ozv.SumAfzayeshMostamary -= (int)Pay.MostamariMablag;
                                        db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                                        db.SaveChanges();

                                        if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > Pay.PayDate)
                                        {
                                            T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                                            lastmostpaie.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == lastmostpaie.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)lastmostpaie.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum(); 
                                            db.Entry(lastmostpaie).State =EntityState.Modified;
                                            db.SaveChanges();
                                        }

                                    }
                                    catch
                                    {

                                    }
                                }
                               
                                try
                                {


                                    var PD = (from e in db.G_M_Pays where e.Id == Pay.Id select e).FirstOrDefault();
                                    PD.T_OzvCode = (from e in db.T_OzvCode where e.Id == PD.IdRefOzv select e).FirstOrDefault();
                                    try
                                    {
                                        PD.Vam = (from e in db.Vams where e.Vam_Id == PD.IdRefVam select e).FirstOrDefault();
                                    }
                                    catch
                                    {

                                    }
                                    try
                                    {
                                        PD.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == PD.Nahveh_P select e).FirstOrDefault();
                                    }
                                    catch
                                    {

                                    }

                                }
                                catch
                                {

                                }

                                //ارسال اس ام اس
                                //دووامه: اگر پرداخت فقط مستمری بود لازم نیست وگرنه به جای اکتیووام باید وامی که قسط برای آن پرداخت شد را پیدا کنیم 
                                var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == Pay.IdRefOzv select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                                var activevam = (double?)0;
                                try
                                {
                                    activevam = (from w in db.Vams where w.IdRefOzv == Pay.IdRefOzv && w.EtmamVam == false select w.Vam_Id).FirstOrDefault();
                                }
                                catch
                                {

                                }
                                var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.Vam.EtmamVam == false && e.IdRefOzv == Pay.IdRefOzv) select e;
                                var pardakhtVam = (double?)0;
                                var mandevam = (double?)0;
                                try
                                {
                                    pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;
                                }
                                catch
                                {

                                }
                                try
                                {
                                    if (pardakhtVam == null)
                                        pardakhtVam = 0;
                                    mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.Karmozd+t.VamMablagKhales).FirstOrDefault();
                                    mandevam = mandevam - pardakhtVam;
                                    if (mandevam <= 0)
                                    {
                                        var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                        entity2.EtmamVam = true;
                                        db.Entry(entity2).CurrentValues.SetValues(entity2);



                                        db.SaveChanges();
                                    }
                                    else
                                    {
                                        var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                        entity2.EtmamVam = false;
                                        db.Entry(entity2).CurrentValues.SetValues(entity2);



                                        db.SaveChanges();
                                    }
                                }
                                catch
                                {

                                }
                                try
                                {

                                    var ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();

                                    SendMsg(new string[] { ozv.Mobile }, DateTime.Now.ToPersianDate() +
                                    (Pay.TotGestMablag != null ? (Pay.TotGestMablag > 0 ? "\n" + @" قسط واريزي: " + Pay.TotGestMablag + " ریال" : "") : "") +
                                     ((Pay.TotGestMablag != null && Pay.TotGestMablag > 0) ?((mandevam != null ? ("\n" + @"مانده وام : " + mandevam.Value.ToString()) : "")+ "\n شناسه پرداخت قسط:" + ozv.ghestshenase) /*("\n" + @"جمع اقساط واریزی : " + pardakhtVam + "ریال */: "") +
                                      //(mandevam!=null? ("\n" + @"مانده وام : " + mandevam.Value.ToString()):"") + 
                                      (Pay.MostamariMablag != null ? (Pay.MostamariMablag != 0 ? "\n" + (" مستمری واریزی : ") + Pay.MostamariMablag + " ریال \n" + @"جمع مستمری : " + summostamarises.FirstOrDefault().SumMostamary + " ریال" +" \n شناسه پرداخت مستمری:" + ozv.mostammarryshenase : "") : "") +

                                   

                    "\n" + @"صندوق نظام مهندسي (صنم)");
                                }
                                catch
                                {

                                    ViewBag.ressulte = "Error";
                                    return UserVams();
                                }
                            }
                            catch
                            {
                                ViewBag.ressulte = "Error";
                                return UserVams();
                            }

                            ViewBag.ressulte = "با تشکر! پرداخت شما با موفقیت انجام شد";
                            try
                            {
                                var order = (from e in db.T_orders where e.Orderid == orderid select e).FirstOrDefault();
                                order.finished = true;
                                db.Entry(order).State = EntityState.Modified;
                                db.SaveChanges();
                            }
                            catch { }
                            return UserVams();

                        }
                        else
                        {
                            ViewBag.ressulte = "Error";
                            return UserVams();
                        }
                    }
                    else
                    {
                        ViewBag.ressulte = "Error";
                        return UserVams();
                    }
                }
                else
                    return UserVams();
            }
            else
                return UserVams();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult UserPardakht(PaymentCallbackModel postData, string BankTafsilicode = "10003")
        {
          
            string comment = "پرداخت مستمری آنلاین-";
            var orderid = postData.OrderId;
            if (postData.status == 0&&postData.Token > 0)
            {
                if (ConfirmPayment((long)postData.Token) >= 0)
                {
                    DateTime now = DateTime.Now;
                    G_M_Pays Pay = new G_M_Pays();
                    var DateOfPay = DateTime.Now;
                    SandooghModel db = new SandooghModel();
                    long totalmablagh = 0;
                    try
                    {
                        totalmablagh = long.Parse(postData.Amount.Replace(",", ""));
                    }
                    catch
                    {
                        totalmablagh = 0;
                        ViewBag.ressulte = "Amount Error";
                        return UserPardakht();
                    }
                    comment += "مبلغ " + totalmablagh + "ریال طی تراکنش شماره " +postData.RRN ;
                    try
                    {
                        if (db.G_M_Pays.Where(k => k.Comment.Contains(comment)).Count() > 0)
                        {
                            return UserPardakht();
                        }
                    }
                    catch
                    {

                    }
                    int UserSanad = 0;

                    var list1 = db.Vams;
                    var userid = (from e in db.T_orders where e.Orderid == orderid select e.userid).FirstOrDefault();
                    var usercode = (from e in db.T_User where e.User_ID == userid select e).FirstOrDefault();  /* (from e in db.T_User where e.User_UserName == User.Identity.Name select e).ToList()[0];*/
                    bool success = Membership.ValidateUser(usercode.User_UserName, usercode.User_Password);


                    Pay.TotMablag = totalmablagh;
                    Pay.IdRefOzv = (int)usercode.User_OzvCdoe;
                    Pay.Comment += comment;
                    Pay.Fish_No = postData.RRN.ToString();
                    bool isafzayesh = false;
                    try
                    {
                        if ((from e in db.T_orders where e.Orderid == orderid select e).FirstOrDefault().isafzayesh == true)
                            isafzayesh = true;
                    }
                    catch
                    {

                    }
                    Pay.IsAfzayesh = isafzayesh;
                    Pay.MostamariMablag = totalmablagh;
                    try
                    {
                        Pay.MablaghHarMostamary = usercode.OzvCode.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh;
                    }
                    catch
                    {
                        Pay.MablaghHarMostamary = 0;
                    }
                    Pay.TotGestMablag = 0;
                    Pay.Nahveh_P = 3;
                    Pay.PayDate = now;





                    try
                    {

                        //todo: Add product to repository
                        if (postData == null)
                        {
                            ViewBag.ressulte = "Bank Error";
                            return UserPardakht();
                        }



                        string ozvnam = "";

                        try
                        {
                            ozvnam = usercode.User_Firstname + " " + usercode.User_lastname;
                        }
                        catch
                        {

                        }
                        if (Pay.MostamariMablag != null && Pay.MostamariMablag > 0)
                        {
                            var lastvam = (from v in db.Vams
                                           where (v.IdRefOzv == Pay.IdRefOzv)
                                           orderby v.VamDate descending
                                           select v).Take(1);

                            //آخرین مستمری پرداختی قبل از ثبت این مستمری
                            var lastmostamarry = (from v in db.G_M_Pays
                                                  where (v.IdRefOzv == Pay.IdRefOzv && v.MostamariMablag != null && v.MostamariMablag != 0)
                                                  orderby v.PayDate descending
                                                  select v).Take(1);
                            if (lastmostamarry != null && lastmostamarry.ToList().Count > 0)
                            {
                                //اگر قبلا مستمری پرداخت کرده است
                                var persianCalendar = new System.Globalization.PersianCalendar();
                                var lastpay = (DateTime)lastmostamarry.ToList()[0].PayDate;
                                int emtiaz = 0;
                                while (now >= persianCalendar.AddMonths(lastpay, 3).AddDays(1))
                                {
                                    emtiaz++;
                                    lastpay = persianCalendar.AddMonths(lastpay, 3).AddDays(1);
                                }
                                Pay.Emtiaz = emtiaz;

                            }
                        }
                        int moeinbank = -1;
                        try
                        {
                            moeinbank = int.Parse(BankTafsilicode);

                        }
                        catch
                        {

                        }


                        var maxValue = UserSanad;
                        if (UserSanad == 0)
                        {

                            var sanadno = (from e in db.AccSanad_B
                                           where
                   e.Date_S.Year == DateOfPay.Year
                   && e.Date_S.Month == DateOfPay.Month
                   && e.Date_S.Day == DateOfPay.Day
                   && (e.Lock_Sanad != true) && (e.UserLock != true)
                                           select e.Sanad_No).Distinct();
                            var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                            string startyear = yearrr.Year_Name + "/01/01";
                            string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                            DateTime datestart = (DateTime)startyear.ToMilady();
                            DateTime dateend = (DateTime)endyear.ToMilady();
                            var thisyearssanads = from e in db.AccSanad_B where e.Date_S >= datestart && e.Date_S < dateend select e;

                            var max = thisyearssanads.Max(x => x.Sanad_No);
                            if (sanadno.ToList().Count == 0)
                            {
                                if (DateTime.Now.Date == DateOfPay.Date)
                                    maxValue = (int)max + 1;
                                else
                                {
                                    ViewBag.ressulte = "Error";
                                    return UserPardakht();
                                }

                            }
                            else
                                maxValue = (int)sanadno.ToList().Max();
                        }

                        var sanads = "";

                        if (totalmablagh > 0)
                        {

                            //حساب بانک بدهکار
                            AccSanad_B sanad1 = new AccSanad_B();
                            sanad1.Sanad_No = maxValue;
                            sanad1.Group = "1";
                            sanad1.Kol = "111";
                            string gghhh = moeinbank.ToString();
                            var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == gghhh select e;/*1212*/
                            string moeincode = "";
                            if (bankmoein != null)
                                moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                            if (moeincode != null)
                            {
                                sanad1.Moein = moeincode;
                                sanad1.Tafsili = BankTafsilicode;
                                sanad1.Date_S = DateOfPay;
                                sanad1.Sanad_Tafsili1 = 1;
                                sanad1.Ok_NotOk = false;
                                sanad1.Lock_Sanad = false;
                                sanad1.Bedhkar = totalmablagh;
                                sanad1.Bestankar = 0;
                                string comment1 = "وصول ";
                                if (totalmablagh > 0)
                                    if (Pay.MostamariMablag > 0)
                                        comment1 += (isafzayesh?"افزایش سرمایه" :"  مستمری ماهانه ");
                                    else
                                        comment1 += " ...  ";

                                sanad1.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + postData.RRN + " -پرداخت آنلاین";

                                db.AccSanad_B.Add(sanad1);

                                db.SaveChanges();
                                Pay.SanadNo = sanad1.Sanad_No;
                                sanads += sanad1.ID + ",";
                            }
                            else
                            {
                                ViewBag.ressulte = "Error";
                                return UserPardakht();
                            }
                        }
                        else
                            sanads += ",";

                        sanads += ",";
                        if (Pay.MostamariMablag > 0)//اگر مستمری پرداخت میشود
                        {


                            //مستمری عضو بستانکار
                            AccSanad_B sanad = new AccSanad_B();
                            sanad.Sanad_No = maxValue;
                            sanad.Group = "3";
                            sanad.Kol = "311";

                            sanad.Moein = "003";

                            sanad.Tafsili = Pay.IdRefOzv.ToString();
                            sanad.Date_S = now;
                            sanad.Sanad_Tafsili1 = 2;
                            sanad.Ok_NotOk = false;
                            sanad.Lock_Sanad = false;
                            sanad.Bedhkar = 0;
                            sanad.Bestankar = Pay.MostamariMablag;
                            string comment1 = "وصول ";


                            if (Pay.MostamariMablag > 0)
                                comment1 += (isafzayesh ? "افزایش سرمایه" : "  مستمری ماهانه ");
                            else
                                comment1 += " ...  ";

                            sanad.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + Pay.Fish_No + " " + "_ پرداخت آنلاین";


                            db.AccSanad_B.Add(sanad);
                            db.SaveChanges();
                            Pay.SanadNo = sanad.Sanad_No;
                            sanads += sanad.ID + ",";


                        }
                        else
                            sanads += ",";

                        Pay.Sanads = sanads;
                        db.G_M_Pays.Add(Pay);
                        db.SaveChanges();
                        //new if
                        if (Pay.IsAfzayesh == true)
                        {
                            try
                            {

                                T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();
                                ozv.SumAfzayeshMostamary -= (int)Pay.MostamariMablag;
                                db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                                db.SaveChanges();

                                if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > Pay.PayDate)
                                {
                                    T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                                    lastmostpaie.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == lastmostpaie.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)lastmostpaie.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
                                    db.Entry(lastmostpaie).State = EntityState.Modified;
                                    db.SaveChanges();
                                }

                            }
                            catch
                            {

                            }
                        }
                        try
                        {


                            var PD = (from e in db.G_M_Pays where e.Id == Pay.Id select e).FirstOrDefault();
                            PD.T_OzvCode = (from e in db.T_OzvCode where e.Id == PD.IdRefOzv select e).FirstOrDefault();
                            try
                            {
                                PD.Vam = (from e in db.Vams where e.Vam_Id == PD.IdRefVam select e).FirstOrDefault();
                            }
                            catch
                            {

                            }
                            try
                            {
                                PD.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == PD.Nahveh_P select e).FirstOrDefault();
                            }
                            catch
                            {

                            }

                        }
                        catch
                        {

                        }

                        //ارسال اس ام اس

                        var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == Pay.IdRefOzv select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                        var activevam = (double?)0;
                        try
                        {
                            //دووامه:اگر فقط مستمری پرداخت شده اصلا لازم نیست این کارا، برای اقساط هم بجای اکتیو، وامی که قسط برای آن پرداخت شده را انتخاب میکنیم
                            activevam = (from w in db.Vams where w.IdRefOzv == Pay.IdRefOzv && w.EtmamVam == false select w.Vam_Id).FirstOrDefault();
                        }
                        catch
                        {

                        }
                        var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.Vam.EtmamVam == false && e.IdRefOzv == Pay.IdRefOzv) select e;
                        var pardakhtVam = (double?)0;
                        var mandevam = (double?)0;
                        try
                        {
                            pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;


                        }
                        catch
                        {

                        }
                        try
                        {
                            if (pardakhtVam == null)
                                pardakhtVam = 0;
                            mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                            mandevam = mandevam - pardakhtVam;
                            if (mandevam <= 0)
                            {
                                var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                entity2.EtmamVam = true;
                                db.Entry(entity2).CurrentValues.SetValues(entity2);



                                db.SaveChanges();
                            }
                            else
                            {
                                
                                    var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                    entity2.EtmamVam = false;
                                    db.Entry(entity2).CurrentValues.SetValues(entity2);



                                    db.SaveChanges();
                                
                            }
                        
                        }
                        catch
                        {

                        }
                        try
                        {

                            var ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();

                            SendMsg(new string[] { ozv.Mobile }, DateTime.Now.ToPersianDate() +
                            (Pay.TotGestMablag != null ? (Pay.TotGestMablag > 0 ? "\n" + @" قسط واريزي: " + Pay.TotGestMablag + " ریال" : "") : "") +
                            ((Pay.TotGestMablag != null && Pay.TotGestMablag > 0) ? ((mandevam != null ? ("\n" + @"مانده وام : " + mandevam.Value.ToString()) : "") + "\n شناسه پرداخت قسط:" + ozv.ghestshenase) /*("\n" + @"جمع اقساط واریزی : " + pardakhtVam + "ریال */: "") +
                              //(mandevam!=null? ("\n" + @"مانده وام : " + mandevam.Value.ToString()):"") + 
                             
                              (Pay.MostamariMablag != null ? (Pay.MostamariMablag != 0 ? "\n" + (isafzayesh?@" افزایش سرمایه واريزي : ":" مستمری واریزی : ") + Pay.MostamariMablag + " ریال\n" + @"جمع مستمری : " + summostamarises.FirstOrDefault().SumMostamary + " ریال"+ "\n شناسه پرداخت مستمری:" + ozv.mostammarryshenase : "") : "") +

                          

            "\n" + @"صندوق نظام مهندسي (صنم)");
                        }
                        catch
                        {

                            ViewBag.ressulte = "Error";
                            return UserPardakht();
                        }
                    }
                    catch
                    {
                        ViewBag.ressulte = "Error";
                        return UserPardakht();
                    }

                    ViewBag.ressulte = "باتشکر! پرداخت شما با موفقیت انجام شد";
                    return UserPardakht();
                }
                else
                    return UserPardakht();
            }
            else
            {
                return UserPardakht();
            }
             
         
        }

    
        [AllowAnonymous]
        public ActionResult UserCurrentVamPardakht_Online(string BankTafsilicode = "10020",string paydatee="")
        {
           
            //دووامه: اینجا باید وام فعال توسط دراپ داون انتخاب گردد تا بعد اطلاعات آن وام نشان داده شود و انتخاب گردد و پرداخت برای آن صورت گیرد 
            string comment = "پرداخت قسط آنلاین-";
            BitPay bitpay = new BitPay();
            string url = "https://bitpay.ir/payment/gateway-result-second";

           string Api = "7d99b-eab22-ed6ac-724d5-c7e816bbb3a391068d53a88c8df3";
            // string Api = "adxcv-zzadq-polkjsad-opp13opoz-1sdf455aadzmck1244567";

            string trans_id = HttpContext.Request["trans_id"];
            string id_get = HttpContext.Request["id_get"];
            string factorId = HttpContext.Request["factorId"];

            int result = bitpay.Get(url, Api, trans_id, id_get);

            var orderid = long.Parse(factorId);
            if (result == 1||result==11)
          
            {

                if (true/*ConfirmPayment((long)postData.Token) >= 0*/)
                {

                    DateTime now1 = DateTime.Now;
                    G_M_Pays Pay = new G_M_Pays();
                    var DateOfPay = DateTime.Now;
                    if (paydatee != "")
                    {
                        try
                        {
                            DateOfPay = DateTime.Parse(paydatee);
                        }
                        catch
                        {

                        }
                    }
                    //TimeSpan ts = new TimeSpan(23, 30, 0);
                    //TimeSpan ts1 = new TimeSpan(23, 29, 0);

                    //if (DateOfPay.TimeOfDay > ts)
                    //{
                    //    DateOfPay = DateOfPay.AddDays(1).Subtract(ts1);
                    //}
                    SandooghModel db = new SandooghModel();
                    long totalmablagh = 0;
                    try
                    {
                        totalmablagh = (from e in db.T_orders where e.Orderid == orderid select e.mablagh).FirstOrDefault();
                    }
                    catch
                    {
                        totalmablagh = 0;
                        ViewBag.ressulte = "Amount Error";
                        return UserVams();
                    }
                    comment += "مبلغ " + totalmablagh + "ریال طی تراکنش شماره " + trans_id;

                    try
                    {
                        if (db.G_M_Pays.Where(k => k.Comment.Contains(comment)).Count() > 0)
                        {
                            return UserVams();
                        }
                    }
                    catch
                    {

                    }
                    int UserSanad = 0;

                    var list1 = db.Vams;
                    var userid = (from e in db.T_orders where e.Orderid == orderid select e.userid).FirstOrDefault();
                    var usercode1 = (from e in db.T_User where e.User_ID == userid select e).FirstOrDefault();
                    var usercode = usercode1.User_OzvCdoe;

                    bool success = Membership.ValidateUser(usercode1.User_UserName, usercode1.User_Password);

                    /* var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_OzvCdoe).ToList()[0];*/
                    var list = (from e in list1 where e.IdRefOzv.ToString() == usercode.ToString() && e.EtmamVam == false select e).ToList();
                    if (list != null)
                    {
                        var product = list.LastOrDefault();
                        if (product != null)
                        {
                            Pay.TotMablag = totalmablagh;
                            Pay.IdRefOzv = product.IdRefOzv;
                            Pay.IdRefVam = product.Vam_Id;
                            Pay.Fish_No = trans_id;
                            Pay.IdRefNoeVam = product.IdRefNoeVam;
                            Pay.MablaghharGhest = product.GestMablag;
                            Pay.MostamariMablag = 0;
                            Pay.Comment += comment;
                            try
                            {
                                Pay.MablaghHarMostamary = product.T_OzvCode.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh;
                            }
                            catch
                            {
                                Pay.MablaghHarMostamary = 0;
                            }
                            Pay.MostamariMablag = 0;
                            Pay.Nahveh_P = 3;
                            Pay.PayDate = DateOfPay;
                            Pay.TotGestMablag = totalmablagh;


                            var vamtype = product.T_VamCode.VamName;

                            try
                            {

                           /*     //todo: Add product to repository
                                if (postData == null)
                                {
                                    ViewBag.ressulte = "Bank Error";
                                    return UserVams();
                                }
                                */


                                string ozvnam = "";

                                try
                                {
                                    ozvnam = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e.FName + " " + e.LName).FirstOrDefault();
                                }
                                catch
                                {

                                }
                                if (Pay.MostamariMablag != null && Pay.MostamariMablag > 0)
                                {
                                    var lastvam = (from v in db.Vams
                                                   where (v.IdRefOzv == Pay.IdRefOzv)
                                                   orderby v.VamDate descending
                                                   select v).Take(1);

                                    //آخرین مستمری پرداختی قبل از ثبت این مستمری
                                    var lastmostamarry = (from v in db.G_M_Pays
                                                          where (v.IdRefOzv == Pay.IdRefOzv && v.MostamariMablag != null && v.MostamariMablag != 0)
                                                          orderby v.PayDate descending
                                                          select v).Take(1);
                                    if (lastmostamarry != null && lastmostamarry.ToList().Count > 0)
                                    {
                                        //اگر قبلا مستمری پرداخت کرده است
                                        var persianCalendar = new System.Globalization.PersianCalendar();
                                        var lastpay = (DateTime)lastmostamarry.ToList()[0].PayDate;
                                        int emtiaz = 0;
                                        while (DateOfPay >= persianCalendar.AddMonths(lastpay, 3).AddDays(1))
                                        {
                                            emtiaz++;
                                            lastpay = persianCalendar.AddMonths(lastpay, 3).AddDays(1);
                                        }
                                        Pay.Emtiaz = emtiaz;

                                    }
                                }
                                int moeinbank = -1;
                                try
                                {
                                    moeinbank = int.Parse(BankTafsilicode);

                                }
                                catch
                                {

                                }


                                var maxValue = UserSanad;
                                if (UserSanad == 0)
                                {

                                    var sanadno = (from e in db.AccSanad_B
                                                   where
                           e.Date_S.Year == DateOfPay.Year
                           && e.Date_S.Month == DateOfPay.Month
                           && e.Date_S.Day == DateOfPay.Day
                           && (e.Lock_Sanad != true) && (e.UserLock != true)
                                                   select e.Sanad_No).Distinct();
                                    var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                                    string startyear = yearrr.Year_Name + "/01/01";
                                    string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                                    DateTime datestart = (DateTime)startyear.ToMilady();
                                    DateTime dateend = (DateTime)endyear.ToMilady();
                                    var thisyearssanads = from e in db.AccSanad_B where e.Date_S >= datestart && e.Date_S < dateend select e;

                                    var max = thisyearssanads.Max(x => x.Sanad_No);
                                    if (sanadno.ToList().Count == 0)
                                    {
                                        if (DateTime.Now.Date == DateOfPay.Date)
                                            maxValue = (int)max + 1;
                                        else
                                        {
                                            ViewBag.ressulte = "Error";
                                            return UserVams();
                                        }

                                    }
                                    else
                                        maxValue = (int)sanadno.ToList().Max();
                                }

                                var sanads = "";

                                if (totalmablagh > 0)
                                {

                                    //حساب بانک بدهکار
                                    AccSanad_B sanad1 = new AccSanad_B();
                                    sanad1.Sanad_No = maxValue;
                                    sanad1.Group = "1";
                                    sanad1.Kol = "111";
                                    string gghhhh = moeinbank.ToString();/*1212*/
                                    var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == gghhhh select e;
                                    string moeincode = "";
                                    if (bankmoein != null)
                                        moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                                    if (moeincode != null)
                                    {
                                        sanad1.Moein = moeincode;
                                        sanad1.Tafsili = BankTafsilicode;
                                        sanad1.Date_S = DateOfPay;
                                        sanad1.Sanad_Tafsili1 = 1;
                                        sanad1.Ok_NotOk = false;
                                        sanad1.Lock_Sanad = false;
                                        sanad1.Bedhkar = totalmablagh;
                                        sanad1.Bestankar = 0;
                                        string comment1 = "وصول ";
                                        if (totalmablagh > 0)
                                            if (Pay.MostamariMablag > 0)
                                                comment1 += " قسط و مستمری " + vamtype + " ";
                                            else
                                                comment1 += " قسط  " + vamtype + " ";

                                        else
                                            if (Pay.MostamariMablag > 0)
                                            comment1 += "  مستمری ماهانه ";
                                        else
                                            comment1 += " ...  ";

                                        sanad1.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + trans_id + " -پرداخت آنلاین";

                                        db.AccSanad_B.Add(sanad1);

                                        db.SaveChanges();
                                        Pay.SanadNo = sanad1.Sanad_No;
                                        sanads += sanad1.ID + ",";
                                    }
                                    else
                                    {
                                        ViewBag.ressulte = "Error";
                                        return UserVams();
                                    }
                                }
                                else
                                    sanads += ",";

                                if (Pay.TotGestMablag > 0)//اگر قسط پرداخت میشود
                                {
                                    //وام عضو بستانکار
                                    AccSanad_B sanad = new AccSanad_B();
                                    sanad.Sanad_No = maxValue;
                                    sanad.Group = "1";
                                    sanad.Kol = "112";
                                    switch (Pay.IdRefNoeVam)
                                    {
                                        case 1001:
                                            sanad.Moein = "001";
                                            break;
                                        case 1002:
                                            sanad.Moein = "003";
                                            break;
                                        case 1003:
                                            sanad.Moein = "002";
                                            break;
                                    }
                                    sanad.Tafsili = Pay.IdRefOzv.ToString();
                                    sanad.Date_S = DateOfPay;
                                    sanad.Sanad_Tafsili1 = 2;
                                    sanad.Ok_NotOk = false;
                                    sanad.Lock_Sanad = false;
                                    sanad.Bedhkar = 0;
                                    sanad.Bestankar = Pay.TotGestMablag;
                                    string comment1 = "وصول ";
                                    if (Pay.TotGestMablag > 0)
                                        if (Pay.MostamariMablag > 0)
                                            comment1 += " قسط و مستمری " + vamtype + " ";
                                        else
                                            comment1 += " قسط  " + vamtype + " ";

                                    else
                                        if (Pay.MostamariMablag > 0)
                                        comment1 += "  مستمری ماهانه ";
                                    else
                                        comment1 += " ...  ";
                                    sanad.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + Pay.Fish_No + " ";
                                    db.AccSanad_B.Add(sanad);
                                    db.SaveChanges();
                                    Pay.SanadNo = sanad.Sanad_No;
                                    sanads += sanad.ID + ",";


                                }
                                else
                                    sanads += ",";
                                if (Pay.MostamariMablag > 0)//اگر مستمری پرداخت میشود
                                {


                                    //مستمری عضو بستانکار
                                    AccSanad_B sanad = new AccSanad_B();
                                    sanad.Sanad_No = maxValue;
                                    sanad.Group = "3";
                                    sanad.Kol = "311";

                                    sanad.Moein = "003";

                                    sanad.Tafsili = Pay.IdRefOzv.ToString();
                                    sanad.Date_S = DateOfPay;
                                    sanad.Sanad_Tafsili1 = 2;
                                    sanad.Ok_NotOk = false;
                                    sanad.Lock_Sanad = false;
                                    sanad.Bedhkar = 0;
                                    sanad.Bestankar = Pay.MostamariMablag;
                                    string comment1 = "وصول ";
                                    if (Pay.TotGestMablag > 0)
                                        if (Pay.MostamariMablag > 0)
                                            comment1 += " قسط و مستمری " + vamtype + " ";
                                        else
                                            comment1 += " قسط  " + vamtype + " ";

                                    else
                                        if (Pay.MostamariMablag > 0)
                                        comment1 += "  مستمری ماهانه ";
                                    else
                                        comment1 += " ...  ";

                                    sanad.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + Pay.Fish_No + " " + "_ پرداخت آنلاین";


                                    db.AccSanad_B.Add(sanad);
                                    db.SaveChanges();
                                    Pay.SanadNo = sanad.Sanad_No;
                                    sanads += sanad.ID + ",";


                                }
                                else
                                    sanads += ",";

                                Pay.Sanads = sanads;
                                db.G_M_Pays.Add(Pay);
                                db.SaveChanges();
                               
                                //new if
                                if (Pay.IsAfzayesh == true)
                                {
                                    try
                                    {

                                        T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();
                                        ozv.SumAfzayeshMostamary -= (int)Pay.MostamariMablag;
                                        db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                                        db.SaveChanges();

                                        if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > Pay.PayDate)
                                        {
                                            T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                                            lastmostpaie.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == lastmostpaie.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)lastmostpaie.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
                                            db.Entry(lastmostpaie).State = EntityState.Modified;
                                            db.SaveChanges();
                                        }

                                    }
                                    catch
                                    {

                                    }
                                }
                                try
                                {


                                    var PD = (from e in db.G_M_Pays where e.Id == Pay.Id select e).FirstOrDefault();
                                    PD.T_OzvCode = (from e in db.T_OzvCode where e.Id == PD.IdRefOzv select e).FirstOrDefault();
                                    try
                                    {
                                        PD.Vam = (from e in db.Vams where e.Vam_Id == PD.IdRefVam select e).FirstOrDefault();
                                    }
                                    catch
                                    {

                                    }
                                    try
                                    {
                                        PD.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == PD.Nahveh_P select e).FirstOrDefault();
                                    }
                                    catch
                                    {

                                    }

                                }
                                catch
                                {

                                }

                                //ارسال اس ام اس
                                //دووامه: اگر پرداخت فقط مستمری بود لازم نیست وگرنه به جای اکتیووام باید وامی که قسط برای آن پرداخت شد را پیدا کنیم 
                                var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == Pay.IdRefOzv select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                                var activevam = (double?)0;
                                try
                                {
                                    activevam = (from w in db.Vams where w.IdRefOzv == Pay.IdRefOzv && w.EtmamVam == false select w.Vam_Id).FirstOrDefault();
                                }
                                catch
                                {

                                }
                                var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.Vam.EtmamVam == false && e.IdRefOzv == Pay.IdRefOzv) select e;
                                var pardakhtVam = (double?)0;
                                var mandevam = (double?)0;
                                try
                                {
                                    pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;
                                }
                                catch
                                {

                                }
                                try
                                {
                                    if (pardakhtVam == null)
                                        pardakhtVam = 0;
                                    mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.Karmozd + t.VamMablagKhales).FirstOrDefault();
                                    mandevam = mandevam - pardakhtVam;
                                    if (mandevam <= 0)
                                    {
                                        var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                        entity2.EtmamVam = true;
                                        db.Entry(entity2).CurrentValues.SetValues(entity2);



                                        db.SaveChanges();
                                    }
                                    else
                                    {
                                        var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                        entity2.EtmamVam = false;
                                        db.Entry(entity2).CurrentValues.SetValues(entity2);



                                        db.SaveChanges();
                                    }
                                }
                                catch
                                {

                                }
                                try
                                {
                                    var ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();

                                    SendMsg(new string[] { ozv.Mobile }, DateTime.Now.ToPersianDate() +
                                    (Pay.TotGestMablag != null ? (Pay.TotGestMablag > 0 ? "\n" + @" قسط واريزي: " + Pay.TotGestMablag + " ریال" : "") : "") +
                                    ((Pay.TotGestMablag != null && Pay.TotGestMablag > 0) ? ((mandevam != null ? ("\n" + @"مانده وام : " + mandevam.Value.ToString()) : "") + "\n شناسه پرداخت قسط:" + ozv.ghestshenase) /*("\n" + @"جمع اقساط واریزی : " + pardakhtVam + "ریال */: "") +
                                       //(mandevam!=null? ("\n" + @"مانده وام : " + mandevam.Value.ToString()):"") + 
                                       (Pay.MostamariMablag != null ? (Pay.MostamariMablag != 0 ? "\n" + @" مستمري واريزي : " + Pay.MostamariMablag + " ریال \n" + @"جمع مستمری : " + summostamarises.FirstOrDefault().SumMostamary + " ریال"+"\n شناسه پرداخت مستمری:" + ozv.mostammarryshenase : "") : "") +

                                  

                    "\n" + @"صندوق نظام مهندسي (صنم)");
                                }
                                catch
                                {

                                    ViewBag.ressulte = "Error";
                                    return UserVams();
                                }
                            }
                            catch
                            {
                                ViewBag.ressulte = "Error";
                                return UserVams();
                            }

                            ViewBag.ressulte = "با تشکر! پرداخت شما با موفقیت انجام شد";
                            try
                            {
                                var order = (from e in db.T_orders where e.Orderid == orderid select e).FirstOrDefault();
                                order.finished = true;
                                order.transact_id = long.Parse(trans_id);
                              
                                db.Entry(order).State = EntityState.Modified;
                                db.SaveChanges();
                            }
                            catch { }
                            return UserVams();

                        }
                        else
                        {
                            ViewBag.ressulte = "Error";
                            return UserVams();
                        }
                    }
                    else
                    {
                        ViewBag.ressulte = "Error";
                        return UserVams();
                    }
                }
                else
                    return UserVams();
            }
            else
                return UserVams();
        }

 
        [AllowAnonymous]
        public ActionResult UserPardakht_Online( string BankTafsilicode = "10020",string paydatee="")
        {
           
            string comment = "پرداخت مستمری آنلاین-";
            BitPay bitpay = new BitPay();
            string url = "https://bitpay.ir/payment/gateway-result-second";

            string Api = "7d99b-eab22-ed6ac-724d5-c7e816bbb3a391068d53a88c8df3";
            //string Api = "adxcv-zzadq-polkjsad-opp13opoz-1sdf455aadzmck1244567";

            string trans_id = HttpContext.Request["trans_id"];
            string id_get = HttpContext.Request["id_get"];
            string factorId = HttpContext.Request["factorId"];

            int result = bitpay.Get(url, Api, trans_id, id_get);

            var orderid =long.Parse(factorId);
            if (result == 1||result==11)
            {
                if (/*ConfirmPayment((long)postData.Token) >= 0*/true)
                {
                    DateTime now1 = DateTime.Now;
                    G_M_Pays Pay = new G_M_Pays();
                    var DateOfPay = DateTime.Now;
                    if (paydatee != "")
                    {
                        try
                        {
                            DateOfPay = DateTime.Parse(paydatee);
                        }
                        catch
                        {

                        }
                    }
                    //TimeSpan ts = new TimeSpan(23, 30, 0);
                    //TimeSpan ts1 = new TimeSpan(23, 29, 0);

                    //if (DateOfPay.TimeOfDay > ts)
                    //{
                    //    DateOfPay = DateOfPay.AddDays(1).Subtract(ts1);
                    //}
                    SandooghModel db = new SandooghModel();
                    long totalmablagh = 0;
                    try
                    {
                        totalmablagh = (from e in db.T_orders where e.Orderid == orderid select e.mablagh).FirstOrDefault();
                    }
                    catch
                    {
                        totalmablagh = 0;
                        ViewBag.ressulte = "Amount Error";
                        return UserPardakht();
                    }
                    comment += "مبلغ " + totalmablagh + "ریال طی تراکنش شماره " +trans_id;
                        try
                    {
                        if (db.G_M_Pays.Where(k => k.Comment.Contains(comment)).Count() > 0)
                        {
                            return UserPardakht();
                        }
                    }
                    catch
                    {

                    }
                    int UserSanad = 0;

                    var list1 = db.Vams;
                    var userid = (from e in db.T_orders where e.Orderid == orderid select e.userid).FirstOrDefault();
                    var usercode = (from e in db.T_User where e.User_ID == userid select e).FirstOrDefault();  /* (from e in db.T_User where e.User_UserName == User.Identity.Name select e).ToList()[0];*/
                    bool success = Membership.ValidateUser(usercode.User_UserName, usercode.User_Password);


                    Pay.TotMablag = totalmablagh;
                    Pay.IdRefOzv = (int)usercode.User_OzvCdoe;
                    Pay.Comment += comment;
                    Pay.Fish_No =trans_id;
                    bool isafzayesh = false;
                    try
                    {
                        if ((from e in db.T_orders where e.Orderid == orderid select e).FirstOrDefault().isafzayesh == true)
                            isafzayesh = true;
                    }
                    catch
                    {

                    }
                    Pay.IsAfzayesh = isafzayesh;
                    Pay.MostamariMablag = totalmablagh;
                    try
                    {
                        Pay.MablaghHarMostamary = usercode.OzvCode.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh;
                    }
                    catch
                    {
                        Pay.MablaghHarMostamary = 0;
                    }
                    Pay.TotGestMablag = 0;
                    Pay.Nahveh_P = 3;
                    Pay.PayDate = DateOfPay;





                    try
                    {



                        string ozvnam = "";

                        try
                        {
                            ozvnam = usercode.User_Firstname + " " + usercode.User_lastname;
                        }
                        catch
                        {

                        }
                        if (Pay.MostamariMablag != null && Pay.MostamariMablag > 0)
                        {
                            var lastvam = (from v in db.Vams
                                           where (v.IdRefOzv == Pay.IdRefOzv)
                                           orderby v.VamDate descending
                                           select v).Take(1);

                            //آخرین مستمری پرداختی قبل از ثبت این مستمری
                            var lastmostamarry = (from v in db.G_M_Pays
                                                  where (v.IdRefOzv == Pay.IdRefOzv && v.MostamariMablag != null && v.MostamariMablag != 0)
                                                  orderby v.PayDate descending
                                                  select v).Take(1);
                            if (lastmostamarry != null && lastmostamarry.ToList().Count > 0)
                            {
                                //اگر قبلا مستمری پرداخت کرده است
                                var persianCalendar = new System.Globalization.PersianCalendar();
                                var lastpay = (DateTime)lastmostamarry.ToList()[0].PayDate;
                                int emtiaz = 0;
                                while (DateOfPay >= persianCalendar.AddMonths(lastpay, 3).AddDays(1))
                                {
                                    emtiaz++;
                                    lastpay = persianCalendar.AddMonths(lastpay, 3).AddDays(1);
                                }
                                Pay.Emtiaz = emtiaz;

                            }
                        }
                        int moeinbank = -1;
                        try
                        {
                            moeinbank = int.Parse(BankTafsilicode);

                        }
                        catch
                        {

                        }


                        var maxValue = UserSanad;
                        if (UserSanad == 0)
                        {

                            var sanadno = (from e in db.AccSanad_B
                                           where
                   e.Date_S.Year == DateOfPay.Year
                   && e.Date_S.Month == DateOfPay.Month
                   && e.Date_S.Day == DateOfPay.Day
                   && (e.Lock_Sanad != true) && (e.UserLock != true)
                                           select e.Sanad_No).Distinct();
                            var yearrr = (from e in db.Acc_Years where e.Year_Isactive == true select e).FirstOrDefault();
                            string startyear = yearrr.Year_Name + "/01/01";
                            string endyear = (int.Parse(yearrr.Year_Name) + 1) + "/01/01";
                            DateTime datestart = (DateTime)startyear.ToMilady();
                            DateTime dateend = (DateTime)endyear.ToMilady();
                            var thisyearssanads = from e in db.AccSanad_B where e.Date_S >= datestart && e.Date_S < dateend select e;

                            var max = thisyearssanads.Max(x => x.Sanad_No);
                            if (sanadno.ToList().Count == 0)
                            {
                                if (DateTime.Now.Date == DateOfPay.Date)
                                    maxValue = (int)max + 1;
                                else
                                {
                                    ViewBag.ressulte = "Error";
                                    return UserPardakht();
                                }

                            }
                            else
                                maxValue = (int)sanadno.ToList().Max();
                        }

                        var sanads = "";

                        if (totalmablagh > 0)
                        {

                            //حساب بانک بدهکار
                            AccSanad_B sanad1 = new AccSanad_B();
                            sanad1.Sanad_No = maxValue;
                            sanad1.Group = "1";
                            sanad1.Kol = "111";
                            string gghhhhhh = moeinbank.ToString();
                            var bankmoein = from e in db.Acc_Tafsili2 where e.Tafsili2_Code == gghhhhhh select e;/*1212*/
                            string moeincode = "";
                            if (bankmoein != null)
                                moeincode = bankmoein.ToList()[0].Tafsili2_MoeinCode;
                            if (moeincode != null)
                            {
                                sanad1.Moein = moeincode;
                                sanad1.Tafsili = BankTafsilicode;
                                sanad1.Date_S = DateOfPay;
                                sanad1.Sanad_Tafsili1 = 1;
                                sanad1.Ok_NotOk = false;
                                sanad1.Lock_Sanad = false;
                                sanad1.Bedhkar = totalmablagh;
                                sanad1.Bestankar = 0;
                                string comment1 = "وصول ";
                                if (totalmablagh > 0)
                                    if (Pay.MostamariMablag > 0)
                                        comment1 += (isafzayesh ? "افزایش سرمایه" : "  مستمری ماهانه ");
                                    else
                                        comment1 += " ...  ";

                                sanad1.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " +trans_id + " -پرداخت آنلاین";

                                db.AccSanad_B.Add(sanad1);

                                db.SaveChanges();
                                Pay.SanadNo = sanad1.Sanad_No;
                                sanads += sanad1.ID + ",";
                            }
                            else
                            {
                                ViewBag.ressulte = "Error";
                                return UserPardakht();
                            }
                        }
                        else
                            sanads += ",";

                        sanads += ",";
                        if (Pay.MostamariMablag > 0)//اگر مستمری پرداخت میشود
                        {


                            //مستمری عضو بستانکار
                            AccSanad_B sanad = new AccSanad_B();
                            sanad.Sanad_No = maxValue;
                            sanad.Group = "3";
                            sanad.Kol = "311";

                            sanad.Moein = "003";

                            sanad.Tafsili = Pay.IdRefOzv.ToString();
                            sanad.Date_S = DateOfPay;
                            sanad.Sanad_Tafsili1 = 2;
                            sanad.Ok_NotOk = false;
                            sanad.Lock_Sanad = false;
                            sanad.Bedhkar = 0;
                            sanad.Bestankar = Pay.MostamariMablag;
                            string comment1 = "وصول ";


                            if (Pay.MostamariMablag > 0)
                                comment1 += (isafzayesh ? "افزایش سرمایه" : "  مستمری ماهانه ");
                            else
                                comment1 += " ...  ";

                            sanad.Articl_Comment = comment1 + ozvnam + " طی تراکنش شماره " + trans_id + " " + "_ پرداخت آنلاین";


                            db.AccSanad_B.Add(sanad);
                            db.SaveChanges();
                            Pay.SanadNo = sanad.Sanad_No;
                            sanads += sanad.ID + ",";


                        }
                        else
                            sanads += ",";

                        Pay.Sanads = sanads;
                        db.G_M_Pays.Add(Pay);
                        db.SaveChanges();
                        //new if
                        if (Pay.IsAfzayesh == true)
                        {
                            try
                            {

                                T_OzvCode ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();
                                ozv.SumAfzayeshMostamary -= (int)Pay.MostamariMablag;
                                db.Entry(ozv).State = System.Data.Entity.EntityState.Modified;
                                db.SaveChanges();

                                if (ozv.T_MostamaryMablagh.Last().MostamaryMablagh_DateStart > Pay.PayDate)
                                {
                                    T_MostamaryMablagh lastmostpaie = db.T_MostamaryMablagh.Find(ozv.T_MostamaryMablagh.Last().MostamaryMablagh_ID);
                                    lastmostpaie.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == lastmostpaie.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)lastmostpaie.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
                                    db.Entry(lastmostpaie).State = EntityState.Modified;
                                    db.SaveChanges();
                                }

                            }
                            catch
                            {

                            }
                        }
                        try
                        {


                            var PD = (from e in db.G_M_Pays where e.Id == Pay.Id select e).FirstOrDefault();
                            PD.T_OzvCode = (from e in db.T_OzvCode where e.Id == PD.IdRefOzv select e).FirstOrDefault();
                            try
                            {
                                PD.Vam = (from e in db.Vams where e.Vam_Id == PD.IdRefVam select e).FirstOrDefault();
                            }
                            catch
                            {

                            }
                            try
                            {
                                PD.Nahveh_P1 = (from e in db.Nahveh_P where e.Id == PD.Nahveh_P select e).FirstOrDefault();
                            }
                            catch
                            {

                            }

                        }
                        catch
                        {

                        }

                        //ارسال اس ام اس

                        var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == Pay.IdRefOzv select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });
                        var activevam = (double?)0;
                        try
                        {
                            //دووامه:اگر فقط مستمری پرداخت شده اصلا لازم نیست این کارا، برای اقساط هم بجای اکتیو، وامی که قسط برای آن پرداخت شده را انتخاب میکنیم
                            activevam = (from w in db.Vams where w.IdRefOzv == Pay.IdRefOzv && w.EtmamVam == false select w.Vam_Id).FirstOrDefault();
                        }
                        catch
                        {

                        }
                        var natamampardakhty = from e in db.G_M_Pays where (e.IdRefVam == activevam && e.Vam.EtmamVam == false && e.IdRefOzv == Pay.IdRefOzv) select e;
                        var pardakhtVam = (double?)0;
                        var mandevam = (double?)0;
                        try
                        {
                            pardakhtVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = g.Key, SumPardakhty = g.Sum(v => v.TotGestMablag) }).FirstOrDefault().SumPardakhty;


                        }
                        catch
                        {

                        }
                        try
                        {
                            if (pardakhtVam == null)
                                pardakhtVam = 0;
                            mandevam = (from t in db.Vams where t.Vam_Id == activevam select t.VamMablagKhales + t.Karmozd).FirstOrDefault();
                            mandevam = mandevam - pardakhtVam;
                            if (mandevam <= 0)
                            {
                                var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                entity2.EtmamVam = true;
                                db.Entry(entity2).CurrentValues.SetValues(entity2);



                                db.SaveChanges();
                            }
                            else
                            {

                                var entity2 = db.Vams.Where(c => c.Vam_Id == Pay.IdRefVam).AsQueryable().FirstOrDefault();
                                entity2.EtmamVam = false;
                                db.Entry(entity2).CurrentValues.SetValues(entity2);



                                db.SaveChanges();

                            }

                        }
                        catch
                        {

                        }
                        try
                        {

                            var ozv = (from e in db.T_OzvCode where e.Id == Pay.IdRefOzv select e).FirstOrDefault();

                            SendMsg(new string[] { ozv.Mobile }, DateTime.Now.ToPersianDate() +
                            (Pay.TotGestMablag != null ? (Pay.TotGestMablag > 0 ? "\n" + @" قسط واريزي: " + Pay.TotGestMablag + " ریال" : "") : "") +
                            ((Pay.TotGestMablag != null && Pay.TotGestMablag > 0) ? ((mandevam != null ? ("\n" + @"مانده وام : " + mandevam.Value.ToString()) : "") + "\n شناسه پرداخت قسط:" + ozv.ghestshenase) /*("\n" + @"جمع اقساط واریزی : " + pardakhtVam + "ریال */: "") +
                                        //(mandevam!=null? ("\n" + @"مانده وام : " + mandevam.Value.ToString()):"") + 
                        (Pay.MostamariMablag != null ? (Pay.MostamariMablag != 0 ? ("\n" + (isafzayesh ? @" افزایش سرمایه واريزي : " : " مستمری واریزی : ") + Pay.MostamariMablag + " ریال \n" + @"جمع مستمری: " + summostamarises.FirstOrDefault().SumMostamary + " ریال" +
"\n شناسه پرداخت مستمری:" + ozv.mostammarryshenase) : "") : "") +

                           
            "\n" + @"صندوق نظام مهندسي (صنم)");
                        }
                        catch
                        {

                            ViewBag.ressulte = "Error";
                            return UserPardakht();
                        }
                    }
                    catch
                    {
                        ViewBag.ressulte = "Error";
                        return UserPardakht();
                    }

                    ViewBag.ressulte = "باتشکر! پرداخت شما با موفقیت انجام شد";
                    try
                    {
                        var order = (from e in db.T_orders where e.Orderid == orderid select e).FirstOrDefault();
                        order.finished = true;
                        order.transact_id = long.Parse(trans_id);
                        db.Entry(order).State = EntityState.Modified;
                        db.SaveChanges();
                    }
                    catch { }
                    return UserPardakht();
                }
                else
                    return UserPardakht();
            }
            else
            {
                return UserPardakht();
            }


        }

        [NonAction]
        public System.Threading.Tasks.Task<MVCSandoogh.GhasedakServiceRefrence.SendSMSResponse>  SendMsg(string[] numbers, string message)
        {


            try
            {
                ArrayOfString senderNumbers = new ArrayOfString();

                senderNumbers.Add("90007081");
                v2SoapClient asc = new v2SoapClient();
                var recivers = new ArrayOfString();
                recivers.AddRange(numbers.ToList());
                var messages = new ArrayOfString();
                messages.AddRange(new string[] { message }.ToList<string>());
                //
                var result = asc.SendSMSAsync("sandogh.1378@gmail.com", "@SA12345@", senderNumbers, recivers, messages, null, null, null);
                return result;
            }
            catch (Exception ex)
            {
                return null;
            }
            //try
            //{

            //    var smsService = new SmsService();
            //    var ssvm = new SendViewModel
            //    {
            //        Password = "S!23@",
            //        Username = "sandoogh",
            //        Folder = "web",
            //        Number = "500010033384311",
            //        ReceiverPhoneNumbers = numbers.ToList(),
            //        SmsText = message
            //    };
            //    var result = Task.Run(() => smsService.Send(ssvm)).Result;
            //    return result;
            //}
            //catch (Exception ex)
            //{

            //    return null;
            //}
            /* try
             {

                 // SendSoap sso = new SendSoapClient();
                 // sso.SendSimpleSMS("nezam0441", "Nez441am@", numbers, "30001220000749", message, false);
                 SMSZoneSoap sso = new SMSZoneSoapClient();
                 ArrayOfString aos = new ArrayOfString();
                 aos.InsertRange(0, numbers);

                 DoSendRequestBody dsrb = new DoSendRequestBody(aos, message, "500010033384311", "sandoogh", "S!23@", true, "webservice");
                 DoSendRequest request = new DoSendRequest(dsrb);
                 sso.DoSend(request);
             }
             catch
             {

             }*/


        }
        public ActionResult TaeidOrRadMorkhasyById(string id,string taeid)
        {
            SandooghModel db = new SandooghModel();
            int idd = -1;
            try
            {
                idd = int.Parse(id);
            }
            catch
            {
                idd = -1;
            }
            if (idd == -1)
                return Json("", JsonRequestBehavior.AllowGet);
            else
            {
                AccountController acc = new AccountController();


               
                var letter = (from e in db.Automation_Letter where e.Letter_ID == idd select e).FirstOrDefault();
                letter.Letter_DateTaeid = DateTime.Now;
                letter.Letter_MorakhasyTaeid = taeid == "1" ? true : false;
                letter.Letter_TaeidKonande= long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
                db.Entry(letter).State = System.Data.Entity.EntityState.Modified;
                // db.T_OzvCode.Add(postData);
                db.SaveChanges();
                return Json(1, JsonRequestBehavior.AllowGet);
            }

        }
        public ActionResult DeleteMorkhasyById(string id)
        {
            SandooghModel db = new SandooghModel();
            int idd = -1;
            try
            {
                idd = int.Parse(id);
            }
            catch
            {
                idd = -1;
            }
            if (idd == -1)
                return Json("", JsonRequestBehavior.AllowGet);
            else
            {
                AccountController acc = new AccountController();



                var letter = (from e in db.Automation_Letter where e.Letter_ID == idd select e).FirstOrDefault();
                //  letter.Letter_DateTaeid = DateTime.Now;
                db.Automation_Refer.RemoveRange(letter.Automation_Refer);
                db.Automation_Letter.Remove(letter);
                db.SaveChanges();
                return Json(1, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult GetLetterMozuById(string id)
        {
            SandooghModel db = new SandooghModel();
            int idd = -1;
            try
            {
                idd = int.Parse(id);
            }
            catch
            {
                idd = -1;
            }
            if (idd == -1)
                return Json("", JsonRequestBehavior.AllowGet);
            else
            {

                var Mozu = (from e in db.Automation_Letter where e.Letter_ID == idd select e.Letter_Mozu).FirstOrDefault();
                return Json(Mozu.ToString(), JsonRequestBehavior.AllowGet);
            }

       }
        public ActionResult Refers()
        {
            return View();
        }
        public ActionResult Related()
        {
            return View();
        }
        [HttpPost]
       public ActionResult GetSearchRefer(int page, int rows, string IdLetter, string sidx = "Id", string sord = "asc")
        {
            long idletter = long.Parse(IdLetter);
            SandooghModel db = new SandooghModel();
            var list = (from k in db.Automation_Refer where k.Refer_letter == idletter select k).ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            //if (sidx.ToUpper() == "FNAME")
            //    sidx = "T_OzvCode.FName";
            //if (sidx.ToUpper() == "LNAME")
            //    sidx = "T_OzvCode.LName";
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();//کل داده ها را مرتب شده برمیگرداند و دو پارامتر اولی هیچ تاثیری ندارند.
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {

                    Id = (long)product.Refer_id,
                    RowCells = new List<object>
                               {
                                     product.Refer_id,product.Refer_letter,
                                    product.T_User_ErjaDahande.User_Firstname + " " + product.T_User_ErjaDahande.User_lastname + "(" + product.T_User_ErjaDahande.User_ID + ")",
                         product.T_UserErjaGirandeh.User_Firstname + " " + product.T_UserErjaGirandeh.User_lastname + "(" + product.T_UserErjaGirandeh.User_ID + ")",
                         product.Refer_DateErja!=null?((DateTime)product.Refer_DateErja).ToPersianDate():""
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetSearchMortabet(int page, int rows, string IdLetter, string sidx = "Id", string sord = "asc")
        {
            long idletter = long.Parse(IdLetter);
            SandooghModel db = new SandooghModel();
         

            try
            {
               

                   var list = (from k in db.Automation_LetterScanDB.ToList()
                              where k.Letter_Id.Equals(idletter)
                              join
      l in db.Automation_Letter.ToList() on k.Letter_Mortabet equals (l.Letter_ID)
      into leters
                              from h in leters.DefaultIfEmpty()
                              select new
                            {
                                Refer_DateErja = "",
                                Erjadahande = "",
                                Erjagirandeg = "",
                                Letter = h
                            }).ToList();
             
               

              
               

            

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list.AsQueryable();
                //if (sidx.ToUpper() == "FNAME")
                //    sidx = "T_OzvCode.FName";
                //if (sidx.ToUpper() == "LNAME")
                //    sidx = "T_OzvCode.LName";
                var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                .Skip(pageIndex * pageSize)
                                                .Take(pageSize);

                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.Letter.Letter_ID,
                        RowCells = new List<object>
                               {
                      product.Letter.Letter_ID,product.Letter.Letter_Comment, product.Letter.Letter_File ,product.Letter.Letter_Mozu,product.Letter.Letter_TarikhSabt!=null?((DateTime)product.Letter.Letter_TarikhSabt).ToPersianDate():"",product.Letter.Letter_TarikhTahie!=null?((DateTime)product.Letter.Letter_TarikhTahie).ToPersianDate():""
                      ,product.Letter.Automation_LetterType.LetterType_Name,product.Letter.T_User_Gyrandeh.User_Firstname+" "+product.Letter.T_User_Gyrandeh.User_lastname+"("+product.Letter.T_User_Gyrandeh.User_ID+")",
                      product.Letter.T_User_Ferestandeh.User_Firstname+" "+product.Letter.T_User_Ferestandeh.User_lastname+"("+product.Letter.T_User_Ferestandeh.User_ID+")"
,product.Refer_DateErja!=""?(DateTime.Parse(product.Refer_DateErja).ToPersianDate()):"",product.Erjadahande,product.Erjagirandeg
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
          
        }

        public ActionResult AddLetter(int letterid)
        {
            ViewBag.LetterId = letterid;
            List<SelectListItem> allLetterType = new List<SelectListItem>();
            SandooghModel db = new SandooghModel();
            foreach (Automation_LetterType ltype in db.Automation_LetterType)
            {
                //   [Authorize(Roles = "Admin , User,sadmin")]
                if (ltype.LetterType_ID == 1 || ltype.LetterType_ID == 2 || ltype.LetterType_ID == 3)
                {
                    SelectListItem sli = new SelectListItem();
                    sli.Value = ltype.LetterType_ID.ToString();
                    sli.Text = ltype.LetterType_Name;
                    allLetterType.Add(sli);
                }
            }
            ViewBag.AllLeterType = allLetterType;
            return View();
        }

        public ActionResult JalaseList()
        {

            List<SelectListItem> allLetterType = new List<SelectListItem>();
            SandooghModel db = new SandooghModel();
            foreach (Automation_LetterType ltype in db.Automation_LetterType)
            {
                //   [Authorize(Roles = "Admin , User,sadmin")]
                if (ltype.LetterType_ID == 8)
                {
                    SelectListItem sli = new SelectListItem();

                    sli.Value = ltype.LetterType_ID.ToString();
                    sli.Text = ltype.LetterType_Name;
                    allLetterType.Add(sli);
                }
            }
            ViewBag.AllLeterType = allLetterType;
            return View();
        }

        public ActionResult MorkhasyList()
        {

            List<SelectListItem> allLetterType = new List<SelectListItem>();
            SandooghModel db = new SandooghModel();
            foreach (Automation_LetterType ltype in db.Automation_LetterType)
            {
                //   [Authorize(Roles = "Admin , User,sadmin")]
                if (ltype.LetterType_ID>= 4 && ltype.LetterType_ID <=7)
                {
                    SelectListItem sli = new SelectListItem();

                    sli.Value = ltype.LetterType_ID.ToString();
                    sli.Text = ltype.LetterType_Name;
                    allLetterType.Add(sli);
                }
            }
            ViewBag.AllLeterType = allLetterType;
            return View();
        }

        public ActionResult AddMorkhasiMamooriat()
        {
            
            List<SelectListItem> allLetterType = new List<SelectListItem>();
            SandooghModel db = new SandooghModel();
            foreach (Automation_LetterType ltype in db.Automation_LetterType)
            {
                //   [Authorize(Roles = "Admin , User,sadmin")]
                if (ltype.LetterType_ID >= 4 && ltype.LetterType_ID <= 7)

                {
                    SelectListItem sli = new SelectListItem();

                    sli.Value = ltype.LetterType_ID.ToString();
                    sli.Text = ltype.LetterType_Name;
                    allLetterType.Add(sli);
                }
            }
            ViewBag.AllLeterType = allLetterType;
            return View();
        }

        

        [Authorize(Roles = "Admin ,sadmin")]
        public ActionResult AddJalase()
        {

            List<SelectListItem> allLetterType = new List<SelectListItem>();
            SandooghModel db = new SandooghModel();
            foreach (Automation_LetterType ltype in db.Automation_LetterType)
            {
                //   [Authorize(Roles = "Admin , User,sadmin")]
                if (ltype.LetterType_ID ==8)

                {
                    SelectListItem sli = new SelectListItem();

                    sli.Value = ltype.LetterType_ID.ToString();
                    sli.Text = ltype.LetterType_Name;
                    allLetterType.Add(sli);
                }
            }
            ViewBag.AllLeterType = allLetterType;
            //try { ViewBag.Hghjalase1 = db.Option_T.FirstOrDefault().Hghjalase1; } catch { }
            //try { ViewBag.Hghjalase = db.Option_T.FirstOrDefault().Hghjalase2; } catch { }
         

            return View();
        }
        [HttpPost]
        [Authorize(Roles = "Admin ,sadmin")]
        public ActionResult AddMorkhasy(Automation_Letter postData, string dateaz = "", string dateta = "", Array Files = null, string related = "-1", int lettertype = 1, string sherkatkonandegan="",string Day="",string Hour="",string Minute="")
        {
           
            if (dateaz != "")
            {
                try
                {
                    postData.Letter_MorakhasyAz = PersianDateUtils.ToMilady(dateaz.Split(' ')[0]);
                    try
                    {
                        postData.Letter_MorakhasyAz = ((DateTime)(postData.Letter_MorakhasyAz)).AddHours(int.Parse(dateaz.Split(' ')[1].Split(':')[0]));
                    }
                    catch
                    {

                    }
                    try
                    {
                        postData.Letter_MorakhasyAz = ((DateTime)(postData.Letter_MorakhasyAz)).AddMinutes(int.Parse(dateaz.Split(' ')[1].Split(':')[1]));
                    }
                    catch
                    {

                    }
                    try
                    {
                        if (Files != null)
                        {
                            postData.Letter_File = Files.GetValue(0).ToString();
                        }
                    }
                    catch
                    {

                    }

                }
                catch
                {

                }
            }
            if (dateta != "")
            {
                try
                {
                    postData.Letter_MorakhasyTa = PersianDateUtils.ToMilady(dateta.Split(' ')[0]);
                    try
                    {
                        postData.Letter_MorakhasyTa = ((DateTime)(postData.Letter_MorakhasyTa)).AddHours(int.Parse(dateta.Split(' ')[1].Split(':')[0]));
                    }
                    catch
                    {

                    }
                    try
                    {
                        postData.Letter_MorakhasyTa = ((DateTime)(postData.Letter_MorakhasyTa)).AddMinutes(int.Parse(dateta.Split(' ')[1].Split(':')[1]));
                    }
                    catch
                    {

                    }
                }
                catch
                {

                }
            }
            SandooghModel db = new SandooghModel();
            //ToDo: Add Product To Repository

            if (postData == null)
                return Json(false);
            else
            {
                Automation_Letter p = postData;
                AccountController acc = new AccountController();

                if (sherkatkonandegan != "")
                {
                    p.Letter_Ferestandeh = long.Parse(sherkatkonandegan);
                }
                else p.Letter_Ferestandeh = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));


                p.Letter_TarikhTahie = DateTime.Now;
                p.Letter_Day = Day;
                p.Letter_Hour = Hour;
                p.Letter_Minute = Minute;
                p.Letter_Gyrandeh = long.Parse(acc.GetUserID_By_UserName("SAdmin"));


                p.Letter_TarikhSabt = DateTime.Now;
                p.Letter_Type = lettertype;

                db.Automation_Letter.Add(p);
                db.SaveChanges();




                Automation_Refer refer = new Automation_Refer();
                //morkhasi
                if (postData.Letter_Type >= 4 && postData.Letter_Type <= 8)
                    foreach (string user in Roles.GetUsersInRole("Chairman"))
                    {
                        refer.Refer_DateErja = DateTime.Now;
                        refer.Refer_ErjaDahande = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));

                        refer.Refer_ErjaGirande = long.Parse(acc.GetUserID_By_UserName(user));
                        refer.Refer_letter = postData.Letter_ID;
                        db.Automation_Refer.Add(refer);
                        db.SaveChanges();
                    }
                return Json(true);
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin , User,sadmin")]
        public ActionResult AddLetter(Automation_Letter postData, string dateaz = "", string dateta = "", Array Files=null,string related="-1",int lettertype=1)
        {
           
            SandooghModel db = new SandooghModel();
            //ToDo: Add Product To Repository
            long erjagirande = -1;
            if (postData == null)
                return Json(false);
            else
            {
                Automation_Letter p = postData;
                AccountController acc = new AccountController();
                try
                {
                    if (Files != null)
                    {
                        p.Letter_File = Files.GetValue(0).ToString();
                    }
                }
                catch
                {

                }
                  
                p.Letter_Ferestandeh = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
                   
                p.Letter_TarikhTahie = DateTime.Now;
                if (related != null && related != "" && related != "-1")
                {
                    int rr = int.Parse(related);
                    p.Letter_Gyrandeh = (from r in db.Automation_Letter where r.Letter_ID == rr select r.Letter_Ferestandeh).ToList().FirstOrDefault();
                    erjagirande = (long)p.Letter_Gyrandeh;
                }
                else
                {
                    p.Letter_Gyrandeh = long.Parse(acc.GetUserID_By_UserName("SAdmin"));
                }

                p.Letter_TarikhSabt = DateTime.Now;
                if (User.IsInRole("Admin") || User.IsInRole("sadmin"))
                    p.Letter_Type = lettertype;
                else
                     p.Letter_Type = 1;//وارده
                db.Automation_Letter.Add(p);
                db.SaveChanges();

                if (related != null && related != "" && related != "-1")
                {
                    Automation_LetterScanDB als = new Automation_LetterScanDB();
                    als.Letter_Id = long.Parse(related);
                    als.Letter_Mortabet = postData.Letter_ID;

                    db.Automation_LetterScanDB.Add(als);
                    db.SaveChanges();

                    Automation_Refer refer = new Automation_Refer();
                    refer.Refer_DateErja = DateTime.Now;
                    refer.Refer_ErjaDahande = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
                    refer.Refer_ErjaGirande = erjagirande;
                    refer.Refer_letter = postData.Letter_ID;
                    db.Automation_Refer.Add(refer);
                    db.SaveChanges();


                }
                else
                {
                    Automation_Refer refer = new Automation_Refer();
                    refer.Refer_DateErja = DateTime.Now;
                    refer.Refer_ErjaDahande = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
                    refer.Refer_ErjaGirande = long.Parse(acc.GetUserID_By_UserName("SAdmin"));
                    refer.Refer_letter = postData.Letter_ID;
                    db.Automation_Refer.Add(refer);
                    db.SaveChanges();

                 
                   
                }



                return Json(true);
                }
            }

        [HttpPost]
        [Authorize(Roles = "Admin , User,sadmin")]
        public ActionResult AddRefer(string letterid,string gyrandeeehid)
        {
            SandooghModel db = new SandooghModel();
            //ToDo: Add Product To Repository
            AccountController acc = new AccountController();

            if (letterid != null && letterid != "" && gyrandeeehid != null && gyrandeeehid != "")
            {
                Automation_Refer refer = new Automation_Refer();
                refer.Refer_DateErja = DateTime.Now;
                refer.Refer_ErjaDahande = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
                refer.Refer_ErjaGirande = long.Parse(gyrandeeehid);
                refer.Refer_letter = long.Parse(letterid);
                db.Automation_Refer.Add(refer);
                db.SaveChanges();
                return Json(true);
            }
            else
                     return Json(false);
            }
  


        [HttpGet]
        public JsonResult GetUsersToAutocomplete()
        {
            SandooghModel db = new SandooghModel();


            var list = db.T_User.ToList();

            var result = from oz in list

                         select new
                         {
                             name = oz.User_Firstname + " " + oz.User_lastname + "(" + oz.User_ID + ")",

                             id = oz.User_ID
                         };

            return Json(result.ToList(), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize(Roles = "Admin , User,sadmin")]
        public ActionResult GetUserVamList(string sidx, string sord, int page, int rows, string noevam="", string azdate="", string tadate="", string type="g",string idrefozv="-1", bool filter = false)
        {
            if (idrefozv != "-1"||idrefozv=="-2")
            {
                
                try
                {
                    SandooghModel db = new SandooghModel();
                  
                    var list1 = db.Vams;
                    var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_OzvCdoe).ToList()[0];
                    if (idrefozv != "-1" && idrefozv != ""&&idrefozv!="-2")
                        try
                        {
                            usercode = int.Parse(idrefozv);
                        }
                        catch
                        {

                        }
                    var list = (from e in list1 where e.IdRefOzv.ToString() == usercode.ToString() select e).ToList();
                    if (filter)
                    {

                        long vamtype = -1;


                        try
                        {
                            vamtype = long.Parse(noevam);
                        }
                        catch
                        {
                            vamtype = -1;
                        }

                        if (vamtype != -1)
                            list = (from e in list where e.IdRefNoeVam == vamtype select e).ToList();
                        if (type == "t")
                            list = (from e in list where e.EtmamVam == true select e).ToList();
                        if (type == "tn")
                            list = (from e in list where e.EtmamVam == false select e).ToList();

                        DateTime azdatei = DateTime.MinValue;
                        DateTime tadatei = DateTime.MaxValue;
                        try
                        {
                            azdatei = (DateTime)azdate.ToMilady();
                        }
                        catch
                        {

                        }
                        try
                        {
                            tadatei = (DateTime)tadate.ToMilady();
                        }
                        catch
                        {

                        }
                        list = (from e in list where e.VamDate >= azdatei && e.VamDate <= tadatei select e).ToList();

                    }
                    var vamids = (from e in list select e.Vam_Id);
                    var natamampardakhty = from e in db.G_M_Pays where (vamids.Contains((long)e.IdRefVam)) select e;

                    var pardakhtHarVam = (from v in natamampardakhty group v by v.IdRefVam into g select new { Vamid = (long)g.Key, SumPardakhty = (double)g.Sum(v => v.TotGestMablag) }).ToList();
                    var bedoonepardakht = (from k in list where k.G_M_Pays.Count == 0 select new { Vamid = (long)k.Vam_Id, SumPardakhty = (double)0 }).ToList();
                    pardakhtHarVam = pardakhtHarVam.Union(bedoonepardakht).ToList();


                    var finallist = (from e in list
                                     join par in pardakhtHarVam on e.Vam_Id equals par.Vamid
                                     select
new
{
    e.IdRefNoeVam,
    e.T_VamCode.VamName,
    e.Vam_Id,
    FName = e.T_OzvCode.FName.ToString(),
    e.T_OzvCode.LName,
    VamDate = e.VamDate != null ? ((DateTime)e.VamDate).ToPersianDate() : "",
    e.Karmozd,
    VamMablagKhales = e.VamMablagKhales.ToString(),
    e.IdRefOzv,
    e.TedadAgsat,
    AvlinGestDate = e.AvlinGestDate != null ? ((DateTime)e.AvlinGestDate).ToPersianDate() : "",
    e.GestMablag,
    e.CheckVam,
    e.HesabNoVam,
    e.CheckOzv,
    e.HesabNo,
    e.BankName,
    e.Comment,
    e.EtmamVam,
    SumPardakhty = par.SumPardakhty,
    Mandevam = e.VamMablagKhales + e.Karmozd - par.SumPardakhty,
    nakhales = e.VamMablagKhales + e.Karmozd
}).ToList();

                    var pageIndex = page - 1;
                    var pageSize = rows;
                    var totalRecords = finallist.Count;
                    var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                    var productsQuery = finallist.AsQueryable();

                    var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                    .Skip(pageIndex * pageSize)
                                                    .Take(pageSize);

                    var productsData = new JqGridData
                    {
                        Total = totalPages,
                        Page = page,
                        Records = totalRecords,
                        Rows = (productsList.Select(product => new JqGridRowData
                        {
                            Id = product.Vam_Id,
                            RowCells = new List<object>
                               {
                      product.IdRefNoeVam,product.VamName, product.Vam_Id ,product.FName.ToString(),product.LName,product.VamDate, product.Karmozd,product.VamMablagKhales.ToString(),product.nakhales,product.SumPardakhty,product.Mandevam
                    ,product.IdRefOzv,product.TedadAgsat,product.AvlinGestDate,product.GestMablag,product.CheckVam,product.HesabNoVam,product.CheckOzv,product.HesabNo,product.BankName,
                 product.Comment,product.EtmamVam
                                }
                        })).ToList()
                    };
                    return Json(productsData, JsonRequestBehavior.AllowGet);
                }
                catch
                {
                    return null;
                }
            }
            else
                return null;
        }

        [HttpPost]
        [Authorize(Roles = "Admin ,Sadmin, User")]
        public ActionResult GetUserLetterList(string sidx, string sord, int page, int rows, string noename, string girande, string ferestande, string datesabtaz,string datesabtta,string mozu)
        {



            try
            {
                SandooghModel db = new SandooghModel();
              
                var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_ID).ToList()[0];
                var list = (from e in db.Automation_Letter where (e.Letter_Type <4 && e.Letter_Ferestandeh.ToString() == usercode.ToString() && e.Letter_TarikhSabt==null) select new { Refer_DateErja = "",
                    Erjadahande = "",
                    Erjagirandeg = "",
                  Letter= e } ).ToList();
                var listerjaat = (from e in db.Automation_Refer where (e.Automation_Letter.Letter_Type <4&&e.Refer_ErjaDahande == usercode || e.Refer_ErjaGirande == usercode) select new{
                    Refer_DateErja=e.Refer_DateErja.ToString(),
                    Erjadahande =(e.T_User_ErjaDahande.User_Firstname+" "+ e.T_User_ErjaDahande.User_lastname),
                    Erjagirandeg = (e.T_UserErjaGirandeh.User_Firstname + " " + e.T_UserErjaGirandeh.User_lastname),
                   Letter=e.Automation_Letter}).ToList();
              
                DateTime dateaz = (DateTime)(datesabtaz.ToMilady() == null ? DateTime.MinValue : datesabtaz.ToMilady());
                DateTime dateta = (DateTime)(datesabtta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)datesabtta.ToMilady()).AddDays(1));
                var kolletter = (from u in listerjaat select u).ToList()
                   .Union
                   (from e in list select e).ToList();

                if (dateaz==DateTime.MinValue && dateta==DateTime.MaxValue)
                {

                }
                else
                {
                    kolletter = (from u in listerjaat where u.Letter.Letter_TarikhSabt >= dateaz && u.Letter.Letter_TarikhSabt < dateta select u).ToList()
                                      .Union
                                      (from e in list where e.Letter.Letter_TarikhSabt >= dateaz && e.Letter.Letter_TarikhSabt < dateta select e).ToList();

                }

                if (noename!=null && noename.Length>0)
                {
                    try
                    {
                        int lettertype = int.Parse(noename);
                        kolletter = (from e in kolletter where e.Letter.Letter_Type == lettertype select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (girande != null && girande.Length > 0)
                {
                    try
                    {
                        int Gyrande = int.Parse(girande);
                        kolletter = (from e in kolletter where e.Letter.Letter_Gyrandeh == Gyrande select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (ferestande != null && ferestande.Length > 0)
                {
                    try
                    {
                        int Ferestandeh = int.Parse(ferestande);
                        kolletter = (from e in kolletter where e.Letter.Letter_Ferestandeh == Ferestandeh select e).ToList();
                    }
                    catch
                    {

                    }
                }

                var finallist = kolletter.ToList();

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = finallist.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = finallist.AsQueryable();
                //if (sidx.ToUpper() == "FNAME")
                //    sidx = "T_OzvCode.FName";
                //if (sidx.ToUpper() == "LNAME")
                //    sidx = "T_OzvCode.LName";
                var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                .Skip(pageIndex * pageSize)
                                                .Take(pageSize);

                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.Letter.Letter_ID,
                        RowCells = new List<object>
                               {
                      product.Letter.Letter_ID,product.Letter.Letter_Comment, product.Letter.Letter_File ,product.Letter.Letter_Mozu,product.Letter.Letter_TarikhSabt!=null?((DateTime)product.Letter.Letter_TarikhSabt).ToPersianDate():"",product.Letter.Letter_TarikhTahie!=null?((DateTime)product.Letter.Letter_TarikhTahie).ToPersianDate():""
                      ,product.Letter.Automation_LetterType.LetterType_Name,product.Letter.T_User_Gyrandeh.User_Firstname+" "+product.Letter.T_User_Gyrandeh.User_lastname+"("+product.Letter.T_User_Gyrandeh.User_ID+")",
                      product.Letter.T_User_Ferestandeh.User_Firstname+" "+product.Letter.T_User_Ferestandeh.User_lastname+"("+product.Letter.T_User_Ferestandeh.User_ID+")"
,product.Refer_DateErja!=""?(DateTime.Parse(product.Refer_DateErja).ToPersianDate()):"",product.Erjadahande,product.Erjagirandeg
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpPost]
        [Authorize(Roles = "Admin ,Sadmin,Chairman")]
        public ActionResult GetJalaseAzTa(string datesabtaz, string datesabtta)
        {
            SandooghModel db = new SandooghModel();
            DateTime dateaz = (DateTime)(datesabtaz.ToMilady() == null ? DateTime.MinValue : datesabtaz.ToMilady());
            DateTime dateta = (DateTime)(datesabtta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)datesabtta.ToMilady()).AddDays(1));
            var comments = db.Automation_Letter.Where(k => k.Letter_Type == 8 && k.Letter_MorakhasyAz >= dateaz&&
            k.Letter_MorakhasyAz < dateta).Select(k=>k.Letter_Comment).Distinct();
            var ozvs = db.Automation_Letter.Where(k => k.Letter_Type == 8 && k.Letter_MorakhasyAz >= dateaz &&
             k.Letter_MorakhasyAz < dateta).Select(k => k.Letter_Ferestandeh).Distinct();
            DataTable table = new DataTable();
            table.Columns.Add("ozv");
            foreach(var jalaseid in comments)
            {
                table.Columns.Add(jalaseid);
            }
            table.Columns.Add("MablaghHarJalase");
            table.Columns.Add("MablaghKol");

            foreach (var o in ozvs)
            {
                table.Rows.Add();
                var user = db.T_User.Where(k => k.User_ID == o).FirstOrDefault();
                var tozv = db.T_OzvCode.Where(k => k.Id == user.User_OzvCdoe).FirstOrDefault();

                try
                { 
                    table.Rows[table.Rows.Count - 1]["ozv"] = tozv.FName + " " + tozv.LName; 
                }
                catch
                {
                    table.Rows[table.Rows.Count - 1]["ozv"] = user.User_Firstname;
                }

                var mablaghharjalase = 0;
                var semat = "";
                try
                {
                    if (user.User_UserName == "sareban")
                        semat = "رئیس هیئت مدیره";
                    else
                        semat = tozv.Semat;
                }
                catch
                {

                }
                if (semat != null && semat == "عضو هیئت مدیره")
                    mablaghharjalase = (int)db.Option_T.FirstOrDefault().Hghjalase2;
                else
                if (semat != null && (semat == "خزانه دار"||
                    semat == "نائب رئیس هیئت مدیره" ||
                    semat == "رئیس هیئت مدیره")
                    )
                {
                    mablaghharjalase = (int)db.Option_T.FirstOrDefault().Hghjalase1;
                }
                else
                    mablaghharjalase = 0;
                   
                table.Rows[table.Rows.Count - 1]["MablaghHarJalase"] = mablaghharjalase;
                table.Rows[table.Rows.Count - 1]["MablaghKol"] = 0;

                foreach (var c in comments)
                {
                    try
                    {
                        table.Rows[table.Rows.Count - 1][c] = "عدم حضور/نامشخص";
                        var selected = db.Automation_Letter.Where(l => l.Letter_Comment == c && l.Letter_Ferestandeh == o).FirstOrDefault();
                       if ( selected!=null&&selected.Letter_MorakhasyTaeid==true)
                        {

                            table.Rows[table.Rows.Count - 1][c] = "حاضر";
                            table.Rows[table.Rows.Count - 1]["MablaghKol"]= mablaghharjalase+ long.Parse(table.Rows[table.Rows.Count - 1]["MablaghKol"].ToString());


                        }
                    }
                    catch { 
                    
                    }
                }
              
            }
            string jsonData = JsonConvert.SerializeObject(table);
            return Json(jsonData, JsonRequestBehavior.AllowGet);

        }

            [HttpPost]
        [Authorize(Roles = "Admin ,Sadmin,Chairman")]
        public ActionResult GetUserJalaseList(string sidx, string sord, int page, int rows, string noename, string girande, string ferestande, string datesabtaz, string datesabtta, string mozu)
        {
            try
            {
                SandooghModel db = new SandooghModel();

                var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_ID).ToList()[0];
                var list = (from e in db.Automation_Letter
                            where (e.Letter_Ferestandeh.ToString() == usercode.ToString() && e.Letter_TarikhSabt == null)
                            select e).ToList();
                var listerjaat = (from e in db.Automation_Refer
                                  where (e.Refer_ErjaDahande == usercode || e.Refer_ErjaGirande == usercode)
                                  select e.Automation_Letter).ToList();

                DateTime dateaz = (DateTime)(datesabtaz.ToMilady() == null ? DateTime.MinValue : datesabtaz.ToMilady());
                DateTime dateta = (DateTime)(datesabtta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)datesabtta.ToMilady()).AddDays(1));
                var kolletter = (from u in listerjaat where u.Letter_Type == 8 select u).ToList()
                   .Union
                   (from e in list where e.Letter_Type ==8 select e).ToList();

                if (dateaz == DateTime.MinValue && dateta == DateTime.MaxValue)
                {

                }
                else
                {
                    kolletter = (from u in listerjaat where u.Letter_MorakhasyAz >= dateaz && u.Letter_MorakhasyAz < dateta && u.Letter_Type == 8 select u).ToList()
                                      .Union
                                      (from e in list where e.Letter_MorakhasyAz >= dateaz && e.Letter_MorakhasyAz < dateta && e.Letter_Type == 8  select e).ToList();

                }

                if (noename != null && noename.Length > 0)
                {
                    try
                    {
                        int lettertype = int.Parse(noename);
                        kolletter = (from e in kolletter where e.Letter_Type == lettertype select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (girande != null && girande.Length > 0)
                {
                    try
                    {
                        int Gyrande = int.Parse(girande);
                        kolletter = (from e in kolletter where e.Letter_Gyrandeh == Gyrande select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (ferestande != null && ferestande.Length > 0)
                {
                    try
                    {
                        int Ferestandeh = int.Parse(ferestande);
                        kolletter = (from e in kolletter where e.Letter_Ferestandeh == Ferestandeh select e).ToList();
                    }
                    catch
                    {

                    }
                }

                var finallist = kolletter.ToList();

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = finallist.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = finallist.AsQueryable();
                //if (sidx.ToUpper() == "FNAME")
                //    sidx = "T_OzvCode.FName";
                //if (sidx.ToUpper() == "LNAME")
                //    sidx = "T_OzvCode.LName";
                var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                .Skip(pageIndex * pageSize)
                                                .Take(pageSize);

                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.Letter_ID,
                        RowCells = new List<object>
                               {
                      product.Letter_ID,product.Letter_Comment,product.Letter_Mozu,product.Letter_File, product.Letter_TarikhSabt!=null?((DateTime)product.Letter_TarikhSabt).ToPersianDate():""
                      ,product.Automation_LetterType.LetterType_Name,product.Letter_MorakhasyAz!=null?(((DateTime)product.Letter_MorakhasyAz).ToPersianDate()+' '+((DateTime)product.Letter_MorakhasyAz).Hour+':'+((DateTime)product.Letter_MorakhasyAz).Minute):"",product.Letter_MorakhasyTa!=null?(((DateTime)product.Letter_MorakhasyTa).ToPersianDate()+' '+((DateTime)product.Letter_MorakhasyTa).Hour+':'+((DateTime)product.Letter_MorakhasyTa).Minute):"",
                      product.T_User_Ferestandeh.User_Firstname+" "+product.T_User_Ferestandeh.User_lastname+"("+product.T_User_Ferestandeh.User_ID+")"
,product.Letter_MorakhasyTaeid==null?"نامشخص":(product.Letter_MorakhasyTaeid==false?"غیبت":"حضور در جلسه"),product.T_User_TaeidKonande!=null?(product.T_User_TaeidKonande.User_Firstname+' '+product.T_User_TaeidKonande.User_lastname+"("+product.T_User_TaeidKonande.User_ID+")"):""
,product.Letter_DateTaeid!=null?((DateTime)product.Letter_DateTaeid).ToPersianDate():""
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin ,Sadmin,Chairman")]
        public ActionResult GetUserMorkhasiList(string sidx, string sord, int page, int rows, string noename, string girande, string ferestande, string datesabtaz, string datesabtta, string mozu)
        {
         try
            {
                SandooghModel db = new SandooghModel();

                var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_ID).ToList()[0];
                var list = (from e in db.Automation_Letter
                            where ( e.Letter_Ferestandeh.ToString() == usercode.ToString() && e.Letter_TarikhSabt == null)
                            select e).ToList();
                var listerjaat = (from e in db.Automation_Refer
                                  where ( e.Refer_ErjaDahande == usercode || e.Refer_ErjaGirande == usercode)
                                  select e.Automation_Letter).ToList();

                DateTime dateaz = (DateTime)(datesabtaz.ToMilady() == null ? DateTime.MinValue : datesabtaz.ToMilady());
                DateTime dateta = (DateTime)(datesabtta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)datesabtta.ToMilady()).AddDays(1));
                var kolletter = (from u in listerjaat where u.Letter_Type >= 4 && u.Letter_Type <= 7 select u ).ToList()
                   .Union
                   (from e in list where e.Letter_Type >= 4 && e.Letter_Type <= 7 select e).ToList();

                if (dateaz == DateTime.MinValue && dateta == DateTime.MaxValue)
                {

                }
                else
                {
                    kolletter = (from u in listerjaat where u.Letter_TarikhSabt >= dateaz && u.Letter_TarikhSabt < dateta  && u.Letter_Type >= 4 && u.Letter_Type <= 7  select u).ToList()
                                      .Union
                                      (from e in list where e.Letter_TarikhSabt >= dateaz && e.Letter_TarikhSabt < dateta && e.Letter_Type >= 4 && e.Letter_Type <= 7 select e).ToList();

                }

                if (noename != null && noename.Length > 0)
                {
                    try
                    {
                        int lettertype = int.Parse(noename);
                        kolletter = (from e in kolletter where e.Letter_Type == lettertype select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (girande != null && girande.Length > 0)
                {
                    try
                    {
                        int Gyrande = int.Parse(girande);
                        kolletter = (from e in kolletter where e.Letter_Gyrandeh == Gyrande select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (ferestande != null && ferestande.Length > 0)
                {
                    try
                    {
                        int Ferestandeh = int.Parse(ferestande);
                        kolletter = (from e in kolletter where e.Letter_Ferestandeh == Ferestandeh select e).ToList();
                    }
                    catch
                    {

                    }
                }

                var finallist = kolletter.Distinct().ToList();

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = finallist.Count();
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = finallist.AsQueryable();
                //if (sidx.ToUpper() == "FNAME")
                //    sidx = "T_OzvCode.FName";
                //if (sidx.ToUpper() == "LNAME")
                //    sidx = "T_OzvCode.LName";
                var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                                .Skip(pageIndex * pageSize)
                                                .Take(pageSize);

                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.Letter_ID,
                        RowCells = new List<object>
                               {
                      product.Letter_ID,product.Letter_TarikhSabt!=null?((DateTime)product.Letter_TarikhSabt).ToPersianDate():""
                      ,product.Automation_LetterType.LetterType_Name,product.Letter_File, product.Letter_MorakhasyAz!=null?(((DateTime)product.Letter_MorakhasyAz).ToPersianDate()+' '+((DateTime)product.Letter_MorakhasyAz).Hour+':'+((DateTime)product.Letter_MorakhasyAz).Minute):"",product.Letter_MorakhasyTa!=null?(((DateTime)product.Letter_MorakhasyTa).ToPersianDate()+' '+((DateTime)product.Letter_MorakhasyTa).Hour+':'+((DateTime)product.Letter_MorakhasyTa).Minute):"",
                     product.Letter_Day, product.Letter_Hour,product.Letter_Minute, product.T_User_Ferestandeh.User_Firstname+" "+product.T_User_Ferestandeh.User_lastname+"("+product.T_User_Ferestandeh.User_ID+")"
,product.Letter_MorakhasyTaeid==null?"نامشخص":(product.Letter_MorakhasyTaeid==false?"عدم تائید":"تائید شده"),product.T_User_TaeidKonande!=null?(product.T_User_TaeidKonande.User_Firstname+' '+product.T_User_TaeidKonande.User_lastname+"("+product.T_User_TaeidKonande.User_ID+")"):""
,product.Letter_DateTaeid!=null?((DateTime)product.Letter_DateTaeid).ToPersianDate():""
                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }

        
              [Authorize(Roles = "Admin ,Sadmin,chairman")]
        public ActionResult GetUserjalaseSum(string noename, string girande, string ferestande, string datesabtaz, string datesabtta, string mozu)
        {
            try
            {
                SandooghModel db = new SandooghModel();

                var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_ID).ToList()[0];
                var list = (from e in db.Automation_Letter
                            where (e.Letter_Ferestandeh.ToString() == usercode.ToString() && e.Letter_TarikhSabt == null)
                            select e).ToList();
                var listerjaat = (from e in db.Automation_Refer
                                  where (e.Refer_ErjaDahande == usercode || e.Refer_ErjaGirande == usercode)
                                  select e.Automation_Letter).ToList();

                DateTime dateaz = (DateTime)(datesabtaz.ToMilady() == null ? DateTime.MinValue : datesabtaz.ToMilady());
                DateTime dateta = (DateTime)(datesabtta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)datesabtta.ToMilady()).AddDays(1));
                var kolletter = (from u in listerjaat where u.Letter_Type ==8 && u.Letter_MorakhasyTaeid == true select u).ToList()
                   .Union
                   (from e in list where e.Letter_Type ==8 && e.Letter_MorakhasyTaeid == true select e).ToList();

                if (dateaz == DateTime.MinValue && dateta == DateTime.MaxValue)
                {

                }
                else
                {
                    kolletter = (from u in listerjaat where u.Letter_TarikhSabt >= dateaz && u.Letter_TarikhSabt < dateta && u.Letter_Type==8 && u.Letter_MorakhasyTaeid == true select u).ToList()
                                      .Union
                                      (from e in list where e.Letter_TarikhSabt >= dateaz && e.Letter_TarikhSabt < dateta && e.Letter_Type ==8 && e.Letter_MorakhasyTaeid == true select e).ToList();

                }

                if (noename != null && noename.Length > 0)
                {
                    try
                    {
                        int lettertype = int.Parse(noename);
                        kolletter = (from e in kolletter where e.Letter_Type == lettertype select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (girande != null && girande.Length > 0)
                {
                    try
                    {
                        int Gyrande = int.Parse(girande);
                        kolletter = (from e in kolletter where e.Letter_Gyrandeh == Gyrande select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (ferestande != null && ferestande.Length > 0)
                {
                    try
                    {
                        int Ferestandeh = int.Parse(ferestande);
                        kolletter = (from e in kolletter where e.Letter_Ferestandeh == Ferestandeh select e).ToList();
                    }
                    catch
                    {

                    }
                }
                var hour = kolletter.Distinct().ToList().Count;
               



                var finallist = new { d = hour };


                return Json(finallist, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }

        [Authorize(Roles = "Admin ,Sadmin,chairman")]
        public ActionResult GetUserMorkhasiSum( string noename, string girande, string ferestande, string datesabtaz, string datesabtta, string mozu)
        {
            try
            {
                SandooghModel db = new SandooghModel();

                var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_ID).ToList()[0];
                var list = (from e in db.Automation_Letter
                            where (e.Letter_Ferestandeh.ToString() == usercode.ToString() && e.Letter_TarikhSabt == null)
                            select e).ToList();
                var listerjaat = (from e in db.Automation_Refer
                                  where (e.Refer_ErjaDahande == usercode || e.Refer_ErjaGirande == usercode)
                                  select e.Automation_Letter).ToList();

                DateTime dateaz = (DateTime)(datesabtaz.ToMilady() == null ? DateTime.MinValue : datesabtaz.ToMilady());
                DateTime dateta = (DateTime)(datesabtta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)datesabtta.ToMilady()).AddDays(1));
                var kolletter = (from u in listerjaat where u.Letter_Type >= 4 && u.Letter_Type <= 7 &&u.Letter_MorakhasyTaeid==true select u).ToList()
                   .Union
                   (from e in list where e.Letter_Type >= 4 && e.Letter_Type <= 7 && e.Letter_MorakhasyTaeid == true select e).ToList();

                if (dateaz == DateTime.MinValue && dateta == DateTime.MaxValue)
                {

                }
                else
                {
                    kolletter = (from u in listerjaat where u.Letter_TarikhSabt >= dateaz && u.Letter_TarikhSabt < dateta && u.Letter_Type >= 4 && u.Letter_Type <= 7 && u.Letter_MorakhasyTaeid == true select u).ToList()
                                      .Union
                                      (from e in list where e.Letter_TarikhSabt >= dateaz && e.Letter_TarikhSabt < dateta && e.Letter_Type >= 4 && e.Letter_Type <= 7 && e.Letter_MorakhasyTaeid == true select e).ToList();

                }

                if (noename != null && noename.Length > 0)
                {
                    try
                    {
                        int lettertype = int.Parse(noename);
                        kolletter = (from e in kolletter where e.Letter_Type == lettertype select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (girande != null && girande.Length > 0)
                {
                    try
                    {
                        int Gyrande = int.Parse(girande);
                        kolletter = (from e in kolletter where e.Letter_Gyrandeh == Gyrande select e).ToList();
                    }
                    catch
                    {

                    }
                }
                if (ferestande != null && ferestande.Length > 0)
                {
                    try
                    {
                        int Ferestandeh = int.Parse(ferestande);
                        kolletter = (from e in kolletter where e.Letter_Ferestandeh == Ferestandeh select e).ToList();
                    }
                    catch
                    {

                    }
                }



                var hour = kolletter.Distinct().ToList().Sum(a => (a.Letter_Hour!=""&&a.Letter_Hour!=null)?(int.Parse(a.Letter_Hour)):0);
                var minute = kolletter.Distinct().ToList().Sum(a => (a.Letter_Minute != "" && a.Letter_Minute != null) ? (int.Parse(a.Letter_Minute)) : 0);
                var day = kolletter.Distinct().ToList().Sum(a => (a.Letter_Day != "" && a.Letter_Day != null) ? (int.Parse(a.Letter_Day)) : 0);


                hour = hour + (minute / 60);
                minute = minute % 60;

                day = day +((int)((hour*2)+(minute / 30))/13);
                int m=(int)Math.Floor(((((hour * 2) + (minute / 30)) / 13) * 6.5));
               
                int pp =(int) (((((((hour * 2) + (minute / 30)) / 13)) * 6.5) - m) * 60);
                minute = minute - pp;
                hour =hour-m;

                var finallist =new {h=hour, m=minute,d=day} ;

            
                return Json(finallist, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }

        [Authorize(Roles = "Admin ,Sadmin")]
        public ActionResult GetDatetimediffer(string noename, string girande, string ferestande, string datesabtaz, string datesabtta, string mozu)
        {
            try
            {
                SandooghModel db = new SandooghModel();

                int houraz =int.Parse( datesabtaz.Split('_')[1]);
                int minaz = int.Parse(datesabtaz.Split('_')[2]);
                int hourta = int.Parse(datesabtta.Split('_')[1]);
                int minta = int.Parse(datesabtta.Split('_')[2]);

                datesabtaz = datesabtaz.Split('_')[0];
                datesabtta = datesabtta.Split('_')[0];

                DateTime dateaz = (DateTime)(datesabtaz.ToMilady() == null ? DateTime.MinValue : datesabtaz.ToMilady());
                DateTime dateta = (DateTime)(datesabtta.ToMilady() == null ? DateTime.MaxValue : ((DateTime)datesabtta.ToMilady()));
                dateaz= dateaz.AddHours(houraz);
                dateaz = dateaz.AddMinutes(minaz);
                dateta=dateta.AddHours(hourta);
                dateta= dateta.AddMinutes(minta);

                var finallist = ((dateta - dateaz).TotalMinutes);


                return Json(finallist, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
     

        [HttpPost]
        public ActionResult UserGetPardakhty(string sidx="id", string sord="desc", int page=1, int rows=100000 , string type="ge", string azdate="", string tadate="", bool filter = false,string idrefvam="",string idrefozv="-1",int ismost=0)
        {
            int idvam = -1;
            try
            {
                if (idrefvam != "")
                {
                    idvam = int.Parse(idrefvam);
                }
            }
            catch
            {

            }
            if (azdate == "")
                azdate = DateTime.MinValue.ToString();
            if(tadate=="")
            {
                tadate = DateTime.MaxValue.ToString();
            }
            SandooghModel db = new SandooghModel();
          

            var list1 = db.G_M_Pays;
           
             
                var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_OzvCdoe).ToList()[0];
            if (idrefozv != "-1")
                try
                {
                    usercode = int.Parse(idrefozv);
                }
                catch
                {

                }
           var list = (from e in list1 where e.IdRefOzv.ToString() == usercode.ToString() select e).ToList();
            if (ismost == 1)
                list = (from e in list where e.MostamariMablag > 0 select e).ToList();
                if (filter)
            {
              
                
                if (type == "m")
                    list = (from e in list where e.MostamariMablag > 0 select e).ToList();
                if (type == "ge")
                    list = (from e in list where e.TotGestMablag > 0 select e).ToList();

                if(idvam!=-1)
                    list= (from e in list where e.IdRefVam == idvam select e).ToList();
                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = (DateTime)tadate.ToMilady();
                }
                catch
                {

                }
                list = (from e in list where e.PayDate >= azdatei && e.PayDate <= tadatei select e).ToList();

            }

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
           
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                       product.Id ,product.T_OzvCode.FName.ToString(),product. T_OzvCode.LName,product.IsAfzayesh==true?"افزایش سرمایه":"",
                        product. PayDate!=null?((DateTime)product.PayDate).ToPersianDate():"",
                        product.TotMablag.ToString()
                    ,product.IdRefOzv.ToString(),product.Vam!=null?product.Vam.T_VamCode.VamName:"",product.TedadGest.ToString(),product.TedadMostamari.ToString(),
                        product.TotGestMablag.ToString(),product.MablaghharGhest.ToString(),product.MablaghHarMostamary.ToString(),product.TakhirMablag.ToString(),product.MostamariMablag.ToString(),product.Nahveh_P1!=null?product.Nahveh_P1.Nahveh_P1:"",
                  product.Fish_No,product.Comment,product.IdRefNoeVam.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult UserGetPardakhtywait(string sidx = "id", string sord = "desc", int page = 1, int rows = 100000, string type = "ge", string azdate = "", string tadate = "", bool filter = false, string idrefvam = "", string idrefozv = "-1",string waitorno="w")
        {
            int idvam = -1;
            try
            {
                if (idrefvam != "")
                {
                    idvam = int.Parse(idrefvam);
                }
            }
            catch
            {

            }
            if (azdate == "")
                azdate = DateTime.MinValue.ToString();
            if (tadate == "")
            {
                tadate = DateTime.MaxValue.ToString();
            }
            SandooghModel db = new SandooghModel();
            var list1 = db.G_M_Payswait;
          
            var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_OzvCdoe).ToList()[0];
            if (idrefozv != "-1")
                try
                {
                    usercode = int.Parse(idrefozv);
                }
                catch
                {

                }
            var list = (from e in list1 where e.IdRefOzv.ToString() == usercode.ToString() select e).ToList();
            if (waitorno == "w")
                list = (from e in list where e.IsTaeid == false &&e.statuse!=1 select e).ToList();
            if (waitorno == "nw")
                list = (from e in list where e.IsTaeid == true && e.statuse != 1 select e).ToList();
            if (waitorno == "na")
                list = (from e in list where e.statuse == 1 && e.IsTaeid == false select e).ToList();//تایید نشده و رد شده

            if (filter)
            {


                if (type == "m")
                    list = (from e in list where e.MostamariMablag > 0 select e).ToList();
                if (type == "ge")
                    list = (from e in list where e.TotGestMablag > 0 select e).ToList();

                if (idvam != -1)
                    list = (from e in list where e.IdRefVam == idvam select e).ToList();
                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = (DateTime)tadate.ToMilady();
                }
                catch
                {

                }
                list = (from e in list where e.PayDate >= azdatei && e.PayDate <= tadatei select e).ToList();

            }

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                       product.Id ,product.T_OzvCode.FName.ToString(),product.T_OzvCode.LName,product.IsAfzayesh==true?"افزایش سرمایه":"", product. PayDate!=null?((DateTime)product.PayDate).ToPersianDate():"",
                        product.TotMablag.ToString()
                    ,product.IdRefOzv.ToString(),product.Vam!=null?product.Vam.T_VamCode.VamName:"",product.TotGestMablag.ToString(),product.MablaghharGhest.ToString(),product.MablaghHarMostamary.ToString(),product.TakhirMablag.ToString(),product.MostamariMablag.ToString(),product.AfzayeshMablagh, product.Nahveh_P1!=null?product.Nahveh_P1.Nahveh_P1:"",
                  product.Fish_No,product.Comment,product.IdRefNoeVam.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UserGetCurrentVam(int id=0)
        {
            //دووامه:وام را از دراپ داون لیست انتخاب میکنیم 

            SandooghModel db = new SandooghModel();

           
           
            var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_OzvCdoe).ToList()[0];
            if (id != 0)
                usercode = (from e in db.T_User where e.User_OzvCdoe == id select e.User_OzvCdoe).ToList()[0];
            var list=(from e in db.Vams where e.EtmamVam == false && e.IdRefOzv== usercode select e).ToList();
          
            if (list != null&&list.Count>0)
            {
               
                var product = list.FirstOrDefault();

                var list1 = from e in db.G_M_Pays where e.IdRefVam == product.Vam_Id select e;

                if (product!=null)
                {
                    var vamtype = product.T_VamCode.VamName;
                    var mablaghvam = (product.VamMablagKhales + product.Karmozd);
                    var karmozd = product.Karmozd;
                    var aghsat = product.TedadAgsat;
                    var datevam = ((DateTime)product.VamDate).ToPersianDate();
                    var mablaghghest = product.GestMablag;
                    var tedadaaghsatevosolshode =(list1==null||list1.Count()==0)?0: (int)list1.Sum(e => e.TotGestMablag) / (int)product.GestMablag;
                    var mablaghvosolitakonoon = (list1 == null || list1.Count() == 0) ? 0 : list1.Sum(e => e.TotGestMablag);
                    var mandebedehi = mablaghvam - mablaghvosolitakonoon;
                    var persianCalendar = new System.Globalization.PersianCalendar();
                    var dateavalinghestvosoolnashode = persianCalendar.AddMonths((DateTime)product.AvlinGestDate, tedadaaghsatevosolshode).ToPersianDate();
                        //(((DateTime)product.Vam.AvlinGestDate)).ToPersianDate();               
                    int nowyear = persianCalendar.GetYear(DateTime.Now);
                    int nowmonth = persianCalendar.GetMonth(DateTime.Now);
                    int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);
                    var sarresid = 0.0;
                    int days = (((nowyear - persianCalendar.GetYear((DateTime)product.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)product.AvlinGestDate)))) * 30 + nowday - (persianCalendar.GetDayOfMonth((DateTime)product.AvlinGestDate));
                  
                    // var MablaghSarresidKolliVam = (product.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)product.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)product.AvlinGestDate)))));
                    var MablaghSarresidKolliVam = (product.GestMablag * Math.Ceiling((double)days/(double)30));

                    if (mablaghvosolitakonoon < MablaghSarresidKolliVam)
                        sarresid = (double)MablaghSarresidKolliVam - (double)mablaghvosolitakonoon;
                    else
                        sarresid = 0;

                    if (sarresid < 0) sarresid = 0.00;

                    if (sarresid > mandebedehi) sarresid = (double)mandebedehi;
                    return Json(new
                    {
                        vamtype,
                        mablaghvam,
                        karmozd,
                        aghsat,
                        datevam,
                        mablaghghest,
                        tedadaaghsatevosolshode,
                        mablaghvosolitakonoon,
                        mandebedehi,
                        dateavalinghestvosoolnashode,
                        sarresid
                    });
                }
                else
                    return null;
            }
            else
                return null;
        }
        [HttpPost]
        public ActionResult UserGetCurrentPardakhty(string sidx, string sord, int page, int rows, string azdate, string tadate,  bool filter = false)
        {
            //دووامه:وام را از دراپ داون لیست انتخاب میکنیم
          
            SandooghModel db = new SandooghModel();
            var list1 = db.G_M_Pays;
            var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e.User_OzvCdoe).ToList()[0];
           var list = (from e in list1 where e.IdRefOzv.ToString() == usercode.ToString() && e.Vam!=null && e.Vam.EtmamVam==false select e).ToList();

            if (filter)
            {

                long vamtype = -1;



                if (vamtype != -1)
                    list = (from e in list where e.IdRefNoeVam == vamtype select e).ToList();
             
               //type=قسط
                    list = (from e in list where e.TotGestMablag > 0 select e).ToList();

                DateTime azdatei = DateTime.MinValue;
                DateTime tadatei = DateTime.MaxValue;
                try
                {
                    azdatei = (DateTime)azdate.ToMilady();
                }
                catch
                {

                }
                try
                {
                    tadatei = (DateTime)tadate.ToMilady();
                }
                catch
                {

                }
                list = (from e in list where e.PayDate >= azdatei && e.PayDate <= tadatei select e).ToList();

            }

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                       product.Id ,product.T_OzvCode.FName.ToString(),product. T_OzvCode.LName,product. PayDate!=null?((DateTime)product.PayDate).ToPersianDate():"",product.TotMablag.ToString()
                    ,product.IdRefOzv.ToString(),product.Vam!=null?product.Vam.T_VamCode.VamName:"",product.TedadGest.ToString(),product.TotGestMablag.ToString(),product.MablaghharGhest.ToString(),product.MablaghHarMostamary.ToString(),product.TakhirMablag.ToString(),product.MostamariMablag.ToString(),product.Nahveh_P1!=null?product.Nahveh_P1.Nahveh_P1:"",
                  product.Fish_No,product.Comment,product.IdRefNoeVam.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Kartable()
        {
            List<SelectListItem> allLetterType = new List<SelectListItem>();
            SandooghModel db = new SandooghModel();
            foreach (Automation_LetterType ltype in db.Automation_LetterType)
            {
               
                    if (ltype.LetterType_ID <= 3)
                    {
                        SelectListItem sli = new SelectListItem();
                        sli.Value = ltype.LetterType_ID.ToString();
                        sli.Text = ltype.LetterType_Name;
                        allLetterType.Add(sli);
                    }
                   
               

            }
            ViewBag.AllLeterType = allLetterType;
            return View();
        }

        public ActionResult UserPardakht()
        {
           
            SandooghModel db = new SandooghModel();

            List<G_M_Pays> FinalPaylist = new List<G_M_Pays>();
            FinalPaylist = (from e in db.G_M_Pays select e).ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();
            List<SelectListItem> allnahvepardakht = new List<SelectListItem>();
            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();

            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }
            List<Nahveh_P> allnahvecodes = db.Nahveh_P.ToList();
            foreach (Nahveh_P nahvecode in allnahvecodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = nahvecode.Id.ToString();
                sli.Text = nahvecode.Nahveh_P1;
                allnahvepardakht.Add(sli);
            }

            ViewBag.AllVamTypes = allvamtypes;
            ViewBag.AllNahvePardakht = allnahvepardakht;
       
            try
            {
             
                var usercode = (from e in db.T_User where e.User_UserName == User.Identity.Name select e).FirstOrDefault();
                    ViewBag.Mostamarry = usercode.OzvCode.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh;
            }
            catch { ViewBag.Mostamarry = "500000"; }

            return View("UserPardakht", FinalPaylist);
        }
         public ActionResult UserVams()
        {
            SandooghModel db = new SandooghModel();
            List<Vam> FinalNobatlist = new List<Vam>();
            FinalNobatlist = db.Vams.ToList();
            List<SelectListItem> allvamtypes = new List<SelectListItem>();

            List<T_VamCode> allvamcodes = db.T_VamCode.ToList();
            foreach (T_VamCode vamcode in allvamcodes)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = vamcode.Id.ToString();
                sli.Text = vamcode.VamName;
                allvamtypes.Add(sli);
            }

            foreach (Vam model in FinalNobatlist)
            {
                model.AllVamTypes = allvamtypes;

            }
            if (FinalNobatlist.Count == 0)
                return null;

            return View(FinalNobatlist);
        }
       
      
       
      
        [HttpGet]
        public JsonResult GetSummostamaryByUserName(string UserName)
        {
            try
            {
                SandooghModel db = new SandooghModel();
                string name = this.User.Identity.Name;
                AccountController acc = new AccountController();
                string Id = acc.GetUserID_By_UserName(UserName);
                int id = int.Parse(Id);
                int Idd =(int) (from e in db.T_User where e.User_ID == id select e.User_OzvCdoe).FirstOrDefault();
                int idd = Idd;
                //todo: Delete product
              
                var ozvwithid = from o in db.T_OzvCode where o.Id == idd select o;
                if (ozvwithid.ToList() != null && ozvwithid.ToList().Count > 0)
                {

                    var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });

                    var product =
                           from ozv in db.T_OzvCode
                           where ozv.Id.Equals(idd)
                           join
                   most in summostamarises on ozv.Id equals most.Id
                   into ozvmost
                           from ozvmostamary in ozvmost.DefaultIfEmpty()
                           select new
                           {
                               ozv.Id,
                               ozvmostamary.SumMostamary,
                               ozv.FName,
                               ozv.LName
                           };
                    if (product == null)
                        return Json(false);

                    return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);
                }
                return Json(false);
            }//end try

            catch
            {
                return Json(false);
            }


        }
        [HttpGet]
        public JsonResult GetSummostamaryByMemberId(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var ozvwithid = from o in db.T_OzvCode where o.Id == idd select o;
                if (ozvwithid.ToList() != null && ozvwithid.ToList().Count > 0)
                {

                    var summostamarises = (from v in db.G_M_Pays group v by v.IdRefOzv into g where g.Key == idd select new { Id = g.Key, SumMostamary = g.Sum(v => v.MostamariMablag) });

                    var product =
                           from ozv in db.T_OzvCode
                           where ozv.Id.Equals(idd)
                           join
                   most in summostamarises on ozv.Id equals most.Id
                   into ozvmost
                           from ozvmostamary in ozvmost.DefaultIfEmpty()
                           select new
                           {
                               ozv.Id,
                               ozvmostamary.SumMostamary,
                               ozv.FName,
                               ozv.LName
                           };
                    if (product == null)
                        return Json(false);

                    return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);
                }
                return Json(false);
            }//end try

            catch
            {
                return Json(false);
            }


        }
        [HttpGet]
        public JsonResult GetZamenByZemanatId(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();


                var product =
                       from zam in db.VamZamen
                       where zam.Id == idd
                       select new
                       {
                           zam.Id,
                           zam.IdOzvRef,
                           zam.T_OzvCode.FName,
                           zam.T_OzvCode.LName,
                           zam.Mablag,
                           zam.CheckNo,
                           zam.HesabNo,
                           zam.BankName,
                           zam.Comment
                       };
                if (product == null)
                    return Json(false);

                return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(false);
            }
            return Json(false);
        }
        [HttpGet]
       public ActionResult UserZamenin()
        {
            return View();
        }

       
        [HttpPost]
     
        public ActionResult GetSearchZamen(int page, int rows, string IdVamRef, string sidx = "Id", string sord = "asc")
        {
            long idvamref = long.Parse(IdVamRef);
            SandooghModel db = new SandooghModel();
            var list = (from k in db.VamZamen where k.IdVamRef == idvamref select k).ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            if (sidx.ToUpper() == "FNAME")
                sidx = "T_OzvCode.FName";
            if (sidx.ToUpper() == "LNAME")
                sidx = "T_OzvCode.LName";
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();//کل داده ها را مرتب شده برمیگرداند و دو پارامتر اولی هیچ تاثیری ندارند.
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {

                    Id = (long)product.Id,
                    RowCells = new List<object>
                               {
                                     product.Id,product.IdOzvRef,
                                     product.T_OzvCode. FName,product.T_OzvCode.LName
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }

   
      
        [HttpGet]
        public JsonResult GetMemberById(string Id)
        {
            try
            {

                int idd = int.Parse(Id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var product =
                    from ozv in db.T_OzvCode
                    where ozv.Id.Equals(idd)
                    select new
                    {
                        ozv.Id,
                        ozv.FName,
                        ozv.LName,

                    };
                if (product == null)
                    return Json(false);

                return Json(product.FirstOrDefault(), JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json(false);
            }
            return Json(false);
        }


        // GET: Ozviat
        public ActionResult Index()
        {
            return View();
        }
     
      
       
        [HttpPost]
        public ActionResult GetAvalinGhestDate(Vam postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            DateTime avvalin = (DateTime)(postData.VamDate == null ? DateTime.Now : postData.VamDate);
            var persianCalendar = new PersianCalendar();
            persianCalendar.AddMonths(avvalin, 1);
            return Json(persianCalendar.AddMonths(avvalin, 1).ToPersianDate(), JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Authorize(Roles = "Admin ,Sadmin")]
        public ActionResult DeleteRefer(string id)
        {
            try
            {
                long idd = long.Parse(id);
                //todo: Delete product
                SandooghModel db = new SandooghModel();
                var product = db.Automation_Refer.FirstOrDefault(x => x.Refer_id == idd);
                if (product == null)
                    return Json(false);

                db.Automation_Refer.Remove(product);
                db.SaveChanges();
                return Json(true);
            }
            catch
            {
                return Json(false);
            }
        }



    }
}

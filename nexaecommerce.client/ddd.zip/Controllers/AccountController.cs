﻿using MVCSandoogh.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using WebMatrix.WebData;

namespace MVCSandoogh.Controllers
{
    public class AccountController : Controller
    {
        IAccountData objIAccountData;

        public AccountController()
        {
            objIAccountData = new AccountData();
        }

        public void SignOut()
        {
             
            Session.Clear();
            FormsAuthentication.SignOut();
            //redirect example
            Response.Redirect(new Uri(Request.Url, Url.Action("Index", "Home")).ToString());
          

        }

        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }
        public ActionResult CaptchaImage(string prefix, bool noisy = true)
        {
            var rand = new Random((int)DateTime.Now.Ticks);
            //generate new question 
            int a = rand.Next(10, 99);
            int b = rand.Next(0, 9);
            var captcha = string.Format("{0} + {1} = ?", a, b);

            //store answer 
            Session["Captcha" + prefix] = a + b;

            //image stream 
            FileContentResult img = null;

            using (var mem = new MemoryStream())
            using (var bmp = new Bitmap(130, 30))
            using (var gfx = Graphics.FromImage((Image)bmp))
            {
                gfx.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                gfx.SmoothingMode = SmoothingMode.AntiAlias;
                gfx.FillRectangle(Brushes.White, new Rectangle(0, 0, bmp.Width, bmp.Height));

                //add noise 
                if (noisy)
                {
                    int i, r, x, y;
                    var pen = new Pen(Color.Yellow);
                    for (i = 1; i < 10; i++)
                    {
                        pen.Color = Color.FromArgb(
                        (rand.Next(0, 255)),
                        (rand.Next(0, 255)),
                        (rand.Next(0, 255)));

                        r = rand.Next(0, (130 / 3));
                        x = rand.Next(0, 130);
                        y = rand.Next(0, 30);

                        gfx.DrawEllipse(pen, x-r, y-r, r, r);
                    }
                }

                //add question 
                gfx.DrawString(captcha, new Font("Tahoma", 15), Brushes.Gray, 2, 3);

                //render as Jpeg 
                bmp.Save(mem, System.Drawing.Imaging.ImageFormat.Jpeg);
                img = this.File(mem.GetBuffer(), "image/Jpeg");
            }

            return img;
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Login login, string returnUrl)
        {
            SandooghModel db = new SandooghModel();
           if (ModelState.IsValid)
            {
                bool success = Membership.ValidateUser(login.username, login.password);
            string name=    this.User.Identity.Name;
                var UserID = GetUserID_By_UserName(login.username);
              

              //  var LoginType = GetRoleBy_UserID(Convert.ToString(UserID));

                if (success == true)
                {
                    FormsAuthentication.SetAuthCookie(login.username, false);
                      Session["Name"] = login.username;
               
                        Session["UserID"] = UserID;
                    int u = -1;
                    try
                    {
                        u = int.Parse(UserID);
                        var user = (from e in db.T_User where e.User_ID==u select e);
                        Session["LogesuserName"] = user.FirstOrDefault().User_Firstname + " " + user.FirstOrDefault().User_lastname;
                    }
                    catch
                    {

                    }

                    //     Session["LoginType"] = LoginType;

                    if (returnUrl!=null&&returnUrl.Length!=0)
                         return Redirect(returnUrl);
                    else
                    if (Roles.IsUserInRole(login.username, "Admin"))
                    {
                        return RedirectToAction("AdminDashBoard", "Dashbord");
                    }
                    else
                    {
                       
                        return RedirectToAction("UserDashboard", "Dashbord");
                    }
                    // }
                }
                else
                {
                    ModelState.AddModelError("Error", "لطفا با نام کاربری و پسورد معتبر وارد شوید ");
                    return View(login);
                }
            }
            else
            {
                ModelState.AddModelError("Error", "Please enter Username and Password And Fill The Captcha");
            }
            return View(login);

        }
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Register()
        {
            Register register = new Models.Register();
            register.EmailID = "";
            register.password = "";
            return View(register);
        }
        [HttpGet]
        [Authorize(Roles = "User,Admin")]
        public ActionResult EditUser(string user)
        {
            long useridd = long.Parse(user);
            SandooghModel db = new SandooghModel();
          
          T_User  user1 = db.T_User.Where(x => x.User_ID ==useridd).FirstOrDefault();
            Register register = new Models.Register();
          register.EmailID = user1.User_Email;
            register.FullName = user1.User_Firstname;
            register.Mobile = user1.User_Mobile;
            register.password = Membership.GetUser(user1.User_UserName).GetPassword();
            return View(register);
        }


     
       
        public ActionResult RegisterAll()
        {
            SandooghModel db = new SandooghModel();
            var users = from e in db.T_User select e.User_UserName;
            var ozvs = from e in db.T_OzvCode where !users.Contains(e.Id.ToString()) select e;
            var ozvstocreate = ozvs.ToList();
            foreach (T_OzvCode ozv in ozvstocreate)
            {

                Membership.CreateUser(ozv.Id.ToString(), ozv.MelliCode);
                List<string> parameters = new List<string>(new string[] {

            "User_UserName","User_Firstname","User_lastname",
            "User_Email","User_Mobile","User_OzvCdoe"});
                List<object> values = new List<object>(new object[] {

           ozv.Id,ozv.FName+' '+ozv.LName,"",
           ozv.Id,ozv.Mobile,ozv.Id});
                DataGatheration gath = new DataGatheration();
                gath.GetTableStoredProcedure("NewInsertUser", parameters, values);
                Roles.AddUserToRole(ozv.Id.ToString(), "User");

            }
          
          
            return View();



        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(Register register)
        {
            //validate captcha 
      /*      if (Session["Captcha"] == null || Session["Captcha"].ToString() != register.Captcha)
            {
                ModelState.AddModelError("Captcha", "حاصل جمع صحیح نیست. لطفا مجددا وارد نمایید");
            }*/
            if (ModelState.IsValid)
            {
        
                if (Membership.GetUser(register.EmailID) == null)
                {
                    Membership.CreateUser(register.EmailID, register.password);
                    List<string> parameters = new List<string>(new string[] {

            "User_UserName","User_Firstname","User_lastname",
            "User_Email","User_Mobile","User_OzvCdoe"});
                    List<object> values = new List<object>(new object[] {

           register.EmailID,register.FullName,"",
           register.EmailID,register.Mobile,register.IdOzvRef});
                    DataGatheration gath = new DataGatheration();
                    gath.GetTableStoredProcedure("NewInsertUser", parameters, values);
                    Roles.AddUserToRole(register.EmailID, "User");

                    //WebSecurity.CreateUserAndAccount(x,
                    //    new { FullName = register.FullName, EmailID = register.EmailID, LastName=register.LastName,Mobile=register.Mobile });
                    FormsAuthentication.SetAuthCookie(register.EmailID, false);
                    //if (string.IsNullOrEmpty(Convert.ToString(LoginType)))
                    //{
                    //    ModelState.AddModelError("Error", "Rights to User are not Provide Contact to Admin");
                    //    return View(login);
                    //}
                    //else
                    //{
                    Session["Name"] = register.EmailID;
                    Session["UserID"] = GetUserID_By_UserName(register.EmailID);
                    //     Session["LoginType"] = LoginType;


                    if (Roles.IsUserInRole(register.EmailID, "Admin"))
                    {
                        return RedirectToAction("AdminDashBoard", "Dashbord");
                    }
                    else
                   
                    {
                        return RedirectToAction("UserDashboard", "Dashbord");
                    }
                    /*  Response.Buffer = true;
                      Response.Redirect("~/account/login");*/
                    ViewBag.ResultMessage = "کاربر جدید با موفقیت ایجاد شد !";
                    ViewBag.errtype = 1;
                }
                else
                {
                    ViewBag.errtype = 2;
                    ViewBag.ResultMessage = "کاربری با این مشخصات در سیستم وجود دارد !";
                }

            }
            else
            {
                ViewBag.errtype = -1;
                ViewBag.ResultMessage = "اشکال در ایجاد کاربر جدید!";
                ModelState.AddModelError("خطا", "لطفا جزئیات را کامل وارد نمائید");
               
            }
            return View();



        }

        [HttpPost]
        [Authorize(Roles = "User,Admin")]
        public ActionResult EditUser(Register register)
        {
            try
            {
            MembershipUser user= Membership.GetUser(register.EmailID);
            user.ChangePassword(user.GetPassword(),register.password);

            }
            catch
            {

            }
               
            List<string> parameters = new List<string>(new string[] {

          "User_UserName","User_Firstname","User_lastname",
            "User_Email","User_Mobile"});
            List<object> values = new List<object>(new object[] {

           register.EmailID,register.FullName,"",
           register.EmailID,register.Mobile});
            DataGatheration gath = new DataGatheration();
            gath.GetTableStoredProcedure("NewUpdateUser", parameters, values);
            ViewBag.ResultMessage = "ویرایش پروفایل با موفقیت انجام شد";

            return RedirectToAction("AllRegisterUserDetails", "Account");
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult RoleCreate()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult RoleCreate(Role role)
        {
            if (ModelState.IsValid)
            {
                if (Roles.RoleExists(role.RoleName))
                {
                    ModelState.AddModelError("Error", "Rolename already exists");
                    return View(role);
                }
                else
                {
                    Roles.CreateRole(role.RoleName);
                    return RedirectToAction("RoleIndex", "Account");
                }
            }
            else
            {
                ModelState.AddModelError("Error", "Please enter Username and Password");
            }
            return View(role);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult RoleAddToUser()
        {
            AssignRoleVM objvm = new AssignRoleVM();

            objvm.RolesList = GetAll_Roles();
            objvm.Userlist = GetAll_Users();
            return View(objvm);
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult RoleAddToUser(AssignRoleVM objvm)
        {

            if (objvm.RoleName == "0")
            {
                ModelState.AddModelError("نام نقش", "لطفا نام نقش را انتخاب نمائید");
            }

            if (objvm.UserName == "0")
            {
                ModelState.AddModelError("نام کاربری", "لطفا نام کاربری را انتخاب نمائید");
            }

            if (ModelState.IsValid)
            {

                try
                {
                    Roles.AddUserToRole(objvm.UserName, objvm.RoleName);
                    ViewBag.ResultMessage = "نقش مورد نظر با موفقیت به کاربر اضافه شد !";
                }
                catch
                {

                }
                objvm.RolesList = GetAll_Roles();
                objvm.Userlist = GetAll_Users();

                return View(objvm);
            }
            else
            {
                objvm.RolesList = GetAll_Roles();
                objvm.Userlist = GetAll_Users();
                ModelState.AddModelError("خطا", "لطفا نام کاربری و رمز عبور را وارد نمائید");
            }

            return View(objvm);
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
    
        public void DeleteRoleForUser(string UserName,string RoleName)
        {
            if (RoleName == "0")
            {
                ModelState.AddModelError("نام نقش", "لطفا نام نقش راانتخاب نمائید");
            }

            if (UserName == "0")
            {
                ModelState.AddModelError("نام کاربری", "لطفا نام کاربری را انتخاب نمائید");
            }

           

            if (ModelState.IsValid)
            {
                try
                {

 Roles.RemoveUserFromRole(UserName, RoleName);
                    ViewBag.ResultMessage = "نقش  با مووفقیت از این کاربر حذف شد !";
                }
                catch
                {

                }
                   
                   
              
            }
        
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteRoleForUser()
        {
            AssignRoleVM objvm = new AssignRoleVM();
            objvm.RolesList = GetAll_Roles();
            objvm.Userlist = GetAll_Users();
            return View(objvm);
        }


        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult DisplayAllUserroles()
        {
            int totalUsers = 0;
            var Userlist = objIAccountData.GetAllUsers();
           
            AllroleandUser objru = new AllroleandUser();
           List<AllroleandUser> AllDetailsUserlist = new List<AllroleandUser>();
            foreach(var user in Userlist)
            {
               string[] roles = Roles.GetRolesForUser(user.UserName);
               foreach(string role in roles)
                {
                    AllroleandUser uuu = new AllroleandUser();
                    uuu.UserName = user.UserName;
                    uuu.RoleName = role;
                    AllDetailsUserlist.Add(uuu);
                }   
               
            }
            objru.AllDetailsUserlist = AllDetailsUserlist;
          

            return View(objru);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult RoleIndex()
        {
            var roles = objIAccountData.GetRoles();
            return View(roles);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult RoleDelete(string RoleName)
        {
            Roles.DeleteRole(RoleName);
            return RedirectToAction("RoleIndex", "Account");
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult GetRoles(string UserName)
        {
            if (!string.IsNullOrWhiteSpace(UserName))
            {
                ViewBag.RolesForThisUser = Roles.GetRolesForUser(UserName);
                SelectList list = new SelectList(Roles.GetAllRoles());
                ViewBag.Roles = list;
            }
            return View("RoleAddToUser");
        }

        public ActionResult LogOff()
        {
            WebSecurity.Logout();
            Response.Redirect("~/account/login");
            return View();
        }

        [HttpGet]

        public ActionResult Changepassword()
        {
            return View(new ChangepasswordVM());
        }

        [HttpPost]
        [Authorize(Roles = "User,Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult Changepassword(ChangepasswordVM VM)
        {
            if (ModelState.IsValid)
            {


                MembershipUser u = Membership.GetUser(User.Identity.Name);
 
                var value = u.ChangePassword( VM.OldPassword, VM.Newpassword);

                    if (value == false)
                    {
                        ModelState.AddModelError("Error", "Incorrect Old Password");
                        return View(VM);
                    }
                    else
                    {
                        ViewBag.ResultMessage = "تغییر پسورد با موفقیت انجام شد";
                    }

                }
          
            else
            {
                ModelState.AddModelError("Error", "لطفا اطلاعاتخواسته شده را پر نمایید");
            }
            return View(VM);
        }
        [Authorize(Roles = "Admin")]
        public string Getpassword(string username)
        {

         return   Membership.GetUser(username).GetPassword();
        }
        [Authorize(Roles = "Admin")]
        public List<T_User> GetAllUsers()
        {
            SandooghModel db = new SandooghModel();
            DbSet<T_User> users = db.T_User;
          foreach(var user in users)
            {
                user.User_Password = Getpassword(user.User_Email);
            }
            return users.ToList();

        }
        [Authorize(Roles = "Admin")]
        [AllowAnonymous]
        public ActionResult AllRegisterUserDetails()
        {
            var Users = GetAllUsers();
            return View(Users);
        }

        [NonAction]
    
        public string GetRoleBy_UserID(string UserId)
        {
            return objIAccountData.GetRoleByUserID(UserId);
        }

        [NonAction]
        public string GetUserID_By_UserName(string UserName)
        {
            return objIAccountData.GetUserID_By_UserName(UserName);
        }
      
        [HttpGet]
        [AllowAnonymous]
        public ActionResult CheckUserNameExists(string username)
        {
            bool UserExists = false;

            try
            {
                var nameexits = objIAccountData.Get_checkUsernameExits(username);

                if (string.Equals(nameexits, "1"))
                {
                    UserExists = true;
                }
                else
                {
                    UserExists = false;
                }
                return Json(!UserExists, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        [NonAction]
        [Authorize(Roles = "Admin")]
        public List<SelectListItem> GetAll_Roles()
        {
            List<SelectListItem> listrole = new List<SelectListItem>();

            listrole.Add(new SelectListItem { Text = "-لطفا نقش را انتخاب نمائید-", Value = "0" });

            foreach (var item in Roles.GetAllRoles())
            {
                listrole.Add(new SelectListItem { Text = item, Value = item });
            }

            return listrole;
        }

        [NonAction]
        [Authorize(Roles = "Admin")]
        public List<SelectListItem> GetAll_Users()
        {
            Membership.DeleteUser("ehdirazzaghi2");
            var Userlist = objIAccountData.GetAllUsers();
            List<SelectListItem> listuser = new List<SelectListItem>();
            listuser.Add(new SelectListItem { Text = "لطفا نام کاربری را انتخاب نمائید", Value = "0" });
            foreach (var item in Userlist)
            {
                listuser.Add(new SelectListItem { Text = item.UserName, Value = item.UserName });
            }

            return listuser;
        }
     
    }
}


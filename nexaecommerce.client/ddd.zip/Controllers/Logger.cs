﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCSandoogh.Controllers
{
    public class Logger
    {

    }
}
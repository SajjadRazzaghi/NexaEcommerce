﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.Data;

namespace MVCSandoogh.Controllers
{
    public class CityCodeController : Controller
    {
        // GET: CityCode
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Starter()
        {
            return View();
        }
    [HttpPost]
     public ActionResult ChangeVamTable()
        {
            DataGatheration gath = new DataGatheration();
            DataTable table = gath.GetSqlTableWithComand(@"SELECT     Id, VamDate,AvlinGestDate     FROM         Vam");
            foreach(DataRow row in table.Rows)
            {
                try
                {

                    DateTime vamdate = DateTime.Parse("1900/01/01");
                    DateTime avlingestdate = DateTime.Parse("1900/01/01");
                    try
                    {
                        vamdate = (DateTime)(row["VamDate"].ToString().ToMilady());
                    }
                    catch
                    {

                    }
                    try
                    {
                        avlingestdate = (DateTime)(row["AvlinGestDate"].ToString().ToMilady());
                    }
                    catch
                    {

                    }
                    int id = int.Parse(row["Id"].ToString());
                    gath.GetSqlTableWithComand(@"UPDATE    Vam SET              VamDate1 = '"+vamdate+@"', AvlinGestDate1 = '"+avlingestdate+"' where  Id ="+id+"");
                }
                catch
                {

                }

            }

            return null;
        }

        [HttpPost]
        public ActionResult ChangeSanadTable()
        {
            DataGatheration gath = new DataGatheration();
            DataTable table = gath.GetSqlTableWithComand(@"SELECT     ID, paydate FROM         Tasvieh");
            foreach (DataRow row in table.Rows)
            {
                try
                {

                    DateTime sanaddate = DateTime.Parse("1900/01/01");

                    try
                    {
                        sanaddate = (DateTime)(row["paYDATE"].ToString().ToMilady());
                    }
                    catch
                    {

                    }

                    int id = int.Parse(row["ID"].ToString());
                    gath.GetSqlTableWithComand(@"UPDATE    Tasvieh SET              p1 = '" + sanaddate + @"' where  ID =" + id + "");
                }
                catch
                {

                }

            }

            return null;
            //DataGatheration gath = new DataGatheration();

            //        gath.GetSqlTableWithComand(@"UPDATE    T_OzvCode SET  GUID='" + Guid.NewGuid() + "' ");


            //return null;
            /*DataGatheration gath = new DataGatheration();
            DataTable table = gath.GetSqlTableWithComand(@"SELECT     ID, OzvDate,TavalodDate FROM         T_OzvCode");
            foreach (DataRow row in table.Rows)
            {
                try
                {

                    DateTime sanaddate = DateTime.Parse("1900/01/01");
                    DateTime sanaddate1 = DateTime.Parse("1900/01/01");

                    try
                    {
                        sanaddate = (DateTime)(row["OzvDate"].ToString().ToMilady());
                    }
                    catch
                    {

                    }
                    try
                    {
                        sanaddate1 = (DateTime)(row["TavalodDate"].ToString().ToMilady());
                    }
                    catch
                    {

                    }

                    int id = int.Parse(row["ID"].ToString());
                    gath.GetSqlTableWithComand(@"UPDATE    T_OzvCode SET  o1='"+sanaddate+"' ,            t1 = '" + sanaddate1 + @"' where  ID =" + id + "");
                }
                catch
                {

                }

            }

            return null;*/
            /*DataGatheration gath = new DataGatheration();
            DataTable table = gath.GetSqlTableWithComand(@"SELECT     ID, paydate FROM         G_M_Pays");
            foreach (DataRow row in table.Rows)
            {
                try
                {

                    DateTime sanaddate = DateTime.Parse("1900/01/01");

                    try
                    {
                        sanaddate = (DateTime)(row["paYDATE"].ToString().ToMilady());
                    }
                    catch
                    {

                    }

                    int id = int.Parse(row["ID"].ToString());
                    gath.GetSqlTableWithComand(@"UPDATE    G_M_Pays SET              paydate1 = '" + sanaddate + @"' where  ID =" + id + "");
                }
                catch
                {

                }

            }

            return null;*/
            /* DataGatheration gath = new DataGatheration();
             DataTable table = gath.GetSqlTableWithComand(@"SELECT     ID, Date_S FROM         AccSanad_B");
             foreach (DataRow row in table.Rows)
             {
                 try
                 {

                     DateTime sanaddate = DateTime.Parse("1900/01/01");

                     try
                     {
                         sanaddate = (DateTime)(row["Date_S"].ToString().ToMilady());
                     }
                     catch
                     {

                     }

                     int id = int.Parse(row["ID"].ToString());
                     gath.GetSqlTableWithComand(@"UPDATE    AccSanad_B SET              Date_Reg = '" + sanaddate + @"' where  ID =" + id + "");
                 }
                 catch
                 {

                 }

             }

             return null;*/
        }

        [HttpPost]
        public ActionResult ChangeVamNobatTable()
        {
            DataGatheration gath = new DataGatheration();
            DataTable table = gath.GetSqlTableWithComand(@"SELECT     Id, NobatDate, NobatDate1 FROM         VamNobat");
            foreach (DataRow row in table.Rows)
            {
                try
                {

                    DateTime vamdate = DateTime.Parse("1900/01/01");
                    DateTime avlingestdate = DateTime.Parse("1900/01/01");
                    try
                    {
                        vamdate = (DateTime)(row["NobatDate"].ToString().ToMilady());
                    }
                    catch
                    {

                    }
                  
                    int id = int.Parse(row["Id"].ToString());
                    gath.GetSqlTableWithComand(@"UPDATE    VamNobat SET              NobatDate1 = '" + vamdate + @"' where  Id =" + id + "");
                }
                catch
                {

                }

            }

            return null;
        }

        [HttpPost]
        public ActionResult GetCities(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.CityCodes.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord) .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.id,
                    RowCells = new List<object>
                               {
                                     product.GUID.ToString(),(int) product.id,
                                     product.CityName.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        // GET: CityCode/Create

        [HttpPost]
        public ActionResult AddCity(CityCode postData)
        {
            SandooghModel db = new SandooghModel();
            postData.GUID = Guid.NewGuid();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
               db.CityCodes.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult EditCity(CityCode postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult DeleteCity(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.CityCodes.FirstOrDefault(x => x.id == idd);
            if (product == null)
                return Json(false);

            db.CityCodes.Remove(product);
            db.SaveChanges();
            return Json(true);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net;
using System.Globalization;
using MVCSandoogh;

using System.Linq;

using MVCSandoogh.Models;
using MVCSandoogh.Extensions;


public  class DataGatheration
    {
   
    public static object PersianToMiladyDate(string dt)
    {
        if (dt == "")
            return DBNull.Value;
        try
        {
            System.Globalization.PersianCalendar g = new PersianCalendar();
            dt = dt.Replace("۰", "0").Replace("۱", "1").Replace("۲", "2").Replace("۳", "3").Replace("۴", "4").Replace("۵", "5").Replace("۶", "6").Replace("۷", "7").Replace("۸", "8").Replace("۹", "9");
            return g.ToDateTime(int.Parse(dt.Split('/')[0]), int.Parse(dt.Split('/')[1]), int.Parse(dt.Split('/')[2]), 0, 0, 0, 0).ToString();
        }
        catch
        {
            return DBNull.Value;
        }

    }
    public static string MiladyDateToPersian(DateTime? dt)
    {
        try
        {
            System.Globalization.PersianCalendar g = new PersianCalendar();
            return g.GetYear(dt.GetValueOrDefault()) + "/" + g.GetMonth(dt.GetValueOrDefault()) + "/" + g.GetDayOfMonth(dt.GetValueOrDefault());
        }
        catch
        {
            return "";
        }

    }
    public  string GetIpAddress()  // Get IP Address
        {
            string ip = "";
            IPHostEntry ipEntry = Dns.GetHostEntry(GetCompCode());
            IPAddress[] addr = ipEntry.AddressList;
            ip = addr[1].ToString();
            return ip;


            //HttpContext c = HttpContext.Current;
            //string ips = c.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            //if (!string.IsNullOrEmpty(ips))
            //{
            //    return ips.Split(',')[0];
            //}
            //return c.Request.ServerVariables["REMOTE_ADDR"];



        //    System.Web.HttpContext context = System.Web.HttpContext.Current;
        //    string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

        //    if (!string.IsNullOrEmpty(ipAddress))
        //    {
        //        string[] addresses = ipAddress.Split(',');
        //        if (addresses.Length != 0)
        //        {
        //            return addresses[0];
        //        }
        //    }

        //    return context.Request.ServerVariables["REMOTE_ADDR"];
        }
        public  string GetCompCode()  // Get Computer Name
        {
            string strHostName = "";
            strHostName = Dns.GetHostName();
            return strHostName;
        }
        private string getjQueryCode(string jsCodetoRun)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("$(document).ready(function() {");
            sb.AppendLine(jsCodetoRun);
            sb.AppendLine(" });");

            return sb.ToString();
        }
        public void runjQueryCode(string jsCodetoRun,Page page)
        {

            ScriptManager requestSM = ScriptManager.GetCurrent(page);
            if (requestSM != null && requestSM.IsInAsyncPostBack)
            {
                ScriptManager.RegisterClientScriptBlock(page,
                                                        typeof(Page),
                                                        Guid.NewGuid().ToString(),
                                                        getjQueryCode(jsCodetoRun),
                                                        true);
            }
            else
            {
               page. ClientScript.RegisterClientScriptBlock(typeof(Page),
                                                       Guid.NewGuid().ToString(),
                                                       getjQueryCode(jsCodetoRun),
                                                       true);
            }
        }
        public  SqlConnection Connection = null;


        public  SqlConnection GetConnection()
        {

            string connectionstring = ConfigurationManager.ConnectionStrings["Mystring"].ConnectionString;

                Connection = new SqlConnection(connectionstring);

           
            return Connection;
        }

        public DataTable GetTableStoredProcedure(string storedprocedurename, List<string> parameters, List<object> values)
        {
            DataSet result = new DataSet();
            result.Tables.Clear();
            using (SqlConnection con = GetConnection())
            {
                try
                {

                    if (con.State != ConnectionState.Open)

                        con.Open();
                    SqlCommand command = new SqlCommand(storedprocedurename, con);
                    command.CommandType = CommandType.StoredProcedure;
                    if (parameters != null && parameters.Count > 0)
                    {
                        if (parameters.Count == values.Count)
                        {
                            for (int i = 0; i < parameters.Count; i++)
                            {
                                command.Parameters.AddWithValue(parameters[i], values[i]);
                            }
                            SqlDataAdapter adapter = new SqlDataAdapter(command);
                            adapter.Fill(result);
                            if (result.Tables.Count > 0)
                            {
                                con.Close();
                                return result.Tables[0];

                            }



                        }
                        else
                        {
                            con.Close();
                            return null;
                        }
                    }
                    else
                    {

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(result);
                        if (result.Tables.Count > 0)
                        {
                            con.Close();
                            return result.Tables[0];
                        }
                        con.Close();
                    }
                }

                catch
                {
                    con.Close();
                    return null;
                }
            }
          
            return null;
        }
        public bool ExecuteNonqueryStoredProcedure(string storedprocedurename, List<string> parameters, List<object> values)
        {
            try
            {
                SqlConnection con = GetConnection();
                if (con.State != ConnectionState.Open) con.Open();
                SqlCommand command = new SqlCommand(storedprocedurename, con);
                command.CommandType = CommandType.StoredProcedure;
                if (parameters != null && parameters.Count > 0)
                {
                    if (parameters.Count == values.Count)
                    {
                        for (int i = 0; i < parameters.Count; i++)
                        {
                            command.Parameters.AddWithValue(parameters[i], values[i]);
                        }

                        command.ExecuteNonQuery();
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    command.ExecuteNonQuery();
                    return true;
                }

            }
            catch
            {
                return false;
            }

        }

       
        public  DataTable GetSqlTableWithTableName(string tableName)
        {
            try
            {
                SqlConnection con = GetConnection();
                if (con.State != ConnectionState.Open) con.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter adapter = new SqlDataAdapter("select * from " + tableName, con.ConnectionString);
                adapter.Fill(ds);
                ds.Tables[0].TableName = tableName;
                con.Close();
                return ds.Tables[0];
            }
            catch
            {
                return null;
            }
        }


        public  DataTable GetSqlTableWithTableNameAndWhereClause(string tableName,string WhereClause)
        {
            try
            {
                SqlConnection con = GetConnection();
                if (con.State != ConnectionState.Open) con.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter adapter = new SqlDataAdapter("select * from " + tableName +" "+ WhereClause, con.ConnectionString);
                adapter.Fill(ds);
                ds.Tables[0].TableName = tableName;
                con.Close();
                return ds.Tables[0];
            }
            catch
            {
                return null;
            }
        }
      
        public  DataTable GetSqlTableWithComand(string CommandName)
        {
            try
            {
                SqlConnection con = GetConnection();
                try
                {
                    if (con.State != ConnectionState.Open) con.Open();
                }
                catch
                {
                }

                DataSet ds = new DataSet();
                ds.Tables.Clear();
                SqlDataAdapter adapter = new SqlDataAdapter(CommandName, con.ConnectionString);
                adapter.Fill(ds);
                con.Close();
                return ds.Tables[0];
            }
            catch
            {
                return null;
            }

        }

        public  bool ExecuteNonQueryWithComand(string CommandName)
        {
            try
            {
               
                SqlConnection con = GetConnection();
                if (con.State != ConnectionState.Open) con.Open();
                SqlCommand command = new SqlCommand(CommandName, con);
                command.ExecuteNonQuery();
                con.Close();
                return true;
                  }
            catch
            {
                return false;
            }

        }
        public long ExecuteNonQueryWithComandandReturn(string CommandName)
        {
            long result = 0;
            try
            {

                SqlConnection con = GetConnection();
                if (con.State != ConnectionState.Open) con.Open();
                SqlCommand command = new SqlCommand(CommandName, con);
                result=long.Parse(command.ExecuteScalar().ToString());
                con.Close();
                return result;
            }
            catch
            {
                return -1;
            }

        }
        
      


    }


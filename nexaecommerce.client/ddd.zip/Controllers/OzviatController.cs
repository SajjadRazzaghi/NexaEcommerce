﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.IO;
using MVCSandoogh.GhasedakServiceRefrence;
using MVCSandoogh;
using MVCSandoogh.Controllers;
using System.Web.Security;
using PIDCoSmsPackage;
using PIDCoSmsPackage.Model;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace MVCSmartLibrary.Controllers
{
   public class OzviatController : Controller
    {


        // GET: Ozviat
        [Authorize(Roles = "Admin")]
        public ActionResult Index()

        {
            SandooghModel db = new SandooghModel();
            List<SelectListItem> CityList = new List<SelectListItem>();
            List<CityCode> citylist = db.CityCodes.ToList();
            foreach (CityCode city in citylist)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = city.id.ToString();
                sli.Text = city.CityName;
                CityList.Add(sli);
            }
            ViewBag.cities = CityList;

            return View();
        }

        
        [HttpPost]
        public ActionResult GetTasviehChartData(string azdate, string tadate)
        {

            SandooghModel db = new SandooghModel();
            DateTime azdatei1 = DateTime.MinValue;
            DateTime tadatei1 = DateTime.MaxValue;
            try
            {
                azdatei1 = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei1 = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            Dictionary<string, int> Result = new Dictionary<string, int>();
            //  if (!(azdatei1 == DateTime.MinValue && tadatei1 == DateTime.MaxValue))
            {
                if (azdatei1 == DateTime.MinValue)
                    azdatei1 = DateTime.Parse("2019/03/21 12:00:00 AM");// (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Min(e => e.PayDate).Value;
                if (tadatei1 == DateTime.MaxValue)
                    tadatei1 = (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Max(e => e.PayDate).Value;

                PersianCalendar pl = new PersianCalendar();
                int nowmonth = pl.GetMonth(tadatei1);
                int nowyear = pl.GetYear(tadatei1);
                int beforyea = pl.GetYear(azdatei1);
                int beformonth = pl.GetMonth(azdatei1);
                Dictionary<int, int> BeforDic = new Dictionary<int, int>();

                Dictionary<int, int> yearDic = new Dictionary<int, int>();
                int j = beformonth;
                for (int i = beformonth; beforyea * 12 + beformonth <= nowyear * 12 + nowmonth; i = (i + 1) % 13, j++)
                {

                    if (i == 0) i++;

                    DateTime dateaz = (DateTime)(beforyea + "/" + i + "/1").ToMilady();
                    yearDic.Add(j, beforyea);
                    DateTime dateta = (DateTime)((i == 12 ? beforyea+1:beforyea) + "/" + (i == 12 ? 1 : i + 1) + "/1").ToMilady();
                    int count = (from e in db.Tasviehs where e.PayDate >= dateaz && e.PayDate < dateta select e.Id).Count();
                    if (count == null) count = 0;
                    if (i == 12)
                    {
                        beforyea += 1;
                        beformonth = 1;

                    }
                    else
                        beformonth = i + 1;
                    BeforDic.Add(j, count);

                }



                for (int k = 0; k < BeforDic.Count; k++)
                {
                    switch (BeforDic.ElementAt(k).Key % 12)
                    {
                        case 1:
                            Result.Add("فروردین" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 2:
                            Result.Add("اردیبهشت" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 3:
                            Result.Add("خرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 4:
                            Result.Add("تیر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 5:
                            Result.Add("مرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 6:
                            Result.Add("شهریور" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 7:
                            Result.Add("مهر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 8:
                            Result.Add("آبان" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 9:
                            Result.Add("آذر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 10:
                            Result.Add("دی" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 11:
                            Result.Add("بهمن" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 0:
                            Result.Add("اسفند" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                    }
                }

            }

            return Json(Result, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public ActionResult GetChartData()
        {

            SandooghModel db = new SandooghModel();
            DateTime now = DateTime.Now;
            PersianCalendar pl = new PersianCalendar();
           int nowmonth= pl.GetMonth(now);
            int nowyear = pl.GetYear(now);
            int beforyea = nowyear - 1;
            int beformonth = 1;
            Dictionary<int, int> BeforDic = new Dictionary<int, int>();
            Dictionary<int, int> NowDic = new Dictionary<int, int>();
            for (int i=1;i<=12;i++)
            {
                DateTime dateaz =(DateTime) (beforyea + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    beforyea += 1;
                    beformonth = 1;
                }
                else
                {
                    beformonth = i + 1;
                }
                DateTime dateta = (DateTime)(beforyea + "/" + beformonth + "/1").ToMilady();
                int count = (from e in db.T_OzvCode where e.OzvDate >= dateaz && e.OzvDate < dateta select e.Id).Count();
                if (count == null) count = 0;
                BeforDic.Add(i,count);

            }
          
            int nm = 1;
            for (int i = 1; i <= nowmonth; i++)
            {
                DateTime dateaz = (DateTime)(nowyear + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    nowyear += 1;
                    nm = 1;
                }
                else
                {
                    nm = i + 1;
                }
                DateTime dateta = (DateTime)(nowyear + "/" + nm + "/1").ToMilady();
                int count = (from e in db.T_OzvCode where e.OzvDate >= dateaz && e.OzvDate < dateta select e.Id).Count();
                if (count == null) count = 0;
                NowDic.Add(i, count);
            }

             nowyear = pl.GetYear(now);
             beforyea = nowyear - 1;
            Dictionary<string, int> Result = new Dictionary<string, int>();
            for(int k=0;k<BeforDic.Count;k++)
            {
                switch(BeforDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین"+beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                }
            }

            for (int k = 0; k < NowDic.Count; k++)
            {
                switch (NowDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                }
            }


            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetChartData1(string azdate,string tadate)
        {

            SandooghModel db = new SandooghModel();
            DateTime azdatei1 = DateTime.MinValue;
            DateTime tadatei1 = DateTime.MaxValue;
            try
            {
                azdatei1 = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei1 = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            Dictionary<string, int> Result = new Dictionary<string, int>();
            //  if (!(azdatei1 == DateTime.MinValue && tadatei1 == DateTime.MaxValue))
            {
                if (azdatei1 == DateTime.MinValue)
                    azdatei1 = DateTime.Parse("2019/03/21 12:00:00 AM");// (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Min(e => e.PayDate).Value;
                if (tadatei1 == DateTime.MaxValue)
                    tadatei1 = (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Max(e => e.PayDate).Value;

                PersianCalendar pl = new PersianCalendar();
                int nowmonth = pl.GetMonth(tadatei1);
                int nowyear = pl.GetYear(tadatei1);
                int beforyea = pl.GetYear(azdatei1);
                int beformonth = pl.GetMonth(azdatei1);
                Dictionary<int, int> BeforDic = new Dictionary<int, int>();

                Dictionary<int, int> yearDic = new Dictionary<int, int>();
                int j = beformonth;
                for (int i = beformonth; beforyea * 12 + beformonth <= nowyear * 12 + nowmonth; i = (i + 1) % 13, j++)
                {

                    if (i == 0) i++;

                    DateTime dateaz = (DateTime)(beforyea + "/" + i + "/1").ToMilady();
                    yearDic.Add(j, beforyea);
                    DateTime dateta = (DateTime)((i == 12 ? beforyea + 1 : beforyea) + "/" + (i == 12 ? 1 : i + 1) + "/1").ToMilady();
                    int count = (from e in db.Tasviehs where e.PayDate >= dateaz && e.PayDate < dateta select e.Id).Count();
                    if (count == null) count = 0;
                    if (i == 12)
                    {
                        beforyea += 1;
                        beformonth = 1;

                    }
                    else
                        beformonth = i + 1;
                    BeforDic.Add(j, count);

                }



                for (int k = 0; k < BeforDic.Count; k++)
                {
                    switch (BeforDic.ElementAt(k).Key % 12)
                    {
                        case 1:
                            Result.Add("فروردین" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 2:
                            Result.Add("اردیبهشت" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 3:
                            Result.Add("خرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 4:
                            Result.Add("تیر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 5:
                            Result.Add("مرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 6:
                            Result.Add("شهریور" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 7:
                            Result.Add("مهر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 8:
                            Result.Add("آبان" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 9:
                            Result.Add("آذر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 10:
                            Result.Add("دی" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 11:
                            Result.Add("بهمن" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 0:
                            Result.Add("اسفند" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                    }
                }

            }

            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult AvalinDarkhast()

        {
            SandooghModel db = new SandooghModel();
            List<SelectListItem> CityList = new List<SelectListItem>();
            List<CityCode> citylist = db.CityCodes.ToList();
            foreach (CityCode city in citylist)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = city.id.ToString();
                sli.Text = city.CityName;
                CityList.Add(sli);
            }
            ViewBag.cities = CityList;

            return View();
        }
        private string GetReplacementValue(string fieldName, T_OzvCode ozvCode)
        {
            // استفاده از reflection برای یافتن ویژگی‌های (properties) مدل T_OzvCode
            var properties = typeof(T_OzvCode).GetProperties();

            foreach (var property in properties)
            {
                if (string.Equals(property.Name, fieldName, StringComparison.OrdinalIgnoreCase))
                {
                    // یافتن فیلد مطابق با نام فیلد و خواندن مقدار آن از ozvCode
                    var value = property.GetValue(ozvCode);

                    // تبدیل مقدار به رشته و برگشت آن
                    return value?.ToString() ?? "";
                }
            }

            // اگر نام فیلد معتبر نباشد، مقدار خالی یا مقدار پیشفرض دلخواه را برگردانید.
            return "";
        }
        [HttpPost]
        public ActionResult SendAllSms(string Message,string codemelli, string ozviatcode, string fname, string lname, string tavalod, string sodoor, string type, string Faal = "")
        {
            string originalmessage = Message;
            /* عضو محترم صنم، خواهشمند است جهت واریز وجوه مستمری و اقساط، از طریق کلیه همراه بانکها و اینترنت بانکهای موجود خود، به روش انتقال <<پایا>>  یا <<ساتنا>>، با درج شناسه مربوطه اقدام فرمائید.
   شماره شبای صندوق:
    IR380130100000000428808130
   شناسه واریز مستمری:#mostammarryshenase
   شناسه واریز قسط:#ghestshenase
            همچنین به منظور مشاهده و پیگیری واریزی ها، می توانید با استفاده از نام کاربری و کلمه عبور خود، از طریق وب سایت سازمان نظام مهندسی ساختمان و ورود به سامانه صندوق قرض الحسنه، اقدام نمایید.
            نام کاربری:#Id
   کلمه عبور:#MelliCode
            */
            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();

            if (Faal == "a")
                list = (from e in list where e.Faal == true select e).ToList();
            else
                  if (Faal == "da")
                list = (from e in list where e.Faal == false select e).ToList();

            if (type == "m")
                list = (from e in list where e.OzvCode_Jensiat == 1 select e).ToList();
            else
                if (type == "z")
                list = (from e in list where e.OzvCode_Jensiat == 2 select e).ToList();

            if (codemelli != null && codemelli.Length > 0)
                list = (from e in list where e.MelliCode.Contains(codemelli) select e).ToList();
            if (ozviatcode != null && ozviatcode.Length > 0)
                list = (from e in list where e.NezamNo.Contains(ozviatcode) select e).ToList();
            if (fname != null && fname.Length > 0)
                list = (from e in list where e.FName.Contains(fname) select e).ToList();
            if (lname != null && lname.Length > 0)
                list = (from e in list where e.LName.Contains(lname) select e).ToList();
            try
            {
                if (tavalod != null && tavalod.Length > 0)
                {
                    int tavalod1 = int.Parse(tavalod);
                    list = (from e in list where e.OzvCode_TavalodCity == tavalod1 select e).ToList();
                }
            }
            catch
            {

            }
            try
            {
                if (sodoor != null && sodoor.Length > 0)
                {
                    int sodoor1 = int.Parse(sodoor);
                    list = (from e in list where e.OzvCode_ShCity == sodoor1 select e).ToList();
                }
            }
            catch
            {

            }


        
            var totalRecords = list.Count;
          

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery                                   
                                            .ToList();


            List<string> numbers = new List<string>();
         
            foreach (T_OzvCode s in productsList)
            {
                int d = 1;
                numbers.Add(s.Mobile);
                string tempmessage = originalmessage;
                // برای یافتن نام فیلد در متن پیام اصلی از Regex استفاده می‌کنیم.
                MatchCollection matches = Regex.Matches(tempmessage, "#([A-Za-z_]+)");
               
                foreach (Match match in matches)
                {
                    // نام فیلد را از متن استخراج می‌کنیم (مثلاً "نام_فیلد").
                    string fieldName = match.Groups[1].Value;

                    // مقدار متناظر با نام فیلد را از مدل T_OzvCode استخراج می‌کنیم.
                    string replacementValue = GetReplacementValue(fieldName, s); // تابعی که مقدار متناظر را با توجه به نام فیلد برمی‌گرداند.

                    // مقدار نام فیلد را با مقدار متناظر جایگزین می‌کنیم.
                    tempmessage = tempmessage.Replace("#" + fieldName, replacementValue);
                }

                if (originalmessage.Contains("#"))
                {
                    SendMsg(numbers.ToArray(), tempmessage);
                    numbers = new List<string>();
                }
                else
                {
                    d++;
                    if (d == 98)
                    {
                        d = 1;
                        SendMsg(numbers.ToArray(), tempmessage);
                        numbers = new List<string>();


                    }
                }

            }
            if (numbers.Count > 0&&!originalmessage.Contains("#"))
            {
                SendMsg(numbers.ToArray(),Message);

           }
            return Json(true, JsonRequestBehavior.AllowGet);
        }
        public ActionResult SendSms()
        {
            SandooghModel db = new SandooghModel();
            List<SelectListItem> CityList = new List<SelectListItem>();
            List<CityCode> citylist = db.CityCodes.ToList();
            foreach (CityCode city in citylist)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = city.id.ToString();
                sli.Text = city.CityName;
                CityList.Add(sli);
            }
            ViewBag.cities = CityList;
            return View();
        }
        public ActionResult ScanType()
        {
            return View();
        }
        [HttpPost]
        public ActionResult GetScanTypes(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_ScanType.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.ScanType_ID,
                    RowCells = new List<object>
                               {
                                    product.ScanType_ID,
                                     product.ScanType_Name.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult AddScanType(T_ScanType postData)
        {
            SandooghModel db = new SandooghModel();
         
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.T_ScanType.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult EditScanType(T_ScanType postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult DeleteScanType(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_ScanType.FirstOrDefault(x => x.ScanType_ID == idd);
            if (product == null)
                return Json(false);

            db.T_ScanType.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
      
        //[NonAction]
        public System.Threading.Tasks.Task<MVCSandoogh.GhasedakServiceRefrence.SendSMSResponse> SendMsg(string[] numbers, string message)
        {
            //var client = new RestClient("http://api.ghasedaksms.com/v2/sms/send/bulk");
            //var request = new RestRequest(Method.Post);
            //request.AddHeader("apikey", "n2zyZ9qR9kUJuTy3bpepy8hTJoSQha4KvcY3LvXQqbs");

            //request.AddParameter("receptor", 09121111111, 9122222222);
            //request.AddParameter("message", "تست 1 , تست 2");
            //request.AddParameter("checkingids", "11509774,11509775");
            //request.AddParameter("sender", "50001000,50002000");
            //IRestResponse response = client.Execute(request);


           try
            {
                ArrayOfString senderNumbers = new ArrayOfString();
        
                senderNumbers.Add( "90007081");
              v2SoapClient asc=new v2SoapClient();
                var recivers = new ArrayOfString();
                recivers.AddRange(numbers.ToList());
                var messages  = new ArrayOfString();
                messages.AddRange(new string[] { message }.ToList<string>());
                //
               var result= asc.SendSMSAsync("sandogh.1378@gmail.com", "@SA12345@", senderNumbers, recivers, messages,null, null, null);
                return result;
            }
            catch (Exception ex)
            {
                return null;
            }
            //try
            //{

            //    var smsService = new SmsService();
            //    var ssvm = new SendViewModel
            //    {
            //        Password = "S!23@",
            //        Username = "sandoogh",
            //        Folder = "web",
            //        Number = "500010033384311",
            //        ReceiverPhoneNumbers = numbers.ToList(),
            //        SmsText = message
            //    };
            //     var result= Task.Run(()=>  smsService.Send(ssvm)).Result;
            //    return result;
            //}
            //catch(Exception ex)
            //{

            //    return null;
            //}

            /*   try
            {           
                SMSZoneSoap sso = new SMSZoneSoapClient();
                ArrayOfString aos = new ArrayOfString();
                aos.InsertRange(0, numbers);        
                DoSendRequestBody dsrb = new DoSendRequestBody(aos, message, "500010033384311", "sandoogh","S!23@",true, "webservice");
                DoSendRequest request = new DoSendRequest(dsrb);
                sso.DoSend(request);
            }
            catch
            {

            }*/


        }
        [HttpPost]
        public ActionResult GetScandbs(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();

            try
            {
                var list = db.ScanDB.ToList();

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list.AsQueryable();
                var productsList = productsQuery.OrderBy(sidx + " " + sord)

                                                .ToList();
                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.id,
                        RowCells = new List<object>
                               {
                                     product.id,product.ScanURL,
                                   product.T_OzvCode.FName,product.T_OzvCode.LName,product.T_ScanType!=null?product.T_ScanType.ScanType_Name:""  ,product.ScanDoc,
                       product.SanadSendDate!=null?((DateTime)product.SanadSendDate).ToPersianDate():""
                        ,product.IdRef.ToString(), product.T_User.User_UserName,product.Scan_ScanType


                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpPost]
        public ActionResult DeleteScandb(string id)
        {
            int idd = int.Parse(id);
         
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.ScanDB.FirstOrDefault(x => x.id == idd);
            System.IO.File.Delete(Server.MapPath( product.ScanURL.Replace("../../..", "~")));
            if (product == null)
                return Json(false);

            db.ScanDB.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddScans(ScanDB postData,Array Files)
        {
            SandooghModel db = new SandooghModel();
            //ToDo: Add Product To Repository

            if (postData == null)
                return Json(false);
            else
            {
                AccountController acc = new AccountController();
                foreach (object filename in Files)
                {
                    ScanDB p = postData;
                    p.SendedUser = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
                    p.SanadSendDate = DateTime.Now;
                    p.ScanURL =filename.ToString();
                  
                    db.ScanDB.Add(p);
                    db.SaveChanges();
                    return Json(true);
                }
            }
            return Json(false);
        }

        
          [AcceptVerbs(HttpVerbs.Post)]
            public ActionResult UploadLettersDataFile(HttpPostedFileBase qqfile)
        {

            if (qqfile != null && qqfile.ContentLength > 0)
            {
                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(qqfile.FileName);
                var path = Path.Combine(Server.MapPath("~/UploadedFiles/Letters"), fileName);
                qqfile.SaveAs(@path);
                // further processing on file can be done here
                return Json(new { success = true, FilName = "../../../UploadedFiles/Letters/" + fileName });

            }
            else
            {
                // this works for Firefox, Chrome
                var filename = Request["qqfile"];
                if (!string.IsNullOrEmpty(filename))
                {
                    string newFileName = Guid.NewGuid().ToString() + Path.GetExtension(filename.ToString());
                    filename = Path.Combine(Server.MapPath("~/UploadedFiles/Letters"), newFileName);
                    using (var output = System.IO.File.Create(filename))
                    {
                        Request.InputStream.CopyTo(output);
                    }
                    // further processing on file can be done here
                    return Json(new { success = true, FilName = "../../../UploadedFiles/Letters/" + newFileName });

                }
            }
            return Json(new { success = false });
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult UploadBatchDataFile(HttpPostedFileBase qqfile)
        {
           
            if (qqfile != null && qqfile.ContentLength > 0)
            {
                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(qqfile.FileName);
                var path = Path.Combine(Server.MapPath("~/UploadedFiles/BatchData"), fileName);
                qqfile.SaveAs(@path);
                // further processing on file can be done here
                return Json(new { success = true, FilName = "../../../UploadedFiles/BatchData/" + fileName });

            }
            else
            {
                // this works for Firefox, Chrome
                var filename = Request["qqfile"];
                if (!string.IsNullOrEmpty(filename))
                {
                    string newFileName = Guid.NewGuid().ToString() + Path.GetExtension(filename.ToString());
                    filename = Path.Combine(Server.MapPath("~/UploadedFiles/BatchData"), newFileName);
                    using (var output = System.IO.File.Create(filename))
                    {
                        Request.InputStream.CopyTo(output);
                    }
                    // further processing on file can be done here
                    return Json(new { success = true, FilName = "../../../UploadedFiles/BatchData/" + newFileName });

                }
            }
            return Json(new { success = false });
        }
        public ActionResult MostamaryMablagh(string idrefozv = "")
        {
            ViewBag.IdOzv = idrefozv;
            return View();
        }

        [Authorize(Roles = "Admin")]
        public ActionResult OzvScans(string idrefozv="",string scantype="1")
        {
          
            ViewBag.IdOzv = idrefozv;
            ViewBag.ScanType = scantype;
            SandooghModel db = new SandooghModel();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<T_ScanType> groupList = db.T_ScanType.ToList();
            foreach (T_ScanType group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.ScanType_ID.ToString();
                sli.Text = group.ScanType_Name;
                GroupList.Add(sli);
            }
            ViewBag.scantypes = GroupList;
            return View();
        }
        public string ghestshenase = "";
        public string mostamarryshenase = "";
        public string afzayeshshenase = "";

        public string[] setpardakhtyviewbags(string codemelli)
        {
           
            string[] result= new string[3];
            try
            {
                string shenaseghabz = "";
                SandooghModel db = new SandooghModel();
                shenaseghabz = codemelli;

                string afzayesh = "";
                string mostamarry = "";
                string ghest = "";
                string temp = "00000000000000000" + shenaseghabz + "03";
                temp = temp.Substring(temp.Length - 15);
                afzayesh = setcontroli(temp);
                if (afzayesh != "")
                    afzayeshshenase = codemelli+"03" + afzayesh;
                else
                    afzayeshshenase = "";
                temp = "00000000000000000" + shenaseghabz + "01";
                temp = temp.Substring(temp.Length - 15);
                mostamarry = setcontroli(temp);
                if (mostamarry != "")
                    mostamarryshenase = codemelli+"01" + mostamarry;
                else
                    mostamarryshenase = "";
                temp = "00000000000000000" + shenaseghabz + "02";
                temp = temp.Substring(temp.Length - 15);
                ghest = setcontroli(temp);
                if (ghest != "")
                    ghestshenase = codemelli + "02"  + ghest;
                else
                    ghestshenase = "";
                result[0] = afzayeshshenase;
                result[1] = mostamarryshenase;
                result[2] = ghestshenase;
            }
            catch
            {

            }
            return result;
        }
        public string setcontroli(string id)
        {
            int[] iValue = { 15, 14, 13, 12, 11, 10, 9, 1, 2, 3, 4, 5, 6, 7, 8 };
            string sID = id;
            int digitID = 0;
            string tempID;

            if (string.IsNullOrEmpty(sID) || sID.Length > 15)
            {
                return ""; // When The Entered Number Is Greater Than Normal Length ID (15 characters) OR That Is Empty This Section Fired Up!
            }

            sID = "00000000000000000" + sID;
            sID = sID.Substring(sID.Length - 15);

            tempID = sID;
            //     sID = sID.Substring(sID.Length - 17, 15);

            char[] arrID = sID.ToCharArray();
            for (int i = 0; i < iValue.Length; i++)
            {
                digitID += (iValue[i] * (arrID[i] - '0'));
            }

            digitID = int.Parse(("0" + (digitID % 99)).Substring(("0" + (digitID % 99)).Length - 2));

            if(digitID<10)
                return "0"+ digitID.ToString();
            else
            return digitID.ToString(); // The Entered Digit Number Is Correct


        }
        [HttpGet]
        public JsonResult GetShenaseFormOzviat(string Id)
        {
            try
            {
                long id1 = long.Parse(Id);
                SandooghModel db = new SandooghModel();
                var list = from e in db.T_OzvCode
                           where e.Id == id1
                           select e;
                if (list.FirstOrDefault().ghestshenase == null || list.FirstOrDefault().ghestshenase.Length == 0 ||
                    list.FirstOrDefault().mostammarryshenase == null || list.FirstOrDefault().mostammarryshenase.Length == 0 ||
                    list.FirstOrDefault().afzayeshhenase == null || list.FirstOrDefault().afzayeshhenase.Length == 0)
                {
                    var f = setpardakhtyviewbags(list.FirstOrDefault().MelliCode);
                    afzayeshshenase = f[0];
                    mostamarryshenase = f[1];
                    ghestshenase = f[2];

                }
                else
                {
                    afzayeshshenase = list.FirstOrDefault().afzayeshhenase;
                    mostamarryshenase = list.FirstOrDefault().mostammarryshenase;
                    ghestshenase = list.FirstOrDefault().ghestshenase;

                }
            PersianCalendar pl = new PersianCalendar();
                    var result = from oz in list.ToList()
                                 select new
                                 {
                                     name = oz.FName + " " + oz.LName,

                                     id = oz.Id,

                                     codemelli = oz.MelliCode,
                                     afzayeshshenase = afzayeshshenase,
                                     mostamarryshenase = mostamarryshenase,
                                     ghestshenase = ghestshenase


                                 };
                    return Json(result.FirstOrDefault(), JsonRequestBehavior.AllowGet);
               
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult SetAllShenaseOfOzviat()
        {
          
                SandooghModel db = new SandooghModel();
                var ids = db.T_OzvCode.Where(l=>l.ghestshenase==""||l.ghestshenase==null|| l.mostammarryshenase == "" || l.mostammarryshenase == null
                || l.afzayeshhenase == "" || l.afzayeshhenase == null).Select(k => k.Id).ToList();
                foreach (var ozvid in ids)
                {

                try
                {
                    var list = (from e in db.T_OzvCode
                                where e.Id == ozvid
                                select e).FirstOrDefault();
                    var f = setpardakhtyviewbags(list.MelliCode);
                    afzayeshshenase = f[0];
                    mostamarryshenase = f[1];
                    ghestshenase = f[2];
                    list.afzayeshhenase = afzayeshshenase;
                    list.mostammarryshenase = mostamarryshenase;
                    list.ghestshenase = ghestshenase;
                    db.Entry(list).State = EntityState.Modified;
                    db.SaveChanges();
                }
            catch
            {
               
            }
        }
         return Json(true);
        }
        [HttpGet]
        public JsonResult GetMembersWithCodeFormOzviat(string Id)
        {
            try
            {
                long id1 = long.Parse(Id);
                SandooghModel db = new SandooghModel();
                var list = from e in db.T_OzvCode
                           where e.Id == id1 
                           select e;
                PersianCalendar pl = new PersianCalendar();
                var result = from oz in list.ToList()
                             select new
                             {
                                 name = oz.FName + " " + oz.LName,
                                 fname = oz.FName,
                                 lname = oz.LName,
                                 id = oz.Id,
                                 mobile = oz.Mobile,
                                 picture = oz.ScanDBs != null ? oz.ScanDBs.Where(a => a.IdRef == oz.Id && a.Scan_ScanType == 1).ToList().Count > 0 ? oz.ScanDBs.Where(a => a.IdRef == oz.Id && a.Scan_ScanType == 1).FirstOrDefault().ScanURL : null : null
               ,
                                 codemelli = oz.MelliCode,
                                 shsh = oz.ShNo,
                                 father = oz.FatherName,
                                 ozviatenezam = oz.NezamNo,
                                 parvane = oz.parvanehNo,
                                 shaba = oz.SH_Shaba,
                                 address = oz.Address,
                                 phone = oz.Tel,
                                 date = DateTime.Now.ToPersianDate(),
                                 avalieh = (oz.G_M_Pays != null && oz.G_M_Pays.Count > 0) ? oz.G_M_Pays.FirstOrDefault().MostamariMablag.ToString() : "................",
                                 mostamarimablagh = (oz.T_MostamaryMablagh != null && oz.T_MostamaryMablagh.Count > 0) ? oz.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh.ToString() : "................"

                             };
                return Json(result.FirstOrDefault(), JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpGet]
        public JsonResult GetUsersWithCode()
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_User.ToList();
            var result = from oz in list
                         select new
                         {
                             name = oz.User_Firstname + ' ' + oz.User_lastname + '(' + oz.User_OzvCdoe + ')',
                             fname = oz.User_Firstname,
                             lname = oz.User_lastname,
                             id = oz.OzvCode
                         };
            return Json(result.ToList(), JsonRequestBehavior.AllowGet);
        }
      
        [HttpGet]
        public JsonResult GetMembersWithCode()
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();
            var result = from oz in list
                         select new
                         {
                             name = oz.FName + ' ' + oz.LName +'('+oz.Id+')',
                             fname=oz.FName,
                             lname=oz.LName,
                             id = oz.Id,
                             mobile=oz.Mobile
                         };
            return Json(result.ToList(), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult GetSearchOzv(int page, int rows, string sidx = "Id", string sord = "asc")
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();//کل داده ها را مرتب شده برمیگرداند و دو پارامتر اولی هیچ تاثیری ندارند.
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                                     product.Id,
                                     product.FName.ToString(),product.LName,product.FatherName,
                                     product.MelliCode
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
      
        [HttpGet]
        [AllowAnonymous]
        public ActionResult SearchOzv()
        {
            return View();
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMembersForSms(string sidx, string sord, int page, int rows, string codemelli, string ozviatcode, string fname, string lname, string tavalod, string sodoor, string type, string Faal = "")
        {

            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();

            if (Faal == "a")
                list = (from e in list where e.Faal == true select e).ToList();
            else
                  if (Faal == "da")
                list = (from e in list where e.Faal == false select e).ToList();

            if (type == "m")
                list = (from e in list where e.OzvCode_Jensiat == 1 select e).ToList();
            else
                if (type == "z")
                list = (from e in list where e.OzvCode_Jensiat == 2 select e).ToList();

            if (codemelli != null && codemelli.Length > 0)
                list = (from e in list where e.MelliCode.Contains(codemelli) select e).ToList();
            if (ozviatcode != null && ozviatcode.Length > 0)
            {
                try
                {
                    list = (from e in list where e.Id.ToString().Contains(ozviatcode) select e).ToList();
                }
                catch
                {

                }
            }
               
            if (fname != null && fname.Length > 0)
                list = (from e in list where e.FName.Contains(fname) select e).ToList();
            if (lname != null && lname.Length > 0)
                list = (from e in list where e.LName.Contains(lname) select e).ToList();
            try
            {
                if (tavalod != null && tavalod.Length > 0)
                {
                    int tavalod1 = int.Parse(tavalod);
                    list = (from e in list where e.OzvCode_TavalodCity == tavalod1 select e).ToList();
                }
            }
            catch
            {

            }
            try
            {
                if (sodoor != null && sodoor.Length > 0)
                {
                    int sodoor1 = int.Parse(sodoor);
                    list = (from e in list where e.OzvCode_ShCity == sodoor1 select e).ToList();
                }
            }
            catch
            {

            }


            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            PersianCalendar pl = new PersianCalendar();

            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                                     product.Id,product.Faal,
                                     product.FName.ToString(),product.LName,product.FatherName,
                                     product.MelliCode,product.TavalodDate!=null?((DateTime)product.TavalodDate).ToPersianDate():"",product.OzvDate!=null?((DateTime)product.OzvDate).ToPersianDate():"",product.ShNo,product.CityCode!=null?product.CityCode.CityName:null,product.CityCode1!=null?product.CityCode1.CityName:null,
                                     product.Taahol!=null?product.Taahol.Taahol_Name:null,product.NezamNo,product.Mobile
                                   
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
     
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMembers(string sidx, string sord, int page, int rows, string codemelli, string ozviatcode, string fname, string lname, string tavalod, string sodoor,string type, string azdate1, string tadate1,string azdate,string tadate,string faaldardate, string Faal="")
        {

            SandooghModel db = new SandooghModel();
            int code = 0;
            try
            {
                code = int.Parse(ozviatcode);
            }
            catch
            {

            }
            var list = from e in db.T_OzvCode select e;
            if (faaldardate != "")//اگر فیلتر فعالها را در تاریخ خاص بخواهیم به آن یکی فعال یا غیر فعالی ترتیب اثر نمی دهد
            {
                DateTime faaldar = DateTime.MinValue;
                try
                {
                  faaldar=  (DateTime)faaldardate.ToMilady();
                }
                catch
                {

                }
               list= (from e in list where e.OzvDate<=faaldar&&( e.Faal == true||(e.Tasviehs.Count>0&&e.Tasviehs.FirstOrDefault().PayDate>=faaldar)||(db.AccSanad_B.Where(l => l.Tafsili == e.Id.ToString() && l.Date_S >= faaldar).Count() > 0)) select e);
            }
            
                if (Faal == "a")
                    list = (from e in list where e.Faal == true select e);
                else
                      if (Faal == "da")
                    list = (from e in list where e.Faal == false select e);
            
            if (type=="m")
                list = (from e in list where e.OzvCode_Jensiat==1 select e);
            else
                if(type=="z")
                list = (from e in list where e.OzvCode_Jensiat==2 select e);

            if (codemelli != null && codemelli.Length > 0)
                    list = (from e in list where e.MelliCode.Contains(codemelli) select e);
                if (ozviatcode != null && ozviatcode.Length > 0)
                    list = (from e in list where e.Id==code select e);
                if (fname != null && fname.Length > 0)
                    list = (from e in list where e.FName.Contains(fname) select e);
                if (lname != null && lname.Length > 0)
                    list = (from e in list where e.LName.Contains(lname) select e);
                try
                {
                    if (tavalod != null && tavalod.Length > 0)
                    {
                        int tavalod1 = int.Parse(tavalod);
                        list = (from e in list where e.OzvCode_TavalodCity==tavalod1 select e);
                    }
                }
                catch
                {

                }
                try
                {
                    if (sodoor != null && sodoor.Length > 0)
                    {
                        int sodoor1 = int.Parse(sodoor);
                        list = (from e in list where e.OzvCode_ShCity == sodoor1 select e);
                    }
                }
                catch
                {

                }
            DateTime azdatei1 = DateTime.MinValue;
            DateTime tadatei1 = DateTime.MaxValue;
            try
            {
                azdatei1 = (DateTime)azdate1.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei1 = (DateTime)tadate1.ToMilady();
            }
            catch
            {

            }
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
           
            if(!(azdatei1==DateTime.MinValue&&tadatei1==DateTime.MaxValue))
            {
                var list241 = from e in db.Tasviehs where e.PayDate >= azdatei1 && e.PayDate <= tadatei1 select e.IdRefOzv;
                list = (from e in list where e.OzvDate >= azdatei && e.OzvDate <= tadatei && list241.Contains(e.Id) select e);
            }
                else
                   list = (from e in list where e.OzvDate >= azdatei && e.OzvDate <= tadatei select e);


            var list1 = list.ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            PersianCalendar pl = new PersianCalendar();
          //  productsList = productsList.Where(k => k.Id == 12729).ToList();


            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                                     product.GUID.ToString(),product.Semat, product.Id, product.Faal,
                                     product.FName.ToString(),product.LName ,  product.ScanDBs!=null? product.ScanDBs.Where(a => a.IdRef==product.Id && a.Scan_ScanType==1).ToList().Count>0? product.ScanDBs.Where(a => a.IdRef==product.Id && a.Scan_ScanType==1).FirstOrDefault().ScanURL:null:null,product.FatherName,
                                     product.MelliCode,product.TavalodDate!=null?((DateTime)product.TavalodDate).ToPersianDate():"",product.OzvDate!=null?((DateTime)product.OzvDate).ToPersianDate():"",product.Tasviehs.FirstOrDefault()!=null?((DateTime)product.Tasviehs.FirstOrDefault().PayDate).ToPersianDate():"",product.ShNo,product.CityCode!=null?product.CityCode.CityName:null,product.CityCode1!=null?product.CityCode1.CityName:null,
                                     product.Taahol!=null?product.Taahol.Taahol_Name:null,product.parvanehNo,product.NezamNo,product.Tel,product.Mobile,
                                     product.Address, pl.AddMonths(product.OzvDate, 6).ToPersianDate(), pl.AddMonths(product.OzvDate, 6)>DateTime.Now?0:1,product.SH_Shaba,product.SumAfzayeshMostamary,product.afzayeshhenase,product.mostammarryshenase,product.ghestshenase
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }



        //[HttpPost]
        //[Authorize(Roles = "Admin")]
        //public ActionResult GetAvvalinDarkhastMembers(string sidx, string sord, int page, int rows)
        //{

        //    SandooghModel db = new SandooghModel();
        //    DateTime now = DateTime.Now.Date;
        //    PersianCalendar pc = new PersianCalendar();
        //    DateTime date=  pc.AddMonths(now,-6);
        //    DateTime azdatei = date.AddDays(-7);
        //    DateTime tadatei = date.AddMilliseconds(1);
        //    List<long> etmamnashode = new List<long>();//اعضایی که کمتر از 1000تومن بدهی دارند
        //    var list = (from e in db.T_OzvCode where /*e.OzvDate > azdatei &&*/ e.OzvDate < tadatei && e.Faal==true && e.VamNobats.Count==0 && e.Vams.Count==0  select e);
        //    var listvamnatamam = (from k in db.Vams where k.EtmamVam == false select k).ToList();
        //    string p = "";
        //    foreach (var v in listvamnatamam)
        //    {
        //        var pardakhty=(from e in db.G_M_Pays where e.IdRefVam == v.Vam_Id select e).Sum(e => e.TotGestMablag);
        //        var mablaghvam = (v.VamMablagKhales + v.Karmozd);
        //        var mandebedehi = mablaghvam - pardakhty;

        //        if(mandebedehi < 10000)
        //        {
        //            etmamnashode.Add(v.T_OzvCode.Id );
        //        }

        //        if(mandebedehi<=0)
        //        {
        //            //10385 , 10471 , 10378 , 10830 , 10805 , 10388 , 10791 , 10868 , 10867 , 10940 , 10985 , 10590 , 10978 ,
        //            //10979 , 10951 , 11010 , 11057 , 11027 , 10780 , 10781 , 11083 , 11072 , 11109 , 11110 , 11133 , 11116 
        //            //11138 , 11090 , 11137 , 10489 , 10964 , 10971 , 11144 , 11185 , 11186 , 11201 , 11307 , 10686 , 11255 
        //           //11313 , 11314 , 11317 , 10596 , 11391 , 11377 , 10142 , "
        //            v.EtmamVam = true;
        //            p += v.IdRefOzv + " , ";
        //            db.Entry(v).State = System.Data.Entity.EntityState.Modified;

        //            db.SaveChanges();

        //        }
        //    }
        //    var listnatamamvam = (from k in db.Vams where k.EtmamVam == false  select k.IdRefOzv).ToList();
        //    var list2 = (from e in db.Vams where  e.EtmamVam==true && e.T_OzvCode.Faal == true && !listnatamamvam.Contains(e.IdRefOzv) select e.IdRefOzv).Distinct();
        //    //دووامه:"لیست2"بررسی شود که آیا شخص وام دیگری ندارد که هنوز تمام نشده باشد
        //    var list3 = (from e in db.T_OzvCode where list2.Contains(e.Id)|| /*کمتر از 1000 تومن*/etmamnashode.Contains(e.Id) select e);
        //    var list1 = list.Union(list3).Distinct().ToList();
        //  //  list1 = (from e in list1 where e.Id == 10191 select e).ToList();
        //   var list4 = (from e in list1 where e.Faal==true &&( e.VamNobats.Where(r =>r.IdRefOzv==e.Id && r.IdRefVam == null) == null || e.VamNobats.Where(r=> r.IdRefOzv == e.Id && r.IdRefVam==null).ToList().Count==0) select new { e, day=Math.Round(e.Vams.Count > 0 ? (DateTime.Now.Date.Subtract((DateTime)e.Vams.OrderByDescending(i=>i.Vam_Id).First() .G_M_Pays.OrderByDescending(ll=>ll.PayDate).First().PayDate)).TotalDays : ((DateTime.Now.Date.Subtract(e.OzvDate.AddMonths(6)))).TotalDays) }).ToList();
        //    var pageIndex = page - 1;
        //    var pageSize = rows;
        //    var totalRecords = list4.Count;
        //    var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

        //    var productsQuery = list4.AsQueryable();
        //    var productsList = productsQuery.OrderBy("day asc")
        //                                    .Skip(pageIndex * pageSize)
        //                                    .Take(pageSize)
        //                                    .ToList();
        //    PersianCalendar pl = new PersianCalendar();

        //    var productsData = new JqGridData
        //    {
        //        Total = totalPages,
        //        Page = page,
        //        Records = totalRecords,
        //        Rows = (productsList.Select(product => new JqGridRowData
        //        {
        //            Id = product.e.Id,
        //            RowCells = new List<object>
        //                       {
        //                             product.e.GUID.ToString(), product.e.Id,product.e.Faal,
        //                             product.e.FName.ToString(),product.e.LName,product.e.FatherName,
        //                             product.e.MelliCode,product.e.TavalodDate!=null?((DateTime)product.e.TavalodDate).ToPersianDate():"",product.e.OzvDate!=null?((DateTime)product.e.OzvDate).ToPersianDate():"",product.e.ShNo,product.e.CityCode!=null?product.e.CityCode.CityName:null,product.e.CityCode1!=null?product.e.CityCode1.CityName:null,
        //                             product.e.Taahol!=null?product.e.Taahol.Taahol_Name:null,product.e.parvanehNo,product.e.NezamNo,product.e.Tel,product.e.Mobile,
        //                             product.e.Address,((DateTime) (product.e.Vams.Count>0?(product.e.G_M_Pays.Where(pp=>pp.TotGestMablag>0).OrderByDescending(pp1=>pp1.PayDate).FirstOrDefault().PayDate):pl.AddMonths(product.e.OzvDate, 6))).ToPersianDate(), pl.AddMonths(product.e.OzvDate, 6)>DateTime.Now?0:1,product.day,((product.e.G_M_Pays!=null&&product.e.G_M_Pays.Where(k=>k.MostamariMablag>0&&((DateTime)k.PayDate)>=((DateTime) (product.e.Vams.Count>0?(product.e.G_M_Pays.Where(pp=>pp.TotGestMablag>0).OrderByDescending(pp1=>pp1.PayDate).FirstOrDefault().PayDate):pl.AddMonths(product.e.OzvDate, 6)))).Count()>0))?1:0
        //                        }
        //        })).ToList()
        //    };
        //    return Json(productsData, JsonRequestBehavior.AllowGet);
        //}
     
        // کلاس برای نتیجه محاسبه امتیاز منفی وام
        public class VamNegativeScoreResult
        {
            public int NegativeScore { get; set; }
            public int DelayedMonths { get; set; }
            public string DelayReason { get; set; }
        }

        // کلاس برای نتیجه نهایی (ترکیبی)
        public class TotalNegativeScoreResult
        {
            public int TotalNegativeScore { get; set; }
            public int MostamariNegativeScore { get; set; }
            public int VamNegativeScore { get; set; }
            public int MostamariDelayedMonths { get; set; }
            public int VamDelayedMonths { get; set; }
            public string MostamariDelayReason { get; set; }
            public string VamDelayReason { get; set; }
            public string CombinedDelayReason { get; set; }
        }


        private static int GetRequiredMembershipMonths(
      DateTime membershipDate,
      T_VamQueueSetting setting)
        {
            if (setting == null || !setting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات ورود به نوبت وام تکمیل نشده است."
                );
            }

            PersianCalendar pc = new PersianCalendar();

            DateTime dey1402 =
                pc.ToDateTime(1402, 10, 1, 0, 0, 0, 0);

            return membershipDate.Date < dey1402.Date
                ? setting.MembershipMonthsBeforeDey1402
                : setting.MembershipMonthsFromDey1402;
        }

        private static DateTime GetMembershipEligibilityDate(
            T_OzvCode member,
            T_VamQueueSetting setting)
        {
            return member.OzvDate.AddMonths(
                GetRequiredMembershipMonths(member.OzvDate, setting)
            );
        }

        /// <summary>
        /// نتیجه‌ی یکپارچه‌ی تعیین تاریخ پایه، امتیاز منفی و تاریخ مجاز ورود به نوبت.
        /// امتیاز خام برای گزارش حفظ می‌شود؛ فقط تأخیر ورود به نوبت حداکثر ۶ ماه است.
        /// </summary>
        public class QueueEligibilityInfo
        {
            public DateTime BaseDate { get; set; }
            public DateTime? LastLoanPaymentDate { get; set; }
            public TotalNegativeScoreResult Score { get; set; }
            public int QueueDelayMonths { get; set; }
            public DateTime QueueEligibleDate { get; set; }
        }

        /// <summary>
        /// محاسبه‌ی مشترک شرایط ورود به نوبت؛ هم در صفحه‌ی فهرست اولیه
        /// و هم هنگام نمایش/ثبت نوبت از همین تابع استفاده می‌شود.
        /// </summary>
        public QueueEligibilityInfo CalculateQueueEligibilityInfo(
            T_OzvCode member,
            SandooghModel db)
        {
            if (member == null)
                throw new ArgumentNullException("member");
            if (db == null)
                throw new ArgumentNullException("db");

            var queueSetting = db.VamQueueSettings
      .FirstOrDefault(x => x.Id == 1);

            if (queueSetting == null || !queueSetting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات ورود به نوبت وام توسط مدیر سیستم تکمیل نشده است."
                );
            }

            var info = new QueueEligibilityInfo();

            DateTime membershipEligibilityDate =
                GetMembershipEligibilityDate(member, queueSetting);
            var lastVam = db.Vams
                .Where(v => v.IdRefOzv == member.Id && v.EtmamVam == true)
                .OrderByDescending(v => v.Vam_Id)
                .FirstOrDefault();

            if (lastVam == null)
            {
                info.BaseDate = membershipEligibilityDate;
            }
            else
            {
                DateTime? firstGestDate = lastVam.AvlinGestDate;
                int installmentCount = lastVam.TedadAgsat ?? 0;
                decimal installmentAmount = Convert.ToDecimal(lastVam.GestMablag ?? 0);

                if (!firstGestDate.HasValue || installmentCount <= 0 || installmentAmount <= 0)
                {
                    info.BaseDate = membershipEligibilityDate;
                }
                else
                {
                    DateTime finalDueDate = firstGestDate.Value.AddMonths(installmentCount - 1);
                    var loanPayments = db.G_M_Pays
                        .Where(p => p.IdRefVam == lastVam.Vam_Id &&
                                    p.TotGestMablag > 0 && p.PayDate.HasValue)
                        .OrderBy(p => p.PayDate)
                        .ToList();

                    info.LastLoanPaymentDate = loanPayments
                        .OrderByDescending(p => p.PayDate)
                        .Select(p => p.PayDate)
                        .FirstOrDefault();

                    // شمارش اقساط کامل، با همان قاعده‌ی فعلی تخصیص پرداخت‌ها به قدیمی‌ترین قسط.
                    // تلورانس فعلی این الگوریتم حفظ شده تا امتیاز/قاعده‌ی قبلی ناخواسته تغییر نکند.
                    const decimal MaxInstallmentTolerance = 1000000m;
                    const decimal InstallmentToleranceRatio = 0.1m;
                    int paidInstallmentCount = 0;
                    decimal currentInstallmentPaid = 0;

                    foreach (var payment in loanPayments)
                    {
                        decimal remainingPayment = Convert.ToDecimal(payment.TotGestMablag ?? 0);
                        if (remainingPayment <= 0)
                            continue;

                        while (remainingPayment > 0 && paidInstallmentCount < installmentCount)
                        {
                            decimal remainingInstallment = installmentAmount - currentInstallmentPaid;
                            if (remainingInstallment <= 0)
                            {
                                paidInstallmentCount++;
                                currentInstallmentPaid = 0;
                                continue;
                            }

                            if (remainingPayment >= remainingInstallment)
                            {
                                remainingPayment -= remainingInstallment;
                                currentInstallmentPaid = 0;
                                paidInstallmentCount++;
                            }
                            else
                            {
                                decimal totalPaid = currentInstallmentPaid + remainingPayment;
                                decimal shortfall = installmentAmount - totalPaid;
                                decimal effectiveTolerance = Math.Min(
                                    MaxInstallmentTolerance,
                                    installmentAmount * InstallmentToleranceRatio);

                                if (shortfall > 0 && shortfall <= effectiveTolerance)
                                {
                                    paidInstallmentCount++;
                                    currentInstallmentPaid = 0;
                                    remainingPayment = 0;
                                }
                                else
                                {
                                    currentInstallmentPaid = totalPaid;
                                    remainingPayment = 0;
                                }
                            }
                        }
                    }

                    int halfPlusOne = (installmentCount / 2) + 1;
                    bool hasPaidHalfPlusOne = paidInstallmentCount >= halfPlusOne;
                    bool paidMoreThanThreeMonthsEarly =
                        info.LastLoanPaymentDate.HasValue &&
                        info.LastLoanPaymentDate.Value < finalDueDate.AddMonths(-3);

                    if (!info.LastLoanPaymentDate.HasValue)
                    {
                        info.BaseDate = finalDueDate;
                    }
                    else if (!paidMoreThanThreeMonthsEarly)
                    {
                        info.BaseDate = info.LastLoanPaymentDate.Value;
                    }
                    else if (!hasPaidHalfPlusOne)
                    {
                        info.BaseDate = info.LastLoanPaymentDate.Value.AddMonths(3);
                    }
                    else
                    {
                        info.BaseDate = firstGestDate.Value
                            .AddMonths(halfPlusOne - 1)
                            .AddMonths(3);
                    }
                }
            }

            info.Score = info.BaseDate.Date <= DateTime.Today
                ? CalculateTotalNegativeScore(info.BaseDate, member.Id, db)
                : new TotalNegativeScoreResult
                {
                    CombinedDelayReason = "هنوز به موعد پرداخت نرسیده است"
                };

            var score = info.Score ?? new TotalNegativeScoreResult();

            info.QueueDelayMonths =
                MVCSandoogh.VamPolicyHelper.CalculateQueueDelayMonths(
                    Math.Max(0, score.MostamariDelayedMonths),
                    Math.Max(0, score.VamDelayedMonths),
                    queueSetting
                );

            info.QueueEligibleDate =
                info.BaseDate.AddMonths(info.QueueDelayMonths);

            return info;
        }

        // کلاس برای نگهداری اطلاعات اقساط وام
        public class VamInstallmentInfo
        {
            public DateTime DueDate { get; set; }

            public DateTime? PayDate { get; set; }

            public long Amount { get; set; }

            /// <summary>
            /// مجموع مبلغی که تاکنون برای این قسط پرداخت شده است.
            /// قسط فقط زمانی تسویه‌شده محسوب می‌شود که PaidAmount >= Amount باشد.
            /// </summary>
            public decimal PaidAmount { get; set; }

            public bool IsPaid { get; set; }

            public int DelayMonths { get; set; }
        }
private VamNegativeScoreResult CalculateVamNegativeScore(long memberId, SandooghModel db)
        {
            // ============================================================
            // حداکثر تلورانس مجاز پرداخت قسط
            // ۱۰۰,۰۰۰ تومان معادل ۱,۰۰۰,۰۰۰ ریال
            //
            // توجه: اگر مبالغ در دیتابیس به تومان ذخیره شده‌اند،
            // این مقدار را به 100_000m تغییر دهید.
            // ============================================================
            const decimal MaxInstallmentTolerance = 1000000m;

            // حداکثر نسبت تلورانس به مبلغ قسط (۲۰٪)
            // برای جلوگیری از تسویه نادرست اقساط کوچک
            const decimal InstallmentToleranceRatio = 0.1m;
            var result = new VamNegativeScoreResult();

            try
            {
                // ============================================================
                // 1. دریافت آخرین وام تسویه شده عضو
                // ============================================================

                var lastVam = db.Vams
                    .Where(v =>
                        v.IdRefOzv == memberId &&
                        v.EtmamVam == true)
                    .OrderByDescending(v => v.Vam_Id)
                    .FirstOrDefault();

                if (lastVam == null)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "وام تسویه شده‌ای وجود ندارد";

                    return result;
                }

                var firstGestDate = lastVam.AvlinGestDate;

                if (!firstGestDate.HasValue)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "تاریخ اقساط مشخص نیست";

                    return result;
                }

                // ============================================================
                // 2. دریافت پرداخت‌های وام
                // ============================================================

                var payments = db.G_M_Pays
                    .Where(p =>
                        p.IdRefVam == lastVam.Vam_Id &&
                        p.TotGestMablag > 0)
                    .OrderBy(p => p.PayDate)
                    .ToList();

                // ============================================================
                // 3. ساخت لیست اقساط
                // ============================================================

                var installments = new List<VamInstallmentInfo>();

                long gestMablag = (long)(lastVam.GestMablag ?? 0);

                PersianCalendar pc = new PersianCalendar();

                // تاریخ شمسی اولین قسط
                int startY = pc.GetYear(firstGestDate.Value);
                int startM = pc.GetMonth(firstGestDate.Value);
                int startD = pc.GetDayOfMonth(firstGestDate.Value);

                int tedadAgsat = lastVam.TedadAgsat ?? 0;

                for (int i = 0; i < tedadAgsat; i++)
                {
                    int targetM = startM + i;
                    int targetY = startY;

                    // مدیریت تغییر سال
                    while (targetM > 12)
                    {
                        targetM -= 12;
                        targetY++;
                    }

                    // --------------------------------------------------------
                    // تعیین تاریخ سررسید
                    // اگر مثلاً روز 31 باشد و ماه مقصد 31 روز نداشته باشد،
                    // آخرین روز معتبر همان ماه انتخاب می‌شود.
                    // --------------------------------------------------------

                    int validDay = startD;

                    DateTime persianDueDate = pc.ToDateTime(
                        targetY,
                        targetM,
                        1,
                        0,
                        0,
                        0,
                        0);

                    while (validDay > 1)
                    {
                        try
                        {
                            persianDueDate = pc.ToDateTime(
                                targetY,
                                targetM,
                                validDay,
                                0,
                                0,
                                0,
                                0);

                            break;
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                            validDay--;
                        }
                    }

                    installments.Add(new VamInstallmentInfo
                    {
                        DueDate = persianDueDate,
                        PayDate = null,
                        Amount = gestMablag,
                        PaidAmount = 0,
                        IsPaid = false,
                        DelayMonths = 0
                    });
                }

                // ============================================================
                // 4. تطبیق پرداخت‌ها با اقساط
                //
                // پرداخت جزئی باعث تسویه قسط نمی‌شود.
                // قسط فقط زمانی IsPaid=true می‌شود که کل مبلغ آن پرداخت شود.
                //
                // مثال:
                //
                // مبلغ قسط = 10 میلیون
                //
                // پرداخت اول = 3 میلیون
                // PaidAmount = 3 میلیون
                // IsPaid = false
                //
                // پرداخت دوم = 7 میلیون
                // PaidAmount = 10 میلیون
                // IsPaid = true
                // ============================================================

                foreach (var payment in payments)
                {
                    if (!payment.PayDate.HasValue)
                        continue;

                    decimal remainingAmount =
                        (decimal)(payment.TotGestMablag ?? 0);

                    if (remainingAmount <= 0)
                        continue;

                    foreach (var inst in installments
                        .Where(x => !x.IsPaid)
                        .OrderBy(x => x.DueDate))
                    {
                        if (remainingAmount <= 0)
                            break;

                        decimal installmentAmount =
                            (decimal)inst.Amount;

                        decimal installmentRemaining =
                            installmentAmount - inst.PaidAmount;

                        // اگر قسط قبلاً کامل شده باشد
                        if (installmentRemaining <= 0)
                        {
                            inst.PaidAmount = installmentAmount;
                            inst.IsPaid = true;

                            if (!inst.PayDate.HasValue)
                            {
                                inst.PayDate = payment.PayDate;
                            }

                            continue;
                        }

                        // ====================================================
                        // پرداخت کامل قسط
                        // ====================================================

                        if (remainingAmount >= installmentRemaining)
                        {
                            inst.PaidAmount += installmentRemaining;

                            if (inst.PaidAmount > installmentAmount)
                            {
                                inst.PaidAmount = installmentAmount;
                            }

                            inst.IsPaid = true;

                            // تاریخ پرداخت کامل قسط
                            inst.PayDate = payment.PayDate;

                            remainingAmount -= installmentRemaining;
                        }
                        else
                        {
                            // =================================================
                            // پرداخت جزئی
                            // =================================================

                            inst.PaidAmount += remainingAmount;

                            if (inst.PaidAmount > installmentAmount)
                            {
                                inst.PaidAmount = installmentAmount;
                            }

                            // -------------------------------------------------
                            // بررسی تلورانس
                            // اگر مبلغ کسری تا تلورانس مؤثر باشد،
                            // قسط تسویه‌شده در نظر گرفته می‌شود.
                            // -------------------------------------------------
                            decimal shortfall = installmentAmount - inst.PaidAmount;

                            decimal effectiveTolerance = Math.Min(
                                MaxInstallmentTolerance,
                                installmentAmount * InstallmentToleranceRatio);

                            if (shortfall > 0 && shortfall <= effectiveTolerance)
                            {
                                inst.IsPaid = true;
                                inst.PayDate = payment.PayDate;
                            }
                            else
                            {
                                // قسط هنوز کامل پرداخت نشده است
                                inst.IsPaid = false;
                                inst.PayDate = null;
                            }

                            remainingAmount = 0;
                        }
                    }
                }

                // ============================================================
                // 5. محاسبه تأخیر
                //
                // قانون جدید:
                //
                // سررسید:
                //     1403/06/16
                //
                // +3 ماه:
                //     1403/09/16
                //
                // تا این تاریخ:
                //     بدون امتیاز
                //
                // از:
                //     1403/09/17
                //
                // تأخیر قابل امتیازدهی شروع می‌شود.
                // ============================================================

                int totalScore = 0;
                int maxDelay = 0;

                var delayDetails = new List<string>();

                foreach (var inst in installments)
                {
                    DateTime checkDate;

                    // اگر قسط کامل پرداخت شده باشد،
                    // تاریخ پرداخت کامل ملاک است.
                    if (inst.IsPaid && inst.PayDate.HasValue)
                    {
                        checkDate = inst.PayDate.Value;
                    }
                    else
                    {
                        // اگر قسط کامل نشده باشد،
                        // امروز ملاک محاسبه تأخیر است.
                        checkDate = DateTime.Today;
                    }

                    // --------------------------------------------------------
                    // تاریخ پایان مهلت 3 ماهه
                    //
                    // مثلاً:
                    // 1403/06/16 + 3 ماه = 1403/09/16
                    // --------------------------------------------------------

                    DateTime threeMonthsAfterDue;

                    try
                    {
                        threeMonthsAfterDue =
                            pc.ToDateTime(
                                pc.GetYear(inst.DueDate),
                                pc.GetMonth(inst.DueDate),
                                pc.GetDayOfMonth(inst.DueDate),
                                0,
                                0,
                                0,
                                0);

                        // اضافه کردن سه ماه با تقویم شمسی
                        int dueY = pc.GetYear(inst.DueDate);
                        int dueM = pc.GetMonth(inst.DueDate);
                        int dueD = pc.GetDayOfMonth(inst.DueDate);

                        int targetY = dueY;
                        int targetM = dueM + 3;

                        while (targetM > 12)
                        {
                            targetM -= 12;
                            targetY++;
                        }

                        // اگر روز سررسید در ماه مقصد وجود نداشته باشد،
                        // آخرین روز معتبر ماه انتخاب می‌شود.
                        int validDay = dueD;

                        threeMonthsAfterDue =
                            pc.ToDateTime(
                                targetY,
                                targetM,
                                1,
                                0,
                                0,
                                0,
                                0);

                        while (validDay > 1)
                        {
                            try
                            {
                                threeMonthsAfterDue =
                                    pc.ToDateTime(
                                        targetY,
                                        targetM,
                                        validDay,
                                        0,
                                        0,
                                        0,
                                        0);

                                break;
                            }
                            catch (ArgumentOutOfRangeException)
                            {
                                validDay--;
                            }
                        }
                    }
                    catch
                    {
                        // در صورت خطای غیرمنتظره، از AddMonths میلادی
                        // به عنوان fallback استفاده می‌کنیم.
                        threeMonthsAfterDue =
                            inst.DueDate.AddMonths(3);
                    }

                    // ========================================================
                    // هنوز 3 ماه کامل نشده است
                    // ========================================================

                    if (checkDate <= threeMonthsAfterDue)
                    {
                        inst.DelayMonths = 0;
                        continue;
                    }

                    // ========================================================
                    // از اینجا به بعد، تأخیر بیشتر از 3 ماه است.
                    //
                    // مثال:
                    //
                    // سررسید: 16 شهریور
                    // پایان مهلت: 16 آذر
                    //
                    // پرداخت: 17 آذر
                    //
                    // => وارد تأخیر امتیازدار شده است.
                    // ========================================================

                    int dueY2 = pc.GetYear(inst.DueDate);
                    int dueM2 = pc.GetMonth(inst.DueDate);

                    int checkY = pc.GetYear(checkDate);
                    int checkM = pc.GetMonth(checkDate);
                    int checkD = pc.GetDayOfMonth(checkDate);

                    // اختلاف ماه از تاریخ سررسید
                    int monthDiff =
                        (checkY - dueY2) * 12 +
                        (checkM - dueM2);

                    // اگر روز پرداخت/بررسی قبل از روز سررسید باشد،
                    // هنوز یک ماه کامل دیگر نگذشته است.
                    if (checkD < pc.GetDayOfMonth(inst.DueDate))
                    {
                        monthDiff--;
                    }

                    // حداقل تأخیر امتیازدار = 1 ماه
                    //
                    // چون 3 ماه اول مهلت هستند،
                    // 4 ماه از سررسید => 1 ماه تأخیر امتیازدار
                    int delayMonths = monthDiff - 3;

                    if (delayMonths < 1)
                    {
                        delayMonths = 1;
                    }

                    inst.DelayMonths = delayMonths;

                    // بیشترین تأخیر
                    if (inst.DelayMonths > maxDelay)
                    {
                        maxDelay = inst.DelayMonths;
                    }

                    // ========================================================
                    // محاسبه امتیاز
                    //
                    // 1 تا 3 ماه تأخیر امتیازدار = 1 امتیاز
                    // 4 تا 6 ماه = 2 امتیاز
                    // 7 تا 9 ماه = 3 امتیاز
                    // ...
                    // ========================================================

                    int score =
                        (inst.DelayMonths + 2) / 3;

                    totalScore += score;

                    string payDateStr;

                    if (inst.IsPaid && inst.PayDate.HasValue)
                    {
                        payDateStr =
                            ConvertToPersianDate(
                                inst.PayDate.Value);
                    }
                    else
                    {
                        payDateStr = "پرداخت نشده";
                    }

                    string paidAmountStr =
                        inst.PaidAmount.ToString(
                            "N0",
                            CultureInfo.InvariantCulture);

                    string installmentAmountStr =
                        inst.Amount.ToString(
                            "N0",
                            CultureInfo.InvariantCulture);

                    delayDetails.Add(
                        $"قسط {ConvertToPersianDate(inst.DueDate)} " +
                        $"(پرداخت: {payDateStr}) " +
                        $"- مبلغ قسط: {installmentAmountStr} " +
                        $"- پرداخت شده: {paidAmountStr}: " +
                        $"{inst.DelayMonths} ماه تاخیر → {score} امتیاز");
                }

                // ============================================================
                // 6. ساخت توضیحات نهایی
                // ============================================================

                string delayReason;

                if (totalScore > 0)
                {
                    delayReason =
                        $"تاخیر در اقساط وام: " +
                        $"{string.Join(" | ", delayDetails)}";
                }
                else if (maxDelay > 0)
                {
                    delayReason =
                        $"تاخیر جزئی در وام " +
                        $"(کمتر از ۳ ماه و بدون امتیاز منفی): " +
                        $"{maxDelay} ماه";
                }
                else
                {
                    delayReason =
                        "بدون تاخیر قابل توجه در اقساط وام";
                }

                // ============================================================
                // 7. خروجی نهایی
                // ============================================================

                result.NegativeScore = totalScore;
                result.DelayedMonths = maxDelay;
                result.DelayReason = delayReason;

                return result;
            }
            catch (Exception ex)
            {
                result.NegativeScore = 0;
                result.DelayedMonths = 0;
                result.DelayReason =
                    $"خطا در محاسبه وام: {ex.Message}";

                return result;
            }
        }
        public class NegativeScoreResult
            {
                public int NegativeScore { get; set; }
                public int DelayedMonths { get; set; }
                public string DelayReason { get; set; }

         
      
        }

            // کلاس برای وضعیت ماهانه
            public class MonthStatusInfo
            {
                public DateTime Month { get; set; }
                public bool IsFullyPaid { get; set; }
                public long Expected { get; set; }
                public long Paid { get; set; }
            }

            // کلاس برای نگهداری اطلاعات بازه
            public class DelayRangeInfo
            {
                public DateTime StartDate { get; set; }
                public DateTime EndDate { get; set; }
                public int Months { get; set; }
                public int Score { get; set; }
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetAvvalinDarkhastMembers(
            string sidx,
            string sord,
            int page,
            int rows)
        {
            var results = new List<MemberNegativeScoreResult>();

            int totalRecords = 0;
            int totalPages = 0;

            try
            {
                using (SandooghModel db = new SandooghModel())
                {
                   var today = DateTime.Today;

var sixMonthsAgo = today.AddMonths(-6);

var queueSetting = db.VamQueueSettings
    .FirstOrDefault(x => x.Id == 1);

if (queueSetting == null || !queueSetting.IsConfigured)
{
    throw new InvalidOperationException(
        "تنظیمات ورود به نوبت وام تکمیل نشده است."
    );
}

var membershipBeforeDeyCutoff =
    today.AddMonths(-queueSetting.MembershipMonthsBeforeDey1402);

var membershipFromDeyCutoff =
    today.AddMonths(-queueSetting.MembershipMonthsFromDey1402);

var dey1402 =
    new PersianCalendar().ToDateTime(1402, 10, 1, 0, 0, 0, 0);
                    // =========================================================
                    // اعضای واجد شرایط
                    // =========================================================
                    var eligibleMemberIds = db.T_OzvCode
                        //.Where(o => o.Id == 12597)
                        .Where(o => o.Faal == true)
                        .Where(o =>
                            !db.VamNobats.Any(vn =>
                                vn.IdRefOzv == o.Id &&
                                vn.IdRefVam == null))
                        .Where(o =>
                            (
                                // عضو بدون وام: 6 ماه برای عضویت‌های قبل از دی 1402 و 4 ماه از دی 1402
                                !db.Vams.Any(v =>
                                    v.IdRefOzv == o.Id)
                                &&
                                (
                                   (o.OzvDate < dey1402 &&
 o.OzvDate <= membershipBeforeDeyCutoff)
                                    ||
                                    (o.OzvDate >= dey1402 &&
 o.OzvDate <= membershipFromDeyCutoff)
                                )
                            )
                            ||
                            (
                                // حداقل یک وام تسویه شده دارد
                                db.Vams.Any(v =>
                                    v.IdRefOzv == o.Id &&
                                    v.EtmamVam == true)
                                &&
                                // وام تسویه نشده ندارد
                                !db.Vams.Any(v =>
                                    v.IdRefOzv == o.Id &&
                                    v.EtmamVam == false)
                            )
                        )
                        .Select(o => o.Id)
                        .ToList();


                    var eligibleMembers =
                        new List<MemberNegativeScoreResult>();

                    var queueInfoByMember =
                        new Dictionary<int, QueueEligibilityInfo>();


                    // =========================================================
                    // تعیین StartDate برای هر عضو
                    // =========================================================
                    foreach (var memberId in eligibleMemberIds)
                    {
                        var member = db.T_OzvCode
                            .FirstOrDefault(o => o.Id == memberId);

                        if (member == null)
                            continue;


                        var queueInfo = CalculateQueueEligibilityInfo(member, db);
                        queueInfoByMember[member.Id] = queueInfo;
                        var membershipEligibilityDate =
      GetMembershipEligibilityDate(member, queueSetting);
                        DateTime actualStartDate = queueInfo.BaseDate;
                        DateTime? lastVamPayDate = queueInfo.LastLoanPaymentDate;

                        var lastPaymentDate =
                            lastVamPayDate ??
                            actualStartDate;


                        // =====================================================
                        // آیا بعد از شش ماه عضویت پرداخت مستمری داشته؟
                        // =====================================================
                        var hasPaidAfterDue =
                            db.G_M_Pays.Any(gp =>
                                gp.IdRefOzv == memberId &&
                                gp.MostamariMablag > 0 &&
                                gp.PayDate >= membershipEligibilityDate);


                        // =====================================================
                        // ساخت نتیجه عضو
                        // =====================================================
                        var item =
                            new MemberNegativeScoreResult
                            {
                                Id = member.Id,

                                GUID =
                                    member.GUID ?? Guid.Empty,

                                Faal =
                                    member.Faal ?? false,

                                FName =
                                    member.FName,

                                LName =
                                    member.LName,

                                FatherName =
                                    member.FatherName,

                                MelliCode =
                                    member.MelliCode,

                                TavalodDate =
                                    member.TavalodDate,

                                OzvDate =
                                    member.OzvDate,

                                ShNo =
                                    member.ShNo,

                                parvanehNo =
                                    member.parvanehNo,

                                NezamNo =
                                    member.NezamNo,

                                Tel =
                                    member.Tel,

                                Mobile =
                                    member.Mobile,

                                Address =
                                    member.Address,

                        // ---------------------------------------------
                        // تاریخ محاسبه چرخه
                        // ---------------------------------------------
                        StartDate =
                                    actualStartDate,

                                IsOver6Months =
                                    member.OzvDate <= sixMonthsAgo,

                                HasPaidAfterDue =
                                    hasPaidAfterDue,

                                DayDiff =
                                    (int)(
                                        today -
                                        actualStartDate)
                                    .TotalDays,

                                LastPaymentDate =
                                    lastPaymentDate
                            };


                        eligibleMembers.Add(item);
                    }


                    // =========================================================
                    // محاسبه امتیاز منفی
                    // =========================================================
                    foreach (var member in eligibleMembers)
                    {
                        QueueEligibilityInfo queueInfo;
                        if (queueInfoByMember.TryGetValue((int)member.Id, out queueInfo))
                        {
                            var totalResult = queueInfo.Score ?? new TotalNegativeScoreResult();

                            member.NegativeScore = totalResult.TotalNegativeScore;
                            member.DelayedMonths = Math.Max(
                                totalResult.MostamariDelayedMonths,
                                totalResult.VamDelayedMonths);
                            member.DelayReason = totalResult.CombinedDelayReason;
                            member.MostamariNegativeScore = totalResult.MostamariNegativeScore;
                            member.VamNegativeScore = totalResult.VamNegativeScore;
                            member.MostamariDelayReason = totalResult.MostamariDelayReason;
                            member.VamDelayReason = totalResult.VamDelayReason;

                            member.QueueDelayMonths = queueInfo.QueueDelayMonths;
                            member.QueueEligibleDate = queueInfo.QueueEligibleDate;
                            member.CanEnterQueue = queueInfo.QueueEligibleDate.Date <= today.Date;
                        }
                        else
                        {
                            member.NegativeScore = 0;
                            member.DelayedMonths = 0;
                            member.QueueDelayMonths = 0;
                            member.CanEnterQueue = false;
                            member.DelayReason = "محاسبه شرایط ورود به نوبت انجام نشد";
                        }
                    }


                    // =========================================================
                    // تعداد کل رکوردها
                    // =========================================================
                    totalRecords =
                        eligibleMembers.Count;


                    totalPages =
                        rows > 0
                            ? (int)Math.Ceiling(
                                totalRecords * 1.0 / rows)
                            : 0;


                    // =========================================================
                    // مرتب‌سازی
                    // =========================================================
                    var orderedMembers =
                        eligibleMembers.AsQueryable();


                    if (sord == "asc")
                    {
                        if (sidx == "DayDiff")
                        {
                            orderedMembers =
                                orderedMembers.OrderBy(
                                    m => m.DayDiff);
                        }
                        else if (sidx == "NegativeScore")
                        {
                            orderedMembers =
                                orderedMembers.OrderBy(
                                    m => m.NegativeScore);
                        }
                        else
                        {
                            orderedMembers =
                                orderedMembers.OrderBy(
                                    m => m.Id);
                        }
                    }
                    else
                    {
                        if (sidx == "DayDiff")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    m => m.DayDiff);
                        }
                        else if (sidx == "NegativeScore")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    m => m.NegativeScore);
                        }
                        else
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    m => m.Id);
                        }
                    }


                    // =========================================================
                    // Paging
                    // =========================================================
                    var pagedMembers =
                        orderedMembers
                            .Skip((page - 1) * rows)
                            .Take(rows)
                            .ToList();


                    // =========================================================
                    // jqGrid
                    // =========================================================
                    var productsData =
                        new JqGridData
                        {
                            Total =
                                totalPages,

                            Page =
                                page,

                            Records =
                                totalRecords,

                            Rows =
                                pagedMembers
                                    .Select(product =>
                                        new JqGridRowData
                                        {
                                            Id =
                                                product.Id,

                                            RowCells =
                                                new List<object>
                                                {
                                            product.GUID.ToString(),

                                            product.Id,

                                            product.Faal,

                                            product.FName ?? "",

                                            product.LName ?? "",

                                            product.FatherName ?? "",

                                            product.MelliCode ?? "",

                                            ConvertToPersianDate(
                                                product.TavalodDate),

                                            ConvertToPersianDate(
                                                product.OzvDate),

                                            product.ShNo ?? "",

                                            product.parvanehNo ?? "",

                                            product.NezamNo ?? "",

                                            product.Tel ?? "",

                                            product.Mobile ?? "",

                                            product.Address ?? "",

                                            ConvertToPersianDate(
                                                product.LastPaymentDate),

                                            product.IsOver6Months
                                                ? 1
                                                : 0,

                                            product.DayDiff ?? 0,

                                            product.HasPaidAfterDue
                                                ? 1
                                                : 0,

                                            product.NegativeScore,

                                            product.DelayedMonths,

                                            product.DelayReason ?? "",

                                            product.QueueDelayMonths,

                                            ConvertToPersianDate(product.QueueEligibleDate)
                                                }
                                        })
                                    .ToList()
                        };


                    return Json(
                        productsData,
                        JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    "Error: " + ex.Message);


                return Json(
                    new JqGridData
                    {
                        Total = 0,

                        Page = page,

                        Records = 0,

                        Rows =
                            new List<JqGridRowData>()
                    },
                    JsonRequestBehavior.AllowGet);
            }
        }
        private TotalNegativeScoreResult CalculateTotalNegativeScore(DateTime startDate, long memberId, SandooghModel db)
        {
            var result = new TotalNegativeScoreResult();

            // محاسبه امتیاز منفی مستمری
            var mostamariResult = CalculateMostamariNegativeScore(startDate, memberId, db);
            result.MostamariNegativeScore = mostamariResult.NegativeScore;
            result.MostamariDelayedMonths = mostamariResult.DelayedMonths;
            result.MostamariDelayReason = mostamariResult.DelayReason;

            // محاسبه امتیاز منفی وام (برای وام تسویه شده)
            var vamResult = CalculateVamNegativeScore(memberId, db);
            result.VamNegativeScore = vamResult.NegativeScore;
            result.VamDelayedMonths = vamResult.DelayedMonths;
            result.VamDelayReason = vamResult.DelayReason;

            // جمع کل امتیازات
            result.TotalNegativeScore = result.MostamariNegativeScore + result.VamNegativeScore;

            // ساخت توضیحات ترکیبی
            var combinedParts = new List<string>();

            // بخش مستمری
            if (result.MostamariNegativeScore > 0)
            {
                combinedParts.Add($"مستمری: {result.MostamariDelayReason}");
            }
            else if (result.MostamariDelayedMonths > 0)
            {
                combinedParts.Add($"مستمری: {result.MostamariDelayReason}");
            }
            else
            {
                combinedParts.Add("مستمری: بدون تاخیر");
            }

            // بخش وام
            if (result.VamNegativeScore > 0)
            {
                combinedParts.Add($"وام: {result.VamDelayReason}");
            }
            else if (result.VamDelayedMonths > 0)
            {
                combinedParts.Add($"وام: {result.VamDelayReason}");
            }
            else
            {
                combinedParts.Add("وام: بدون تاخیر");
            }

            result.CombinedDelayReason = string.Join(" | ", combinedParts);

            return result;
        }
        private static DateTime GetPersianMonthStart(DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            return pc.ToDateTime(
                pc.GetYear(date),
                pc.GetMonth(date),
                1, 0, 0, 0, 0);
        }

        private static DateTime GetNextPersianMonthStart(DateTime persianMonthStart)
        {
            PersianCalendar pc = new PersianCalendar();
            int py = pc.GetYear(persianMonthStart);
            int pm = pc.GetMonth(persianMonthStart) + 1;

            if (pm > 12) { pm = 1; py++; }

            return pc.ToDateTime(py, pm, 1, 0, 0, 0, 0);
        }
        private NegativeScoreResult CalculateMostamariNegativeScore(DateTime startDate, long memberId, SandooghModel db)
        {
            var result = new NegativeScoreResult();

            // ============================================================
            // تلورانس پرداخت مستمری
            //
            // واحد: ریال (اگر تومان ذخیره می‌شود، اعداد را ÷۱۰ کنید)
            //
            // سقف مطلق: ۲۰,۰۰۰ تومان = ۲۰۰,۰۰۰ ریال
            // نسبت: ۲۰٪ مبلغ مورد انتظار
            // ============================================================
            const decimal MaxMostamariTolerance = 200000m;
            const decimal MostamariToleranceRatio = 0.2m;

            try
            {
                // دریافت کاربر
                var user = db.T_OzvCode.FirstOrDefault(o => o.Id == memberId);
                if (user == null)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "عضو یافت نشد";
                    return result;
                }

                // تاریخ شروع محاسبه - از پارامتر ورودی استفاده می‌شود
                var effectiveStartDate = startDate;

                if (effectiveStartDate > DateTime.Today)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "هنوز به موعد پرداخت نرسیده است";
                    return result;
                }

                // دریافت همه تغییرات مستمری پایه
                var baseChanges = user.T_MostamaryMablagh
                    .Where(m => m.MostamaryMablagh_DateStart.HasValue)
                    .OrderBy(m => m.MostamaryMablagh_DateStart)
                    .ToList();

                // ============================================================
                // ساخت لیست ماه‌های شمسی
                //
                // قاعده: اگر StartDate دقیقاً اول ماه شمسی نباشد،
                // آن ماه نادیده گرفته می‌شود و محاسبه از اول ماه بعد شروع می‌شود.
                // (مناسب برای عضو جدیدی که وسط ماه اضافه شده)
                // ============================================================

                PersianCalendar pc = new PersianCalendar();

                var today = DateTime.Today;
                var oneYearLater = today.AddMonths(12);

                var startMonthBegin = GetPersianMonthStart(effectiveStartDate);

                DateTime currentDate;

                if (effectiveStartDate.Date == startMonthBegin.Date)
                {
                    // StartDate دقیقاً اول ماه است → همان ماه شروع می‌شود
                    currentDate = startMonthBegin;
                }
                else
                {
                    // StartDate وسط ماه است → از اول ماه بعد شروع می‌شود
                    currentDate = GetNextPersianMonthStart(startMonthBegin);
                }

                var months = new List<DateTime>();

                while (currentDate <= oneYearLater)
                {
                    months.Add(currentDate);
                    currentDate = GetNextPersianMonthStart(currentDate);
                }

                if (months.Count == 0)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "بدون تأخیر قابل توجه";
                    return result;
                }
                // محاسبه مبلغ مورد انتظار برای هر ماه
                var expectedAmounts = new Dictionary<DateTime, long>();
                foreach (var month in months)
                {
                    long expectedAmount = 500000;

                    var baseForMonth = baseChanges
                        .Where(b => b.MostamaryMablagh_DateStart.Value <= month)
                        .OrderByDescending(b => b.MostamaryMablagh_DateStart)
                        .FirstOrDefault();

                    if (baseForMonth != null && baseForMonth.MostamaryMablagh_Mablagh.HasValue)
                    {
                        expectedAmount = (long)baseForMonth.MostamaryMablagh_Mablagh.Value;
                    }

                    expectedAmounts[month] = expectedAmount;
                }

                // دریافت مبالغ پرداخت شده (فقط مستمری‌های عادی، نه افزایش‌ها)
                var payments = db.G_M_Pays
                    .Where(p => p.IdRefOzv == memberId
                                && p.MostamariMablag > 0
                                && (p.IsAfzayesh == null || p.IsAfzayesh != true))
                    .ToList();

                var paidAmounts = new Dictionary<DateTime, long>();
                foreach (var payment in payments)
                {
                    if (payment.PayDate.HasValue)
                    {
                        var paymentMonth = GetPersianMonthStart(payment.PayDate.Value);
                        if (!paidAmounts.ContainsKey(paymentMonth))
                            paidAmounts[paymentMonth] = 0;
                        paidAmounts[paymentMonth] += (long)(payment.MostamariMablag ?? 0);
                    }
                }

                // تشخیص ماه‌هایی که کامل پرداخت نشده‌اند
                var monthStatus = new List<MonthStatusInfo>();
                foreach (var month in months)
                {
                    var expected = expectedAmounts[month];
                    var paid = paidAmounts.ContainsKey(month) ? paidAmounts[month] : 0;

                    // ---------------------------------------------------------
                    // محاسبه تلورانس مؤثر
                    // min(سقف مطلق، درصدی از مبلغ مورد انتظار)
                    // ---------------------------------------------------------
                    decimal expectedDec = expected;
                    decimal paidDec = paid;

                    decimal shortfall = expectedDec - paidDec;

                    decimal effectiveTolerance = Math.Min(
                        MaxMostamariTolerance,
                        expectedDec * MostamariToleranceRatio);

                    // ماه «کامل» است اگر:
                    // - پرداخت ≥ مورد انتظار باشد، یا
                    // - کسری مثبت باشد ولی از تلورانس مؤثر بیشتر نباشد
                    bool isFullyPaid =
                        paidDec >= expectedDec ||
                        (shortfall > 0 && shortfall <= effectiveTolerance);

                    monthStatus.Add(new MonthStatusInfo
                    {
                        Month = month,
                        IsFullyPaid = isFullyPaid,
                        Expected = expected,
                        Paid = paid   // مبلغ واقعی پرداخت‌شده حفظ می‌شود
                    });
                }

                // پیدا کردن بازه‌های تاخیر متوالی (فقط تا امروز)
                var delayRanges = new List<DelayRangeInfo>();
                int consecutive = 0;
                DateTime? rangeStart = null;

                for (int i = 0; i < monthStatus.Count; i++)
                {
                    // فقط ماه‌های کامل‌شده بررسی شوند
                    // ماه جاری (که هنوز تمام نشده) نادیده گرفته می‌شود
                    if (monthStatus[i].Month >= GetPersianMonthStart(today))
                        break;

                    bool isFullyPaid = monthStatus[i].IsFullyPaid;
                    

                    if (!isFullyPaid)
                    {
                        if (consecutive == 0)
                        {
                            rangeStart = monthStatus[i].Month;
                        }
                        consecutive++;
                    }
                    else
                    {
                        if (consecutive > 0)
                        {
                            int score = consecutive <= 4 ? 0 : ((consecutive - 4) / 4) + 1;

                            var lastMonth = monthStatus
                                .Where(m => m.Month < GetPersianMonthStart(today))
                                .LastOrDefault();

                            if (lastMonth != null)
                            {
                                delayRanges.Add(new DelayRangeInfo
                                {
                                    StartDate = rangeStart.Value,
                                    EndDate = lastMonth.Month,
                                    Months = consecutive,
                                    Score = score
                                });
                            }
                        }
                    }
                }

                // بررسی آخرین بازه
                if (consecutive > 0)
                {
                    int score = consecutive <= 4 ? 0 : ((consecutive - 4) / 4) + 1;

                    var lastMonth = monthStatus.Where(m => m.Month <= today).LastOrDefault();
                    if (lastMonth != null)
                    {
                        delayRanges.Add(new DelayRangeInfo
                        {
                            StartDate = rangeStart.Value,
                            EndDate = lastMonth.Month,
                            Months = consecutive,
                            Score = score
                        });
                    }
                }

                var totalScore = delayRanges.Sum(r => r.Score);
                var maxDelay = delayRanges.Any() ? delayRanges.Max(r => r.Months) : 0;

                // ساخت DelayReason
                string delayReason;
                if (totalScore > 0)
                {
                    var detailsList = new List<string>();
                    foreach (var r in delayRanges.Where(r => r.Score > 0))
                    {
                        detailsList.Add($"بازه {ConvertToPersianDate(r.StartDate)} تا {ConvertToPersianDate(r.EndDate)}: {r.Months} ماه → {r.Score} امتیاز");
                    }
                    delayReason = $"دارای {totalScore} امتیاز منفی ({string.Join(" | ", detailsList)})";
                }
                else if (maxDelay > 0)
                {
                    var detailsList = new List<string>();
                    foreach (var r in delayRanges)
                    {
                        detailsList.Add($"بازه {ConvertToPersianDate(r.StartDate)} تا {ConvertToPersianDate(r.EndDate)}: {r.Months} ماه");
                    }
                    delayReason = $"بدون تأخیر قابل توجه ({string.Join(" | ", detailsList)})";
                }
                else
                {
                    delayReason = "بدون تأخیر قابل توجه";
                }

                result.NegativeScore = totalScore;
                result.DelayedMonths = maxDelay;
                result.DelayReason = delayReason;

                return result;
            }
            catch (Exception ex)
            {
                result.NegativeScore = 0;
                result.DelayedMonths = 0;
                result.DelayReason = $"خطا در محاسبه: {ex.Message}";
                return result;
            }
        }
        // متد تبدیل تاریخ میلادی به شمسی
        private string ConvertToPersianDate(DateTime? date)
            {
                if (!date.HasValue)
                    return "";

                PersianCalendar pc = new PersianCalendar();
                return $"{pc.GetYear(date.Value)}/{pc.GetMonth(date.Value):00}/{pc.GetDayOfMonth(date.Value):00}";
            }
        
 
   
        private string FixDelayReason(string delayReason, DateTime? lastPaymentDate)
        {
            if (string.IsNullOrEmpty(delayReason))
                return "بدون تاخیر";

            if (!lastPaymentDate.HasValue)
                return delayReason;

            var miladyDate = lastPaymentDate.Value.ToString("yyyy-MM-dd");
            var persianDate = ConvertToPersianDate(lastPaymentDate);

            return delayReason.Replace(miladyDate, persianDate);
        }

        // متد تبدیل تاریخ میلادی به شمسی
        
        // متد تبدیل اعداد انگلیسی به فارسی (اختیاری)
        private string ConvertToPersianNumbers(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            string[] englishNumbers = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            string[] persianNumbers = { "۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹" };

            for (int i = 0; i < englishNumbers.Length; i++)
            {
                input = input.Replace(englishNumbers[i], persianNumbers[i]);
            }

            return input;
        }
        private string GetCityName(SandooghModel db, int? cityCode)
        {
            if (!cityCode.HasValue) return "";
            var city = db.CityCodes.FirstOrDefault(c => c.id == cityCode.Value);
            return city?.CityName ?? "";
        }

        private string GetTaaholName(SandooghModel db, int? taaholId)
        {
            if (!taaholId.HasValue) return "";
            var taahol = db.Taahols.FirstOrDefault(t => t.Taahol_Id == taaholId.Value);
            return taahol?.Taahol_Name ?? "";
        }
        public class MemberNegativeScoreResult
        {
            public long Id { get; set; }
            public Guid GUID { get; set; }
            public bool Faal { get; set; }
            public string FName { get; set; }
            public string LName { get; set; }
            public string FatherName { get; set; }
            public string MelliCode { get; set; }
            public DateTime? TavalodDate { get; set; }
            public DateTime? OzvDate { get; set; }
            public string ShNo { get; set; }
            public string parvanehNo { get; set; }
            public string NezamNo { get; set; }
            public string Tel { get; set; }
            public string Mobile { get; set; }
            public string Address { get; set; }
            public DateTime? LastPaymentDate { get; set; }
            public DateTime? StartDate { get; set; }
            public bool IsOver6Months { get; set; }
            public int? DayDiff { get; set; }
            public bool HasPaidAfterDue { get; set; }
            public int NegativeScore { get; set; }
            public int DelayedMonths { get; set; }
            public string DelayReason { get; set; }
            public int TotalRecords { get; set; }
            public int TotalPages { get; set; }
            public int MostamariNegativeScore { get; set; }
            public int VamNegativeScore { get; set; }
            public string MostamariDelayReason { get; set; }
            public string VamDelayReason { get; set; }
            public int QueueDelayMonths { get; set; }
            public DateTime? QueueEligibleDate { get; set; }
            public bool CanEnterQueue { get; set; }
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddMostamary(T_MostamaryMablagh postData)
        {
           if (postData.MostamaryMablagh_IdRefOzvCode == null) return Json(false);
            SandooghModel db = new SandooghModel();
            //ToDo: Add Product To Repository
          
            if (postData == null)
                return Json(false);
            AccountController acc = new AccountController();

            postData.MostamaryMablagh_ModifiedUser = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
            postData.MostamaryMablagh_CurrentBeruzDate = postData.MostamaryMablagh_DateStart;
            postData.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == postData.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)postData.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
            db.T_MostamaryMablagh.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteMostamary(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_MostamaryMablagh.FirstOrDefault(x => x.MostamaryMablagh_ID == idd);
            if (product == null)
                return Json(false);

            db.T_MostamaryMablagh.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        
        [Authorize(Roles = "Admin")]
        public JsonResult updateafzayeshpayeh(long id,int mablagh)
        {
            SandooghModel db = new SandooghModel();

            try
            {
                var ozv =  db.T_OzvCode.Where(k => k.Id== id).FirstOrDefault();
                ozv.SumAfzayeshMostamary = mablagh;
                db.Entry(ozv).State = EntityState.Modified;
                db.SaveChanges();
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GeMostamaryMablaghByid(long id)
        {
            SandooghModel db = new SandooghModel();
  
        
                var AkharinVosoliDate = "";
                var mablaghmost = 500000;
                var ghabeleafzayesh = 0;
                bool afzayeshdade = false;
                var MandeMostMablagh = 0;
                var tedad = 0;
            var user = (from e in db.T_OzvCode where e.Id == id select e).FirstOrDefault();

            try
            {

                
                ghabeleafzayesh = (int)user.SumAfzayeshMostamary;


                try
                {
                    if (user.G_M_Pays.Where(k => k.IsAfzayesh == true).Count() > 0)
                    {
                        afzayeshdade = true;
                    }
                    else
                    {
                        afzayeshdade = false;
                    }
                }
                catch
                {

                }
                var mostamarypaie = user.T_MostamaryMablagh.LastOrDefault();
                if (mostamarypaie.MostamaryMablagh_Mablagh == 500000 && mostamarypaie.MostamaryMablagh_DateStart >= PersianDateUtils.ToMilady("1402/10/01"))
                {
                    //اگر بعد از تاریخ 14021001 یک مستمری پایه با مبلغ 50 تومن ثبت شده آن را به 100 تومن تغییر بده
                    mostamarypaie.MostamaryMablagh_Mablagh = 1000000;
                    db.Entry(mostamarypaie).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
                var summost = user.G_M_Pays.Where(e => e.PayDate <= mostamarypaie.MostamaryMablagh_DateStart || e.IsAfzayesh != true).Sum(k => k.MostamariMablag);

                if (mostamarypaie != null)
                {

                    int kheilivaghtpishmande = 0;
                    if (mostamarypaie.MostamaryMablagh_DateStart == PersianDateUtils.ToMilady("1397/09/01"))//اگر این تاریخ باشد یعنی یک مستمری پایه قبل از این نیز بررسی شود
                    {
                        mostamarypaie = user.T_MostamaryMablagh.Where(k => k.MostamaryMablagh_DateStart != PersianDateUtils.ToMilady("1397/09/01")).OrderByDescending(e => e.MostamaryMablagh_ID).FirstOrDefault();
                        kheilivaghtpishmande = 1;
                    }

                    var mybaiestta970901 = 0;
                    var mybaiestta14021001 = 0;
                    var tedadpardakhtshode = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart) / mostamarypaie.MostamaryMablagh_Mablagh);
                    var kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * mostamarypaie.MostamaryMablagh_Mablagh);

                    var persianCalendar = new System.Globalization.PersianCalendar();
                    if (kheilivaghtpishmande == 1)
                    {
                        for (int y = 0; persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, y) <= PersianDateUtils.ToMilady("1397/09/01"); y++)
                        {

                            mybaiestta970901 = y;

                        }
                    }
                    AkharinVosoliDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();

                    if (kheilivaghtpishmande == 1 && PersianDateUtils.ToMilady(AkharinVosoliDate) > PersianDateUtils.ToMilady("1397/09/01"))
                    {
                        var temp = mostamarypaie.MostamaryMablagh_Mablagh * mybaiestta970901 + mostamarypaie.MostamaryMablagh_VarizyTaDateStart;
                        mostamarypaie = user.T_MostamaryMablagh.LastOrDefault();
                        mostamarypaie.MostamaryMablagh_VarizyTaDateStart = (int)temp;
                        tedadpardakhtshode = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart) / mostamarypaie.MostamaryMablagh_Mablagh);
                        kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * mostamarypaie.MostamaryMablagh_Mablagh);

                        AkharinVosoliDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();


                        kheilivaghtpishmande = 0;
                    }//یعنی تا تاریخی که میبایست حداقل 20 تومان رو واریز میکرد کرده و حالا باید با مستمری پایه جدید اقدام بشه
                    else
                               if (mostamarypaie.MostamaryMablagh_Mablagh == 500000)
                    {

                        //یعنی تاریخ این مستمری پایه حتما قبل از 1 آذر 1402 هست 
                        if (PersianDateUtils.ToMilady(AkharinVosoliDate) >= PersianDateUtils.ToMilady("1402/10/01"))//
                        {
                            for (int y = 0; persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, y) <= PersianDateUtils.ToMilady("1402/10/01"); y++)
                            {

                                mybaiestta14021001 = y;

                            }
                            var temp = mostamarypaie.MostamaryMablagh_Mablagh * mybaiestta14021001 + mostamarypaie.MostamaryMablagh_VarizyTaDateStart;
                            try
                            {
                                var afzayeshinbein = user.G_M_Pays.Where(e => e.PayDate <= PersianDateUtils.ToMilady("1402/10/01") && e.PayDate > mostamarypaie.MostamaryMablagh_DateStart && e.IsAfzayesh == true).Sum(k => k.MostamariMablag);

                                temp = temp + afzayeshinbein;
                            }
                            catch
                            {

                            }




                            MVCSandoogh.Models.T_MostamaryMablagh moma = new MVCSandoogh.Models.T_MostamaryMablagh();
                            try { moma.MostamaryMablagh_CurrentBeruzDate = PersianDateUtils.ToMilady("1402/10/01"); } catch { }
                            try { moma.MostamaryMablagh_DateStart = PersianDateUtils.ToMilady("1402/10/01"); } catch { }

                            moma.MostamaryMablagh_IdRefOzvCode = mostamarypaie.MostamaryMablagh_IdRefOzvCode;
                            moma.MostamaryMablagh_Mablagh = 1000000;
                            moma.MostamaryMablagh_VarizyTaDateStart = (int)temp;
                            db.T_MostamaryMablagh.Add(moma);
                            db.SaveChanges();
                            //    mostamarypaie = moma;
                            //    tedadpardakhtshode = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart) / mostamarypaie.MostamaryMablagh_Mablagh);
                            //    kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * mostamarypaie.MostamaryMablagh_Mablagh);
                            //    AkharinVosoliDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();
                            return GeMostamaryMablaghByid(id);
                            //  ispaieadded = true;
                            //continue;
                        }

                    }

                    mablaghmost = (int)mostamarypaie.MostamaryMablagh_Mablagh;
                    int nowyear = persianCalendar.GetYear(DateTime.Now);
                    int nowmonth = persianCalendar.GetMonth(DateTime.Now);
                    int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);
                    if (kheilivaghtpishmande == 1)
                    {
                        nowyear = 1397;
                        nowmonth = 09;
                        nowday = 01;
                    }
                    int MibayestVarizMost = 0;
                    DateTime now = persianCalendar.ToDateTime(nowyear, nowmonth, nowday, 0, 0, 0, 0);
                    DateTime tempdate = (DateTime)mostamarypaie.MostamaryMablagh_DateStart;
                    while (tempdate <= now)
                    {
                        MibayestVarizMost++;
                        tempdate = persianCalendar.AddMonths((tempdate), 1);
                    }
                    // if (MibayestVarizMost > 0) { MibayestVarizMost++; }
                    if (kheilivaghtpishmande == 1)
                    {
                        nowyear = persianCalendar.GetYear(DateTime.Now);
                        nowmonth = persianCalendar.GetMonth(DateTime.Now);
                        nowday = persianCalendar.GetDayOfMonth(DateTime.Now);


                    }
                    // var MablaghSarresidKolliVam = (product.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)product.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)product.AvlinGestDate)))));
                    MibayestVarizMost = MibayestVarizMost - tedadpardakhtshode;
                    tedad = (int)MibayestVarizMost;
                    var MibayestVarizMost50 = 0;
                    var MibayestVarizMost100 = 0;

                    if (MibayestVarizMost < 0) { MibayestVarizMost = 0; }
                    MandeMostMablagh = (int)MibayestVarizMost * mablaghmost;
                    if (kheilivaghtpishmande == 1 || mostamarypaie.MostamaryMablagh_Mablagh == 500000)
                    {

                        DateTime now1 = persianCalendar.ToDateTime(nowyear, nowmonth, nowday, 0, 0, 0, 0);
                        DateTime n14021001 = persianCalendar.ToDateTime(1402, 10, 01, 0, 0, 0, 0);
                        DateTime n13970901 = persianCalendar.ToDateTime(1397, 09, 01, 0, 0, 0, 0);



                        if (kheilivaghtpishmande != 1)

                        {
                            n13970901 = (DateTime)PersianDateUtils.ToMilady(AkharinVosoliDate);
                        }
                        while (persianCalendar.AddMonths(n13970901, 1) < n14021001)
                        {
                            MibayestVarizMost50++;
                            n13970901 = persianCalendar.AddMonths(n13970901, 1);
                        }

                        while (n14021001 <= now1)
                        {
                            MibayestVarizMost100++;
                            n14021001 = persianCalendar.AddMonths(n14021001, 1);
                        }

                        if (MibayestVarizMost50 > 0)
                        {
                            MibayestVarizMost50++;
                        }
                        //if (MibayestVarizMost100 > 0)
                        //{
                        //    MibayestVarizMost100++;
                        //}
                        if (kheilivaghtpishmande != 1)
                        {
                            MandeMostMablagh = MibayestVarizMost50 * 500000 + MibayestVarizMost100 * 1000000;
                        }
                        else
                        {
                            MandeMostMablagh += MibayestVarizMost50 * 500000 + MibayestVarizMost100 * 1000000;

                        }
                    }

                    if (MibayestVarizMost >= 7 && ((mostamarypaie.MostamaryMablagh_DateStart < PersianDateUtils.ToMilady("1402/10/01") && mostamarypaie.MostamaryMablagh_Mablagh > 500000)) && kheilivaghtpishmande != 1)
                    {
                        MVCSandoogh.Models.T_MostamaryMablagh moma = new MVCSandoogh.Models.T_MostamaryMablagh();
                        try { moma.MostamaryMablagh_CurrentBeruzDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_CurrentBeruzDate, (int)tedadpardakhtshode); } catch { }
                        try { moma.MostamaryMablagh_DateStart = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode); } catch { }
                        var tempmablagh = user.G_M_Pays.Where(e => e.PayDate <= moma.MostamaryMablagh_DateStart || e.IsAfzayesh != true).Sum(k => k.MostamariMablag);

                        moma.MostamaryMablagh_IdRefOzvCode = mostamarypaie.MostamaryMablagh_IdRefOzvCode;
                        moma.MostamaryMablagh_Mablagh = 500000;
                        moma.MostamaryMablagh_VarizyTaDateStart = (int)tempmablagh;
                        db.T_MostamaryMablagh.Add(moma);
                        db.SaveChanges();
                        mostamarypaie = moma;
                        kheilivaghtpishmande = 0;
                        tedadpardakhtshode = 0;
                        AkharinVosoliDate = persianCalendar.AddMonths((DateTime)moma.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();
                        MandeMostMablagh = MibayestVarizMost * 500000;
                        kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * 500000);

                    }
                    //else
             //if (MibayestVarizMost >= 5 && ((mostamarypaie.MostamaryMablagh_DateStart >= PersianDateUtils.ToMilady("1402/10/01") && mostamarypaie.MostamaryMablagh_Mablagh > 1000000)) && kheilivaghtpishmande != 1)
             //       {
             //           MVCSandoogh.Models.T_MostamaryMablagh moma = new MVCSandoogh.Models.T_MostamaryMablagh();
             //           try { moma.MostamaryMablagh_CurrentBeruzDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_CurrentBeruzDate, (int)tedadpardakhtshode); } catch { }
             //           try { moma.MostamaryMablagh_DateStart = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode); } catch { }
             //           var tempmablagh = user.G_M_Pays.Where(e => e.PayDate <= moma.MostamaryMablagh_DateStart || e.IsAfzayesh != true).Sum(k => k.MostamariMablag);

             //           moma.MostamaryMablagh_IdRefOzvCode = mostamarypaie.MostamaryMablagh_IdRefOzvCode;
             //           moma.MostamaryMablagh_Mablagh = 1000000;
             //           moma.MostamaryMablagh_VarizyTaDateStart = (int)tempmablagh;
             //           db.T_MostamaryMablagh.Add(moma);
             //           db.SaveChanges();
             //           mostamarypaie = moma;
             //           kheilivaghtpishmande = 0;
             //           tedadpardakhtshode = 0;
             //           AkharinVosoliDate = persianCalendar.AddMonths((DateTime)moma.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();
             //           MandeMostMablagh = MibayestVarizMost * 1000000;
             //           kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * 1000000);



             //       }
             //pasha
                    if (kasr > 0)
                    {
                        if ((MandeMostMablagh - (int)kasr) > 0) 
                        { MandeMostMablagh = MandeMostMablagh - (int)kasr; }
                        else
                        { MandeMostMablagh = 0; }


                    }

                    ViewBag.AkharinVosoliDate = AkharinVosoliDate;
                    ViewBag.MandeMostMablagh = MandeMostMablagh;

                }
            }
            catch
            {

            }

            try
            {
                try
                {
                    if (user.Faal == false)
                    {
                        AkharinVosoliDate = "--";
                        MandeMostMablagh = 0;
                    }
                }
                catch
                {

                }
                  var list = (from e in db.T_MostamaryMablagh.Where(k=>k.MostamaryMablagh_IdRefOzvCode==id).ToList() select new { AkharinVosoliDate = AkharinVosoliDate,
                MandeMostMablagh = MandeMostMablagh<0?0: MandeMostMablagh,
                      MostamaryMablagh_VarizyTaDateStart = e.MostamaryMablagh_VarizyTaDateStart, MostamaryMablagh_CurrentBeruzDate = (e.MostamaryMablagh_CurrentBeruzDate != null ? PersianDateUtils.ToPersianDate((DateTime)e.MostamaryMablagh_CurrentBeruzDate) : ""), MostamaryMablagh_DateStart =(e.MostamaryMablagh_DateStart!=null? PersianDateUtils.ToPersianDate((DateTime) e.MostamaryMablagh_DateStart):""), e.MostamaryMablagh_Mablagh,
                      SumAfzayeshMostamary=e.T_OzvCode.Faal==true? e.T_OzvCode.SumAfzayeshMostamary : 0 });
               
                return Json(list, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
                [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GeMostamaryMablagh(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
     
            try
            { 
           var  list = db.T_MostamaryMablagh.ToList();
       
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                           
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.MostamaryMablagh_ID,
                    RowCells = new List<object>
                               {
                                     product.MostamaryMablagh_ID,
                                   product.T_OzvCode.FName,product.T_OzvCode.LName  ,product.MostamaryMablagh_Mablagh.ToString(),
                     product.MostamaryMablagh_CurrentBeruzDate!=null?((DateTime)product.MostamaryMablagh_CurrentBeruzDate).ToPersianDate():"", 
                     product.MostamaryMablagh_DateStart!=null?((DateTime)product.MostamaryMablagh_DateStart).ToPersianDate():""
                        ,product.MostamaryMablagh_IdRefOzvCode.ToString(), product.T_User.User_UserName

                                   
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        public ActionResult CitySelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.CityCodes.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.CityName,
                Value = x.id.ToString(CultureInfo.InvariantCulture)
            }).ToList();
            return PartialView("_SelectPartial", suppliers);
        }
        public ActionResult TaaholSelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.Taahols.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.Taahol_Name,
                Value = x.Taahol_Id.ToString(CultureInfo.InvariantCulture)
            }).ToList();
            return PartialView("_SelectPartial", suppliers);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public ActionResult DeleteMember(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_OzvCode.FirstOrDefault(x => x.Id ==idd );
            if (product == null)
                return Json(false);
            if (Membership.GetUser(Id.ToString()) != null)
            {
                Membership.DeleteUser(Id.ToString());
              
            }
            List<string> parameters = new List<string>(new string[] { "User_UserName" });
            List<object> values = new List<object>(new object[] { Id });
            DataGatheration gath = new DataGatheration();
            gath.GetTableStoredProcedure("NewDeleteUser", parameters, values);

            var number = 0;
            try
            {
                number = (from e in db.AccSanad_B where e.Tafsili == Id select e).ToList().Count;
            }
            catch
            {

            }
            if (number == 0)
            {
                try
                {
                    string hh = idd.ToString();
                    /*1212*/
                    var t2 = db.Acc_Tafsili2.FirstOrDefault(x => x.Tafsili2_Code == hh);
                    db.Acc_Tafsili2.Remove(t2);
                    db.SaveChanges();
                }
                catch
                {

                }
                    try
                {
                    var t3 = db.ScanDB.Where(x => x.IdRef == idd).ToList();
                    foreach (var scan in t3)
                    {
                        db.ScanDB.Remove(scan);
                        try
                        {
                            System.IO.File.Delete(Server.MapPath(scan.ScanURL.Replace("../../..", "~")));
                        }
                        catch
                        {

                        }

                    }
                    db.SaveChanges();
                }
                catch
                {

                }
                try
                {
                    db.T_OzvCode.Remove(product);
                    db.SaveChanges();
                }
                catch
                {

                }
                return Json(true);
            }
            else
                return Json(false);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddMember(T_OzvCode postData)
        {
            SandooghModel db = new SandooghModel();
                int idddd = (from e in db.T_OzvCode select e.Id).Max();

                postData.Faal = true;
                postData.GUID = Guid.NewGuid();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                postData.OzvDate = DateTime.Now;
                postData.Faal = true;
                postData.CityCode = (from o in db.CityCodes
                                     where o.id == postData.CityCode.id
                                     select o).First();
                postData.CityCode1 = (from o in db.CityCodes
                                      where o.id == postData.CityCode1.id
                                      select o).First();
                postData.Taahol = (from o in db.Taahols
                                   where o.Taahol_Id == postData.Taahol.Taahol_Id
                                   select o).First();
                db.Entry(postData.CityCode).State = EntityState.Modified;
                db.Entry(postData.CityCode1).State = EntityState.Modified;
                db.Entry(postData.Taahol).State = EntityState.Modified;
                if (postData != null) postData.Id = idddd + 1;
                db.T_OzvCode.Add(postData);
                db.SaveChanges();

                Acc_Tafsili2 t2 = new Acc_Tafsili2();

                t2.Tafsili2_Tafsili1 = 2;
                t2.Tafsili2_Code = postData.Id.ToString();/*1212*/
            t2.Tafsili2_Comment = postData.FName + " " + postData.LName;
                db.Acc_Tafsili2.Add(t2);

                db.SaveChanges();

                string message = " مهندس ارجمند " + postData.FName + " " + postData.LName + "" + "\n" +
                    "حضور شما را در جمع اعضاي صندوق قرض الحسنه نظام مهندسي ساختمان استان آذربايجان غربي گرامي ميداريم."
                + "\n" + "شماره عضويت : " + postData.Id + "\n" +
                "تاريخ عضويت : " + DateTime.Now.ToPersianDate() + "\n" + "هيئت مديره صندوق قرض الحسنه";
                SendMsg(new string[] { postData.Mobile }, message);

                if (Membership.GetUser(postData.Id.ToString()) == null)
                {
                if (postData.MelliCode.Length < 8)postData.MelliCode = "123456789";
                    Membership.CreateUser(postData.Id.ToString(), postData.MelliCode);
                    List<string> parameters = new List<string>(new string[] {

            "User_UserName","User_Firstname","User_lastname",
            "User_Email","User_Mobile","User_OzvCdoe"});
                    List<object> values = new List<object>(new object[] {

           postData.Id,postData.FName+" "+postData.LName,"",
           postData.Id,postData.Mobile,postData.Id});
                    DataGatheration gath = new DataGatheration();
                    gath.GetTableStoredProcedure("NewInsertUser", parameters, values);
                    Roles.AddUserToRole(postData.Id.ToString(), "User");
                }
                return Json(true);
           
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditMember(T_OzvCode postData)
        {
            SandooghModel db = new SandooghModel();
               //todo: Add product to repository
            if (postData == null)
                return Json(false);
            var sumafzayesh = (from e in db.T_OzvCode where e.Id == postData.Id select e.SumAfzayeshMostamary).FirstOrDefault();
            postData.SumAfzayeshMostamary = sumafzayesh;
         
            postData.CityCode = (from o in db.CityCodes
                                 where o.id == postData.CityCode.id
                                 select o).First();
            postData.OzvCode_TavalodCity = postData.CityCode.id;
            postData.CityCode1 = (from o in db.CityCodes
                                  where o.id == postData.CityCode1.id
                                  select o).First();
            postData.OzvCode_ShCity = postData.CityCode1.id;
            postData.Taahol = (from o in db.Taahols
                               where o.Taahol_Id == postData.Taahol.Taahol_Id
                               select o).First();
            postData.ozvcode_Taahol = postData.Taahol.Taahol_Id;
            db.Entry(postData.CityCode).State = EntityState.Modified;
            db.Entry(postData.CityCode1).State = EntityState.Modified;
            db.Entry(postData.Taahol).State = EntityState.Modified;
            db.Entry(postData).State= EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();

            SandooghModel bb = new SandooghModel();
            /*1212*/
            string hh = postData.Id.ToString();
            Acc_Tafsili2 t2 =bb.Acc_Tafsili2.Where(e=> e.Tafsili2_Code == hh).FirstOrDefault();
            t2.Tafsili2_Comment = postData.FName + " " + postData.LName;
            bb.Entry(t2).State = EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            bb.SaveChanges();




            return Json(true);
        }
        
      


    }
}


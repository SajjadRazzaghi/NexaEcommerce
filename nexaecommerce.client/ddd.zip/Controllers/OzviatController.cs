﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCSandoogh.Models;
using MVCSandoogh.Extensions;
using System.Globalization;
using System.Data.Entity;
using System.IO;
using MVCSandoogh.GhasedakServiceRefrence;
using MVCSandoogh;
using MVCSandoogh.Controllers;
using System.Web.Security;
using PIDCoSmsPackage;
using PIDCoSmsPackage.Model;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace MVCSmartLibrary.Controllers
{
   public class OzviatController : Controller
    {


        // GET: Ozviat
        [Authorize(Roles = "Admin")]
        public ActionResult Index()

        {
            SandooghModel db = new SandooghModel();
            List<SelectListItem> CityList = new List<SelectListItem>();
            List<CityCode> citylist = db.CityCodes.ToList();
            foreach (CityCode city in citylist)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = city.id.ToString();
                sli.Text = city.CityName;
                CityList.Add(sli);
            }
            ViewBag.cities = CityList;

            return View();
        }

        
        [HttpPost]
        public ActionResult GetTasviehChartData(string azdate, string tadate)
        {

            SandooghModel db = new SandooghModel();
            DateTime azdatei1 = DateTime.MinValue;
            DateTime tadatei1 = DateTime.MaxValue;
            try
            {
                azdatei1 = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei1 = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            Dictionary<string, int> Result = new Dictionary<string, int>();
            //  if (!(azdatei1 == DateTime.MinValue && tadatei1 == DateTime.MaxValue))
            {
                if (azdatei1 == DateTime.MinValue)
                    azdatei1 = DateTime.Parse("2019/03/21 12:00:00 AM");// (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Min(e => e.PayDate).Value;
                if (tadatei1 == DateTime.MaxValue)
                    tadatei1 = (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Max(e => e.PayDate).Value;

                PersianCalendar pl = new PersianCalendar();
                int nowmonth = pl.GetMonth(tadatei1);
                int nowyear = pl.GetYear(tadatei1);
                int beforyea = pl.GetYear(azdatei1);
                int beformonth = pl.GetMonth(azdatei1);
                Dictionary<int, int> BeforDic = new Dictionary<int, int>();

                Dictionary<int, int> yearDic = new Dictionary<int, int>();
                int j = beformonth;
                for (int i = beformonth; beforyea * 12 + beformonth <= nowyear * 12 + nowmonth; i = (i + 1) % 13, j++)
                {

                    if (i == 0) i++;

                    DateTime dateaz = (DateTime)(beforyea + "/" + i + "/1").ToMilady();
                    yearDic.Add(j, beforyea);
                    DateTime dateta = (DateTime)((i == 12 ? beforyea+1:beforyea) + "/" + (i == 12 ? 1 : i + 1) + "/1").ToMilady();
                    int count = (from e in db.Tasviehs where e.PayDate >= dateaz && e.PayDate < dateta select e.Id).Count();
                    if (count == null) count = 0;
                    if (i == 12)
                    {
                        beforyea += 1;
                        beformonth = 1;

                    }
                    else
                        beformonth = i + 1;
                    BeforDic.Add(j, count);

                }



                for (int k = 0; k < BeforDic.Count; k++)
                {
                    switch (BeforDic.ElementAt(k).Key % 12)
                    {
                        case 1:
                            Result.Add("فروردین" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 2:
                            Result.Add("اردیبهشت" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 3:
                            Result.Add("خرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 4:
                            Result.Add("تیر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 5:
                            Result.Add("مرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 6:
                            Result.Add("شهریور" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 7:
                            Result.Add("مهر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 8:
                            Result.Add("آبان" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 9:
                            Result.Add("آذر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 10:
                            Result.Add("دی" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 11:
                            Result.Add("بهمن" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 0:
                            Result.Add("اسفند" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                    }
                }

            }

            return Json(Result, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public ActionResult GetChartData()
        {

            SandooghModel db = new SandooghModel();
            DateTime now = DateTime.Now;
            PersianCalendar pl = new PersianCalendar();
           int nowmonth= pl.GetMonth(now);
            int nowyear = pl.GetYear(now);
            int beforyea = nowyear - 1;
            int beformonth = 1;
            Dictionary<int, int> BeforDic = new Dictionary<int, int>();
            Dictionary<int, int> NowDic = new Dictionary<int, int>();
            for (int i=1;i<=12;i++)
            {
                DateTime dateaz =(DateTime) (beforyea + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    beforyea += 1;
                    beformonth = 1;
                }
                else
                {
                    beformonth = i + 1;
                }
                DateTime dateta = (DateTime)(beforyea + "/" + beformonth + "/1").ToMilady();
                int count = (from e in db.T_OzvCode where e.OzvDate >= dateaz && e.OzvDate < dateta select e.Id).Count();
                if (count == null) count = 0;
                BeforDic.Add(i,count);

            }
          
            int nm = 1;
            for (int i = 1; i <= nowmonth; i++)
            {
                DateTime dateaz = (DateTime)(nowyear + "/" + i + "/1").ToMilady();
                if (i + 1 == 13)
                {
                    nowyear += 1;
                    nm = 1;
                }
                else
                {
                    nm = i + 1;
                }
                DateTime dateta = (DateTime)(nowyear + "/" + nm + "/1").ToMilady();
                int count = (from e in db.T_OzvCode where e.OzvDate >= dateaz && e.OzvDate < dateta select e.Id).Count();
                if (count == null) count = 0;
                NowDic.Add(i, count);
            }

             nowyear = pl.GetYear(now);
             beforyea = nowyear - 1;
            Dictionary<string, int> Result = new Dictionary<string, int>();
            for(int k=0;k<BeforDic.Count;k++)
            {
                switch(BeforDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین"+beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + beforyea, BeforDic.ElementAt(k).Value);
                        break;
                }
            }

            for (int k = 0; k < NowDic.Count; k++)
            {
                switch (NowDic.ElementAt(k).Key)
                {
                    case 1:
                        Result.Add("فروردین" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 2:
                        Result.Add("اردیبهشت" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 3:
                        Result.Add("خرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 4:
                        Result.Add("تیر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 5:
                        Result.Add("مرداد" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 6:
                        Result.Add("شهریور" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 7:
                        Result.Add("مهر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 8:
                        Result.Add("آبان" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 9:
                        Result.Add("آذر" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 10:
                        Result.Add("دی" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 11:
                        Result.Add("بهمن" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                    case 12:
                        Result.Add("اسفند" + nowyear, NowDic.ElementAt(k).Value);
                        break;
                }
            }


            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetChartData1(string azdate,string tadate)
        {

            SandooghModel db = new SandooghModel();
            DateTime azdatei1 = DateTime.MinValue;
            DateTime tadatei1 = DateTime.MaxValue;
            try
            {
                azdatei1 = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei1 = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
            Dictionary<string, int> Result = new Dictionary<string, int>();
            //  if (!(azdatei1 == DateTime.MinValue && tadatei1 == DateTime.MaxValue))
            {
                if (azdatei1 == DateTime.MinValue)
                    azdatei1 = DateTime.Parse("2019/03/21 12:00:00 AM");// (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Min(e => e.PayDate).Value;
                if (tadatei1 == DateTime.MaxValue)
                    tadatei1 = (from e in db.Tasviehs select e).Where(e => e.PayDate != null).Max(e => e.PayDate).Value;

                PersianCalendar pl = new PersianCalendar();
                int nowmonth = pl.GetMonth(tadatei1);
                int nowyear = pl.GetYear(tadatei1);
                int beforyea = pl.GetYear(azdatei1);
                int beformonth = pl.GetMonth(azdatei1);
                Dictionary<int, int> BeforDic = new Dictionary<int, int>();

                Dictionary<int, int> yearDic = new Dictionary<int, int>();
                int j = beformonth;
                for (int i = beformonth; beforyea * 12 + beformonth <= nowyear * 12 + nowmonth; i = (i + 1) % 13, j++)
                {

                    if (i == 0) i++;

                    DateTime dateaz = (DateTime)(beforyea + "/" + i + "/1").ToMilady();
                    yearDic.Add(j, beforyea);
                    DateTime dateta = (DateTime)((i == 12 ? beforyea + 1 : beforyea) + "/" + (i == 12 ? 1 : i + 1) + "/1").ToMilady();
                    int count = (from e in db.Tasviehs where e.PayDate >= dateaz && e.PayDate < dateta select e.Id).Count();
                    if (count == null) count = 0;
                    if (i == 12)
                    {
                        beforyea += 1;
                        beformonth = 1;

                    }
                    else
                        beformonth = i + 1;
                    BeforDic.Add(j, count);

                }



                for (int k = 0; k < BeforDic.Count; k++)
                {
                    switch (BeforDic.ElementAt(k).Key % 12)
                    {
                        case 1:
                            Result.Add("فروردین" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 2:
                            Result.Add("اردیبهشت" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 3:
                            Result.Add("خرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 4:
                            Result.Add("تیر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 5:
                            Result.Add("مرداد" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 6:
                            Result.Add("شهریور" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 7:
                            Result.Add("مهر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 8:
                            Result.Add("آبان" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 9:
                            Result.Add("آذر" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 10:
                            Result.Add("دی" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 11:
                            Result.Add("بهمن" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                        case 0:
                            Result.Add("اسفند" + yearDic.ElementAt(k), BeforDic.ElementAt(k).Value);
                            break;
                    }
                }

            }

            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult AvalinDarkhast()

        {
            SandooghModel db = new SandooghModel();
            List<SelectListItem> CityList = new List<SelectListItem>();
            List<CityCode> citylist = db.CityCodes.ToList();
            foreach (CityCode city in citylist)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = city.id.ToString();
                sli.Text = city.CityName;
                CityList.Add(sli);
            }
            ViewBag.cities = CityList;

            return View();
        }
        private string GetReplacementValue(string fieldName, T_OzvCode ozvCode)
        {
            // استفاده از reflection برای یافتن ویژگی‌های (properties) مدل T_OzvCode
            var properties = typeof(T_OzvCode).GetProperties();

            foreach (var property in properties)
            {
                if (string.Equals(property.Name, fieldName, StringComparison.OrdinalIgnoreCase))
                {
                    // یافتن فیلد مطابق با نام فیلد و خواندن مقدار آن از ozvCode
                    var value = property.GetValue(ozvCode);

                    // تبدیل مقدار به رشته و برگشت آن
                    return value?.ToString() ?? "";
                }
            }

            // اگر نام فیلد معتبر نباشد، مقدار خالی یا مقدار پیشفرض دلخواه را برگردانید.
            return "";
        }
        [HttpPost]
        public ActionResult SendAllSms(string Message,string codemelli, string ozviatcode, string fname, string lname, string tavalod, string sodoor, string type, string Faal = "")
        {
            string originalmessage = Message;
            /* عضو محترم صنم، خواهشمند است جهت واریز وجوه مستمری و اقساط، از طریق کلیه همراه بانکها و اینترنت بانکهای موجود خود، به روش انتقال <<پایا>>  یا <<ساتنا>>، با درج شناسه مربوطه اقدام فرمائید.
   شماره شبای صندوق:
    IR380130100000000428808130
   شناسه واریز مستمری:#mostammarryshenase
   شناسه واریز قسط:#ghestshenase
            همچنین به منظور مشاهده و پیگیری واریزی ها، می توانید با استفاده از نام کاربری و کلمه عبور خود، از طریق وب سایت سازمان نظام مهندسی ساختمان و ورود به سامانه صندوق قرض الحسنه، اقدام نمایید.
            نام کاربری:#Id
   کلمه عبور:#MelliCode
            */
            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();

            if (Faal == "a")
                list = (from e in list where e.Faal == true select e).ToList();
            else
                  if (Faal == "da")
                list = (from e in list where e.Faal == false select e).ToList();

            if (type == "m")
                list = (from e in list where e.OzvCode_Jensiat == 1 select e).ToList();
            else
                if (type == "z")
                list = (from e in list where e.OzvCode_Jensiat == 2 select e).ToList();

            if (codemelli != null && codemelli.Length > 0)
                list = (from e in list where e.MelliCode.Contains(codemelli) select e).ToList();
            if (ozviatcode != null && ozviatcode.Length > 0)
                list = (from e in list where e.NezamNo.Contains(ozviatcode) select e).ToList();
            if (fname != null && fname.Length > 0)
                list = (from e in list where e.FName.Contains(fname) select e).ToList();
            if (lname != null && lname.Length > 0)
                list = (from e in list where e.LName.Contains(lname) select e).ToList();
            try
            {
                if (tavalod != null && tavalod.Length > 0)
                {
                    int tavalod1 = int.Parse(tavalod);
                    list = (from e in list where e.OzvCode_TavalodCity == tavalod1 select e).ToList();
                }
            }
            catch
            {

            }
            try
            {
                if (sodoor != null && sodoor.Length > 0)
                {
                    int sodoor1 = int.Parse(sodoor);
                    list = (from e in list where e.OzvCode_ShCity == sodoor1 select e).ToList();
                }
            }
            catch
            {

            }


        
            var totalRecords = list.Count;
          

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery                                   
                                            .ToList();


            List<string> numbers = new List<string>();
         
            foreach (T_OzvCode s in productsList)
            {
                int d = 1;
                numbers.Add(s.Mobile);
                string tempmessage = originalmessage;
                // برای یافتن نام فیلد در متن پیام اصلی از Regex استفاده می‌کنیم.
                MatchCollection matches = Regex.Matches(tempmessage, "#([A-Za-z_]+)");
               
                foreach (Match match in matches)
                {
                    // نام فیلد را از متن استخراج می‌کنیم (مثلاً "نام_فیلد").
                    string fieldName = match.Groups[1].Value;

                    // مقدار متناظر با نام فیلد را از مدل T_OzvCode استخراج می‌کنیم.
                    string replacementValue = GetReplacementValue(fieldName, s); // تابعی که مقدار متناظر را با توجه به نام فیلد برمی‌گرداند.

                    // مقدار نام فیلد را با مقدار متناظر جایگزین می‌کنیم.
                    tempmessage = tempmessage.Replace("#" + fieldName, replacementValue);
                }

                if (originalmessage.Contains("#"))
                {
                    SendMsg(numbers.ToArray(), tempmessage);
                    numbers = new List<string>();
                }
                else
                {
                    d++;
                    if (d == 98)
                    {
                        d = 1;
                        SendMsg(numbers.ToArray(), tempmessage);
                        numbers = new List<string>();


                    }
                }

            }
            if (numbers.Count > 0&&!originalmessage.Contains("#"))
            {
                SendMsg(numbers.ToArray(),Message);

           }
            return Json(true, JsonRequestBehavior.AllowGet);
        }
        public ActionResult SendSms()
        {
            SandooghModel db = new SandooghModel();
            List<SelectListItem> CityList = new List<SelectListItem>();
            List<CityCode> citylist = db.CityCodes.ToList();
            foreach (CityCode city in citylist)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = city.id.ToString();
                sli.Text = city.CityName;
                CityList.Add(sli);
            }
            ViewBag.cities = CityList;
            return View();
        }
        public ActionResult ScanType()
        {
            return View();
        }
        [HttpPost]
        public ActionResult GetScanTypes(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_ScanType.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.ScanType_ID,
                    RowCells = new List<object>
                               {
                                    product.ScanType_ID,
                                     product.ScanType_Name.ToString()
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult AddScanType(T_ScanType postData)
        {
            SandooghModel db = new SandooghModel();
         
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.T_ScanType.Add(postData);
            db.SaveChanges();
            return Json(true);
        }
        [HttpPost]
        public ActionResult EditScanType(T_ScanType postData)
        {
            SandooghModel db = new SandooghModel();
            //todo: Add product to repository
            if (postData == null)
                return Json(false);
            db.Entry(postData).State = System.Data.Entity.EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        public ActionResult DeleteScanType(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_ScanType.FirstOrDefault(x => x.ScanType_ID == idd);
            if (product == null)
                return Json(false);

            db.T_ScanType.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
      
        //[NonAction]
        public System.Threading.Tasks.Task<MVCSandoogh.GhasedakServiceRefrence.SendSMSResponse> SendMsg(string[] numbers, string message)
        {
            //var client = new RestClient("http://api.ghasedaksms.com/v2/sms/send/bulk");
            //var request = new RestRequest(Method.Post);
            //request.AddHeader("apikey", "n2zyZ9qR9kUJuTy3bpepy8hTJoSQha4KvcY3LvXQqbs");

            //request.AddParameter("receptor", 09121111111, 9122222222);
            //request.AddParameter("message", "تست 1 , تست 2");
            //request.AddParameter("checkingids", "11509774,11509775");
            //request.AddParameter("sender", "50001000,50002000");
            //IRestResponse response = client.Execute(request);


           try
            {
                ArrayOfString senderNumbers = new ArrayOfString();
        
                senderNumbers.Add( "90007081");
              v2SoapClient asc=new v2SoapClient();
                var recivers = new ArrayOfString();
                recivers.AddRange(numbers.ToList());
                var messages  = new ArrayOfString();
                messages.AddRange(new string[] { message }.ToList<string>());
                //
               var result= asc.SendSMSAsync("sandogh.1378@gmail.com", "@SA12345@", senderNumbers, recivers, messages,null, null, null);
                return result;
            }
            catch (Exception ex)
            {
                return null;
            }
            //try
            //{

            //    var smsService = new SmsService();
            //    var ssvm = new SendViewModel
            //    {
            //        Password = "S!23@",
            //        Username = "sandoogh",
            //        Folder = "web",
            //        Number = "500010033384311",
            //        ReceiverPhoneNumbers = numbers.ToList(),
            //        SmsText = message
            //    };
            //     var result= Task.Run(()=>  smsService.Send(ssvm)).Result;
            //    return result;
            //}
            //catch(Exception ex)
            //{

            //    return null;
            //}

            /*   try
            {           
                SMSZoneSoap sso = new SMSZoneSoapClient();
                ArrayOfString aos = new ArrayOfString();
                aos.InsertRange(0, numbers);        
                DoSendRequestBody dsrb = new DoSendRequestBody(aos, message, "500010033384311", "sandoogh","S!23@",true, "webservice");
                DoSendRequest request = new DoSendRequest(dsrb);
                sso.DoSend(request);
            }
            catch
            {

            }*/


        }
        [HttpPost]
        public ActionResult GetScandbs(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();

            try
            {
                var list = db.ScanDB.ToList();

                var pageIndex = page - 1;
                var pageSize = rows;
                var totalRecords = list.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

                var productsQuery = list.AsQueryable();
                var productsList = productsQuery.OrderBy(sidx + " " + sord)

                                                .ToList();
                var productsData = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,
                    Rows = (productsList.Select(product => new JqGridRowData
                    {
                        Id = product.id,
                        RowCells = new List<object>
                               {
                                     product.id,product.ScanURL,
                                   product.T_OzvCode.FName,product.T_OzvCode.LName,product.T_ScanType!=null?product.T_ScanType.ScanType_Name:""  ,product.ScanDoc,
                       product.SanadSendDate!=null?((DateTime)product.SanadSendDate).ToPersianDate():""
                        ,product.IdRef.ToString(), product.T_User.User_UserName,product.Scan_ScanType


                                }
                    })).ToList()
                };
                return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpPost]
        public ActionResult DeleteScandb(string id)
        {
            int idd = int.Parse(id);
         
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.ScanDB.FirstOrDefault(x => x.id == idd);
            System.IO.File.Delete(Server.MapPath( product.ScanURL.Replace("../../..", "~")));
            if (product == null)
                return Json(false);

            db.ScanDB.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddScans(ScanDB postData,Array Files)
        {
            SandooghModel db = new SandooghModel();
            //ToDo: Add Product To Repository

            if (postData == null)
                return Json(false);
            else
            {
                AccountController acc = new AccountController();
                foreach (object filename in Files)
                {
                    ScanDB p = postData;
                    p.SendedUser = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
                    p.SanadSendDate = DateTime.Now;
                    p.ScanURL =filename.ToString();
                  
                    db.ScanDB.Add(p);
                    db.SaveChanges();
                    return Json(true);
                }
            }
            return Json(false);
        }

        
          [AcceptVerbs(HttpVerbs.Post)]
            public ActionResult UploadLettersDataFile(HttpPostedFileBase qqfile)
        {

            if (qqfile != null && qqfile.ContentLength > 0)
            {
                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(qqfile.FileName);
                var path = Path.Combine(Server.MapPath("~/UploadedFiles/Letters"), fileName);
                qqfile.SaveAs(@path);
                // further processing on file can be done here
                return Json(new { success = true, FilName = "../../../UploadedFiles/Letters/" + fileName });

            }
            else
            {
                // this works for Firefox, Chrome
                var filename = Request["qqfile"];
                if (!string.IsNullOrEmpty(filename))
                {
                    string newFileName = Guid.NewGuid().ToString() + Path.GetExtension(filename.ToString());
                    filename = Path.Combine(Server.MapPath("~/UploadedFiles/Letters"), newFileName);
                    using (var output = System.IO.File.Create(filename))
                    {
                        Request.InputStream.CopyTo(output);
                    }
                    // further processing on file can be done here
                    return Json(new { success = true, FilName = "../../../UploadedFiles/Letters/" + newFileName });

                }
            }
            return Json(new { success = false });
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult UploadBatchDataFile(HttpPostedFileBase qqfile)
        {
           
            if (qqfile != null && qqfile.ContentLength > 0)
            {
                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(qqfile.FileName);
                var path = Path.Combine(Server.MapPath("~/UploadedFiles/BatchData"), fileName);
                qqfile.SaveAs(@path);
                // further processing on file can be done here
                return Json(new { success = true, FilName = "../../../UploadedFiles/BatchData/" + fileName });

            }
            else
            {
                // this works for Firefox, Chrome
                var filename = Request["qqfile"];
                if (!string.IsNullOrEmpty(filename))
                {
                    string newFileName = Guid.NewGuid().ToString() + Path.GetExtension(filename.ToString());
                    filename = Path.Combine(Server.MapPath("~/UploadedFiles/BatchData"), newFileName);
                    using (var output = System.IO.File.Create(filename))
                    {
                        Request.InputStream.CopyTo(output);
                    }
                    // further processing on file can be done here
                    return Json(new { success = true, FilName = "../../../UploadedFiles/BatchData/" + newFileName });

                }
            }
            return Json(new { success = false });
        }
        public ActionResult MostamaryMablagh(string idrefozv = "")
        {
            ViewBag.IdOzv = idrefozv;
            return View();
        }

        [Authorize(Roles = "Admin")]
        public ActionResult OzvScans(string idrefozv="",string scantype="1")
        {
          
            ViewBag.IdOzv = idrefozv;
            ViewBag.ScanType = scantype;
            SandooghModel db = new SandooghModel();
            List<SelectListItem> GroupList = new List<SelectListItem>();
            List<T_ScanType> groupList = db.T_ScanType.ToList();
            foreach (T_ScanType group in groupList)
            {
                SelectListItem sli = new SelectListItem();
                sli.Value = group.ScanType_ID.ToString();
                sli.Text = group.ScanType_Name;
                GroupList.Add(sli);
            }
            ViewBag.scantypes = GroupList;
            return View();
        }
        public string ghestshenase = "";
        public string mostamarryshenase = "";
        public string afzayeshshenase = "";

        public string[] setpardakhtyviewbags(string codemelli)
        {
           
            string[] result= new string[3];
            try
            {
                string shenaseghabz = "";
                SandooghModel db = new SandooghModel();
                shenaseghabz = codemelli;

                string afzayesh = "";
                string mostamarry = "";
                string ghest = "";
                string temp = "00000000000000000" + shenaseghabz + "03";
                temp = temp.Substring(temp.Length - 15);
                afzayesh = setcontroli(temp);
                if (afzayesh != "")
                    afzayeshshenase = codemelli+"03" + afzayesh;
                else
                    afzayeshshenase = "";
                temp = "00000000000000000" + shenaseghabz + "01";
                temp = temp.Substring(temp.Length - 15);
                mostamarry = setcontroli(temp);
                if (mostamarry != "")
                    mostamarryshenase = codemelli+"01" + mostamarry;
                else
                    mostamarryshenase = "";
                temp = "00000000000000000" + shenaseghabz + "02";
                temp = temp.Substring(temp.Length - 15);
                ghest = setcontroli(temp);
                if (ghest != "")
                    ghestshenase = codemelli + "02"  + ghest;
                else
                    ghestshenase = "";
                result[0] = afzayeshshenase;
                result[1] = mostamarryshenase;
                result[2] = ghestshenase;
            }
            catch
            {

            }
            return result;
        }
        public string setcontroli(string id)
        {
            int[] iValue = { 15, 14, 13, 12, 11, 10, 9, 1, 2, 3, 4, 5, 6, 7, 8 };
            string sID = id;
            int digitID = 0;
            string tempID;

            if (string.IsNullOrEmpty(sID) || sID.Length > 15)
            {
                return ""; // When The Entered Number Is Greater Than Normal Length ID (15 characters) OR That Is Empty This Section Fired Up!
            }

            sID = "00000000000000000" + sID;
            sID = sID.Substring(sID.Length - 15);

            tempID = sID;
            //     sID = sID.Substring(sID.Length - 17, 15);

            char[] arrID = sID.ToCharArray();
            for (int i = 0; i < iValue.Length; i++)
            {
                digitID += (iValue[i] * (arrID[i] - '0'));
            }

            digitID = int.Parse(("0" + (digitID % 99)).Substring(("0" + (digitID % 99)).Length - 2));

            if(digitID<10)
                return "0"+ digitID.ToString();
            else
            return digitID.ToString(); // The Entered Digit Number Is Correct


        }
        [HttpGet]
        public JsonResult GetShenaseFormOzviat(string Id)
        {
            try
            {
                long id1 = long.Parse(Id);
                SandooghModel db = new SandooghModel();
                var list = from e in db.T_OzvCode
                           where e.Id == id1
                           select e;
                if (list.FirstOrDefault().ghestshenase == null || list.FirstOrDefault().ghestshenase.Length == 0 ||
                    list.FirstOrDefault().mostammarryshenase == null || list.FirstOrDefault().mostammarryshenase.Length == 0 ||
                    list.FirstOrDefault().afzayeshhenase == null || list.FirstOrDefault().afzayeshhenase.Length == 0)
                {
                    var f = setpardakhtyviewbags(list.FirstOrDefault().MelliCode);
                    afzayeshshenase = f[0];
                    mostamarryshenase = f[1];
                    ghestshenase = f[2];

                }
                else
                {
                    afzayeshshenase = list.FirstOrDefault().afzayeshhenase;
                    mostamarryshenase = list.FirstOrDefault().mostammarryshenase;
                    ghestshenase = list.FirstOrDefault().ghestshenase;

                }
            PersianCalendar pl = new PersianCalendar();
                    var result = from oz in list.ToList()
                                 select new
                                 {
                                     name = oz.FName + " " + oz.LName,

                                     id = oz.Id,

                                     codemelli = oz.MelliCode,
                                     afzayeshshenase = afzayeshshenase,
                                     mostamarryshenase = mostamarryshenase,
                                     ghestshenase = ghestshenase


                                 };
                    return Json(result.FirstOrDefault(), JsonRequestBehavior.AllowGet);
               
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult SetAllShenaseOfOzviat()
        {
          
                SandooghModel db = new SandooghModel();
                var ids = db.T_OzvCode.Where(l=>l.ghestshenase==""||l.ghestshenase==null|| l.mostammarryshenase == "" || l.mostammarryshenase == null
                || l.afzayeshhenase == "" || l.afzayeshhenase == null).Select(k => k.Id).ToList();
                foreach (var ozvid in ids)
                {

                try
                {
                    var list = (from e in db.T_OzvCode
                                where e.Id == ozvid
                                select e).FirstOrDefault();
                    var f = setpardakhtyviewbags(list.MelliCode);
                    afzayeshshenase = f[0];
                    mostamarryshenase = f[1];
                    ghestshenase = f[2];
                    list.afzayeshhenase = afzayeshshenase;
                    list.mostammarryshenase = mostamarryshenase;
                    list.ghestshenase = ghestshenase;
                    db.Entry(list).State = EntityState.Modified;
                    db.SaveChanges();
                }
            catch
            {
               
            }
        }
         return Json(true);
        }
        [HttpGet]
        public JsonResult GetMembersWithCodeFormOzviat(string Id)
        {
            try
            {
                long id1 = long.Parse(Id);
                SandooghModel db = new SandooghModel();
                var list = from e in db.T_OzvCode
                           where e.Id == id1 
                           select e;
                PersianCalendar pl = new PersianCalendar();
                var result = from oz in list.ToList()
                             select new
                             {
                                 name = oz.FName + " " + oz.LName,
                                 fname = oz.FName,
                                 lname = oz.LName,
                                 id = oz.Id,
                                 mobile = oz.Mobile,
                                 picture = oz.ScanDBs != null ? oz.ScanDBs.Where(a => a.IdRef == oz.Id && a.Scan_ScanType == 1).ToList().Count > 0 ? oz.ScanDBs.Where(a => a.IdRef == oz.Id && a.Scan_ScanType == 1).FirstOrDefault().ScanURL : null : null
               ,
                                 codemelli = oz.MelliCode,
                                 shsh = oz.ShNo,
                                 father = oz.FatherName,
                                 ozviatenezam = oz.NezamNo,
                                 parvane = oz.parvanehNo,
                                 shaba = oz.SH_Shaba,
                                 address = oz.Address,
                                 phone = oz.Tel,
                                 date = DateTime.Now.ToPersianDate(),
                                 avalieh = (oz.G_M_Pays != null && oz.G_M_Pays.Count > 0) ? oz.G_M_Pays.FirstOrDefault().MostamariMablag.ToString() : "................",
                                 mostamarimablagh = (oz.T_MostamaryMablagh != null && oz.T_MostamaryMablagh.Count > 0) ? oz.T_MostamaryMablagh.LastOrDefault().MostamaryMablagh_Mablagh.ToString() : "................"

                             };
                return Json(result.FirstOrDefault(), JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpGet]
        public JsonResult GetUsersWithCode()
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_User.ToList();
            var result = from oz in list
                         select new
                         {
                             name = oz.User_Firstname + ' ' + oz.User_lastname + '(' + oz.User_OzvCdoe + ')',
                             fname = oz.User_Firstname,
                             lname = oz.User_lastname,
                             id = oz.OzvCode
                         };
            return Json(result.ToList(), JsonRequestBehavior.AllowGet);
        }
      
        [HttpGet]
        public JsonResult GetMembersWithCode()
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();
            var result = from oz in list
                         select new
                         {
                             name = oz.FName + ' ' + oz.LName +'('+oz.Id+')',
                             fname=oz.FName,
                             lname=oz.LName,
                             id = oz.Id,
                             mobile=oz.Mobile
                         };
            return Json(result.ToList(), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult GetSearchOzv(int page, int rows, string sidx = "Id", string sord = "asc")
        {
            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();

            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord).ToList();//کل داده ها را مرتب شده برمیگرداند و دو پارامتر اولی هیچ تاثیری ندارند.
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                                     product.Id,
                                     product.FName.ToString(),product.LName,product.FatherName,
                                     product.MelliCode
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
      
        [HttpGet]
        [AllowAnonymous]
        public ActionResult SearchOzv()
        {
            return View();
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMembersForSms(string sidx, string sord, int page, int rows, string codemelli, string ozviatcode, string fname, string lname, string tavalod, string sodoor, string type, string Faal = "")
        {

            SandooghModel db = new SandooghModel();
            var list = db.T_OzvCode.ToList();

            if (Faal == "a")
                list = (from e in list where e.Faal == true select e).ToList();
            else
                  if (Faal == "da")
                list = (from e in list where e.Faal == false select e).ToList();

            if (type == "m")
                list = (from e in list where e.OzvCode_Jensiat == 1 select e).ToList();
            else
                if (type == "z")
                list = (from e in list where e.OzvCode_Jensiat == 2 select e).ToList();

            if (codemelli != null && codemelli.Length > 0)
                list = (from e in list where e.MelliCode.Contains(codemelli) select e).ToList();
            if (ozviatcode != null && ozviatcode.Length > 0)
            {
                try
                {
                    list = (from e in list where e.Id.ToString().Contains(ozviatcode) select e).ToList();
                }
                catch
                {

                }
            }
               
            if (fname != null && fname.Length > 0)
                list = (from e in list where e.FName.Contains(fname) select e).ToList();
            if (lname != null && lname.Length > 0)
                list = (from e in list where e.LName.Contains(lname) select e).ToList();
            try
            {
                if (tavalod != null && tavalod.Length > 0)
                {
                    int tavalod1 = int.Parse(tavalod);
                    list = (from e in list where e.OzvCode_TavalodCity == tavalod1 select e).ToList();
                }
            }
            catch
            {

            }
            try
            {
                if (sodoor != null && sodoor.Length > 0)
                {
                    int sodoor1 = int.Parse(sodoor);
                    list = (from e in list where e.OzvCode_ShCity == sodoor1 select e).ToList();
                }
            }
            catch
            {

            }


            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            PersianCalendar pl = new PersianCalendar();

            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                                     product.Id,product.Faal,
                                     product.FName.ToString(),product.LName,product.FatherName,
                                     product.MelliCode,product.TavalodDate!=null?((DateTime)product.TavalodDate).ToPersianDate():"",product.OzvDate!=null?((DateTime)product.OzvDate).ToPersianDate():"",product.ShNo,product.CityCode!=null?product.CityCode.CityName:null,product.CityCode1!=null?product.CityCode1.CityName:null,
                                     product.Taahol!=null?product.Taahol.Taahol_Name:null,product.NezamNo,product.Mobile
                                   
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }
     
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMembers(string sidx, string sord, int page, int rows, string codemelli, string ozviatcode, string fname, string lname, string tavalod, string sodoor,string type, string azdate1, string tadate1,string azdate,string tadate,string faaldardate, string Faal="")
        {

            SandooghModel db = new SandooghModel();
            int code = 0;
            try
            {
                code = int.Parse(ozviatcode);
            }
            catch
            {

            }
            var list = from e in db.T_OzvCode select e;
            if (faaldardate != "")//اگر فیلتر فعالها را در تاریخ خاص بخواهیم به آن یکی فعال یا غیر فعالی ترتیب اثر نمی دهد
            {
                DateTime faaldar = DateTime.MinValue;
                try
                {
                  faaldar=  (DateTime)faaldardate.ToMilady();
                }
                catch
                {

                }
               list= (from e in list where e.OzvDate<=faaldar&&( e.Faal == true||(e.Tasviehs.Count>0&&e.Tasviehs.FirstOrDefault().PayDate>=faaldar)||(db.AccSanad_B.Where(l => l.Tafsili == e.Id.ToString() && l.Date_S >= faaldar).Count() > 0)) select e);
            }
            
                if (Faal == "a")
                    list = (from e in list where e.Faal == true select e);
                else
                      if (Faal == "da")
                    list = (from e in list where e.Faal == false select e);
            
            if (type=="m")
                list = (from e in list where e.OzvCode_Jensiat==1 select e);
            else
                if(type=="z")
                list = (from e in list where e.OzvCode_Jensiat==2 select e);

            if (codemelli != null && codemelli.Length > 0)
                    list = (from e in list where e.MelliCode.Contains(codemelli) select e);
                if (ozviatcode != null && ozviatcode.Length > 0)
                    list = (from e in list where e.Id==code select e);
                if (fname != null && fname.Length > 0)
                    list = (from e in list where e.FName.Contains(fname) select e);
                if (lname != null && lname.Length > 0)
                    list = (from e in list where e.LName.Contains(lname) select e);
                try
                {
                    if (tavalod != null && tavalod.Length > 0)
                    {
                        int tavalod1 = int.Parse(tavalod);
                        list = (from e in list where e.OzvCode_TavalodCity==tavalod1 select e);
                    }
                }
                catch
                {

                }
                try
                {
                    if (sodoor != null && sodoor.Length > 0)
                    {
                        int sodoor1 = int.Parse(sodoor);
                        list = (from e in list where e.OzvCode_ShCity == sodoor1 select e);
                    }
                }
                catch
                {

                }
            DateTime azdatei1 = DateTime.MinValue;
            DateTime tadatei1 = DateTime.MaxValue;
            try
            {
                azdatei1 = (DateTime)azdate1.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei1 = (DateTime)tadate1.ToMilady();
            }
            catch
            {

            }
            DateTime azdatei = DateTime.MinValue;
            DateTime tadatei = DateTime.MaxValue;
            try
            {
                azdatei = (DateTime)azdate.ToMilady();
            }
            catch
            {

            }
            try
            {
                tadatei = (DateTime)tadate.ToMilady();
            }
            catch
            {

            }
           
            if(!(azdatei1==DateTime.MinValue&&tadatei1==DateTime.MaxValue))
            {
                var list241 = from e in db.Tasviehs where e.PayDate >= azdatei1 && e.PayDate <= tadatei1 select e.IdRefOzv;
                list = (from e in list where e.OzvDate >= azdatei && e.OzvDate <= tadatei && list241.Contains(e.Id) select e);
            }
                else
                   list = (from e in list where e.OzvDate >= azdatei && e.OzvDate <= tadatei select e);


            var list1 = list.ToList();
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list1.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                            .Skip(pageIndex * pageSize)
                                            .Take(pageSize)
                                            .ToList();
            PersianCalendar pl = new PersianCalendar();
          //  productsList = productsList.Where(k => k.Id == 12729).ToList();


            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.Id,
                    RowCells = new List<object>
                               {
                                     product.GUID.ToString(),product.Semat, product.Id, product.Faal,
                                     product.FName.ToString(),product.LName ,  product.ScanDBs!=null? product.ScanDBs.Where(a => a.IdRef==product.Id && a.Scan_ScanType==1).ToList().Count>0? product.ScanDBs.Where(a => a.IdRef==product.Id && a.Scan_ScanType==1).FirstOrDefault().ScanURL:null:null,product.FatherName,
                                     product.MelliCode,product.TavalodDate!=null?((DateTime)product.TavalodDate).ToPersianDate():"",product.OzvDate!=null?((DateTime)product.OzvDate).ToPersianDate():"",product.Tasviehs.FirstOrDefault()!=null?((DateTime)product.Tasviehs.FirstOrDefault().PayDate).ToPersianDate():"",product.ShNo,product.CityCode!=null?product.CityCode.CityName:null,product.CityCode1!=null?product.CityCode1.CityName:null,
                                     product.Taahol!=null?product.Taahol.Taahol_Name:null,product.parvanehNo,product.NezamNo,product.Tel,product.Mobile,
                                     product.Address, pl.AddMonths(product.OzvDate, 6).ToPersianDate(), pl.AddMonths(product.OzvDate, 6)>DateTime.Now?0:1,product.SH_Shaba,product.SumAfzayeshMostamary,product.afzayeshhenase,product.mostammarryshenase,product.ghestshenase
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
        }



        //[HttpPost]
        //[Authorize(Roles = "Admin")]
        //public ActionResult GetAvvalinDarkhastMembers(string sidx, string sord, int page, int rows)
        //{

        //    SandooghModel db = new SandooghModel();
        //    DateTime now = DateTime.Now.Date;
        //    PersianCalendar pc = new PersianCalendar();
        //    DateTime date=  pc.AddMonths(now,-6);
        //    DateTime azdatei = date.AddDays(-7);
        //    DateTime tadatei = date.AddMilliseconds(1);
        //    List<long> etmamnashode = new List<long>();//اعضایی که کمتر از 1000تومن بدهی دارند
        //    var list = (from e in db.T_OzvCode where /*e.OzvDate > azdatei &&*/ e.OzvDate < tadatei && e.Faal==true && e.VamNobats.Count==0 && e.Vams.Count==0  select e);
        //    var listvamnatamam = (from k in db.Vams where k.EtmamVam == false select k).ToList();
        //    string p = "";
        //    foreach (var v in listvamnatamam)
        //    {
        //        var pardakhty=(from e in db.G_M_Pays where e.IdRefVam == v.Vam_Id select e).Sum(e => e.TotGestMablag);
        //        var mablaghvam = (v.VamMablagKhales + v.Karmozd);
        //        var mandebedehi = mablaghvam - pardakhty;

        //        if(mandebedehi < 10000)
        //        {
        //            etmamnashode.Add(v.T_OzvCode.Id );
        //        }

        //        if(mandebedehi<=0)
        //        {
        //            //10385 , 10471 , 10378 , 10830 , 10805 , 10388 , 10791 , 10868 , 10867 , 10940 , 10985 , 10590 , 10978 ,
        //            //10979 , 10951 , 11010 , 11057 , 11027 , 10780 , 10781 , 11083 , 11072 , 11109 , 11110 , 11133 , 11116 
        //            //11138 , 11090 , 11137 , 10489 , 10964 , 10971 , 11144 , 11185 , 11186 , 11201 , 11307 , 10686 , 11255 
        //           //11313 , 11314 , 11317 , 10596 , 11391 , 11377 , 10142 , "
        //            v.EtmamVam = true;
        //            p += v.IdRefOzv + " , ";
        //            db.Entry(v).State = System.Data.Entity.EntityState.Modified;

        //            db.SaveChanges();

        //        }
        //    }
        //    var listnatamamvam = (from k in db.Vams where k.EtmamVam == false  select k.IdRefOzv).ToList();
        //    var list2 = (from e in db.Vams where  e.EtmamVam==true && e.T_OzvCode.Faal == true && !listnatamamvam.Contains(e.IdRefOzv) select e.IdRefOzv).Distinct();
        //    //دووامه:"لیست2"بررسی شود که آیا شخص وام دیگری ندارد که هنوز تمام نشده باشد
        //    var list3 = (from e in db.T_OzvCode where list2.Contains(e.Id)|| /*کمتر از 1000 تومن*/etmamnashode.Contains(e.Id) select e);
        //    var list1 = list.Union(list3).Distinct().ToList();
        //  //  list1 = (from e in list1 where e.Id == 10191 select e).ToList();
        //   var list4 = (from e in list1 where e.Faal==true &&( e.VamNobats.Where(r =>r.IdRefOzv==e.Id && r.IdRefVam == null) == null || e.VamNobats.Where(r=> r.IdRefOzv == e.Id && r.IdRefVam==null).ToList().Count==0) select new { e, day=Math.Round(e.Vams.Count > 0 ? (DateTime.Now.Date.Subtract((DateTime)e.Vams.OrderByDescending(i=>i.Vam_Id).First() .G_M_Pays.OrderByDescending(ll=>ll.PayDate).First().PayDate)).TotalDays : ((DateTime.Now.Date.Subtract(e.OzvDate.AddMonths(6)))).TotalDays) }).ToList();
        //    var pageIndex = page - 1;
        //    var pageSize = rows;
        //    var totalRecords = list4.Count;
        //    var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

        //    var productsQuery = list4.AsQueryable();
        //    var productsList = productsQuery.OrderBy("day asc")
        //                                    .Skip(pageIndex * pageSize)
        //                                    .Take(pageSize)
        //                                    .ToList();
        //    PersianCalendar pl = new PersianCalendar();

        //    var productsData = new JqGridData
        //    {
        //        Total = totalPages,
        //        Page = page,
        //        Records = totalRecords,
        //        Rows = (productsList.Select(product => new JqGridRowData
        //        {
        //            Id = product.e.Id,
        //            RowCells = new List<object>
        //                       {
        //                             product.e.GUID.ToString(), product.e.Id,product.e.Faal,
        //                             product.e.FName.ToString(),product.e.LName,product.e.FatherName,
        //                             product.e.MelliCode,product.e.TavalodDate!=null?((DateTime)product.e.TavalodDate).ToPersianDate():"",product.e.OzvDate!=null?((DateTime)product.e.OzvDate).ToPersianDate():"",product.e.ShNo,product.e.CityCode!=null?product.e.CityCode.CityName:null,product.e.CityCode1!=null?product.e.CityCode1.CityName:null,
        //                             product.e.Taahol!=null?product.e.Taahol.Taahol_Name:null,product.e.parvanehNo,product.e.NezamNo,product.e.Tel,product.e.Mobile,
        //                             product.e.Address,((DateTime) (product.e.Vams.Count>0?(product.e.G_M_Pays.Where(pp=>pp.TotGestMablag>0).OrderByDescending(pp1=>pp1.PayDate).FirstOrDefault().PayDate):pl.AddMonths(product.e.OzvDate, 6))).ToPersianDate(), pl.AddMonths(product.e.OzvDate, 6)>DateTime.Now?0:1,product.day,((product.e.G_M_Pays!=null&&product.e.G_M_Pays.Where(k=>k.MostamariMablag>0&&((DateTime)k.PayDate)>=((DateTime) (product.e.Vams.Count>0?(product.e.G_M_Pays.Where(pp=>pp.TotGestMablag>0).OrderByDescending(pp1=>pp1.PayDate).FirstOrDefault().PayDate):pl.AddMonths(product.e.OzvDate, 6)))).Count()>0))?1:0
        //                        }
        //        })).ToList()
        //    };
        //    return Json(productsData, JsonRequestBehavior.AllowGet);
        //}
     
        // کلاس برای نتیجه محاسبه امتیاز منفی وام
        public class VamNegativeScoreResult
        {
            public int NegativeScore { get; set; }
            public int DelayedMonths { get; set; }
            public string DelayReason { get; set; }
        }

        // کلاس برای نتیجه نهایی (ترکیبی)
        public class TotalNegativeScoreResult
        {
            public int TotalNegativeScore { get; set; }
            public int MostamariNegativeScore { get; set; }
            public int VamNegativeScore { get; set; }
            public int MostamariDelayedMonths { get; set; }
            public int VamDelayedMonths { get; set; }
            public string MostamariDelayReason { get; set; }
            public string VamDelayReason { get; set; }
            public string CombinedDelayReason { get; set; }
        }


        private static int GetRequiredMembershipMonths(
      DateTime membershipDate,
      T_VamQueueSetting setting)
        {
            if (setting == null || !setting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات ورود به نوبت وام تکمیل نشده است."
                );
            }

            PersianCalendar pc = new PersianCalendar();

            DateTime dey1402 =
                pc.ToDateTime(1402, 10, 1, 0, 0, 0, 0);

            return membershipDate.Date < dey1402.Date
                ? setting.MembershipMonthsBeforeDey1402
                : setting.MembershipMonthsFromDey1402;
        }

        private static DateTime GetMembershipEligibilityDate(
            T_OzvCode member,
            T_VamQueueSetting setting)
        {
            return member.OzvDate.AddMonths(
                GetRequiredMembershipMonths(member.OzvDate, setting)
            );
        }

        /// <summary>
        /// نتیجه‌ی یکپارچه‌ی تعیین تاریخ پایه، امتیاز منفی و تاریخ مجاز ورود به نوبت.
        /// امتیاز خام برای گزارش حفظ می‌شود؛ فقط تأخیر ورود به نوبت حداکثر ۶ ماه است.
        /// </summary>
        public class QueueEligibilityInfo
        {
            // M: مهلت اولیه تأخیر اقساط وام در صف
            public int M_InstallmentGraceMonths { get; set; }

            // N: مهلت اولیه تأخیر مستمری در صف
            public int N_PensionGraceMonths { get; set; }
            public DateTime BaseDate { get; set; }

            public DateTime? LastLoanPaymentDate { get; set; }

            public TotalNegativeScoreResult Score { get; set; }

            public int QueueDelayMonths { get; set; }

            public DateTime QueueEligibleDate { get; set; }

            // طولانی‌ترین بازه متوالی تأخیر مستمری
            public int PensionArrearsDelayedMonths { get; set; }

            // تعداد ماه‌های معوق باقی‌مانده
            public int PensionArrearsOutstandingMonths { get; set; }

            // مبلغ مانده معوقات
            public decimal OutstandingPensionArrearsAmount { get; set; }

            // اگر تأخیر بیش از چهار ماه بوده و هنوز بدهی باقی است
            public bool RequiresPensionArrearsSettlement { get; set; }
            public int NegativeScoreWaitMonths { get; set; }

            public DateTime NegativeScoreWaitUntilDate { get; set; }

           

            public DateTime? OldestOutstandingPensionDueDate { get; set; }

            public bool CanEnterQueue { get; set; }

            public string QueueDecisionReason { get; set; }
        }

        private const int MaxQueueDelayMonths = 6;

        private static void ApplyQueueDecision(
            QueueEligibilityInfo info,
            MVCSandoogh.PensionArrearsSummary pensionArrears,
            T_VamQueueSetting queueSetting,
            DateTime asOfDate)
        {
            if (info == null)
                throw new ArgumentNullException("info");

            if (pensionArrears == null)
                pensionArrears = new MVCSandoogh.PensionArrearsSummary();

            if (queueSetting == null || !queueSetting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات ورود به نوبت تکمیل نشده است."
                );
            }

            if (queueSetting.M_InstallmentGraceMonths < 1 ||
                queueSetting.N_PensionGraceMonths < 1)
            {
                throw new InvalidOperationException(
                    "آستانه‌های تأخیر اقساط و مستمری صف معتبر نیستند."
                );
            }

            PersianCalendar pc = new PersianCalendar();

            asOfDate = asOfDate.Date;

            // =====================================================
            // 1. اطلاعات معوقات مستمری
            // =====================================================

            info.PensionArrearsDelayedMonths =
                pensionArrears.DelayedMonths;

            info.PensionArrearsOutstandingMonths =
                pensionArrears.OutstandingMonths;

            info.OutstandingPensionArrearsAmount =
                pensionArrears.OutstandingAmount;

            // قدیمی‌ترین ماه مستمری که هنوز تسویه نشده است
            var oldestOutstandingMonth =
                (pensionArrears.Months ??
                 new List<MVCSandoogh.PensionArrearsMonthInfo>())
                .Where(x =>
                    !x.IsSettled &&
                    x.ExpectedAmount > x.PaidAmount)
                .OrderBy(x => x.DueDate)
                .FirstOrDefault();

            info.OldestOutstandingPensionDueDate =
                oldestOutstandingMonth == null
                    ? (DateTime?)null
                    : oldestOutstandingMonth.DueDate.Date;

            // =====================================================
            // 2. الزام تسویه معوقات مستمری
            // =====================================================

            info.RequiresPensionArrearsSettlement = false;

            if (info.OldestOutstandingPensionDueDate.HasValue)
            {
                DateTime pensionLimitDate =
                    pc.AddMonths(
                        info.OldestOutstandingPensionDueDate.Value,
                        queueSetting.N_PensionGraceMonths
                    )
                    .Date
                    .AddDays(1);

                info.RequiresPensionArrearsSettlement =
                    asOfDate >= pensionLimitDate;
            }

            // =====================================================
            // 3. جمع امتیاز خام اقساط و مستمری
            // =====================================================

            var score =
                info.Score ?? new TotalNegativeScoreResult();

            int rawQueuePoints = Math.Max(
                0,
                score.TotalNegativeScore
            );

            // سقف انتظار ناشی از مجموع امتیازها
            int scoreWaitMonths = Math.Min(
                MaxQueueDelayMonths,
                rawQueuePoints
            );

            info.NegativeScoreWaitMonths =
                scoreWaitMonths;

            // فیلد قبلی برای سازگاری گزارش‌ها نگه داشته شده است.
            // دیگر افزایش جداگانه‌ای با تنظیمات قدیمی انجام نمی‌شود.
           
            // این فیلد نیز مدت انتظار نهایی و سقف‌خورده را نشان می‌دهد.
            info.QueueDelayMonths = scoreWaitMonths;

            // =====================================================
            // 4. تاریخ شروع انتظار
            // =====================================================

            DateTime scoreWaitStartDate =
                info.LastLoanPaymentDate.HasValue
                    ? info.LastLoanPaymentDate.Value.Date
                    : info.BaseDate.Date;

            info.NegativeScoreWaitUntilDate =
                pc.AddMonths(
                    scoreWaitStartDate,
                    scoreWaitMonths
                ).Date;

            // =====================================================
            // 5. تاریخ نهایی مجاز ورود
            // =====================================================

            // BaseDate محدودیت قبلی عضویت و قواعد تاریخ پایه را حفظ می‌کند.
            // تاریخ پایان انتظار امتیاز نیز جداگانه بررسی می‌شود.
            info.QueueEligibleDate =
                info.NegativeScoreWaitUntilDate.Date >
                info.BaseDate.Date
                    ? info.NegativeScoreWaitUntilDate.Date
                    : info.BaseDate.Date;

            // =====================================================
            // 6. تصمیم نهایی
            // =====================================================

            info.CanEnterQueue =
                !info.RequiresPensionArrearsSettlement &&
                info.QueueEligibleDate.Date <= asOfDate;

            var reasons = new List<string>();

            if (info.RequiresPensionArrearsSettlement)
            {
                reasons.Add(
                    "قدیمی‌ترین مستمری تسویه‌نشده از مهلت N ماه و یک روز عبور کرده است؛ ابتدا باید معوقات تسویه شوند."
                );
            }

            if (info.QueueEligibleDate.Date > asOfDate)
            {
                reasons.Add(
                    "زمان انتظار ورود به نوبت هنوز سپری نشده است."
                );
            }

            if (rawQueuePoints > MaxQueueDelayMonths)
            {
                reasons.Add(
                    "مجموع امتیاز خام تأخیر " +
                    rawQueuePoints +
                    " ماه است؛ به دلیل سقف سیستم، فقط " +
                    MaxQueueDelayMonths +
                    " ماه انتظار اعمال شده است."
                );
            }

            info.QueueDecisionReason =
                reasons.Count == 0
                    ? "تمام شرایط مالی و زمانی ورود به نوبت برقرار است."
                    : string.Join(" | ", reasons);
        }
        /// <summary>
        /// محاسبه‌ی مشترک شرایط ورود به نوبت؛ هم در صفحه‌ی فهرست اولیه
        /// و هم هنگام نمایش/ثبت نوبت از همین تابع استفاده می‌شود.
        /// </summary>
        public QueueEligibilityInfo CalculateQueueEligibilityInfo(
      T_OzvCode member,
      SandooghModel db)
        {
            if (member == null)
                throw new ArgumentNullException("member");

            if (db == null)
                throw new ArgumentNullException("db");

            var queueSetting = db.VamQueueSettings
                .AsNoTracking()
                .FirstOrDefault(x => x.Id == 1);

            if (queueSetting == null || !queueSetting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات ورود به نوبت وام توسط مدیر سیستم تکمیل نشده است."
                );
            }

            // آخرین وام تسویه‌شده
            var lastVam = db.Vams
                .AsNoTracking()
                .Where(v =>
                    v.IdRefOzv == member.Id &&
                    v.EtmamVam == true)
                .OrderByDescending(v => v.VamDate)
                .ThenByDescending(v => v.Vam_Id)
                .FirstOrDefault();

            // پرداخت‌های آخرین وام
            IList<G_M_Pays> loanPayments =
                new List<G_M_Pays>();

            if (lastVam != null)
            {
                loanPayments = db.G_M_Pays
                    .AsNoTracking()
                    .Where(p =>
                        p.IdRefVam == lastVam.Vam_Id &&
                        p.TotGestMablag > 0 &&
                        p.PayDate.HasValue)
                    .OrderBy(p => p.PayDate)
                    .ThenBy(p => p.Id)
                    .ToList();
            }

            // محاسبه تاریخ پایه با حفظ قواعد قبلی تسویه زودهنگام
            // و استفاده مشترک از الگوریتم صفحه فهرست اولیه
            var baseInfo = CalculateQueueBaseInfo(
                member,
                queueSetting,
                lastVam,
                loanPayments
            );

            var info = new QueueEligibilityInfo
            {
                BaseDate = baseInfo.BaseDate,

                LastLoanPaymentDate =
         baseInfo.LastLoanPaymentDate,

                M_InstallmentGraceMonths =
         queueSetting.M_InstallmentGraceMonths,

                N_PensionGraceMonths =
         queueSetting.N_PensionGraceMonths
            };

            var pensionArrears =
     MVCSandoogh.VamPolicyHelper.CalculatePensionArrears(
         db,
         member.Id,
         info.BaseDate,
         DateTime.Today,
         pensionDelayThresholdMonths:
             queueSetting.N_PensionGraceMonths
     );
            // محاسبه امتیاز منفی با استفاده از اطلاعات آماده‌شده
            info.Score = info.BaseDate.Date <= DateTime.Today
                ? CalculateTotalNegativeScore(
                    info.BaseDate,
                    member.Id,
                    db,
                    pensionArrears,
                    member,
                    lastVam,
                    loanPayments,
                    true
                )
                : new TotalNegativeScoreResult
                {
                    CombinedDelayReason =
                        "هنوز به موعد پرداخت نرسیده است"
                };

            // تصمیم نهایی مشترک
            ApplyQueueDecision(
                info,
                pensionArrears,
                queueSetting,
                DateTime.Today
            );

            return info;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public ActionResult GetMemberDecisionSummary(int id)
        {
            if (id <= 0)
            {
                return Json(new
                {
                    Success = false,
                    Message = "شناسه عضو معتبر نیست."
                }, JsonRequestBehavior.AllowGet);
            }

            try
            {
                using (SandooghModel db = new SandooghModel())
                {
                    var member = db.T_OzvCode
                        .AsNoTracking()
                        .FirstOrDefault(x => x.Id == id);

                    if (member == null)
                    {
                        return Json(new
                        {
                            Success = false,
                            Message = "عضو موردنظر پیدا نشد."
                        }, JsonRequestBehavior.AllowGet);
                    }

                    // =====================================================
                    // 1. ارزیابی خوش‌حسابی
                    // =====================================================

                    MVCSandoogh.Services.GoodPayerAssessment goodPayer = null;

                    string goodPayerError = null;

                    try
                    {
                        var batchEvaluation =
                            MVCSandoogh.Services.GoodPayerBatchEvaluator.Evaluate(
                                db,
                                new List<T_OzvCode> { member },
                                DateTime.Today
                            );

                        string batchError;

                        if (batchEvaluation.Errors.TryGetValue(
                            member.Id,
                            out batchError))
                        {
                            goodPayerError = batchError;
                        }
                        else if (!batchEvaluation.Assessments.TryGetValue(
                            member.Id,
                            out goodPayer))
                        {
                            goodPayerError =
                                "نتیجه ارزیابی خوش‌حسابی برای این عضو پیدا نشد.";
                        }
                    }
                    catch (Exception ex)
                    {
                        goodPayerError = ex.Message;
                    }

                    object goodPayerData;

                    if (goodPayer == null)
                    {
                        goodPayerData = new
                        {
                            Available = false,
                            Message = goodPayerError ??
                                      "محاسبه خوش‌حسابی انجام نشد."
                        };
                    }
                    else
                    {
                        var reasonParts = new List<string>();

                        if (!goodPayer.HasSettledLoan)
                        {
                            reasonParts.Add(
                                "عضو سابقه وام تسویه‌شده ندارد؛ خوش‌حسابی قابل احراز نیست."
                            );
                        }
                        else
                        {
                            bool installmentIsBad =
    Math.Abs((long)goodPayer.InstallmentNegativeScore) >
    goodPayer.R;

                            bool pensionIsBad =
                                Math.Abs((long)goodPayer.PensionNegativeScore) >
                                goodPayer.T;
                            if (installmentIsBad)
                            {
                                reasonParts.Add(
                                    "امتیاز منفی اقساط به آستانه مجاز N رسیده یا از آن عبور کرده است."
                                );
                            }
                            else
                            {
                                reasonParts.Add(
                                    "امتیاز اقساط در محدوده مجاز است."
                                );
                            }

                            if (pensionIsBad)
                            {
                                reasonParts.Add(
                                    "امتیاز منفی مستمری به آستانه مجاز M رسیده یا از آن عبور کرده است."
                                );
                            }
                            else
                            {
                                reasonParts.Add(
                                    "امتیاز مستمری در محدوده مجاز است."
                                );
                            }
                        }

                        goodPayerData = new
                        {
                            Available = true,

                            HasSettledLoan = goodPayer.HasSettledLoan,

                            IsGoodPayer = goodPayer.IsGoodPayer,

                            StatusText = !goodPayer.HasSettledLoan
                                ? "فاقد سابقه وام تسویه‌شده"
                                : goodPayer.IsGoodPayer
                                    ? "خوش‌حساب"
                                    : "بدحساب",

                            InstallmentNegativeScore =
                                goodPayer.InstallmentNegativeScore,

                         

                            DelayedInstallments =
                                goodPayer.DelayedInstallments,

                            PensionNegativeScore =
                                goodPayer.PensionNegativeScore,

                            PIntervalMonths =
    goodPayer.P,

                            QIntervalMonths =
    goodPayer.Q,

                            RThreshold =
    goodPayer.R,

                            TThreshold =
    goodPayer.T,

                            DelayedPensionMonths =
                                goodPayer.DelayedPensionMonths,

                            TotalNegativeScore =
                                goodPayer.TotalNegativeScore,

                            FeePercent =
                                goodPayer.FeePercent,

                            Reason = string.Join(" | ", reasonParts)
                        };
                    }

                    // =====================================================
                    // 2. ارزیابی مستقل شرایط ورود به نوبت
                    // =====================================================

                    QueueEligibilityInfo queueInfo = null;

                    string queueError = null;

                    try
                    {
                        queueInfo = CalculateQueueEligibilityInfo(
                            member,
                            db
                        );
                    }
                    catch (Exception ex)
                    {
                        queueError = ex.Message;
                    }

                    object queueData;

                    if (queueInfo == null)
                    {
                        queueData = new
                        {
                            Available = false,
                            Message = queueError ??
                                      "محاسبه شرایط ورود به نوبت انجام نشد."
                        };
                    }
                    else
                    {
                        var score =
                            queueInfo.Score ??
                            new TotalNegativeScoreResult();

                        queueData = new
                        {
                            Available = true,

                            CanEnterQueue =
                                queueInfo.CanEnterQueue,
                            M_InstallmentGraceMonths =
    queueInfo.M_InstallmentGraceMonths,

                            N_PensionGraceMonths =
    queueInfo.N_PensionGraceMonths,
                            RawQueuePoints =
    score.TotalNegativeScore,

                            AppliedQueueWaitMonths =
    queueInfo.NegativeScoreWaitMonths,
                            StatusText = queueInfo.CanEnterQueue
                                ? "مجاز به ورود به نوبت"
                                : "فعلاً مجاز به ورود به نوبت نیست",

                            // امتیازهای مستقل موتور صف
                            TotalNegativeScore =
                                score.TotalNegativeScore,

                            VamNegativeScore =
                                score.VamNegativeScore,

                            MostamariNegativeScore =
                                score.MostamariNegativeScore,

                            VamDelayedMonths =
                                score.VamDelayedMonths,

                            MostamariDelayedMonths =
                                score.MostamariDelayedMonths,

                            VamDelayReason =
                                score.VamDelayReason,

                            MostamariDelayReason =
                                score.MostamariDelayReason,

                            CombinedDelayReason =
                                score.CombinedDelayReason,

                            // تاریخ‌ها
                            BaseDate =
                                ConvertToPersianDate(queueInfo.BaseDate),

                            LastLoanPaymentDate =
                                queueInfo.LastLoanPaymentDate.HasValue
                                    ? ConvertToPersianDate(
                                        queueInfo.LastLoanPaymentDate.Value)
                                    : "ثبت نشده",

                            QueueEligibleDate =
                                ConvertToPersianDate(
                                    queueInfo.QueueEligibleDate),

                            NegativeScoreWaitUntilDate =
                                ConvertToPersianDate(
                                    queueInfo.NegativeScoreWaitUntilDate),

                            OldestOutstandingPensionDueDate =
                                queueInfo.OldestOutstandingPensionDueDate.HasValue
                                    ? ConvertToPersianDate(
                                        queueInfo.OldestOutstandingPensionDueDate.Value)
                                    : "ندارد",

                            // انتظار ناشی از امتیاز منفی
                            NegativeScoreWaitMonths =
                                queueInfo.NegativeScoreWaitMonths,

                        
                            // معوقات مستمری
                            PensionArrearsDelayedMonths =
                                queueInfo.PensionArrearsDelayedMonths,

                            PensionArrearsOutstandingMonths =
                                queueInfo.PensionArrearsOutstandingMonths,

                            OutstandingPensionArrearsAmount =
                                queueInfo.OutstandingPensionArrearsAmount,

                            RequiresPensionArrearsSettlement =
                                queueInfo.RequiresPensionArrearsSettlement,

                            // دلیل تصمیم نهایی
                            QueueDecisionReason =
                                queueInfo.QueueDecisionReason
                        };
                    }

                    return Json(new
                    {
                        Success = true,

                        MemberId = member.Id,

                        MemberName =
                            ((member.FName ?? "") + " " +
                             (member.LName ?? "")).Trim(),

                        GoodPayer = goodPayerData,

                        Queue = queueData

                    }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    Success = false,
                    Message = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        private QueueEligibilityInfo CalculateQueueBaseInfo(
    T_OzvCode member,
    T_VamQueueSetting queueSetting,
    Vam lastVam,
    IList<G_M_Pays> loanPayments)
        {
            if (member == null)
                throw new ArgumentNullException("member");

            var info = new QueueEligibilityInfo();

            DateTime membershipEligibilityDate =
                GetMembershipEligibilityDate(member, queueSetting);

            if (lastVam == null)
            {
                info.BaseDate = membershipEligibilityDate;
                return info;
            }

            DateTime? firstGestDate = lastVam.AvlinGestDate;

            int installmentCount = lastVam.TedadAgsat ?? 0;

            decimal installmentAmount =
                Convert.ToDecimal(lastVam.GestMablag ?? 0);

            if (!firstGestDate.HasValue ||
                installmentCount <= 0 ||
                installmentAmount <= 0)
            {
                info.BaseDate = membershipEligibilityDate;
                return info;
            }

            DateTime finalDueDate =
                firstGestDate.Value.AddMonths(installmentCount - 1);

            int paidInstallmentCount = 0;

            decimal currentInstallmentPaid = 0m;

            DateTime? lastFullInstallmentPaymentDate = null;

            foreach (var payment in (loanPayments ?? new List<G_M_Pays>())
                .Where(x =>
                    x.IdRefVam == lastVam.Vam_Id &&
                    x.TotGestMablag > 0 &&
                    x.PayDate.HasValue)
                .OrderBy(x => x.PayDate)
                .ThenBy(x => x.Id))
            {
                decimal remainingPayment =
                    Convert.ToDecimal(payment.TotGestMablag ?? 0);

                if (remainingPayment <= 0m)
                    continue;

                while (
                    remainingPayment > 0m &&
                    paidInstallmentCount < installmentCount)
                {
                    decimal remainingInstallment =
                        installmentAmount - currentInstallmentPaid;

                    if (remainingInstallment <= 0m)
                    {
                        paidInstallmentCount++;

                        currentInstallmentPaid = 0m;

                        lastFullInstallmentPaymentDate =
                            payment.PayDate.Value.Date;

                        continue;
                    }

                    if (remainingPayment >= remainingInstallment)
                    {
                        remainingPayment -= remainingInstallment;

                        currentInstallmentPaid = 0m;

                        paidInstallmentCount++;

                        lastFullInstallmentPaymentDate =
                            payment.PayDate.Value.Date;
                    }
                    else
                    {
                        currentInstallmentPaid += remainingPayment;

                        remainingPayment = 0m;

                        // اعمال تلورانس مشترک تسویه قسط:
                        // حداکثر یک میلیون ریال و ده درصد مبلغ قسط
                        if (MVCSandoogh.Services.VamInstallmentPaymentRules.IsSettled(
                            installmentAmount,
                            currentInstallmentPaid))
                        {
                            paidInstallmentCount++;

                            lastFullInstallmentPaymentDate =
                                payment.PayDate.Value.Date;

                            currentInstallmentPaid = 0m;
                        }
                    }
                }
            }

            info.LastLoanPaymentDate =
                paidInstallmentCount == installmentCount
                    ? lastFullInstallmentPaymentDate
                    : (DateTime?)null;

            int halfPlusOne =
                (installmentCount / 2) + 1;

            bool hasPaidHalfPlusOne =
                paidInstallmentCount >= halfPlusOne;

            bool paidMoreThanThreeMonthsEarly =
                info.LastLoanPaymentDate.HasValue &&
                info.LastLoanPaymentDate.Value <
                finalDueDate.AddMonths(-3);

            if (!info.LastLoanPaymentDate.HasValue)
            {
                info.BaseDate = finalDueDate;
            }
            else if (!paidMoreThanThreeMonthsEarly)
            {
                info.BaseDate = info.LastLoanPaymentDate.Value;
            }
            else if (!hasPaidHalfPlusOne)
            {
                info.BaseDate =
                    info.LastLoanPaymentDate.Value.AddMonths(3);
            }
            else
            {
                info.BaseDate = firstGestDate.Value
                    .AddMonths(halfPlusOne - 1)
                    .AddMonths(3);
            }

            return info;
        }

        private QueueEligibilityInfo CalculateQueueEligibilityInfoPrepared(
    T_OzvCode member,
    SandooghModel db,
    T_VamQueueSetting queueSetting,
    Vam lastVam,
    IList<G_M_Pays> loanPayments,
    QueueEligibilityInfo baseInfo,
    IList<T_MostamaryMablagh> pensionBaseChanges,
    IList<MinimumPensionSetting> minimumSettings,
    IList<G_M_Pays> pensionPayments)
        {
            if (member == null)
                throw new ArgumentNullException("member");

            if (db == null)
                throw new ArgumentNullException("db");
            if (queueSetting == null || !queueSetting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات ورود به نوبت وام تکمیل نشده است."
                );
            }
            if (baseInfo == null)
                throw new ArgumentNullException("baseInfo");

            var info = new QueueEligibilityInfo
            {
                BaseDate = baseInfo.BaseDate,

                LastLoanPaymentDate =
        baseInfo.LastLoanPaymentDate,

                M_InstallmentGraceMonths =
        queueSetting.M_InstallmentGraceMonths,

                N_PensionGraceMonths =
        queueSetting.N_PensionGraceMonths
            };
            var pensionArrears =
    MVCSandoogh.VamPolicyHelper.CalculatePensionArrears(
        db,
        member.Id,
        info.BaseDate,
        DateTime.Today,
        pensionBaseChanges,
        minimumSettings,
        pensionPayments,
        true,
        queueSetting.N_PensionGraceMonths
    );

            info.Score = info.BaseDate.Date <= DateTime.Today
     ? CalculateTotalNegativeScore(
         info.BaseDate,
         member.Id,
         db,
         pensionArrears,
         member,
         lastVam,
         loanPayments,
         true,
         queueSetting
     )
     : new TotalNegativeScoreResult
     {
         CombinedDelayReason =
             "هنوز به موعد پرداخت نرسیده است"
     };

            ApplyQueueDecision(
     info,
     pensionArrears,
     queueSetting,
     DateTime.Today
 );

            return info;

        
        }
        // کلاس برای نگهداری اطلاعات اقساط وام
        public class VamInstallmentInfo
        {
            public DateTime DueDate { get; set; }

            public DateTime? PayDate { get; set; }

            public long Amount { get; set; }

            /// <summary>
            /// مجموع مبلغی که تاکنون برای این قسط پرداخت شده است.
            /// قسط فقط زمانی تسویه‌شده محسوب می‌شود که PaidAmount >= Amount باشد.
            /// </summary>
            public decimal PaidAmount { get; set; }

            public bool IsPaid { get; set; }

            public int DelayMonths { get; set; }
        }

        private VamNegativeScoreResult CalculateVamNegativeScore(
     long memberId,
     SandooghModel db,
     int installmentGraceMonths,
     Vam preparedLoan = null,
     IList<G_M_Pays> preparedPayments = null,
     bool usePreparedData = false)
        {
            var result = new VamNegativeScoreResult();
            if (installmentGraceMonths < 1 ||
    installmentGraceMonths > 120)
            {
                throw new InvalidOperationException(
                    "مهلت اولیه تأخیر اقساط وام برای صف معتبر نیست."
                );
            }
            try
            {
                // ============================================================
                // 1. دریافت آخرین وام تسویه‌شده عضو
                // ============================================================

                var lastVam = usePreparedData
     ? preparedLoan
     : db.Vams
         .Where(v =>
             v.IdRefOzv == memberId &&
             v.EtmamVam == true)
         .OrderByDescending(v => v.VamDate)
         .ThenByDescending(v => v.Vam_Id)
         .FirstOrDefault();

                if (lastVam == null)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "وام تسویه شده‌ای وجود ندارد";

                    return result;
                }

                var firstGestDate = lastVam.AvlinGestDate;

                if (!firstGestDate.HasValue)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "تاریخ اقساط مشخص نیست";

                    return result;
                }

                // ============================================================
                // 2. دریافت پرداخت‌های وام
                // ============================================================

                var payments = usePreparedData
       ? (preparedPayments ?? new List<G_M_Pays>())
           .Where(p =>
               p.IdRefVam == lastVam.Vam_Id &&
               p.TotGestMablag > 0 &&
               p.PayDate.HasValue)
           .OrderBy(p => p.PayDate)
           .ThenBy(p => p.Id)
           .ToList()
       : db.G_M_Pays
           .Where(p =>
               p.IdRefVam == lastVam.Vam_Id &&
               p.TotGestMablag > 0 &&
               p.PayDate.HasValue)
           .OrderBy(p => p.PayDate)
           .ThenBy(p => p.Id)
           .ToList();

                // ============================================================
                // 3. ساخت لیست اقساط
                // ============================================================

                var installments = new List<VamInstallmentInfo>();

                long gestMablag = (long)(lastVam.GestMablag ?? 0);

                PersianCalendar pc = new PersianCalendar();

                // تاریخ شمسی اولین قسط
                int startY = pc.GetYear(firstGestDate.Value);
                int startM = pc.GetMonth(firstGestDate.Value);
                int startD = pc.GetDayOfMonth(firstGestDate.Value);

                int tedadAgsat = lastVam.TedadAgsat ?? 0;

                for (int i = 0; i < tedadAgsat; i++)
                {
                    int targetM = startM + i;
                    int targetY = startY;

                    // مدیریت تغییر سال
                    while (targetM > 12)
                    {
                        targetM -= 12;
                        targetY++;
                    }

                    // تعیین تاریخ سررسید
                    // اگر روز سررسید در ماه مقصد وجود نداشته باشد،
                    // آخرین روز معتبر همان ماه انتخاب می‌شود.

                    int validDay = startD;

                    DateTime persianDueDate = pc.ToDateTime(
                        targetY,
                        targetM,
                        1,
                        0,
                        0,
                        0,
                        0);

                    while (validDay > 1)
                    {
                        try
                        {
                            persianDueDate = pc.ToDateTime(
                                targetY,
                                targetM,
                                validDay,
                                0,
                                0,
                                0,
                                0);

                            break;
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                            validDay--;
                        }
                    }

                    installments.Add(new VamInstallmentInfo
                    {
                        DueDate = persianDueDate,
                        PayDate = null,
                        Amount = gestMablag,
                        PaidAmount = 0,
                        IsPaid = false,
                        DelayMonths = 0
                    });
                }

                // ============================================================
                // 4. تطبیق پرداخت‌ها با اقساط
                //
                // پرداخت‌ها به ترتیب تاریخ به قدیمی‌ترین قسط تخصیص می‌یابند.
                //
                // تسویه قسط با دو حالت انجام می‌شود:
                // 1. پرداخت کامل مبلغ قسط
                // 2. پرداخت مبلغی که کمبود آن در محدوده تلورانس مجاز باشد.
                //
                // تلورانس مشترک:
                // سقف ثابت = 1,000,000 ریال
                // نسبت به مبلغ قسط = 10 درصد
                // ============================================================

                // ============================================================
                // 4. تطبیق پرداخت‌ها با اقساط
                // بهینه‌شده با حرکت پیوسته روی اقساط
                // ============================================================

                int installmentIndex = 0;

                foreach (var payment in payments)
                {
                    decimal remainingAmount =
                        Convert.ToDecimal(
                            payment.TotGestMablag ?? 0);

                    if (remainingAmount <= 0m)
                        continue;

                    while (
                        remainingAmount > 0m &&
                        installmentIndex < installments.Count)
                    {
                        var inst =
                            installments[installmentIndex];

                        // اقساط تسویه‌شده را رد می‌کنیم.
                        if (inst.IsPaid)
                        {
                            installmentIndex++;
                            continue;
                        }

                        decimal installmentAmount =
                            Convert.ToDecimal(inst.Amount);

                        decimal installmentRemaining =
                            installmentAmount - inst.PaidAmount;

                        if (installmentRemaining <= 0m)
                        {
                            inst.PaidAmount = installmentAmount;
                            inst.IsPaid = true;

                            if (!inst.PayDate.HasValue)
                            {
                                inst.PayDate = payment.PayDate;
                            }

                            installmentIndex++;
                            continue;
                        }

                        // پرداخت کامل قسط
                        if (remainingAmount >= installmentRemaining)
                        {
                            inst.PaidAmount += installmentRemaining;

                            if (inst.PaidAmount > installmentAmount)
                            {
                                inst.PaidAmount = installmentAmount;
                            }

                            inst.IsPaid = true;

                            inst.PayDate = payment.PayDate;

                            remainingAmount -= installmentRemaining;

                            // رفتن به قسط بعدی
                            installmentIndex++;
                        }
                        else
                        {
                            // پرداخت جزئی قسط
                            inst.PaidAmount += remainingAmount;

                            if (inst.PaidAmount > installmentAmount)
                            {
                                inst.PaidAmount = installmentAmount;
                            }

                            bool settledWithTolerance =
                                MVCSandoogh.Services.VamInstallmentPaymentRules.IsSettled(
                                    installmentAmount,
                                    inst.PaidAmount
                                );

                            if (settledWithTolerance)
                            {
                                inst.PaidAmount =
                                    installmentAmount;

                                inst.IsPaid = true;

                                inst.PayDate =
                                    payment.PayDate;

                                // قسط تسویه‌شده است.
                                installmentIndex++;
                            }
                            else
                            {
                                inst.IsPaid = false;

                                inst.PayDate = null;
                            }

                            remainingAmount = 0m;
                        }
                    }
                }

                // ============================================================
                // 5. محاسبه تأخیر
                //
                // مهلت اولیه: 3 ماه پس از سررسید
                //
                // تا پایان این مهلت:
                // بدون امتیاز منفی
                //
                // بعد از پایان مهلت:
                // 1 تا 3 ماه تأخیر امتیازدار = 1 امتیاز
                // 4 تا 6 ماه = 2 امتیاز
                // 7 تا 9 ماه = 3 امتیاز
                // ============================================================

                // ============================================================
                // 5. محاسبه امتیاز صف اقساط وام
                // ============================================================

                int totalScore = 0;
                int maxDelay = 0;

                var delayDetails = new List<string>();

                foreach (var inst in installments)
                {
                    // اگر قسط تسویه شده، تاریخ پرداخت واقعی ملاک است.
                    // اگر هنوز تسویه نشده، تاریخ امروز بررسی می‌شود.
                    DateTime checkDate =
                        inst.IsPaid && inst.PayDate.HasValue
                            ? inst.PayDate.Value.Date
                            : DateTime.Today;

                    // امتیاز تأخیر همین قسط، مستقل از سایر اقساط
                    int delayPoints =
                        MVCSandoogh.VamPolicyHelper.CalculateQueueDelayPoints(
                            inst.DueDate,
                            checkDate,
                            installmentGraceMonths
                        );

                    inst.DelayMonths = delayPoints;

                    if (delayPoints <= 0)
                        continue;

                    totalScore += delayPoints;

                    if (delayPoints > maxDelay)
                    {
                        maxDelay = delayPoints;
                    }

                    string payDateStr =
                        inst.IsPaid && inst.PayDate.HasValue
                            ? ConvertToPersianDate(inst.PayDate.Value)
                            : "پرداخت نشده";

                    string paidAmountStr =
                        inst.PaidAmount.ToString(
                            "N0",
                            CultureInfo.InvariantCulture
                        );

                    string installmentAmountStr =
                        inst.Amount.ToString(
                            "N0",
                            CultureInfo.InvariantCulture
                        );

                    delayDetails.Add(
                        $"قسط {ConvertToPersianDate(inst.DueDate)} " +
                        $"(پرداخت: {payDateStr}) " +
                        $"- مبلغ قسط: {installmentAmountStr} " +
                        $"- پرداخت شده: {paidAmountStr} " +
                        $"- تأخیر مشمول امتیاز: {delayPoints} ماه " +
                        $"→ {delayPoints} امتیاز انتظار"
                    );
                }

                // ============================================================
                // 6. ساخت توضیحات نهایی
                // ============================================================

                string delayReason;

                if (totalScore > 0)
                {
                    delayReason =
                        "امتیاز انتظار اقساط وام: " +
                        string.Join(" | ", delayDetails);
                }
                else
                {
                    delayReason =
                        "بدون تأخیر مشمول امتیاز در اقساط وام";
                }

                // ============================================================
                // 7. خروجی نهایی
                // ============================================================

                result.NegativeScore = totalScore;

                // بیشترین میزان امتیاز انتظار برای یک قسط
                result.DelayedMonths = maxDelay;

                result.DelayReason = delayReason;

                return result;
            }
            catch (Exception ex)
            {
                result.NegativeScore = 0;
                result.DelayedMonths = 0;
                result.DelayReason =
                    $"خطا در محاسبه وام: {ex.Message}";

                return result;
            }
        }

        public class NegativeScoreResult
            {
                public int NegativeScore { get; set; }
                public int DelayedMonths { get; set; }
                public string DelayReason { get; set; }

         
      
        }

            // کلاس برای وضعیت ماهانه
            public class MonthStatusInfo
            {
                public DateTime Month { get; set; }
                public bool IsFullyPaid { get; set; }
                public long Expected { get; set; }
                public long Paid { get; set; }
            }

            // کلاس برای نگهداری اطلاعات بازه
            public class DelayRangeInfo
            {
                public DateTime StartDate { get; set; }
                public DateTime EndDate { get; set; }
                public int Months { get; set; }
                public int Score { get; set; }
        }
        [HttpPost]
        [Authorize(Roles = "Admin")]
      public ActionResult GetAvvalinDarkhastMembers(
    string sidx,
    string sord,
    int page,
    int rows,
    string queueStatus = "all",
    string payerStatus = "all",
    string search = null,
    bool exportAll = false)
        {
            var results = new List<MemberNegativeScoreResult>();

            int totalRecords = 0;
            int totalPages = 0;
            // محدودکردن تعداد رکوردهای دریافتی در هر درخواست
            page = Math.Max(1, page);

            rows = rows > 0
                ? Math.Min(rows, 200)
                : 50;
            try
            {
                System.Diagnostics.Debug.WriteLine(
    "GetAvvalinDarkhastMembers START"
);
                using (SandooghModel db = new SandooghModel())
                {
                   var today = DateTime.Today;

var sixMonthsAgo = today.AddMonths(-6);

                    var queueSetting = db.VamQueueSettings
                        .AsNoTracking()
                        .FirstOrDefault(x => x.Id == 1);

         if (queueSetting == null || !queueSetting.IsConfigured)
{
    throw new InvalidOperationException(
        "تنظیمات ورود به نوبت وام تکمیل نشده است."
    );
}

var membershipBeforeDeyCutoff =
    today.AddMonths(-queueSetting.MembershipMonthsBeforeDey1402);

var membershipFromDeyCutoff =
    today.AddMonths(-queueSetting.MembershipMonthsFromDey1402);

var dey1402 =
    new PersianCalendar().ToDateTime(1402, 10, 1, 0, 0, 0, 0);
                    // =========================================================
                    // اعضای واجد شرایط
                    // =========================================================

                    // =========================================================
                    // 1. دریافت تمام اعضای واجد شرایط
                    // =========================================================

                    var eligibleMemberEntities = db.T_OzvCode
                        .AsNoTracking()
                        .Where(o => o.Faal == true)
                        .Where(o =>
                            !db.VamNobats.Any(vn =>
                                vn.IdRefOzv == o.Id &&
                                vn.IdRefVam == null))
                        .Where(o =>
                            (
                                !db.Vams.Any(v =>
                                    v.IdRefOzv == o.Id)
                                &&
                                (
                                    (o.OzvDate < dey1402 &&
                                     o.OzvDate <= membershipBeforeDeyCutoff)
                                    ||
                                    (o.OzvDate >= dey1402 &&
                                     o.OzvDate <= membershipFromDeyCutoff)
                                )
                            )
                            ||
                            (
                                db.Vams.Any(v =>
                                    v.IdRefOzv == o.Id &&
                                    v.EtmamVam == true)
                                &&
                                !db.Vams.Any(v =>
                                    v.IdRefOzv == o.Id &&
                                    v.EtmamVam == false)
                            )
                        )
                        .ToList();
                    System.Diagnostics.Debug.WriteLine(
    "Eligible members count: " +
    eligibleMemberEntities.Count
);
                    var eligibleMemberIds = eligibleMemberEntities
                        .Select(x => x.Id)
                        .Distinct()
                        .ToList();

                    var eligibleMembers =
                        new List<MemberNegativeScoreResult>();

                    var queueInfoByMember =
                        new Dictionary<int, QueueEligibilityInfo>();
                    var goodPayerByMember =
    new Dictionary<int, MVCSandoogh.Services.GoodPayerAssessment>();

                    var goodPayerErrors =
                        new Dictionary<int, string>();
                    // =========================================================
                    // 2. دریافت آخرین وام تسویه‌شده اعضا به صورت گروهی
                    // =========================================================

                    const int batchSize = 400;

                    var allSettledLoans = new List<Vam>();

                    for (int i = 0; i < eligibleMemberIds.Count; i += batchSize)
                    {
                        var idChunk = eligibleMemberIds
                            .Skip(i)
                            .Take(batchSize)
                            .ToList();

                        var loans = db.Vams
      .AsNoTracking()
      .Where(v =>
          v.IdRefOzv.HasValue &&
          idChunk.Contains(v.IdRefOzv.Value) &&
          v.EtmamVam == true)
      .ToList();

                        allSettledLoans.AddRange(loans);
                    }

                    var lastLoanByMember = allSettledLoans
                        .Where(x => x.IdRefOzv.HasValue)
                        .GroupBy(x => x.IdRefOzv.Value)
                        .ToDictionary(
                            x => x.Key,
                            x => x
                                .OrderByDescending(v => v.VamDate)
                                .ThenByDescending(v => v.Vam_Id)
                                .First()
                        );

                    // =========================================================
                    // 3. دریافت پرداخت‌های اقساط آخرین وام‌ها به صورت گروهی
                    // =========================================================

                    var lastLoanIds = lastLoanByMember.Values
                        .Select(x => x.Vam_Id)
                        .Distinct()
                        .ToList();

                    var allLoanPayments = new List<G_M_Pays>();

                    for (int i = 0; i < lastLoanIds.Count; i += batchSize)
                    {
                        var loanChunk = lastLoanIds
                            .Skip(i)
                            .Take(batchSize)
                            .ToList();

                        var paymentRows = db.G_M_Pays
    .AsNoTracking()
    .Where(p =>
        p.IdRefVam.HasValue &&
        loanChunk.Contains(p.IdRefVam.Value) &&
        p.TotGestMablag > 0 &&
        p.PayDate.HasValue)
    .Select(p => new
    {
        p.Id,
        p.IdRefVam,
        p.TotGestMablag,
        p.PayDate
    })
    .ToList();

                        var payments = paymentRows
                            .Select(p => new G_M_Pays
                            {
                                Id = p.Id,
                                IdRefVam = p.IdRefVam,
                                TotGestMablag = p.TotGestMablag,
                                PayDate = p.PayDate
                            })
                            .ToList();

                        allLoanPayments.AddRange(payments);
                    }

                    var loanPaymentsByLoan = allLoanPayments
                        .Where(x => x.IdRefVam.HasValue)
                        .GroupBy(x => x.IdRefVam.Value)
                        .ToDictionary(
                            x => x.Key,
                            x => x
                                .OrderBy(p => p.PayDate)
                                .ThenBy(p => p.Id)
                                .ToList()
                        );

                    // =========================================================
                    // 4. محاسبه تاریخ پایه همه اعضا در حافظه
                    // =========================================================

                    var baseInfoByMember =
                        new Dictionary<int, QueueEligibilityInfo>();

                    var membershipDateByMember =
                        new Dictionary<int, DateTime>();

                    var emptyLoanPayments =
                        new List<G_M_Pays>();

                    foreach (var member in eligibleMemberEntities)
                    {
                        DateTime membershipDate =
                            GetMembershipEligibilityDate(
                                member,
                                queueSetting
                            );

                        membershipDateByMember[member.Id] =
                            membershipDate;

                        Vam lastLoan;

                        lastLoanByMember.TryGetValue(
                            member.Id,
                            out lastLoan
                        );

                        IList<G_M_Pays> memberLoanPayments =
                            emptyLoanPayments;

                        if (lastLoan != null)
                        {
                            List<G_M_Pays> foundPayments;

                            if (loanPaymentsByLoan.TryGetValue(
                                lastLoan.Vam_Id,
                                out foundPayments))
                            {
                                memberLoanPayments = foundPayments;
                            }
                        }

                        var baseInfo = CalculateQueueBaseInfo(
                            member,
                            queueSetting,
                            lastLoan,
                            memberLoanPayments
                        );

                        baseInfoByMember[member.Id] = baseInfo;
                    }

                    // =========================================================
                    // 5. تعیین حداقل تاریخ لازم برای خواندن مستمری
                    // =========================================================

                    var todayDate = DateTime.Today;

                    var currentPersianMonthStart =
                        GetPersianMonthStart(todayDate);

                    DateTime minimumPaymentDate =
                        membershipDateByMember.Count > 0
                            ? membershipDateByMember.Values.Min()
                            : todayDate;

                    foreach (var baseInfo in baseInfoByMember.Values)
                    {
                        if (baseInfo.BaseDate.Date > todayDate.Date)
                            continue;

                        DateTime firstMonthStart =
                            GetPersianMonthStart(baseInfo.BaseDate);

                        if (firstMonthStart.Date != baseInfo.BaseDate.Date)
                        {
                            firstMonthStart =
                                GetNextPersianMonthStart(firstMonthStart);
                        }

                        if (firstMonthStart < currentPersianMonthStart &&
                            firstMonthStart < minimumPaymentDate)
                        {
                            minimumPaymentDate = firstMonthStart;
                        }
                    }

                    // =========================================================
                    // 6. دریافت تغییرات مبلغ مستمری همه اعضا
                    // =========================================================

                    var allPensionBaseChanges =
                        new List<T_MostamaryMablagh>();

                    for (int i = 0; i < eligibleMemberIds.Count; i += batchSize)
                    {
                        var idChunk = eligibleMemberIds
                            .Skip(i)
                            .Take(batchSize)
                            .ToList();

                        var pensionChangeRows = db.T_MostamaryMablagh
     .AsNoTracking()
     .Where(x =>
         x.MostamaryMablagh_IdRefOzvCode.HasValue &&
         idChunk.Contains(
             x.MostamaryMablagh_IdRefOzvCode.Value) &&
         x.MostamaryMablagh_DateStart.HasValue)
     .Select(x => new
     {
         x.MostamaryMablagh_ID,
         x.MostamaryMablagh_IdRefOzvCode,
         x.MostamaryMablagh_DateStart,
         x.MostamaryMablagh_Mablagh
     })
     .ToList();

                        var changes = pensionChangeRows
                            .Select(x => new T_MostamaryMablagh
                            {
                                MostamaryMablagh_ID =
                                    x.MostamaryMablagh_ID,

                                MostamaryMablagh_IdRefOzvCode =
                                    x.MostamaryMablagh_IdRefOzvCode,

                                MostamaryMablagh_DateStart =
                                    x.MostamaryMablagh_DateStart,

                                MostamaryMablagh_Mablagh =
                                    x.MostamaryMablagh_Mablagh
                            })
                            .ToList();

                        allPensionBaseChanges.AddRange(changes);
                    }

                    // =========================================================
                    // 7. خواندن تنظیمات حداقل مستمری فقط یک بار
                    // =========================================================

                    var allMinimumSettings = db.MinimumPensionSettings
                        .AsNoTracking()
                        .Where(x => x.EffectiveFrom <= todayDate)
                        .OrderByDescending(x => x.EffectiveFrom)
                        .ToList();
                    // تنظیمات خوش‌حسابی فقط یک‌بار خوانده می‌شوند.
                    var goodPayerPolicy = db.VamPolicySettings
                        .AsNoTracking()
                        .FirstOrDefault(x => x.Id == 1);
                    // =========================================================
                    // 8. دریافت پرداخت‌های مستمری همه اعضا به صورت گروهی
                    // =========================================================

                    var allPensionPayments = new List<G_M_Pays>();

                    for (int i = 0; i < eligibleMemberIds.Count; i += batchSize)
                    {
                        var idChunk = eligibleMemberIds
                            .Skip(i)
                            .Take(batchSize)
                            .ToList();

                        var pensionPaymentRows = db.G_M_Pays
      .AsNoTracking()
      .Where(p =>
          p.IdRefOzv.HasValue &&
          idChunk.Contains(p.IdRefOzv.Value) &&
          p.MostamariMablag > 0 &&
          p.PayDate.HasValue &&
          p.PayDate >= minimumPaymentDate)
      .Select(p => new
      {
          p.Id,
          p.IdRefOzv,
          p.MostamariMablag,
          p.IsAfzayesh,
          p.PayDate
      })
      .ToList();

                        var payments = pensionPaymentRows
                            .Select(p => new G_M_Pays
                            {
                                Id = p.Id,
                                IdRefOzv = p.IdRefOzv,
                                MostamariMablag = p.MostamariMablag,
                                IsAfzayesh = p.IsAfzayesh,
                                PayDate = p.PayDate
                            })
                            .ToList();

                        allPensionPayments.AddRange(payments);
                    }

                    var pensionPaymentsByMember = allPensionPayments
                        .Where(x => x.IdRefOzv.HasValue)
                        .GroupBy(x => x.IdRefOzv.Value)
                        .ToDictionary(
                            x => x.Key,
                            x => x
                                .OrderBy(p => p.PayDate)
                                .ThenBy(p => p.Id)
                                .ToList()
                        );

                    var pensionBaseChangesByMember = allPensionBaseChanges
                        .Where(x =>
                            x.MostamaryMablagh_IdRefOzvCode.HasValue)
                        .GroupBy(x =>
                            x.MostamaryMablagh_IdRefOzvCode.Value)
                        .ToDictionary(
                            x => x.Key,
                            x => x.ToList()
                        );

                    var emptyPensionPayments =
                        new List<G_M_Pays>();

                    var emptyPensionBaseChanges =
                        new List<T_MostamaryMablagh>();

                    // =========================================================
                    // 9. محاسبه نهایی شرایط اعضا با اطلاعات آماده
                    // =========================================================

                    foreach (var member in eligibleMemberEntities)
                    {
                        QueueEligibilityInfo baseInfo;

                        if (!baseInfoByMember.TryGetValue(
                            member.Id,
                            out baseInfo))
                        {
                            continue;
                        }

                        Vam lastLoan;

                        lastLoanByMember.TryGetValue(
                            member.Id,
                            out lastLoan
                        );

                        IList<G_M_Pays> memberLoanPayments =
                            emptyLoanPayments;

                        if (lastLoan != null)
                        {
                            List<G_M_Pays> foundLoanPayments;

                            if (loanPaymentsByLoan.TryGetValue(
                                lastLoan.Vam_Id,
                                out foundLoanPayments))
                            {
                                memberLoanPayments = foundLoanPayments;
                            }
                        }

                        IList<T_MostamaryMablagh> memberBaseChanges =
                            emptyPensionBaseChanges;

                        List<T_MostamaryMablagh> foundBaseChanges;

                        if (pensionBaseChangesByMember.TryGetValue(
                            member.Id,
                            out foundBaseChanges))
                        {
                            memberBaseChanges = foundBaseChanges;
                        }

                        IList<G_M_Pays> memberPensionPayments =
                            emptyPensionPayments;

                        List<G_M_Pays> foundPensionPayments;

                        if (pensionPaymentsByMember.TryGetValue(
                            member.Id,
                            out foundPensionPayments))
                        {
                            memberPensionPayments = foundPensionPayments;
                        }

                        var queueInfo =
                            CalculateQueueEligibilityInfoPrepared(
                                member,
                                db,
                                queueSetting,
                                lastLoan,
                                memberLoanPayments,
                                baseInfo,
                                memberBaseChanges,
                                allMinimumSettings,
                                memberPensionPayments
                            );

                        queueInfoByMember[member.Id] = queueInfo;
                        // -------------------------------------------------
                        // ارزیابی خوش‌حسابی با همان داده‌های گروهی آماده‌شده
                        // بدون اجرای Query مجدد برای هر عضو
                        // -------------------------------------------------

                        try
                        {
                            var goodPayerAssessment =
                                MVCSandoogh.Services.VamGoodPayerCalculator.EvaluatePrepared(
                                    member,
                                    lastLoan,
                                    goodPayerPolicy,
                                    memberLoanPayments,
                                    memberBaseChanges,
                                    memberPensionPayments,
                                    allMinimumSettings,
                                    todayDate
                                );

                            goodPayerByMember[member.Id] =
                                goodPayerAssessment;
                        }
                        catch (Exception assessmentException)
                        {
                            // خطای ارزیابی خوش‌حسابی یک عضو نباید
                            // مانع نمایش سایر اعضا شود.

                            goodPayerErrors[member.Id] =
                                assessmentException.Message;
                        }
                        DateTime membershipEligibilityDate =
                            membershipDateByMember[member.Id];

                        DateTime actualStartDate =
                            queueInfo.BaseDate;

                        DateTime? lastVamPayDate =
                            queueInfo.LastLoanPaymentDate;

                        var lastPaymentDate =
                            lastVamPayDate ?? actualStartDate;

                        // این بررسی عمداً پرداخت افزایش سرمایه را هم می‌پذیرد؛
                        // شرط قبلی همین بود و نباید تغییر کند.
                        bool hasPaidAfterDue =
                            memberPensionPayments.Any(gp =>
                                gp.MostamariMablag > 0 &&
                                gp.PayDate.HasValue &&
                                gp.PayDate.Value >= membershipEligibilityDate);

                        var item = new MemberNegativeScoreResult
                        {
                            Id = member.Id,

                            GUID = member.GUID ?? Guid.Empty,

                            Faal = member.Faal ?? false,

                            FName = member.FName,
                            LName = member.LName,
                            FatherName = member.FatherName,
                            MelliCode = member.MelliCode,

                            TavalodDate = member.TavalodDate,
                            OzvDate = member.OzvDate,

                            ShNo = member.ShNo,
                            parvanehNo = member.parvanehNo,
                            NezamNo = member.NezamNo,

                            Tel = member.Tel,
                            Mobile = member.Mobile,
                            Address = member.Address,

                            StartDate = actualStartDate,

                            IsOver6Months =
                                member.OzvDate <= sixMonthsAgo,

                            HasPaidAfterDue = hasPaidAfterDue,

                            DayDiff =
                                (int)(todayDate - actualStartDate).TotalDays,

                            LastPaymentDate = lastPaymentDate
                        };

                        eligibleMembers.Add(item);
                    }


                    // =========================================================
                    // محاسبه امتیاز منفی
                    // =========================================================
                    // =========================================================
                    // تکمیل اطلاعات امتیاز منفی، شرایط ورود و خوش‌حسابی
                    // =========================================================

                    foreach (var member in eligibleMembers)
                    {
                        QueueEligibilityInfo queueInfo;

                        if (queueInfoByMember.TryGetValue(
                            (int)member.Id,
                            out queueInfo))
                        {
                            var totalResult =
                                queueInfo.Score ?? new TotalNegativeScoreResult();

                            // -------------------------------------------------
                            // امتیاز منفی موتور ورود به نوبت
                            // -------------------------------------------------

                            member.NegativeScore =
                                totalResult.TotalNegativeScore;

                            member.DelayedMonths = Math.Max(
                                totalResult.MostamariDelayedMonths,
                                totalResult.VamDelayedMonths
                            );

                            member.DelayReason =
                                totalResult.CombinedDelayReason;

                            member.MostamariNegativeScore =
                                totalResult.MostamariNegativeScore;

                            member.VamNegativeScore =
                                totalResult.VamNegativeScore;

                            member.MostamariDelayReason =
                                totalResult.MostamariDelayReason;

                            member.VamDelayReason =
                                totalResult.VamDelayReason;

                            // -------------------------------------------------
                            // اطلاعات تصمیم‌گیری ورود به نوبت
                            // -------------------------------------------------

                            member.QueueDelayMonths =
                                queueInfo.QueueDelayMonths;

                            member.QueueEligibleDate =
                                queueInfo.QueueEligibleDate;

                            member.CanEnterQueue =
                                queueInfo.CanEnterQueue;

                            member.NegativeScoreWaitMonths =
                                queueInfo.NegativeScoreWaitMonths;

                            member.NegativeScoreWaitUntilDate =
                                queueInfo.NegativeScoreWaitUntilDate;

                            member.PensionArrearsDelayedMonths =
                                queueInfo.PensionArrearsDelayedMonths;

                            member.PensionArrearsOutstandingMonths =
                                queueInfo.PensionArrearsOutstandingMonths;

                            member.OutstandingPensionArrearsAmount =
                                queueInfo.OutstandingPensionArrearsAmount;

                            member.OldestOutstandingPensionDueDate =
                                queueInfo.OldestOutstandingPensionDueDate;

                            member.RequiresPensionArrearsSettlement =
                                queueInfo.RequiresPensionArrearsSettlement;

                            member.LastSettledLoanPaymentDate =
                                queueInfo.LastLoanPaymentDate;

                            member.QueueDecisionReason =
                                queueInfo.QueueDecisionReason;

                            member.QueueDecisionStatus =
                                queueInfo.CanEnterQueue
                                    ? "مجاز"
                                    : queueInfo.RequiresPensionArrearsSettlement
                                        ? "غیرمجاز - معوقات مستمری"
                                        : "در انتظار پایان مهلت";
                        }
                        else
                        {
                            member.NegativeScore = 0;
                            member.DelayedMonths = 0;
                            member.QueueDelayMonths = 0;
                            member.CanEnterQueue = false;

                            member.QueueDecisionStatus =
                                "محاسبه نشد";

                            member.QueueDecisionReason =
                                "محاسبه شرایط ورود به نوبت انجام نشد";

                            member.DelayReason =
                                "محاسبه شرایط ورود به نوبت انجام نشد";
                        }

                        // =================================================
                        // اطلاعات خوش‌حسابی
                        // =================================================

                        // =================================================
                        // اطلاعات خوش‌حسابی
                        // =================================================

                        MVCSandoogh.Services.GoodPayerAssessment assessment;

                        if (goodPayerByMember.TryGetValue(
                            (int)member.Id,
                            out assessment))
                        {
                            member.GoodPayerCanAssess = true;

                            member.GoodPayerHasSettledLoan =
                                assessment.HasSettledLoan;

                            member.IsGoodPayer =
                                assessment.IsGoodPayer;

                            member.GoodPayerStatus =
                                !assessment.HasSettledLoan
                                    ? "فاقد سابقه کافی"
                                    : assessment.IsGoodPayer
                                        ? "خوش‌حساب"
                                        : "بدحساب";

                            member.GoodPayerInstallmentNegativeScore =
                                assessment.InstallmentNegativeScore;

                            member.GoodPayerPensionNegativeScore =
                                assessment.PensionNegativeScore;

                            member.GoodPayerTotalNegativeScore =
                                assessment.TotalNegativeScore;

                            member.GoodPayerPIntervalMonths =
                                assessment.P;

                            member.GoodPayerQIntervalMonths =
                                assessment.Q;

                            member.GoodPayerRThreshold =
                                assessment.R;

                            member.GoodPayerTThreshold =
                                assessment.T;

                            member.GoodPayerDelayedInstallments =
                                assessment.DelayedInstallments;

                            member.GoodPayerDelayedPensionMonths =
                                assessment.DelayedPensionMonths;

                            member.GoodPayerFeePercent =
                                assessment.FeePercent;

                            var reasonParts = new List<string>();

                            if (!assessment.HasSettledLoan)
                            {
                                reasonParts.Add(
                                    "سابقه وام تسویه‌شده ندارد؛ خوش‌حسابی قابل احراز نیست و کارمزد عادی اعمال می‌شود."
                                );
                            }
                            else
                            {
                                bool installmentIsBad =
                                    Math.Abs((long)assessment.InstallmentNegativeScore) >
                                    assessment.R;

                                bool pensionIsBad =
                                    Math.Abs((long)assessment.PensionNegativeScore) >
                                    assessment.T;

                                reasonParts.Add(
                                    "اقساط: " +
                                    Math.Abs((long)assessment.InstallmentNegativeScore) +
                                    " امتیاز منفی، P=" +
                                    assessment.P +
                                    "، سقف مجاز R=" +
                                    assessment.R +
                                    (installmentIsBad
                                        ? "؛ بیشتر از حد مجاز"
                                        : "؛ در محدوده مجاز")
                                );

                                reasonParts.Add(
                                    "مستمری: " +
                                    Math.Abs((long)assessment.PensionNegativeScore) +
                                    " امتیاز منفی، Q=" +
                                    assessment.Q +
                                    "، سقف مجاز T=" +
                                    assessment.T +
                                    (pensionIsBad
                                        ? "؛ بیشتر از حد مجاز"
                                        : "؛ در محدوده مجاز")
                                );

                                reasonParts.Add(
                                    "تعداد اقساط دارای امتیاز منفی: " +
                                    assessment.DelayedInstallments
                                );

                                reasonParts.Add(
                                    "ماه‌های دارای امتیاز منفی مستمری: " +
                                    assessment.DelayedPensionMonths
                                );
                            }

                            member.GoodPayerReason =
                                string.Join(" | ", reasonParts);
                        }
                        else
                        {
                            member.GoodPayerCanAssess = false;

                            member.GoodPayerStatus = "محاسبه نشد";

                            string assessmentError;

                            if (goodPayerErrors.TryGetValue(
                                (int)member.Id,
                                out assessmentError))
                            {
                                member.GoodPayerReason =
                                    "خطا در محاسبه خوش‌حسابی: " +
                                    assessmentError;
                            }
                            else
                            {
                                member.GoodPayerReason =
                                    "نتیجه ارزیابی خوش‌حسابی موجود نیست.";
                            }
                        }
                    }


                    // =========================================================
                    // تعداد کل رکوردها
                    // =========================================================
                    // =========================================================
                    // آمار کل فهرست، بدون تأثیر فیلترهای انتخابی
                    // =========================================================

                    int totalMembersCount =
                        eligibleMembers.Count;

                    int canEnterQueueCount =
                        eligibleMembers.Count(x => x.CanEnterQueue);

                    int waitingQueueCount =
                        eligibleMembers.Count(x =>
                            !x.CanEnterQueue &&
                            !x.RequiresPensionArrearsSettlement);

                    int pensionBlockedCount =
                        eligibleMembers.Count(x =>
                            x.RequiresPensionArrearsSettlement);

                    int goodPayerCount =
                        eligibleMembers.Count(x =>
                            x.GoodPayerStatus == "خوش‌حساب");

                    int badPayerCount =
                        eligibleMembers.Count(x =>
                            x.GoodPayerStatus == "بدحساب");

                    int noHistoryCount =
                        eligibleMembers.Count(x =>
                            x.GoodPayerStatus == "فاقد سابقه کافی");

                    int assessmentErrorCount =
                        eligibleMembers.Count(x =>
                            x.GoodPayerStatus == "محاسبه نشد");


                    // =========================================================
                    // اعمال فیلتر وضعیت ورود به نوبت
                    // =========================================================

                    var filteredQuery =
                        eligibleMembers.AsQueryable();

                    if (queueStatus == "eligible")
                    {
                        filteredQuery = filteredQuery.Where(x =>
                            x.CanEnterQueue);
                    }
                    else if (queueStatus == "waiting")
                    {
                        filteredQuery = filteredQuery.Where(x =>
                            !x.CanEnterQueue &&
                            !x.RequiresPensionArrearsSettlement);
                    }
                    else if (queueStatus == "pensionBlocked")
                    {
                        filteredQuery = filteredQuery.Where(x =>
                            x.RequiresPensionArrearsSettlement);
                    }


                    // =========================================================
                    // اعمال فیلتر خوش‌حسابی
                    // =========================================================

                    if (payerStatus == "good")
                    {
                        filteredQuery = filteredQuery.Where(x =>
                            x.GoodPayerStatus == "خوش‌حساب");
                    }
                    else if (payerStatus == "bad")
                    {
                        filteredQuery = filteredQuery.Where(x =>
                            x.GoodPayerStatus == "بدحساب");
                    }
                    else if (payerStatus == "nohistory")
                    {
                        filteredQuery = filteredQuery.Where(x =>
                            x.GoodPayerStatus == "فاقد سابقه کافی");
                    }
                    else if (payerStatus == "error")
                    {
                        filteredQuery = filteredQuery.Where(x =>
                            x.GoodPayerStatus == "محاسبه نشد");
                    }


                    // =========================================================
                    // جستجو
                    // =========================================================

                    if (!string.IsNullOrWhiteSpace(search))
                    {
                        search = search.Trim();

                        int memberIdSearch;

                        if (int.TryParse(search, out memberIdSearch))
                        {
                            filteredQuery = filteredQuery.Where(x =>
                                x.Id == memberIdSearch ||
                                (x.FName != null && x.FName.Contains(search)) ||
                                (x.LName != null && x.LName.Contains(search)) ||
                                (x.FatherName != null && x.FatherName.Contains(search)) ||
                                (x.MelliCode != null && x.MelliCode.Contains(search)) ||
                                (x.Mobile != null && x.Mobile.Contains(search)));
                        }
                        else
                        {
                            filteredQuery = filteredQuery.Where(x =>
                                (x.FName != null && x.FName.Contains(search)) ||
                                (x.LName != null && x.LName.Contains(search)) ||
                                (x.FatherName != null && x.FatherName.Contains(search)) ||
                                (x.MelliCode != null && x.MelliCode.Contains(search)) ||
                                (x.Mobile != null && x.Mobile.Contains(search)));
                        }
                    }


                    // =========================================================
                    // فهرست نهایی فیلترشده
                    // =========================================================

                    var filteredMembers =
                        filteredQuery.ToList();

                    totalRecords =
                        filteredMembers.Count;

                    totalPages =
                        rows > 0
                            ? (int)Math.Ceiling(
                                totalRecords * 1.0 / rows)
                            : 0;


                    // =========================================================
                    // مرتب‌سازی
                    // =========================================================
                    var orderedMembers =
     filteredMembers.AsQueryable();
                    if (sord == "asc")
                    {
                        if (sidx == "DayDiff")
                        {
                            orderedMembers =
                                orderedMembers.OrderBy(
                                    m => m.DayDiff);
                        }
                        else if (sidx == "NegativeScore")
                        {
                            orderedMembers =
                                orderedMembers.OrderBy(
                                    m => m.NegativeScore);
                        }
                        else if (sidx == "QueueEligibleDate")
                        {
                            orderedMembers = orderedMembers.OrderBy(
                                x => x.QueueEligibleDate);
                        }
                        else if (sidx == "GoodPayerFeePercent")
                        {
                            orderedMembers = orderedMembers.OrderBy(
                                x => x.GoodPayerFeePercent);
                        }
                        else if (sidx == "GoodPayerStatus")
                        {
                            orderedMembers = orderedMembers.OrderBy(
                                x => x.GoodPayerStatus);
                        }
                        else if (sidx == "NegativeScoreWaitMonths")
                        {
                            orderedMembers = orderedMembers.OrderBy(
                                x => x.NegativeScoreWaitMonths);
                        }
                        else if (sidx == "OutstandingPensionArrearsAmount")
                        {
                            orderedMembers = orderedMembers.OrderBy(
                                x => x.OutstandingPensionArrearsAmount);
                        }
                        else
                        {
                            orderedMembers =
                                orderedMembers.OrderBy(
                                    m => m.Id);
                        }
                    }
                    else
                    {
                        if (sidx == "DayDiff")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    m => m.DayDiff);
                        }
                        else if (sidx == "NegativeScore")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    m => m.NegativeScore);
                        }
                        else if (sidx == "QueueEligibleDate")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    x => x.QueueEligibleDate);
                        }
                        else if (sidx == "GoodPayerFeePercent")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    x => x.GoodPayerFeePercent);
                        }
                        else if (sidx == "GoodPayerStatus")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    x => x.GoodPayerStatus);
                        }
                        else if (sidx == "NegativeScoreWaitMonths")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    x => x.NegativeScoreWaitMonths);
                        }
                        else if (sidx == "OutstandingPensionArrearsAmount")
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    x => x.OutstandingPensionArrearsAmount);
                        }
                        else
                        {
                            orderedMembers =
                                orderedMembers.OrderByDescending(
                                    m => m.Id);
                        }
                    }

                    // =========================================================
                    // خروجی کامل اکسل
                    // قبل از صفحه‌بندی و با همان فیلترهای جدول
                    // =========================================================

                    if (exportAll)
                    {
                        var exportMembers =
                            orderedMembers.ToList();

                        return ExportAvvalinDarkhastMembersCsv(
                            exportMembers
                        );
                    }
                    // =========================================================
                    // Paging
                    // =========================================================
                    var pagedMembers =
                        orderedMembers
                            .Skip((page - 1) * rows)
                            .Take(rows)
                            .ToList();


                    // =========================================================
                    // jqGrid
                    // =========================================================
                    var productsData =
                        new JqGridData
                        {
                            Total =
                                totalPages,

                            Page =
                                page,

                            Records =
                                totalRecords,
                            UserData = new
                            {
                                TotalMembers = totalMembersCount,

                                CanEnterQueueCount = canEnterQueueCount,

                                WaitingQueueCount = waitingQueueCount,

                                PensionBlockedCount = pensionBlockedCount,

                                GoodPayerCount = goodPayerCount,

                                BadPayerCount = badPayerCount,

                                NoHistoryCount = noHistoryCount,

                                AssessmentErrorCount = assessmentErrorCount
                            },
                            Rows =
                                pagedMembers
                                    .Select(product =>
                                        new JqGridRowData
                                        {
                                            Id =
                                                product.Id,

                                            RowCells =
                                                new List<object>
                                                {
                                            product.GUID.ToString(),

                                            product.Id,

                                            product.Faal,

                                            product.FName ?? "",

                                            product.LName ?? "",

                                            product.FatherName ?? "",

                                            product.MelliCode ?? "",

                                            ConvertToPersianDate(
                                                product.TavalodDate),

                                            ConvertToPersianDate(
                                                product.OzvDate),

                                            product.ShNo ?? "",

                                            product.parvanehNo ?? "",

                                            product.NezamNo ?? "",

                                            product.Tel ?? "",

                                            product.Mobile ?? "",

                                            product.Address ?? "",

                                            ConvertToPersianDate(
                                                product.LastPaymentDate),

                                            product.IsOver6Months
                                                ? 1
                                                : 0,

                                            product.DayDiff ?? 0,

                                            product.HasPaidAfterDue
                                                ? 1
                                                : 0,

                                            product.NegativeScore,

                                            product.DelayedMonths,

                                            product.DelayReason ?? "",

                                            product.QueueDelayMonths,

                                            ConvertToPersianDate(product.QueueEligibleDate)
                                            ,

// خوش‌حسابی
product.GoodPayerStatus ?? "",



// امتیاز اقساط، فاصله P و سقف R
product.GoodPayerInstallmentNegativeScore,

product.GoodPayerPIntervalMonths,

product.GoodPayerRThreshold,

// امتیاز مستمری، فاصله Q و سقف T
product.GoodPayerPensionNegativeScore,

product.GoodPayerQIntervalMonths,

product.GoodPayerTThreshold,

product.GoodPayerDelayedInstallments,

product.GoodPayerDelayedPensionMonths,

product.GoodPayerFeePercent,

// وضعیت ورود
product.QueueDecisionStatus ?? "",

product.NegativeScoreWaitMonths,

ConvertToPersianDate(
    product.NegativeScoreWaitUntilDate
),

product.PensionArrearsDelayedMonths,

product.PensionArrearsOutstandingMonths,

ConvertToPersianDate(
    product.OldestOutstandingPensionDueDate
),

product.OutstandingPensionArrearsAmount,

ConvertToPersianDate(
    product.LastSettledLoanPaymentDate
),

// جزئیات تشریحی
product.GoodPayerReason ?? "",

product.QueueDecisionReason ?? "",

// فیلدهای کمکی
product.GoodPayerTotalNegativeScore,

product.RequiresPensionArrearsSettlement ? 1 : 0,

product.GoodPayerCanAssess ? 1 : 0,

product.GoodPayerHasSettledLoan ? 1 : 0
                                                }
                                        })
                                    .ToList()
                        };


                    return Json(
                        productsData,
                        JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    "GetAvvalinDarkhastMembers ERROR:"
                );

                System.Diagnostics.Debug.WriteLine(ex.ToString());

                System.Diagnostics.Trace.TraceError(
                    "GetAvvalinDarkhastMembers ERROR: {0}",
                    ex.ToString()
                );

                return new HttpStatusCodeResult(
                    500,
                    "خطا در محاسبه فهرست درخواست‌های اولیه وام. جزئیات در لاگ سرور ثبت شد."
                );
            }
        }
        private TotalNegativeScoreResult CalculateTotalNegativeScore(
    DateTime startDate,
    long memberId,
    SandooghModel db,
    PensionArrearsSummary pensionArrears = null,
    T_OzvCode preparedMember = null,
    Vam preparedLoan = null,
    IList<G_M_Pays> preparedLoanPayments = null,
    bool usePreparedLoanData = false,
    T_VamQueueSetting queueSetting = null)
        {
            if (queueSetting == null || !queueSetting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات ورود به نوبت تکمیل نشده است."
                );
            }
            var result = new TotalNegativeScoreResult();

            // محاسبه امتیاز منفی مستمری
            var mostamariResult =
     CalculateMostamariNegativeScore(
         startDate,
         memberId,
         db,
         pensionArrears,
         preparedMember,
         queueSetting.N_PensionGraceMonths
     );
            result.MostamariNegativeScore = mostamariResult.NegativeScore;
            result.MostamariDelayedMonths = mostamariResult.DelayedMonths;
            result.MostamariDelayReason = mostamariResult.DelayReason;

            // محاسبه امتیاز منفی وام (برای وام تسویه شده)
            var vamResult =
     CalculateVamNegativeScore(
         memberId,
         db,
         queueSetting.M_InstallmentGraceMonths,
         preparedLoan,
         preparedLoanPayments,
         usePreparedLoanData
     );
            result.VamNegativeScore = vamResult.NegativeScore;
            result.VamDelayedMonths = vamResult.DelayedMonths;
            result.VamDelayReason = vamResult.DelayReason;

            // جمع کل امتیازات
            result.TotalNegativeScore = result.MostamariNegativeScore + result.VamNegativeScore;

            // ساخت توضیحات ترکیبی
            var combinedParts = new List<string>();

            // بخش مستمری
            if (result.MostamariNegativeScore > 0)
            {
                combinedParts.Add($"مستمری: {result.MostamariDelayReason}");
            }
            else if (result.MostamariDelayedMonths > 0)
            {
                combinedParts.Add($"مستمری: {result.MostamariDelayReason}");
            }
            else
            {
                combinedParts.Add("مستمری: بدون تاخیر");
            }

            // بخش وام
            if (result.VamNegativeScore > 0)
            {
                combinedParts.Add($"وام: {result.VamDelayReason}");
            }
            else if (result.VamDelayedMonths > 0)
            {
                combinedParts.Add($"وام: {result.VamDelayReason}");
            }
            else
            {
                combinedParts.Add("وام: بدون تاخیر");
            }

            result.CombinedDelayReason = string.Join(" | ", combinedParts);

            return result;
        }
        private static DateTime GetPersianMonthStart(DateTime date)
        {
            PersianCalendar pc = new PersianCalendar();
            return pc.ToDateTime(
                pc.GetYear(date),
                pc.GetMonth(date),
                1, 0, 0, 0, 0);
        }

        private static DateTime GetNextPersianMonthStart(DateTime persianMonthStart)
        {
            PersianCalendar pc = new PersianCalendar();
            int py = pc.GetYear(persianMonthStart);
            int pm = pc.GetMonth(persianMonthStart) + 1;

            if (pm > 12) { pm = 1; py++; }

            return pc.ToDateTime(py, pm, 1, 0, 0, 0, 0);
        }

        private NegativeScoreResult CalculateMostamariNegativeScore(
      DateTime startDate,
      long memberId,
      SandooghModel db,
      PensionArrearsSummary pensionArrears,
      T_OzvCode preparedMember,
      int pensionDelayThresholdMonths)
        {
            var result = new NegativeScoreResult();

            try
            {
                if (db == null)
                    throw new ArgumentNullException("db");

                var user = preparedMember ??
       db.T_OzvCode.FirstOrDefault(o => o.Id == memberId);

                if (user == null)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "عضو یافت نشد";
                    return result;
                }

                if (startDate.Date > DateTime.Today)
                {
                    result.NegativeScore = 0;
                    result.DelayedMonths = 0;
                    result.DelayReason = "هنوز به موعد پرداخت نرسیده است";
                    return result;
                }

                // استفاده از محاسبه‌گر مشترک معوقات مستمری
                // اگر قبلاً محاسبه شده باشد، همان نتیجه استفاده می‌شود.
                if (pensionArrears == null)
                {
                    pensionArrears =
      VamPolicyHelper.CalculatePensionArrears(
          db,
          (int)memberId,
          startDate,
          DateTime.Today,
          pensionDelayThresholdMonths:
              pensionDelayThresholdMonths
      );
                }

                result.NegativeScore =
                    pensionArrears.NegativeScore;

                result.DelayedMonths =
                    pensionArrears.DelayedMonths;

                if (pensionArrears.NegativeScore > 0)
                {
                    result.DelayReason =
                        "دارای " +
                        pensionArrears.NegativeScore +
                        " امتیاز منفی مستمری؛ طولانی‌ترین بازه تأخیر: " +
                        pensionArrears.DelayedMonths +
                        " ماه.";
                }
                else if (pensionArrears.OutstandingMonths > 0)
                {
                    result.DelayReason =
                        "دارای " +
                        pensionArrears.OutstandingMonths +
                        " ماه معوق مستمری، بدون امتیاز منفی؛ مبلغ مانده: " +
                        pensionArrears.OutstandingAmount.ToString("N0") +
                        " ریال.";
                }
                else if (pensionArrears.TotalDelayedMonths > 0)
                {
                    result.DelayReason =
                        "معوقات مستمری قبلاً پرداخت شده‌اند؛ مجموع ماه‌های دیرکرد: " +
                        pensionArrears.TotalDelayedMonths;
                }
                else
                {
                    result.DelayReason =
                        "بدون تأخیر قابل توجه در مستمری";
                }

                return result;
            }
            catch (Exception ex)
            {
                result.NegativeScore = 0;
                result.DelayedMonths = 0;
                result.DelayReason =
                    "خطا در محاسبه مستمری: " + ex.Message;

                return result;
            }
        }
        // متد تبدیل تاریخ میلادی به شمسی
        private string ConvertToPersianDate(DateTime? date)
            {
                if (!date.HasValue)
                    return "";

                PersianCalendar pc = new PersianCalendar();
                return $"{pc.GetYear(date.Value)}/{pc.GetMonth(date.Value):00}/{pc.GetDayOfMonth(date.Value):00}";
            }

        // =========================================================
        // تبدیل مقدار به سلول امن CSV
        // =========================================================

        private static string EscapeAvvalinCsvCell(object value)
        {
            if (value == null)
                return "\"\"";

            string text;

            if (value is bool)
            {
                text = (bool)value ? "بله" : "خیر";
            }
            else
            {
                var formattable = value as IFormattable;

                text = formattable != null
                    ? formattable.ToString(
                        null,
                        CultureInfo.InvariantCulture)
                    : value.ToString();
            }

            // جلوگیری از اجرای فرمول‌های احتمالی داخل Excel
            if (value is string &&
                text.Length > 0 &&
                "=+-@".IndexOf(text[0]) >= 0)
            {
                text = "'" + text;
            }

            return "\"" + text.Replace("\"", "\"\"") + "\"";
        }


        // =========================================================
        // ساخت یک ردیف CSV
        // =========================================================

        private static string BuildAvvalinCsvLine(
            params object[] values)
        {
            return string.Join(
                ",",
                values.Select(EscapeAvvalinCsvCell)
            );
        }


        // =========================================================
        // خروجی کامل فهرست اولیه درخواست وام
        // =========================================================

        private ActionResult ExportAvvalinDarkhastMembersCsv(
            IList<MemberNegativeScoreResult> members)
        {
            var csv = new System.Text.StringBuilder();

            // تشخیص جداکننده توسط Excel
            csv.AppendLine("sep=,");

            // -----------------------------------------------------
            // عناوین ستون‌ها
            // -----------------------------------------------------

            csv.AppendLine(BuildAvvalinCsvLine(
                "کد عضویت",
                "شناسه یکتا",
                "وضعیت عضو",
                "نام",
                "نام خانوادگی",
                "نام پدر",
                "کد ملی",
                "تاریخ تولد",
                "تاریخ عضویت",
                "شماره شناسنامه",
                "شماره پروانه",
                "شماره عضویت نظام",
                "تلفن",
                "موبایل",
                "آدرس",
                "تاریخ آخرین پرداخت",
                "تاریخ شروع محاسبه",
                "بیش از شش ماه از عضویت",
                "روزهای گذشته",
                "واریزی بعد از موعد",
                "امتیاز منفی صف",
                "ماه‌های تأخیر صف",
                "علت تأخیر صف",
                "امتیاز منفی مستمری صف",
                "امتیاز منفی وام صف",
                "علت تأخیر مستمری",
                "علت تأخیر وام",
               "مدت انتظار نهایی صف پس از اعمال سقف شش ماه",
                "تاریخ مجاز ورود",
                "مجاز به ورود",
                "وضعیت خوش‌حسابی",
                "امتیاز منفی اقساط",
                "امتیاز منفی مستمری",
                "مجموع امتیاز خوش‌حسابی",
               "فاصله محاسبه امتیاز اقساط P",
"سقف مجاز امتیاز اقساط R",
"فاصله محاسبه امتیاز مستمری Q",
"سقف مجاز امتیاز مستمری T",
                "تعداد اقساط تأخیردار",
                "ماه‌های تأخیردار مستمری",
                "درصد کارمزد",
                "علت خوش‌حسابی",
                "وضعیت تصمیم ورود",
                "علت تصمیم ورود",
                "مدت انتظار امتیاز منفی",
                "پایان انتظار امتیاز منفی",
                "ماه‌های تأخیر مستمری",
                "ماه‌های معوق باقی‌مانده",
                "قدیمی‌ترین سررسید معوق",
                "مبلغ معوق مستمری",
                "تاریخ واقعی تسویه وام",
                "نیازمند تسویه مستمری",
                "قابل ارزیابی خوش‌حسابی",
                "دارای وام تسویه‌شده"
            ));

            // -----------------------------------------------------
            // اطلاعات تمام اعضای فیلترشده
            // -----------------------------------------------------

            foreach (var item in members)
            {
                csv.AppendLine(BuildAvvalinCsvLine(
                    item.Id,
                    item.GUID,
                    item.Faal ? "فعال" : "غیرفعال",
                    item.FName,
                    item.LName,
                    item.FatherName,
                    item.MelliCode,
                    ConvertToPersianDate(item.TavalodDate),
                    ConvertToPersianDate(item.OzvDate),
                    item.ShNo,
                    item.parvanehNo,
                    item.NezamNo,
                    item.Tel,
                    item.Mobile,
                    item.Address,
                    ConvertToPersianDate(item.LastPaymentDate),
                    ConvertToPersianDate(item.StartDate),
                    item.IsOver6Months,
                    item.DayDiff,
                    item.HasPaidAfterDue,
                    item.NegativeScore,
                    item.DelayedMonths,
                    item.DelayReason,
                    item.MostamariNegativeScore,
                    item.VamNegativeScore,
                    item.MostamariDelayReason,
                    item.VamDelayReason,
                    item.QueueDelayMonths,
                    ConvertToPersianDate(item.QueueEligibleDate),
                    item.CanEnterQueue,
                    item.GoodPayerStatus,
                   item.GoodPayerInstallmentNegativeScore,
item.GoodPayerPIntervalMonths,
item.GoodPayerRThreshold,

item.GoodPayerPensionNegativeScore,
item.GoodPayerQIntervalMonths,
item.GoodPayerTThreshold,

item.GoodPayerTotalNegativeScore,

item.GoodPayerDelayedInstallments,
item.GoodPayerDelayedPensionMonths,
                    item.GoodPayerDelayedInstallments,
                    item.GoodPayerDelayedPensionMonths,
                    item.GoodPayerFeePercent,
                    item.GoodPayerReason,
                    item.QueueDecisionStatus,
                    item.QueueDecisionReason,
                    item.NegativeScoreWaitMonths,
                    ConvertToPersianDate(item.NegativeScoreWaitUntilDate),
                    item.PensionArrearsDelayedMonths,
                    item.PensionArrearsOutstandingMonths,
                    ConvertToPersianDate(item.OldestOutstandingPensionDueDate),
                    item.OutstandingPensionArrearsAmount,
                    ConvertToPersianDate(item.LastSettledLoanPaymentDate),
                    item.RequiresPensionArrearsSettlement,
                    item.GoodPayerCanAssess,
                    item.GoodPayerHasSettledLoan
                ));
            }

            // -----------------------------------------------------
            // UTF-8 همراه BOM برای نمایش صحیح فارسی در Excel
            // -----------------------------------------------------

            byte[] fileBytes =
                System.Text.Encoding.UTF8.GetPreamble()
                    .Concat(
                        System.Text.Encoding.UTF8.GetBytes(
                            csv.ToString()
                        )
                    )
                    .ToArray();

            string fileName =
                "AvvalinDarkhastMembers-" +
                DateTime.Now.ToString(
                    "yyyyMMdd-HHmm",
                    CultureInfo.InvariantCulture
                ) +
                ".csv";

            return File(
                fileBytes,
                "text/csv",
                fileName
            );
        }

        private string FixDelayReason(string delayReason, DateTime? lastPaymentDate)
        {
            if (string.IsNullOrEmpty(delayReason))
                return "بدون تاخیر";

            if (!lastPaymentDate.HasValue)
                return delayReason;

            var miladyDate = lastPaymentDate.Value.ToString("yyyy-MM-dd");
            var persianDate = ConvertToPersianDate(lastPaymentDate);

            return delayReason.Replace(miladyDate, persianDate);
        }

        // متد تبدیل تاریخ میلادی به شمسی
        
        // متد تبدیل اعداد انگلیسی به فارسی (اختیاری)
        private string ConvertToPersianNumbers(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            string[] englishNumbers = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            string[] persianNumbers = { "۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹" };

            for (int i = 0; i < englishNumbers.Length; i++)
            {
                input = input.Replace(englishNumbers[i], persianNumbers[i]);
            }

            return input;
        }
        private string GetCityName(SandooghModel db, int? cityCode)
        {
            if (!cityCode.HasValue) return "";
            var city = db.CityCodes.FirstOrDefault(c => c.id == cityCode.Value);
            return city?.CityName ?? "";
        }

        private string GetTaaholName(SandooghModel db, int? taaholId)
        {
            if (!taaholId.HasValue) return "";
            var taahol = db.Taahols.FirstOrDefault(t => t.Taahol_Id == taaholId.Value);
            return taahol?.Taahol_Name ?? "";
        }
        public class MemberNegativeScoreResult
        {
            public long Id { get; set; }
            public Guid GUID { get; set; }
            public bool Faal { get; set; }
            public string FName { get; set; }
            public string LName { get; set; }
            public string FatherName { get; set; }
            public string MelliCode { get; set; }
            public DateTime? TavalodDate { get; set; }
            public DateTime? OzvDate { get; set; }
            public string ShNo { get; set; }
            public string parvanehNo { get; set; }
            public string NezamNo { get; set; }
            public string Tel { get; set; }
            public string Mobile { get; set; }
            public string Address { get; set; }
            public DateTime? LastPaymentDate { get; set; }
            public DateTime? StartDate { get; set; }
            public bool IsOver6Months { get; set; }
            public int? DayDiff { get; set; }
            public bool HasPaidAfterDue { get; set; }
            public int NegativeScore { get; set; }
            public int DelayedMonths { get; set; }
            public string DelayReason { get; set; }
            public int TotalRecords { get; set; }
            public int TotalPages { get; set; }
            public int MostamariNegativeScore { get; set; }
            public int VamNegativeScore { get; set; }
            public string MostamariDelayReason { get; set; }
            public string VamDelayReason { get; set; }
            public int QueueDelayMonths { get; set; }
            public DateTime? QueueEligibleDate { get; set; }
            public bool CanEnterQueue { get; set; }
            // -------------------------------------------------
            // اطلاعات خوش‌حسابی
            // -------------------------------------------------

            public bool GoodPayerCanAssess { get; set; }

            public bool GoodPayerHasSettledLoan { get; set; }

            public bool IsGoodPayer { get; set; }

            public string GoodPayerStatus { get; set; }

            public int GoodPayerInstallmentNegativeScore { get; set; }

            public int GoodPayerPensionNegativeScore { get; set; }

            public int GoodPayerTotalNegativeScore { get; set; }

            // فاصله محاسبه امتیاز منفی اقساط
            public int GoodPayerPIntervalMonths { get; set; }

            // فاصله محاسبه امتیاز منفی مستمری
            public int GoodPayerQIntervalMonths { get; set; }

            // حداکثر امتیاز منفی مجاز اقساط
            public int GoodPayerRThreshold { get; set; }

            // حداکثر امتیاز منفی مجاز مستمری
            public int GoodPayerTThreshold { get; set; }

            public int GoodPayerDelayedInstallments { get; set; }

            public int GoodPayerDelayedPensionMonths { get; set; }

            public decimal GoodPayerFeePercent { get; set; }

            public string GoodPayerReason { get; set; }


            // -------------------------------------------------
            // اطلاعات دقیق ورود به نوبت
            // -------------------------------------------------

            public string QueueDecisionStatus { get; set; }

            public string QueueDecisionReason { get; set; }

            public int NegativeScoreWaitMonths { get; set; }

            public DateTime? NegativeScoreWaitUntilDate { get; set; }

            public int PensionArrearsDelayedMonths { get; set; }

            public int PensionArrearsOutstandingMonths { get; set; }

            public decimal OutstandingPensionArrearsAmount { get; set; }

            public DateTime? OldestOutstandingPensionDueDate { get; set; }

            public bool RequiresPensionArrearsSettlement { get; set; }

            public DateTime? LastSettledLoanPaymentDate { get; set; }
        }


        public class GoodPayerDashboardRow
        {
            public int Id { get; set; }

            public string FullName { get; set; }

            public string FatherName { get; set; }

            public string Mobile { get; set; }

            public string MembershipDate { get; set; }

            public bool CanAssess { get; set; }

            public bool IsGoodPayer { get; set; }

            public bool HasSettledLoan { get; set; }

            public string Status { get; set; }

            public int InstallmentNegativeScore { get; set; }

            public int PensionNegativeScore { get; set; }

            // P: فاصله محاسبه امتیاز اقساط
            public int PIntervalMonths { get; set; }

            // Q: فاصله محاسبه امتیاز مستمری
            public int QIntervalMonths { get; set; }

            // R: سقف مجاز امتیاز منفی اقساط
            public int RThreshold { get; set; }

            // T: سقف مجاز امتیاز منفی مستمری
            public int TThreshold { get; set; }

            public int DelayedInstallments { get; set; }

            public int DelayedPensionMonths { get; set; }

            public decimal FeePercent { get; set; }

            public string Reason { get; set; }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GetGoodPayerDashboard(
        string sidx,
        string sord,
        int page = 1,
        int rows = 50,
        string status = "all",
        string search = null)
        {
            page = Math.Max(1, page);
            rows = rows > 0 ? Math.Min(rows, 200) : 50;

            var result = new List<GoodPayerDashboardRow>();

            try
            {
                using (SandooghModel db = new SandooghModel())
                {
                    DateTime asOfDate = DateTime.Today;

                    // فقط اعضای فعال
                    var memberQuery = db.T_OzvCode
                        .AsNoTracking()
                        .Where(x => x.Faal == true);

                    // جستجو
                    if (!string.IsNullOrWhiteSpace(search))
                    {
                        search = search.Trim();

                        int memberId;

                        if (int.TryParse(search, out memberId))
                        {
                            memberQuery = memberQuery.Where(x =>
                                x.Id == memberId ||
                                (x.FName != null && x.FName.Contains(search)) ||
                                (x.LName != null && x.LName.Contains(search)) ||
                                (x.MelliCode != null && x.MelliCode.Contains(search)) ||
                                (x.Mobile != null && x.Mobile.Contains(search)));
                        }
                        else
                        {
                            memberQuery = memberQuery.Where(x =>
                                (x.FName != null && x.FName.Contains(search)) ||
                                (x.LName != null && x.LName.Contains(search)) ||
                                (x.MelliCode != null && x.MelliCode.Contains(search)) ||
                                (x.Mobile != null && x.Mobile.Contains(search)));
                        }
                    }

                    // دریافت اعضا و محاسبه گروهی
                    var members = memberQuery
                        .OrderBy(x => x.Id)
                        .ToList();

                    var batchEvaluation =
                        MVCSandoogh.Services.GoodPayerBatchEvaluator.Evaluate(
                            db,
                            members,
                            asOfDate
                        );

                    foreach (var member in members)
                    {
                        try
                        {
                            MVCSandoogh.Services.GoodPayerAssessment assessment;

                            string batchError;

                            if (batchEvaluation.Errors.TryGetValue(
                                member.Id,
                                out batchError))
                            {
                                throw new InvalidOperationException(batchError);
                            }

                            if (!batchEvaluation.Assessments.TryGetValue(
                                member.Id,
                                out assessment))
                            {
                                throw new InvalidOperationException(
                                    "نتیجه ارزیابی خوش‌حسابی برای عضو پیدا نشد."
                                );
                            }

                            var reasonParts = new List<string>();

                            if (!assessment.HasSettledLoan)
                            {
                                reasonParts.Add(
                                    "سابقه وام تسویه‌شده ندارد؛ خوش‌حسابی قابل احراز نیست."
                                );
                            }
                            else
                            {
                                bool installmentIsBad =
                                    Math.Abs((long)assessment.InstallmentNegativeScore) >
                                    assessment.R;

                                bool pensionIsBad =
                                    Math.Abs((long)assessment.PensionNegativeScore) >
                                    assessment.T;

                                reasonParts.Add(
                                    "اقساط: " +
                                    Math.Abs((long)assessment.InstallmentNegativeScore) +
                                    " امتیاز منفی؛ P=" +
                                    assessment.P +
                                    "، سقف مجاز R=" +
                                    assessment.R +
                                    (installmentIsBad
                                        ? "؛ عبور از سقف مجاز"
                                        : "؛ در محدوده مجاز")
                                );

                                reasonParts.Add(
                                    "مستمری: " +
                                    Math.Abs((long)assessment.PensionNegativeScore) +
                                    " امتیاز منفی؛ Q=" +
                                    assessment.Q +
                                    "، سقف مجاز T=" +
                                    assessment.T +
                                    (pensionIsBad
                                        ? "؛ عبور از سقف مجاز"
                                        : "؛ در محدوده مجاز")
                                );

                                reasonParts.Add(
                                    "تعداد اقساط دارای امتیاز منفی: " +
                                    assessment.DelayedInstallments
                                );

                                reasonParts.Add(
                                    "ماه‌های دارای امتیاز منفی مستمری: " +
                                    assessment.DelayedPensionMonths
                                );
                            }

                            result.Add(new GoodPayerDashboardRow
                            {
                                Id = member.Id,

                                FullName =
                                    (member.FName ?? "") + " " +
                                    (member.LName ?? ""),

                                FatherName = member.FatherName ?? "",

                                Mobile = member.Mobile ?? "",

                                MembershipDate =
                                    ConvertToPersianDate(member.OzvDate),

                                CanAssess = true,

                                HasSettledLoan =
                                    assessment.HasSettledLoan,

                                IsGoodPayer =
                                    assessment.IsGoodPayer,

                                Status = !assessment.HasSettledLoan
                                    ? "فاقد سابقه کافی"
                                    : assessment.IsGoodPayer
                                        ? "خوش‌حساب"
                                        : "بدحساب",

                                InstallmentNegativeScore =
                                    assessment.InstallmentNegativeScore,

                                PensionNegativeScore =
                                    assessment.PensionNegativeScore,

                                PIntervalMonths = assessment.P,

                                QIntervalMonths = assessment.Q,

                                RThreshold = assessment.R,

                                TThreshold = assessment.T,

                                DelayedInstallments =
                                    assessment.DelayedInstallments,

                                DelayedPensionMonths =
                                    assessment.DelayedPensionMonths,

                                FeePercent = assessment.FeePercent,

                                Reason = string.Join(" | ", reasonParts)
                            });
                        }
                        catch (Exception memberException)
                        {
                            // خطای یک عضو نباید ارزیابی سایر اعضا را متوقف کند.
                            result.Add(new GoodPayerDashboardRow
                            {
                                Id = member.Id,

                                FullName =
                                    (member.FName ?? "") + " " +
                                    (member.LName ?? ""),

                                FatherName = member.FatherName ?? "",

                                Mobile = member.Mobile ?? "",

                                MembershipDate =
                                    ConvertToPersianDate(member.OzvDate),

                                CanAssess = false,

                                Status = "خطای محاسبه",

                                Reason = memberException.Message
                            });
                        }
                    }
                }

                // فیلتر وضعیت
                if (status == "good")
                {
                    result = result
                        .Where(x => x.CanAssess && x.IsGoodPayer)
                        .ToList();
                }
                else if (status == "bad")
                {
                    result = result
                        .Where(x => x.CanAssess && !x.IsGoodPayer)
                        .ToList();
                }

                // مرتب‌سازی
                IOrderedEnumerable<GoodPayerDashboardRow> ordered;

                bool ascending =
                    string.Equals(
                        sord,
                        "asc",
                        StringComparison.OrdinalIgnoreCase
                    );

                switch (sidx)
                {
                    case "FullName":
                        ordered = ascending
                            ? result.OrderBy(x => x.FullName)
                            : result.OrderByDescending(x => x.FullName);
                        break;

                    case "InstallmentNegativeScore":
                        ordered = ascending
                            ? result.OrderBy(x => x.InstallmentNegativeScore)
                            : result.OrderByDescending(x => x.InstallmentNegativeScore);
                        break;

                    case "PensionNegativeScore":
                        ordered = ascending
                            ? result.OrderBy(x => x.PensionNegativeScore)
                            : result.OrderByDescending(x => x.PensionNegativeScore);
                        break;

                    case "FeePercent":
                        ordered = ascending
                            ? result.OrderBy(x => x.FeePercent)
                            : result.OrderByDescending(x => x.FeePercent);
                        break;

                    default:
                        ordered = result.OrderByDescending(x => x.Id);
                        break;
                }

                int totalRecords = result.Count();

                int totalPages = (int)Math.Ceiling(
                    totalRecords / (double)rows
                );

                var pageItems = ordered
                    .Skip((page - 1) * rows)
                    .Take(rows)
                    .ToList();

                var response = new JqGridData
                {
                    Total = totalPages,
                    Page = page,
                    Records = totalRecords,

                    Rows = pageItems.Select(item =>
                        new JqGridRowData
                        {
                            Id = item.Id,

                            RowCells = new List<object>
                            {
                        item.Id,
                        item.FullName,
                        item.FatherName,
                        item.Mobile,
                        item.MembershipDate,
                        item.Status,

                        item.InstallmentNegativeScore,
                        item.PIntervalMonths,
                        item.RThreshold,
                        item.DelayedInstallments,

                        item.PensionNegativeScore,
                        item.QIntervalMonths,
                        item.TThreshold,
                        item.DelayedPensionMonths,

                        item.FeePercent,
                        item.Reason,
                        item.CanAssess
                            }
                        }).ToList()
                };

                return Json(
                    response,
                    JsonRequestBehavior.AllowGet
                );
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    "GoodPayerDashboard Error: " + ex
                );

                return Json(
                    new JqGridData
                    {
                        Total = 0,
                        Page = page,
                        Records = 0,
                        Rows = new List<JqGridRowData>()
                    },
                    JsonRequestBehavior.AllowGet
                );
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddMostamary(T_MostamaryMablagh postData)
        {
           if (postData.MostamaryMablagh_IdRefOzvCode == null) return Json(false);
            SandooghModel db = new SandooghModel();
            //ToDo: Add Product To Repository
          
            if (postData == null)
                return Json(false);
            AccountController acc = new AccountController();

            postData.MostamaryMablagh_ModifiedUser = long.Parse(acc.GetUserID_By_UserName(User.Identity.Name));
            postData.MostamaryMablagh_CurrentBeruzDate = postData.MostamaryMablagh_DateStart;
            postData.MostamaryMablagh_VarizyTaDateStart = (int)(from e in db.G_M_Pays where (e.IdRefOzv == postData.MostamaryMablagh_IdRefOzvCode && !(e.IsAfzayesh == true && (DateTime)e.PayDate >= (DateTime)postData.MostamaryMablagh_DateStart)) select e.MostamariMablag).Sum();
            db.T_MostamaryMablagh.Add(postData);
            db.SaveChanges();
            return Json(true);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteMostamary(string id)
        {
            int idd = int.Parse(id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_MostamaryMablagh.FirstOrDefault(x => x.MostamaryMablagh_ID == idd);
            if (product == null)
                return Json(false);

            db.T_MostamaryMablagh.Remove(product);
            db.SaveChanges();
            return Json(true);
        }
        
        [Authorize(Roles = "Admin")]
        public JsonResult updateafzayeshpayeh(long id,int mablagh)
        {
            SandooghModel db = new SandooghModel();

            try
            {
                var ozv =  db.T_OzvCode.Where(k => k.Id== id).FirstOrDefault();
                ozv.SumAfzayeshMostamary = mablagh;
                db.Entry(ozv).State = EntityState.Modified;
                db.SaveChanges();
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public JsonResult GeMostamaryMablaghByid(long id)
        {
            SandooghModel db = new SandooghModel();
  
        
                var AkharinVosoliDate = "";
                var mablaghmost = 500000;
                var ghabeleafzayesh = 0;
                bool afzayeshdade = false;
                var MandeMostMablagh = 0;
                var tedad = 0;
            var user = (from e in db.T_OzvCode where e.Id == id select e).FirstOrDefault();

            try
            {

                
                ghabeleafzayesh = (int)user.SumAfzayeshMostamary;


                try
                {
                    if (user.G_M_Pays.Where(k => k.IsAfzayesh == true).Count() > 0)
                    {
                        afzayeshdade = true;
                    }
                    else
                    {
                        afzayeshdade = false;
                    }
                }
                catch
                {

                }
                var mostamarypaie = user.T_MostamaryMablagh.LastOrDefault();
                if (mostamarypaie.MostamaryMablagh_Mablagh == 500000 && mostamarypaie.MostamaryMablagh_DateStart >= PersianDateUtils.ToMilady("1402/10/01"))
                {
                    //اگر بعد از تاریخ 14021001 یک مستمری پایه با مبلغ 50 تومن ثبت شده آن را به 100 تومن تغییر بده
                    mostamarypaie.MostamaryMablagh_Mablagh = 1000000;
                    db.Entry(mostamarypaie).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
                var summost = user.G_M_Pays.Where(e => e.PayDate <= mostamarypaie.MostamaryMablagh_DateStart || e.IsAfzayesh != true).Sum(k => k.MostamariMablag);

                if (mostamarypaie != null)
                {

                    int kheilivaghtpishmande = 0;
                    if (mostamarypaie.MostamaryMablagh_DateStart == PersianDateUtils.ToMilady("1397/09/01"))//اگر این تاریخ باشد یعنی یک مستمری پایه قبل از این نیز بررسی شود
                    {
                        mostamarypaie = user.T_MostamaryMablagh.Where(k => k.MostamaryMablagh_DateStart != PersianDateUtils.ToMilady("1397/09/01")).OrderByDescending(e => e.MostamaryMablagh_ID).FirstOrDefault();
                        kheilivaghtpishmande = 1;
                    }

                    var mybaiestta970901 = 0;
                    var mybaiestta14021001 = 0;
                    var tedadpardakhtshode = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart) / mostamarypaie.MostamaryMablagh_Mablagh);
                    var kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * mostamarypaie.MostamaryMablagh_Mablagh);

                    var persianCalendar = new System.Globalization.PersianCalendar();
                    if (kheilivaghtpishmande == 1)
                    {
                        for (int y = 0; persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, y) <= PersianDateUtils.ToMilady("1397/09/01"); y++)
                        {

                            mybaiestta970901 = y;

                        }
                    }
                    AkharinVosoliDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();

                    if (kheilivaghtpishmande == 1 && PersianDateUtils.ToMilady(AkharinVosoliDate) > PersianDateUtils.ToMilady("1397/09/01"))
                    {
                        var temp = mostamarypaie.MostamaryMablagh_Mablagh * mybaiestta970901 + mostamarypaie.MostamaryMablagh_VarizyTaDateStart;
                        mostamarypaie = user.T_MostamaryMablagh.LastOrDefault();
                        mostamarypaie.MostamaryMablagh_VarizyTaDateStart = (int)temp;
                        tedadpardakhtshode = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart) / mostamarypaie.MostamaryMablagh_Mablagh);
                        kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * mostamarypaie.MostamaryMablagh_Mablagh);

                        AkharinVosoliDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();


                        kheilivaghtpishmande = 0;
                    }//یعنی تا تاریخی که میبایست حداقل 20 تومان رو واریز میکرد کرده و حالا باید با مستمری پایه جدید اقدام بشه
                    else
                               if (mostamarypaie.MostamaryMablagh_Mablagh == 500000)
                    {

                        //یعنی تاریخ این مستمری پایه حتما قبل از 1 آذر 1402 هست 
                        if (PersianDateUtils.ToMilady(AkharinVosoliDate) >= PersianDateUtils.ToMilady("1402/10/01"))//
                        {
                            for (int y = 0; persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, y) <= PersianDateUtils.ToMilady("1402/10/01"); y++)
                            {

                                mybaiestta14021001 = y;

                            }
                            var temp = mostamarypaie.MostamaryMablagh_Mablagh * mybaiestta14021001 + mostamarypaie.MostamaryMablagh_VarizyTaDateStart;
                            try
                            {
                                var afzayeshinbein = user.G_M_Pays.Where(e => e.PayDate <= PersianDateUtils.ToMilady("1402/10/01") && e.PayDate > mostamarypaie.MostamaryMablagh_DateStart && e.IsAfzayesh == true).Sum(k => k.MostamariMablag);

                                temp = temp + afzayeshinbein;
                            }
                            catch
                            {

                            }




                            MVCSandoogh.Models.T_MostamaryMablagh moma = new MVCSandoogh.Models.T_MostamaryMablagh();
                            try { moma.MostamaryMablagh_CurrentBeruzDate = PersianDateUtils.ToMilady("1402/10/01"); } catch { }
                            try { moma.MostamaryMablagh_DateStart = PersianDateUtils.ToMilady("1402/10/01"); } catch { }

                            moma.MostamaryMablagh_IdRefOzvCode = mostamarypaie.MostamaryMablagh_IdRefOzvCode;
                            moma.MostamaryMablagh_Mablagh = 1000000;
                            moma.MostamaryMablagh_VarizyTaDateStart = (int)temp;
                            db.T_MostamaryMablagh.Add(moma);
                            db.SaveChanges();
                            //    mostamarypaie = moma;
                            //    tedadpardakhtshode = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart) / mostamarypaie.MostamaryMablagh_Mablagh);
                            //    kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * mostamarypaie.MostamaryMablagh_Mablagh);
                            //    AkharinVosoliDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();
                            return GeMostamaryMablaghByid(id);
                            //  ispaieadded = true;
                            //continue;
                        }

                    }

                    mablaghmost = (int)mostamarypaie.MostamaryMablagh_Mablagh;
                    int nowyear = persianCalendar.GetYear(DateTime.Now);
                    int nowmonth = persianCalendar.GetMonth(DateTime.Now);
                    int nowday = persianCalendar.GetDayOfMonth(DateTime.Now);
                    if (kheilivaghtpishmande == 1)
                    {
                        nowyear = 1397;
                        nowmonth = 09;
                        nowday = 01;
                    }
                    int MibayestVarizMost = 0;
                    DateTime now = persianCalendar.ToDateTime(nowyear, nowmonth, nowday, 0, 0, 0, 0);
                    DateTime tempdate = (DateTime)mostamarypaie.MostamaryMablagh_DateStart;
                    while (tempdate <= now)
                    {
                        MibayestVarizMost++;
                        tempdate = persianCalendar.AddMonths((tempdate), 1);
                    }
                    // if (MibayestVarizMost > 0) { MibayestVarizMost++; }
                    if (kheilivaghtpishmande == 1)
                    {
                        nowyear = persianCalendar.GetYear(DateTime.Now);
                        nowmonth = persianCalendar.GetMonth(DateTime.Now);
                        nowday = persianCalendar.GetDayOfMonth(DateTime.Now);


                    }
                    // var MablaghSarresidKolliVam = (product.GestMablag * (((nowyear - persianCalendar.GetYear((DateTime)product.AvlinGestDate)) * 12) + (nowmonth - (persianCalendar.GetMonth((DateTime)product.AvlinGestDate)))));
                    MibayestVarizMost = MibayestVarizMost - tedadpardakhtshode;
                    tedad = (int)MibayestVarizMost;
                    var MibayestVarizMost50 = 0;
                    var MibayestVarizMost100 = 0;

                    if (MibayestVarizMost < 0) { MibayestVarizMost = 0; }
                    MandeMostMablagh = (int)MibayestVarizMost * mablaghmost;
                    if (kheilivaghtpishmande == 1 || mostamarypaie.MostamaryMablagh_Mablagh == 500000)
                    {

                        DateTime now1 = persianCalendar.ToDateTime(nowyear, nowmonth, nowday, 0, 0, 0, 0);
                        DateTime n14021001 = persianCalendar.ToDateTime(1402, 10, 01, 0, 0, 0, 0);
                        DateTime n13970901 = persianCalendar.ToDateTime(1397, 09, 01, 0, 0, 0, 0);



                        if (kheilivaghtpishmande != 1)

                        {
                            n13970901 = (DateTime)PersianDateUtils.ToMilady(AkharinVosoliDate);
                        }
                        while (persianCalendar.AddMonths(n13970901, 1) < n14021001)
                        {
                            MibayestVarizMost50++;
                            n13970901 = persianCalendar.AddMonths(n13970901, 1);
                        }

                        while (n14021001 <= now1)
                        {
                            MibayestVarizMost100++;
                            n14021001 = persianCalendar.AddMonths(n14021001, 1);
                        }

                        if (MibayestVarizMost50 > 0)
                        {
                            MibayestVarizMost50++;
                        }
                        //if (MibayestVarizMost100 > 0)
                        //{
                        //    MibayestVarizMost100++;
                        //}
                        if (kheilivaghtpishmande != 1)
                        {
                            MandeMostMablagh = MibayestVarizMost50 * 500000 + MibayestVarizMost100 * 1000000;
                        }
                        else
                        {
                            MandeMostMablagh += MibayestVarizMost50 * 500000 + MibayestVarizMost100 * 1000000;

                        }
                    }

                    if (MibayestVarizMost >= 7 && ((mostamarypaie.MostamaryMablagh_DateStart < PersianDateUtils.ToMilady("1402/10/01") && mostamarypaie.MostamaryMablagh_Mablagh > 500000)) && kheilivaghtpishmande != 1)
                    {
                        MVCSandoogh.Models.T_MostamaryMablagh moma = new MVCSandoogh.Models.T_MostamaryMablagh();
                        try { moma.MostamaryMablagh_CurrentBeruzDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_CurrentBeruzDate, (int)tedadpardakhtshode); } catch { }
                        try { moma.MostamaryMablagh_DateStart = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode); } catch { }
                        var tempmablagh = user.G_M_Pays.Where(e => e.PayDate <= moma.MostamaryMablagh_DateStart || e.IsAfzayesh != true).Sum(k => k.MostamariMablag);

                        moma.MostamaryMablagh_IdRefOzvCode = mostamarypaie.MostamaryMablagh_IdRefOzvCode;
                        moma.MostamaryMablagh_Mablagh = 500000;
                        moma.MostamaryMablagh_VarizyTaDateStart = (int)tempmablagh;
                        db.T_MostamaryMablagh.Add(moma);
                        db.SaveChanges();
                        mostamarypaie = moma;
                        kheilivaghtpishmande = 0;
                        tedadpardakhtshode = 0;
                        AkharinVosoliDate = persianCalendar.AddMonths((DateTime)moma.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();
                        MandeMostMablagh = MibayestVarizMost * 500000;
                        kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * 500000);

                    }
                    //else
             //if (MibayestVarizMost >= 5 && ((mostamarypaie.MostamaryMablagh_DateStart >= PersianDateUtils.ToMilady("1402/10/01") && mostamarypaie.MostamaryMablagh_Mablagh > 1000000)) && kheilivaghtpishmande != 1)
             //       {
             //           MVCSandoogh.Models.T_MostamaryMablagh moma = new MVCSandoogh.Models.T_MostamaryMablagh();
             //           try { moma.MostamaryMablagh_CurrentBeruzDate = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_CurrentBeruzDate, (int)tedadpardakhtshode); } catch { }
             //           try { moma.MostamaryMablagh_DateStart = persianCalendar.AddMonths((DateTime)mostamarypaie.MostamaryMablagh_DateStart, (int)tedadpardakhtshode); } catch { }
             //           var tempmablagh = user.G_M_Pays.Where(e => e.PayDate <= moma.MostamaryMablagh_DateStart || e.IsAfzayesh != true).Sum(k => k.MostamariMablag);

             //           moma.MostamaryMablagh_IdRefOzvCode = mostamarypaie.MostamaryMablagh_IdRefOzvCode;
             //           moma.MostamaryMablagh_Mablagh = 1000000;
             //           moma.MostamaryMablagh_VarizyTaDateStart = (int)tempmablagh;
             //           db.T_MostamaryMablagh.Add(moma);
             //           db.SaveChanges();
             //           mostamarypaie = moma;
             //           kheilivaghtpishmande = 0;
             //           tedadpardakhtshode = 0;
             //           AkharinVosoliDate = persianCalendar.AddMonths((DateTime)moma.MostamaryMablagh_DateStart, (int)tedadpardakhtshode).ToPersianDate();
             //           MandeMostMablagh = MibayestVarizMost * 1000000;
             //           kasr = (int)((summost - mostamarypaie.MostamaryMablagh_VarizyTaDateStart)) - (tedadpardakhtshode * 1000000);



             //       }
             //pasha
                    if (kasr > 0)
                    {
                        if ((MandeMostMablagh - (int)kasr) > 0) 
                        { MandeMostMablagh = MandeMostMablagh - (int)kasr; }
                        else
                        { MandeMostMablagh = 0; }


                    }

                    ViewBag.AkharinVosoliDate = AkharinVosoliDate;
                    ViewBag.MandeMostMablagh = MandeMostMablagh;

                }
            }
            catch
            {

            }

            try
            {
                try
                {
                    if (user.Faal == false)
                    {
                        AkharinVosoliDate = "--";
                        MandeMostMablagh = 0;
                    }
                }
                catch
                {

                }
                  var list = (from e in db.T_MostamaryMablagh.Where(k=>k.MostamaryMablagh_IdRefOzvCode==id).ToList() select new { AkharinVosoliDate = AkharinVosoliDate,
                MandeMostMablagh = MandeMostMablagh<0?0: MandeMostMablagh,
                      MostamaryMablagh_VarizyTaDateStart = e.MostamaryMablagh_VarizyTaDateStart, MostamaryMablagh_CurrentBeruzDate = (e.MostamaryMablagh_CurrentBeruzDate != null ? PersianDateUtils.ToPersianDate((DateTime)e.MostamaryMablagh_CurrentBeruzDate) : ""), MostamaryMablagh_DateStart =(e.MostamaryMablagh_DateStart!=null? PersianDateUtils.ToPersianDate((DateTime) e.MostamaryMablagh_DateStart):""), e.MostamaryMablagh_Mablagh,
                      SumAfzayeshMostamary=e.T_OzvCode.Faal==true? e.T_OzvCode.SumAfzayeshMostamary : 0 });
               
                return Json(list, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
                [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult GeMostamaryMablagh(string sidx, string sord, int page, int rows)
        {
            SandooghModel db = new SandooghModel();
     
            try
            { 
           var  list = db.T_MostamaryMablagh.ToList();
       
            var pageIndex = page - 1;
            var pageSize = rows;
            var totalRecords = list.Count;
            var totalPages = (int)Math.Ceiling(totalRecords / (float)pageSize);

            var productsQuery = list.AsQueryable();
            var productsList = productsQuery.OrderBy(sidx + " " + sord)
                                           
                                            .ToList();
            var productsData = new JqGridData
            {
                Total = totalPages,
                Page = page,
                Records = totalRecords,
                Rows = (productsList.Select(product => new JqGridRowData
                {
                    Id = product.MostamaryMablagh_ID,
                    RowCells = new List<object>
                               {
                                     product.MostamaryMablagh_ID,
                                   product.T_OzvCode.FName,product.T_OzvCode.LName  ,product.MostamaryMablagh_Mablagh.ToString(),
                     product.MostamaryMablagh_CurrentBeruzDate!=null?((DateTime)product.MostamaryMablagh_CurrentBeruzDate).ToPersianDate():"", 
                     product.MostamaryMablagh_DateStart!=null?((DateTime)product.MostamaryMablagh_DateStart).ToPersianDate():""
                        ,product.MostamaryMablagh_IdRefOzvCode.ToString(), product.T_User.User_UserName

                                   
                                }
                })).ToList()
            };
            return Json(productsData, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        public ActionResult CitySelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.CityCodes.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.CityName,
                Value = x.id.ToString(CultureInfo.InvariantCulture)
            }).ToList();
            return PartialView("_SelectPartial", suppliers);
        }
        public ActionResult TaaholSelect()
        {
            SandooghModel db = new SandooghModel();
            var list = db.Taahols.ToList();
            var suppliers = list.Select(x => new SelectListItem
            {
                Text = x.Taahol_Name,
                Value = x.Taahol_Id.ToString(CultureInfo.InvariantCulture)
            }).ToList();
            return PartialView("_SelectPartial", suppliers);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public ActionResult DeleteMember(string Id)
        {
            int idd = int.Parse(Id);
            //todo: Delete product
            SandooghModel db = new SandooghModel();
            var product = db.T_OzvCode.FirstOrDefault(x => x.Id ==idd );
            if (product == null)
                return Json(false);
            if (Membership.GetUser(Id.ToString()) != null)
            {
                Membership.DeleteUser(Id.ToString());
              
            }
            List<string> parameters = new List<string>(new string[] { "User_UserName" });
            List<object> values = new List<object>(new object[] { Id });
            DataGatheration gath = new DataGatheration();
            gath.GetTableStoredProcedure("NewDeleteUser", parameters, values);

            var number = 0;
            try
            {
                number = (from e in db.AccSanad_B where e.Tafsili == Id select e).ToList().Count;
            }
            catch
            {

            }
            if (number == 0)
            {
                try
                {
                    string hh = idd.ToString();
                    /*1212*/
                    var t2 = db.Acc_Tafsili2.FirstOrDefault(x => x.Tafsili2_Code == hh);
                    db.Acc_Tafsili2.Remove(t2);
                    db.SaveChanges();
                }
                catch
                {

                }
                    try
                {
                    var t3 = db.ScanDB.Where(x => x.IdRef == idd).ToList();
                    foreach (var scan in t3)
                    {
                        db.ScanDB.Remove(scan);
                        try
                        {
                            System.IO.File.Delete(Server.MapPath(scan.ScanURL.Replace("../../..", "~")));
                        }
                        catch
                        {

                        }

                    }
                    db.SaveChanges();
                }
                catch
                {

                }
                try
                {
                    db.T_OzvCode.Remove(product);
                    db.SaveChanges();
                }
                catch
                {

                }
                return Json(true);
            }
            else
                return Json(false);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult AddMember(T_OzvCode postData)
        {
            SandooghModel db = new SandooghModel();
                int idddd = (from e in db.T_OzvCode select e.Id).Max();

                postData.Faal = true;
                postData.GUID = Guid.NewGuid();
                //todo: Add product to repository
                if (postData == null)
                    return Json(false);
                postData.OzvDate = DateTime.Now;
                postData.Faal = true;
                postData.CityCode = (from o in db.CityCodes
                                     where o.id == postData.CityCode.id
                                     select o).First();
                postData.CityCode1 = (from o in db.CityCodes
                                      where o.id == postData.CityCode1.id
                                      select o).First();
                postData.Taahol = (from o in db.Taahols
                                   where o.Taahol_Id == postData.Taahol.Taahol_Id
                                   select o).First();
                db.Entry(postData.CityCode).State = EntityState.Modified;
                db.Entry(postData.CityCode1).State = EntityState.Modified;
                db.Entry(postData.Taahol).State = EntityState.Modified;
                if (postData != null) postData.Id = idddd + 1;
                db.T_OzvCode.Add(postData);
                db.SaveChanges();

                Acc_Tafsili2 t2 = new Acc_Tafsili2();

                t2.Tafsili2_Tafsili1 = 2;
                t2.Tafsili2_Code = postData.Id.ToString();/*1212*/
            t2.Tafsili2_Comment = postData.FName + " " + postData.LName;
                db.Acc_Tafsili2.Add(t2);

                db.SaveChanges();

                string message = " مهندس ارجمند " + postData.FName + " " + postData.LName + "" + "\n" +
                    "حضور شما را در جمع اعضاي صندوق قرض الحسنه نظام مهندسي ساختمان استان آذربايجان غربي گرامي ميداريم."
                + "\n" + "شماره عضويت : " + postData.Id + "\n" +
                "تاريخ عضويت : " + DateTime.Now.ToPersianDate() + "\n" + "هيئت مديره صندوق قرض الحسنه";
                SendMsg(new string[] { postData.Mobile }, message);

                if (Membership.GetUser(postData.Id.ToString()) == null)
                {
                if (postData.MelliCode.Length < 8)postData.MelliCode = "123456789";
                    Membership.CreateUser(postData.Id.ToString(), postData.MelliCode);
                    List<string> parameters = new List<string>(new string[] {

            "User_UserName","User_Firstname","User_lastname",
            "User_Email","User_Mobile","User_OzvCdoe"});
                    List<object> values = new List<object>(new object[] {

           postData.Id,postData.FName+" "+postData.LName,"",
           postData.Id,postData.Mobile,postData.Id});
                    DataGatheration gath = new DataGatheration();
                    gath.GetTableStoredProcedure("NewInsertUser", parameters, values);
                    Roles.AddUserToRole(postData.Id.ToString(), "User");
                }
                return Json(true);
           
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult EditMember(T_OzvCode postData)
        {
            SandooghModel db = new SandooghModel();
               //todo: Add product to repository
            if (postData == null)
                return Json(false);
            var sumafzayesh = (from e in db.T_OzvCode where e.Id == postData.Id select e.SumAfzayeshMostamary).FirstOrDefault();
            postData.SumAfzayeshMostamary = sumafzayesh;
         
            postData.CityCode = (from o in db.CityCodes
                                 where o.id == postData.CityCode.id
                                 select o).First();
            postData.OzvCode_TavalodCity = postData.CityCode.id;
            postData.CityCode1 = (from o in db.CityCodes
                                  where o.id == postData.CityCode1.id
                                  select o).First();
            postData.OzvCode_ShCity = postData.CityCode1.id;
            postData.Taahol = (from o in db.Taahols
                               where o.Taahol_Id == postData.Taahol.Taahol_Id
                               select o).First();
            postData.ozvcode_Taahol = postData.Taahol.Taahol_Id;
            db.Entry(postData.CityCode).State = EntityState.Modified;
            db.Entry(postData.CityCode1).State = EntityState.Modified;
            db.Entry(postData.Taahol).State = EntityState.Modified;
            db.Entry(postData).State= EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            db.SaveChanges();

            SandooghModel bb = new SandooghModel();
            /*1212*/
            string hh = postData.Id.ToString();
            Acc_Tafsili2 t2 =bb.Acc_Tafsili2.Where(e=> e.Tafsili2_Code == hh).FirstOrDefault();
            t2.Tafsili2_Comment = postData.FName + " " + postData.LName;
            bb.Entry(t2).State = EntityState.Modified;
            // db.T_OzvCode.Add(postData);
            bb.SaveChanges();




            return Json(true);
        }
        
      


    }
}


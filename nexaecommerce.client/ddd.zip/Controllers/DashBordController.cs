﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSandoogh.Controllers
{
    public class DashBordController : Controller
    {
        //
        // GET: /Dashboard/
  
        [Authorize(Roles = "Admin")]
        public ActionResult AdminDashboard()
        {
            return View();
        }
        [Authorize(Roles = "Admin")]
        public ActionResult AccountingDashBoard()
        {
            return View();
        }
        public void setpardakhtyviewbags()
        {
            string shenaseghabz = "";
            SandooghModel db = new SandooghModel();
            try
            {
               
                var user = (from e in db.T_User where e.User_UserName.ToUpper() == User.Identity.Name.ToUpper() select e).FirstOrDefault();
                shenaseghabz = (from e in db.T_OzvCode
                                where e.Id == user.User_OzvCdoe
                                select e).FirstOrDefault().MelliCode;
            }
            catch
            {

            }
            string mellicode = shenaseghabz;
                string afzayesh = "";
                string mostamarry = "";
                string ghest = "";
                string temp = "00000000000000000" + shenaseghabz + "03";
                temp = temp.Substring(temp.Length - 15);
                afzayesh = setcontroli(temp);
                if (afzayesh != "")
                    ViewBag.afzayeshshenase = mellicode + "03" + afzayesh;
                else
                    ViewBag.afzayeshshenase = "";
                temp = "00000000000000000" + shenaseghabz + "01";
                temp = temp.Substring(temp.Length - 15);
                mostamarry = setcontroli(temp);

                if (mostamarry != "")
                    ViewBag.mostamarryshenase = mellicode + "01" + mostamarry;
                else
                    ViewBag.mostamarryshenase = "";
                temp = "00000000000000000" + shenaseghabz + "02";
                temp = temp.Substring(temp.Length - 15);
                ghest = setcontroli(temp);
                if (ghest != "")
                    ViewBag.ghestshenase = mellicode + "02" + ghest;
                else
                    ViewBag.ghestshenase = "";
           
        }
        public string setcontroli(string id)
        {
            int[] iValue = { 15, 14, 13, 12, 11, 10, 9, 1, 2, 3, 4, 5, 6, 7, 8 };
            string sID = id;
            int digitID = 0;
            string tempID;

            if (string.IsNullOrEmpty(sID) || sID.Length > 15)
            {
                return ""; // When The Entered Number Is Greater Than Normal Length ID (15 characters) OR That Is Empty This Section Fired Up!
            }

            sID = "00000000000000000" + sID;
            sID = sID.Substring(sID.Length - 15);

            tempID = sID;
            //     sID = sID.Substring(sID.Length - 17, 15);

            char[] arrID = sID.ToCharArray();
            for (int i = 0; i < iValue.Length; i++)
            {
                digitID += (iValue[i] * (arrID[i] - '0'));
            }

            digitID = int.Parse(("0" + (digitID % 99)).Substring(("0" + (digitID % 99)).Length - 2));


            if (digitID < 10)
                return "0" + digitID.ToString();
            else
                return digitID.ToString(); // The Entered Digit Number Is Correct


        }
        [Authorize(Roles = "User,sadmin ,Admin,Chairman")]   
      public ActionResult UserDashboard()
        {
            setpardakhtyviewbags();
            return View();
        }

    }
}

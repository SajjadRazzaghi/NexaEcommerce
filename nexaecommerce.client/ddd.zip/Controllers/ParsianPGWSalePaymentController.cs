﻿using PecPGW.Samples.WebApp.MVC.ParsianPGWSalePaymentServices;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.IO;
using PecPGW.Samples.Common;
using PecPGW.Samples.WebApp.MVC.Models;
using MVCSandoogh.Controllers;
using MVCSandoogh.Models;
using MVCSandoogh;

namespace PecPGW.Samples.WebApp.MVC.Controllers
{
	public class ParsianPGWSalePaymentController : Controller
	{
		private const string SaleLoginAccountSessionKey = "SaleLoginAccount";
		private const string ConfirmAfterPaymentSessionKey = "ConfirmAfterPayment";
		private const string ConfirmServiceUrlSessionKey = "ConfirmServiceUrl";
		private const string ReversalServiceUrlSessionKey = "ReversalServiceUrl";

		// GET: ParsianPGWSalePayment
		public ActionResult Index()
		{
			return View();
		}

		
		private string GetLoginAccount()
		{
			return Session[SaleLoginAccountSessionKey].ToString();
		}

		//این اکشن برای پرداخت در عملیات خرید استفاده می شود
		//به نمونه کد فراخوانی سرویس پرداخت قبض درگاه پرداخت اینترنتی پارسیان در کنترلر قبلی مراجعه شود
		[HttpPost]
		public ActionResult SalePayment(string mablagh,string additionalData,string Originator,string type="ghest")
		{
           
            long Amount = 0;
            try
            {
                Amount = long.Parse(mablagh.Replace(",",""));
            }
            catch
            {

            }
            if (Amount > 0)
            {
               
                long token = 0;
                short paymentStatus = Int16.MinValue;
                ClientPaymentResponseDataBase responseData = null;
                using (var service = new ParsianPGWSalePaymentServices.SaleService())
                {
                    //it is not recommended to bypass Server Certificate Validation, due to vaiolating security concerns.
                    System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback((o, xc, xch, sslP) => true);


                    //set Service Url from your application configuration
                    service.Url = ConfigHelper.ParsianPGWSaleServiceUrl;

                    //instantiate a new instance of the class containing request parameters
                    var saleRequest = new ParsianPGWSalePaymentServices.ClientSaleRequestData();

                    string loginAccount = ConfigHelper.LoginAccount;



                    Session[ConfirmAfterPaymentSessionKey] = true;
                    Session[ConfirmServiceUrlSessionKey] = ConfigHelper.ParsianPGWConfirmServiceUrl;
                    Session[ReversalServiceUrlSessionKey] = ConfigHelper.ReversalServiceUrl;

                    saleRequest.LoginAccount = loginAccount;

                    //save LoginAccount into Session, to use in Confirm or Reversal.
                    //Please don't do this in your application, this is only for this Sample!
                    Session[SaleLoginAccountSessionKey] = loginAccount;


                    //make sure you set the CallBackUrl property. because after user has completed Payment on IPG page, it will be redirected to the callback url you provided
                    //to get you back result of the user Payment on IPG.
                    if (type == "most"||type=="afz")
                    {
                        saleRequest.CallBackUrl = ConfigHelper.MostPaymentCallback;
                    }
                    else
                    {
                        saleRequest.CallBackUrl = ConfigHelper.SalePaymentCallback;
                    }


                    //Amount is not used. you should not assign a value to this property.
                    saleRequest.Amount = Amount;

                    //AdditionalData will be saved in Parsian PGW
                    saleRequest.AdditionalData = additionalData;

                    //Mobile Number, Telephone or any property of your user to indicate he/she is ordered this payment request.
                    saleRequest.Originator = Originator;

                    SandooghModel db = new SandooghModel();
                    T_orders order = new T_orders();
                    order.finished = false;
                    order.userid = (from e in db.T_User
                                    where e.User_UserName.ToUpper() == User.Identity.Name.ToUpper()
                                    select e).FirstOrDefault().User_ID;
					if (type == "afz")
						order.isafzayesh = true;
					else
                    if (type == "most")
                    {
                        order.isghest = false;
                    }
                    else
                    {
                        order.isghest = true;
                    }
                    db.T_orders.Add(order);
                    db.SaveChanges();
                    //Order Id MUST be UNIQUE at all times. if a duplicated Order Id is received from your request, you will get Status= -112
                    // DateTime.Now.Ticks does not ensures uniqueness of OrderId. consider generate OrderId by a Sequence or Identity field in your database.
                    saleRequest.OrderId = order.Orderid;

                    //it is recommended to save Request before calling service in your application's Data Store.
                    //e.g. DataStore.DoSaveRequest(loginAccount, OrderId, amount, addData, originator)


                    //call appropriate api based on the documentation provided to you.
                    responseData = service.SalePaymentRequest(saleRequest);

                    //update response of api call for the request you've saved before.
                    //e.g. DataStore.UpdatePaymentRequestResponse(orderId, pgwtoken, pgwStatus).

                    paymentStatus = responseData.Status;

                    //check Status property of the response object to see if the operation was successful.
                    if (responseData.Status == Constants.ParsianPaymentGateway.Successful)
                    {
                        //if everything is OK (LoginAccount and your IP address is valid in Parsian PGW), save the token in a data store
                        // to use it for redirectgion of your web site's user to the Parsian IPG (Internet Payment Gateway) page to complete payment.
                        token = responseData.Token;

                        //you must save the token in a data store for subsequent support and api calls.
                        Session["Token"] = token;
                    }
                    else
                    {
                        ViewBag.Error = responseData.Message;
                    }
                }

                //if pgwStatus == 0 and pgwToken > 0, redirect user to the Parsian IPG to continue payment flow.
                if (paymentStatus == Constants.ParsianPaymentGateway.Successful && token > 0L)
                {
                    //first, save token to your database to be able to track payment process with your business.
                    //after successfully retrieved a token from Parsian PGW, redirect user to Parsian IPG to complete the payment operation.

                    var redirectUrl = string.Format(ConfigHelper.ParsianIPGPageUrl, responseData.Token);
                   

                    return Json(new
                    {
                        status = 0,
                        location = redirectUrl
                    });
                }
                else
                {
                    ViewBag.Error = "Error connecting to pay service";
                    var mdl = new PaymentRequestResponseModel()
                    {
                        Message = responseData?.Message,
                        Status = responseData?.Status,
                        Token = responseData?.Token
                    };
                    return View("_PaymentRequestResults", mdl);
                }
              
            }
            else
            {
                return View();
            }
		}

		/// <summary>
		/// After user in Parsian IPG has completed payment process, it will be redirected to your CallBackUrl specified in initial Payment Request method call.
		/// You MUST insure of user's payment process status. if you havn't received a callback for payment, you should not deliver requested business product or service to your user.
		/// </summary>
		/// <param name="model">This is the model that Parsian IPg will fill for you after user has completed Payment process on Parsian IPG.
		/// to inform you of results of payment.</param>
		/// <returns></returns>
		/// پس از فراخوانی این اکشن توسط درگاه پرداخت اینترنتی پارسیان، 
		/// //متوجه وضعیت انجام فرآیند پرداخت توسط کاربر در صفحه درگاه پرداخت اینترنتی پارسیان خواهید شد
		/// و در صورت موفق بودن انجام پرداخت، باید تایید پرداخت را به درگاه پرداخت اینترنتی پارسیان اعلام نمایید
		/// //تا تراکنش موفق تلقی شود
		/// درصورتی که سرویس تایید پرداخت فراخوانی نشود، پولی که کاربر در صفحه درگاه پرداخت از کارت خود پرداخت نموده، 
		/// به حساب او برگشت داده می شود و خدماتی از سوی شما به او نباید ارائه شود
		/// بنابراین حتماً به خاطر داشته باشد که در کال بک، باید در صورتی که کد وضعیت تراکنش پرداخت موفق اعلام شد
		/// سرویس تایید تراکنش را با فراهم نمودن پارامتر مطلوب
		/// فراخوانی نمایید
		/// و سپس در صورت موفق بودن تایید تراکنش، نسبت به  ارائه خدمات به کاربر وب سایت خود اقدام نمایید
		/// بنابراین اگر پرداخت در صفحه پرداخت توسطک اربر موفق باشد
		/// اما تایید پرداخت را ارسال ننمایید
		/// خدماتی به کاربر نیز نباید بدهید
		/// اما درصورتی که تایید پرداخت را انجام دادید
		/// و تایید پرداخت موفق بود
		/// حتما باید خدمات را به کاربر ارائه دهید
		[HttpPost]
		public ActionResult PaymentCallback(PaymentCallbackModel model)
		{
			if (model != null)
			{
			
				//save callback info to your database and relate those info to the user's requested service or product.
				//if needed, deliver product or service to the user after ensuring payment.
				//in the case of Bill Payment, no delivery is commonly required.
				//but if a Sale payment is performed, may be a product or service delivery will be needed.

				//if transaction by user is successful, call Confirm service from Parsian PGW to complete the transaction
				//and indicate that you will deliver service or product to your end user.
				//it is better to save callback results into a database.

			
				if (model.status == Constants.ParsianPaymentGateway.Successful && (model.Token ?? 0L) > 0L)
				{
					var shouldConfirmAfterPay = (bool)Session[ConfirmAfterPaymentSessionKey];
					if (shouldConfirmAfterPay)
					{
						//ایجاد یک نمونه از سرویس تایید پرداخت
						using (var confirmSvc = new ParsianPGWConfirmPaymentServices.ConfirmService())
						{
							confirmSvc.Url = (string)Session[ConfirmServiceUrlSessionKey];

							//ایجاد یک نمونه از نوع پارامتر سرویس تایید پرداخت
							var confirmRequestData = new ParsianPGWConfirmPaymentServices.ClientConfirmRequestData();

							//شناسه پذیرندگی باید در فراخوانی سرویس تایید تراکنش پرداخت ارائه شود
							confirmRequestData.LoginAccount = GetLoginAccount();

							//توکن باید ارائه شود
							confirmRequestData.Token = model.Token ?? -1;

							//فراخوانی سرویس و دریافت نتیجه فراخوانی
							var confirmResponse = confirmSvc.ConfirmPayment(confirmRequestData);
						
							//کنترل کد وضعیت نتیجه فراخوانی
							//درصورتی که موفق باشد، باید خدمات یا کالا به کاربر پرداخت کننده ارائه شود
							if (confirmResponse.Status == Constants.ParsianPaymentGateway.Successful)
							{
                                //deliver service or product to end user accourding to your business rules.
                                //it is better to save confirm response into a database.
                                UserController uc = new UserController();
                               uc.UserCurrentVamPardakht(model);

                            }
						}
					}

					//بررسی اینکه آیا کاربر باید خدمات یا کالای مورد نظر خود را در قبال وجهی که پرداخت کرده است، دریافت کند
					//یا دریافت نکند.
					//در صورتی که مثلاً کاربر سفارش خود را پس از پرداخت وجه، لغو نماید، برای برگشت وجه پرداخت شده اش به حسابش
					//باید از سرویس برگشت وجه استفاده شود
					//حداکثر زمان مجاز برای فراخوانی سرویس برگشت وجه به حساب مشتری
					//که شروع آن پس از دریافت توکن از سرویس درخواست پرداخت می باشد
					//یک ساعت است

					//if(no service or product will be delivered to the customer)
					//call ReversalService.ReversalRequest() method to indicate return of money to customer.
					//ReversePayment(model.Token ?? 0L);
				}

				return View("~/User/UserCurrentVamPardakht");
			}
			else
			{
				return View("~/User/UserCurrentVamPardakht");
			}
		}
        /*
		//در صورتی که لازم باشد پرداختی که کاربر در صفحه درگاه پرداخت اینترنتی پارسیان انجام داده است
		//به شکلی لغو شود، باید از وب سرویس برگشت وجه استفاده شود
		//این وب سرویس با پاس نمودن توکن درخواستی که پرداخت آن انجام شده است قابل فراخوانی است
		//لطفاً دقت فرمایید که تنها در صورتی باید این سرویس فراخوانی شود که 
		//به عنوان مثال، کاربر درخواست لغو دریافت کالا یا خدمات از وب سایت شما را پس از پرداخت موفق داده باشد
		//فقط بیست دقیقه پس از درخواست اولیه پرداخت که توسط اپلیکیشن داده شده است، فرصت درخواست برگشت وجه پرداخت شده وجود دارد
		[HttpPost]
		public ActionResult ReversePayment(ReversalModel model)
		{
			try
			{
				//ایجاد یک نمونه از سرویس برگشت وجه پرداخت شده
				using (var reversalSvc = new ParsianPGWReversalServices.ReversalService())
				{
					reversalSvc.Url = (string)Session[ReversalServiceUrlSessionKey];

					//ایجاد یک نمونه از نوع پارامتر ورودی متد برگشت وجه
					var requestData = new ParsianPGWReversalServices.ClientReversalRequestData()
					{
						LoginAccount = GetLoginAccount(),
						Token = model.Token
					};

					//فراخوانی متد برگشت وجه از نمونه وب سرویس برگشت وجه
					var response = reversalSvc.ReversalRequest(requestData);

					//کنترل کد وضعیت عملیات درخواست برگشت وجه
					//درصورت موفق بودن، می توانید از ارائه کالا و یا خدمات درخواستی کاربر به او انصراف دهید
					if (response.Status == Constants.ParsianPaymentGateway.Successful)
					{
						//reversal was successful
					}

					var viewModel = new ReversalResponseViewModel()
					{
						Status = response.Status,
						Message = response.Status == 0 ? "Successful" : "Failed!!!"
					};

					return PartialView("_ReverseResponse", viewModel);
				}
			}
			catch (Exception ex)
			{
				logger.Error(new { Method = "Reversal", Exception = ex });
				return PartialView("_ReverseResponse", new ReversalResponseViewModel()
				{
					Message = "Unsuccessful" + Environment.NewLine + ex.ToString()
				});
			}
		}*/
	}
}
﻿<%@ Application Codebehind="Global.asax.cs" Inherits="MVCSandoogh.MvcApplication" Language="C#" %>

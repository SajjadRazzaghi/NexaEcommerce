namespace MVCSandoogh
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_Look
    {
        [Key]
        public long Look_ID { get; set; }

        [StringLength(100)]
        public string Look_TargetColumn { get; set; }

        [StringLength(100)]
        public string Look_DetailTable { get; set; }

        [StringLength(100)]
        public string Look_ValueCol { get; set; }

        [StringLength(100)]
        public string Look_TextCol { get; set; }

        [Column(TypeName = "ntext")]
        public string Look_ValueCaption { get; set; }

        [Column(TypeName = "ntext")]
        public string Look_TextCaption { get; set; }

        [Column(TypeName = "ntext")]
        public string Look_LookFormSP { get; set; }

        [StringLength(100)]
        public string Look_LookParamsAndParamTypes { get; set; }

        [StringLength(50)]
        public string Look_Type { get; set; }

        [Column(TypeName = "ntext")]
        public string Look_String { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using MVCSandoogh.Models;

namespace MVCSandoogh.Helpers
{
  

        public class KhoshHesabiResult
        {
            public bool IsGoodPayer { get; set; }

            public int DelayedInstallmentCount { get; set; }

            public int DelayedPensionCount { get; set; }

            public decimal FeePercent { get; set; }
        }

        public static class KhoshHesabiCalculator
        {
            private class InstallmentItem
            {
                public DateTime DueDate { get; set; }
                public decimal Amount { get; set; }
                public decimal PaidAmount { get; set; }
                public DateTime? PaidDate { get; set; }
            }

            private class PensionMonthItem
            {
                public DateTime DueDate { get; set; }
                public decimal ExpectedAmount { get; set; }
                public decimal PaidAmount { get; set; }
                public DateTime? PaidDate { get; set; }
            }

            public static KhoshHesabiResult Calculate(
                SandooghModel db,
                int memberId,
                DateTime? asOfDate = null)
            {
                DateTime today = (asOfDate ?? DateTime.Today).Date;

                var setting = db.T_VamKhoshHesabiSettings
                    .FirstOrDefault(x => x.Id == 1);

                if (setting == null || !setting.IsConfigured)
                {
                    throw new InvalidOperationException(
                        "تنظیمات خوش‌حسابی توسط مدیر سیستم تکمیل نشده است."
                    );
                }

                var member = db.T_OzvCode
                    .FirstOrDefault(x => x.Id == memberId);

                if (member == null)
                {
                    throw new InvalidOperationException(
                        "عضو موردنظر پیدا نشد."
                    );
                }

                // آخرین وام تسویه‌شده
                var lastVam = db.Vams
                    .Where(x =>
                        x.IdRefOzv == memberId &&
                        x.EtmamVam == true)
                    .OrderByDescending(x => x.VamDate)
                    .ThenByDescending(x => x.Vam_Id)
                    .FirstOrDefault();

                // تعداد اقساط دارای تأخیر
                int delayedInstallments =
                    CountDelayedInstallments(db, lastVam, today);

                // شروع محاسبه مستمری:
                // عضو جدید: تاریخ عضویت
                // عضو دارای سابقه وام: تاریخ اعطای آخرین وام
                DateTime pensionStartDate =
                    member.OzvDate;

                if (lastVam != null)
                {
                    pensionStartDate =
                        lastVam.VamDate ??
                        lastVam.AvlinGestDate ??
                        member.OzvDate;
                }

                int delayedPensions =
                    CountDelayedPensionMonths(
                        db,
                        memberId,
                        pensionStartDate,
                        today
                    );

                bool isGood =
                    delayedInstallments <=
                        setting.MaxDelayedInstallments
                    &&
                    delayedPensions <=
                        setting.MaxDelayedPensions;

                return new KhoshHesabiResult
                {
                    IsGoodPayer = isGood,

                    DelayedInstallmentCount =
                        delayedInstallments,

                    DelayedPensionCount =
                        delayedPensions,

                    FeePercent = isGood
                        ? setting.GoodPayerFeePercent
                        : setting.NormalPayerFeePercent
                };
            }

            private static int CountDelayedInstallments(
                SandooghModel db,
                Vam lastVam,
                DateTime today)
            {
                if (lastVam == null)
                    return 0;

                if (!lastVam.AvlinGestDate.HasValue ||
                    !lastVam.TedadAgsat.HasValue ||
                    !lastVam.GestMablag.HasValue ||
                    lastVam.TedadAgsat.Value <= 0 ||
                    lastVam.GestMablag.Value <= 0)
                {
                    return 0;
                }

                int installmentCount =
                    lastVam.TedadAgsat.Value;

                decimal installmentAmount =
                    Convert.ToDecimal(lastVam.GestMablag.Value);

                PersianCalendar pc =
                    new PersianCalendar();

                var installments =
                    new List<InstallmentItem>();

                // ساخت موعد تمام اقساط
                for (int i = 0; i < installmentCount; i++)
                {
                    DateTime dueDate =
                        pc.AddMonths(
                            lastVam.AvlinGestDate.Value,
                            i
                        ).Date;

                    installments.Add(new InstallmentItem
                    {
                        DueDate = dueDate,
                        Amount = installmentAmount,
                        PaidAmount = 0,
                        PaidDate = null
                    });
                }

                // دریافت پرداخت‌های همان وام
                var payments = db.G_M_Pays
                    .Where(p =>
                        p.IdRefVam == lastVam.Vam_Id &&
                        p.TotGestMablag > 0 &&
                        p.PayDate.HasValue &&
                        p.PayDate <= today)
                    .OrderBy(p => p.PayDate)
                    .ThenBy(p => p.Id)
                    .ToList();

                // تخصیص هر پرداخت به قدیمی‌ترین قسط تسویه‌نشده
                foreach (var payment in payments)
                {
                    decimal remaining =
                        Convert.ToDecimal(payment.TotGestMablag.Value);

                    if (remaining <= 0)
                        continue;

                    foreach (var installment in installments)
                    {
                        if (remaining <= 0)
                            break;

                        decimal need =
                            installment.Amount -
                            installment.PaidAmount;

                        if (need <= 0)
                            continue;

                        decimal amountToPay =
                            Math.Min(remaining, need);

                        installment.PaidAmount += amountToPay;
                        remaining -= amountToPay;

                        // تاریخ تسویه کامل قسط
                        if (installment.PaidAmount >=
                            installment.Amount)
                        {
                            installment.PaidDate =
                                payment.PayDate.Value.Date;
                        }
                    }
                }

                // حتی یک روز تأخیر = یک قسط تأخیردار
                return installments.Count(x =>
                    x.DueDate < today &&
                    (
                        x.PaidAmount < x.Amount ||
                        !x.PaidDate.HasValue ||
                        x.PaidDate.Value.Date > x.DueDate
                    )
                );
            }

            private static int CountDelayedPensionMonths(
                SandooghModel db,
                int memberId,
                DateTime startDate,
                DateTime today)
            {
                PersianCalendar pc =
                    new PersianCalendar();

                // شروع محاسبه از ماه بعد از تاریخ عضویت
                // یا ماه بعد از اعطای آخرین وام
                DateTime firstMonth =
                    GetNextPersianMonthStart(startDate);

                var baseChanges = db.T_MostamaryMablagh
                    .Where(x =>
                        x.MostamaryMablagh_IdRefOzvCode == memberId &&
                        x.MostamaryMablagh_DateStart.HasValue)
                    .OrderBy(x => x.MostamaryMablagh_DateStart)
                    .ToList();

                var months =
                    new List<PensionMonthItem>();

                DateTime currentMonth = firstMonth;

                // موعد مستمری، ابتدای هر ماه شمسی است.
                // از روز دوم ماه، اگر پرداخت کامل نشده باشد، تأخیر محسوب می‌شود.
                while (currentMonth < today)
                {
                    var baseForMonth = baseChanges
                        .Where(x =>
                            x.MostamaryMablagh_DateStart.Value
                            <= currentMonth)
                        .OrderByDescending(x =>
                            x.MostamaryMablagh_DateStart)
                        .FirstOrDefault();

                    decimal expectedAmount = 500000m;

                    if (baseForMonth != null &&
                        baseForMonth.MostamaryMablagh_Mablagh.HasValue)
                    {
                        expectedAmount =
                            Convert.ToDecimal(
                                baseForMonth.MostamaryMablagh_Mablagh.Value
                            );
                    }

                    if (expectedAmount > 0)
                    {
                        months.Add(new PensionMonthItem
                        {
                            DueDate = currentMonth,
                            ExpectedAmount = expectedAmount,
                            PaidAmount = 0,
                            PaidDate = null
                        });
                    }

                    currentMonth =
                        GetNextPersianMonthStart(currentMonth);
                }

                if (months.Count == 0)
                    return 0;

                // پرداخت‌های مستمری بعد از تاریخ شروع بازه
                // افزایش سرمایه مستثنی است.
                var payments = db.G_M_Pays
                    .Where(p =>
                        p.IdRefOzv == memberId &&
                        p.MostamariMablag > 0 &&
                        p.IsAfzayesh != true &&
                        p.PayDate.HasValue &&
                        p.PayDate >= startDate &&
                        p.PayDate <= today)
                    .OrderBy(p => p.PayDate)
                    .ThenBy(p => p.Id)
                    .ToList();

                // پرداخت‌های یکجا و چندماهه به قدیمی‌ترین ماه‌های
                // تسویه‌نشده تخصیص پیدا می‌کنند.
                foreach (var payment in payments)
                {
                    decimal remaining =
                        Convert.ToDecimal(payment.MostamariMablag.Value);

                    if (remaining <= 0)
                        continue;

                    foreach (var month in months)
                    {
                        if (remaining <= 0)
                            break;

                        decimal need =
                            month.ExpectedAmount -
                            month.PaidAmount;

                        if (need <= 0)
                            continue;

                        decimal amountToPay =
                            Math.Min(remaining, need);

                        month.PaidAmount += amountToPay;
                        remaining -= amountToPay;

                        if (month.PaidAmount >=
                            month.ExpectedAmount)
                        {
                            month.PaidDate =
                                payment.PayDate.Value.Date;
                        }
                    }
                }

                // هر ماه فقط یک بار شمرده می‌شود.
                return months.Count(x =>
                    x.DueDate < today &&
                    (
                        x.PaidAmount < x.ExpectedAmount ||
                        !x.PaidDate.HasValue ||
                        x.PaidDate.Value.Date > x.DueDate
                    )
                );
            }

            private static DateTime GetNextPersianMonthStart(
                DateTime date)
            {
                PersianCalendar pc =
                    new PersianCalendar();

                int year = pc.GetYear(date);
                int month = pc.GetMonth(date) + 1;

                if (month > 12)
                {
                    month = 1;
                    year++;
                }

                return pc.ToDateTime(
                    year,
                    month,
                    1,
                    0,
                    0,
                    0,
                    0
                );
            }
        }
    }
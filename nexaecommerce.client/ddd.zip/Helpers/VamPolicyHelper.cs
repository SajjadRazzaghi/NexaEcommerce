﻿using System;
using System.Linq;
using MVCSandoogh.Models;

namespace MVCSandoogh
{
    public static class VamPolicyHelper
    {
        public static decimal GetMinimumPension(
            SandooghModel db,
            DateTime targetDate)
        {
            var setting = db.T_MinMostamaries
                .Where(x => x.EffectiveFrom <= targetDate.Date)
                .OrderByDescending(x => x.EffectiveFrom)
                .FirstOrDefault();

            if (setting == null)
            {
                throw new InvalidOperationException(
                    "حداقل مستمری برای تاریخ موردنظر تعریف نشده است."
                );
            }

            return setting.MinimumAmount;
        }

        public static int CalculateQueueDelayMonths(
            int delayedPensionMonths,
            int delayedInstallmentMonths,
            T_VamQueueSetting setting)
        {
            if (setting == null || !setting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات تأخیر نوبت هنوز تکمیل نشده است."
                );
            }

            if (delayedPensionMonths < 0 ||
                delayedInstallmentMonths < 0)
            {
                throw new ArgumentException(
                    "تعداد ماه‌های تأخیر نمی‌تواند منفی باشد."
                );
            }

            int pensionDelay =
                (delayedPensionMonths /
                 setting.PensionDelayUnitMonths) *
                setting.PensionQueueIncreaseMonths;

            int installmentDelay =
                (delayedInstallmentMonths /
                 setting.InstallmentDelayUnitMonths) *
                setting.InstallmentQueueIncreaseMonths;

            return pensionDelay + installmentDelay;
        }
    }
}
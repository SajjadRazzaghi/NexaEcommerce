﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using MVCSandoogh.Models;

namespace MVCSandoogh
{
    public class PensionArrearsMonthInfo
    {
        public DateTime MonthStart { get; set; }

        public DateTime DueDate { get; set; }

        public decimal ExpectedAmount { get; set; }

        public decimal PaidAmount { get; set; }

        public DateTime? PaidDate { get; set; }

        public bool IsSettled { get; set; }

        public bool IsDelayed { get; set; }
    }

    public class PensionArrearsSummary
    {
        public List<PensionArrearsMonthInfo> Months { get; set; }
            = new List<PensionArrearsMonthInfo>();

        // طولانی‌ترین بازه متوالی تأخیر
        public int DelayedMonths { get; set; }

        // مجموع ماه‌های دارای تأخیر
        public int TotalDelayedMonths { get; set; }

        // تعداد ماه‌هایی که هنوز بدهی دارند
        public int OutstandingMonths { get; set; }

        // مبلغ باقی‌مانده معوقات
        public decimal OutstandingAmount { get; set; }

        // امتیاز منفی تأخیر مستمری
        public int NegativeScore { get; set; }
    }

    public static class VamPolicyHelper
    {
        // ---------------------------------------------------------
        // حداقل مستمری پیش‌فرض بر اساس تاریخ
        // ---------------------------------------------------------

        public static decimal GetDefaultMinimumPension(
            DateTime targetDate)
        {
            PersianCalendar pc = new PersianCalendar();

            DateTime dey1402 = pc.ToDateTime(
                1402, 10, 1, 0, 0, 0, 0);

            return targetDate.Date >= dey1402.Date
                ? 1000000m
                : 500000m;
        }

        // ---------------------------------------------------------
        // خواندن حداقل مستمری با اولویت تنظیمات مدیر
        // ---------------------------------------------------------

        public static decimal GetMinimumPension(
            SandooghModel db,
            DateTime targetDate)
        {
            if (db == null)
                throw new ArgumentNullException("db");

            var setting = db.MinimumPensionSettings
                .Where(x =>
                    x.EffectiveFrom <= targetDate.Date &&
                    (!x.EffectiveTo.HasValue ||
                     x.EffectiveTo.Value >= targetDate.Date))
                .OrderByDescending(x => x.EffectiveFrom)
                .FirstOrDefault();

            if (setting != null &&
                setting.MinimumAmount > 0m)
            {
                return setting.MinimumAmount;
            }

            return GetDefaultMinimumPension(targetDate);
        }

        // ---------------------------------------------------------
        // محاسبه معوقات واقعی مستمری
        // ---------------------------------------------------------

        public static PensionArrearsSummary CalculatePensionArrears(
            SandooghModel db,
            int memberId,
            DateTime startDate,
            DateTime asOfDate)
        {
            if (db == null)
                throw new ArgumentNullException("db");

            var summary = new PensionArrearsSummary();

            var memberExists = db.T_OzvCode
                .Any(x => x.Id == memberId);

            if (!memberExists)
                throw new InvalidOperationException(
                    "عضو موردنظر یافت نشد.");

            startDate = startDate.Date;
            asOfDate = asOfDate.Date;

            if (startDate > asOfDate)
                return summary;

            PersianCalendar pc = new PersianCalendar();

            // -----------------------------------------------------
            // تعیین اولین ماه قابل محاسبه
            // اگر تاریخ شروع وسط ماه باشد، از ماه بعد محاسبه می‌کنیم.
            // -----------------------------------------------------

            DateTime firstMonthStart =
                GetPersianMonthStart(startDate, pc);

            if (firstMonthStart.Date != startDate.Date)
            {
                firstMonthStart =
                    GetNextPersianMonthStart(firstMonthStart, pc);
            }

            DateTime currentMonthStart =
                GetPersianMonthStart(asOfDate, pc);

            // ماه جاری هنوز معوق محسوب نمی‌شود.
            if (firstMonthStart >= currentMonthStart)
                return summary;

            // -----------------------------------------------------
            // دریافت تغییرات مبلغ مستمری پایه عضو
            // -----------------------------------------------------

            var baseChanges = db.T_MostamaryMablagh
                .Where(x =>
                    x.MostamaryMablagh_IdRefOzvCode == memberId &&
                    x.MostamaryMablagh_DateStart.HasValue)
                .OrderBy(x => x.MostamaryMablagh_DateStart)
                .ToList();

            // -----------------------------------------------------
            // دریافت تنظیمات حداقل مستمری
            // -----------------------------------------------------

            var minimumSettings = db.MinimumPensionSettings
                .Where(x => x.EffectiveFrom <= asOfDate)
                .OrderByDescending(x => x.EffectiveFrom)
                .ToList();

            // -----------------------------------------------------
            // ساخت تعهدات ماهانه
            // -----------------------------------------------------

            DateTime monthStart = firstMonthStart;

            while (monthStart < currentMonthStart)
            {
                DateTime nextMonthStart =
                    GetNextPersianMonthStart(monthStart, pc);

                // موعد پرداخت مستمری: پایان ماه شمسی
                DateTime dueDate =
                    nextMonthStart.AddDays(-1).Date;

                // حداقل مبلغ بر اساس تاریخ همان ماه
                var minimumSetting = minimumSettings
                    .Where(x =>
                        x.EffectiveFrom.Date <= monthStart.Date &&
                        (!x.EffectiveTo.HasValue ||
                         x.EffectiveTo.Value.Date >= monthStart.Date))
                    .OrderByDescending(x => x.EffectiveFrom)
                    .FirstOrDefault();

                decimal minimumAmount =
                    minimumSetting != null &&
                    minimumSetting.MinimumAmount > 0m
                        ? minimumSetting.MinimumAmount
                        : GetDefaultMinimumPension(monthStart);

                // مبلغ واقعی مستمری پایه عضو در همان ماه
                var baseForMonth = baseChanges
                    .Where(x =>
                        x.MostamaryMablagh_DateStart.Value.Date
                        <= monthStart.Date)
                    .OrderByDescending(x =>
                        x.MostamaryMablagh_DateStart)
                    .FirstOrDefault();

                decimal expectedAmount = minimumAmount;

                if (baseForMonth != null &&
                    baseForMonth.MostamaryMablagh_Mablagh.HasValue)
                {
                    expectedAmount = Math.Max(
                        minimumAmount,
                        Convert.ToDecimal(
                            baseForMonth.MostamaryMablagh_Mablagh.Value
                        )
                    );
                }

                if (expectedAmount > 0m)
                {
                    summary.Months.Add(
                        new PensionArrearsMonthInfo
                        {
                            MonthStart = monthStart,
                            DueDate = dueDate,
                            ExpectedAmount = expectedAmount,
                            PaidAmount = 0m,
                            PaidDate = null,
                            IsSettled = false,
                            IsDelayed = false
                        });
                }

                monthStart = nextMonthStart;
            }

            if (summary.Months.Count == 0)
                return summary;

            // -----------------------------------------------------
            // دریافت پرداخت‌های واقعی مستمری
            // پرداخت افزایش سرمایه مستثنی است.
            // -----------------------------------------------------

            DateTime endOfDay =
                asOfDate.AddDays(1).AddTicks(-1);

            var payments = db.G_M_Pays
                .Where(x =>
                    x.IdRefOzv == memberId &&
                    x.MostamariMablag > 0 &&
                    (x.IsAfzayesh == null || x.IsAfzayesh != true) &&
                    x.PayDate.HasValue &&
                    x.PayDate >= firstMonthStart &&
                    x.PayDate <= endOfDay)
                .OrderBy(x => x.PayDate)
                .ThenBy(x => x.Id)
                .ToList();

            // -----------------------------------------------------
            // تخصیص پرداخت‌ها به قدیمی‌ترین ماه معوق
            // -----------------------------------------------------

            foreach (var payment in payments)
            {
                decimal remaining =
                    Convert.ToDecimal(
                        payment.MostamariMablag ?? 0);

                if (remaining <= 0m)
                    continue;

                foreach (var month in summary.Months)
                {
                    if (remaining <= 0m)
                        break;

                    if (month.IsSettled)
                        continue;

                    decimal need =
                        month.ExpectedAmount - month.PaidAmount;

                    if (need <= 0m)
                    {
                        month.IsSettled = true;
                        month.PaidAmount = month.ExpectedAmount;
                        continue;
                    }

                    decimal applied =
                        Math.Min(remaining, need);

                    month.PaidAmount += applied;
                    remaining -= applied;

                    // بررسی تسویه با تلورانس مستمری
                    // سقف ۲۰۰ هزار ریال یا ۲۰ درصد
                    decimal shortfall =
                        month.ExpectedAmount - month.PaidAmount;

                    decimal tolerance = Math.Min(
                        200000m,
                        month.ExpectedAmount * 0.2m
                    );

                    bool settled =
                        month.PaidAmount >= month.ExpectedAmount ||
                        (shortfall > 0m &&
                         shortfall <= tolerance);

                    if (settled)
                    {
                        month.IsSettled = true;
                        month.PaidAmount = month.ExpectedAmount;

                        // تاریخ تسویه همان پرداخت تکمیل‌کننده است.
                        month.PaidDate =
                            payment.PayDate.Value.Date;
                    }
                }
            }

            // -----------------------------------------------------
            // محاسبه تأخیر، بدهی باقی‌مانده و امتیاز منفی
            // -----------------------------------------------------

            int currentDelayStreak = 0;

            foreach (var month in summary.Months)
            {
                bool isDelayed;

                if (month.IsSettled && month.PaidDate.HasValue)
                {
                    isDelayed =
                        month.PaidDate.Value.Date >
                        month.DueDate.Date;
                }
                else
                {
                    isDelayed =
                        month.DueDate.Date < asOfDate.Date;
                }

                month.IsDelayed = isDelayed;

                if (!month.IsSettled)
                {
                    summary.OutstandingMonths++;

                    summary.OutstandingAmount += Math.Max(
                        0m,
                        month.ExpectedAmount - month.PaidAmount
                    );
                }

                if (isDelayed)
                {
                    summary.TotalDelayedMonths++;

                    currentDelayStreak++;

                    if (currentDelayStreak > summary.DelayedMonths)
                    {
                        summary.DelayedMonths =
                            currentDelayStreak;
                    }
                }
                else
                {
                    if (currentDelayStreak > 0)
                    {
                        summary.NegativeScore +=
                            CalculatePensionDelayScore(
                                currentDelayStreak
                            );
                    }

                    currentDelayStreak = 0;
                }
            }

            // آخرین بازه تأخیر
            if (currentDelayStreak > 0)
            {
                summary.NegativeScore +=
                    CalculatePensionDelayScore(
                        currentDelayStreak
                    );
            }

            return summary;
        }

        // ---------------------------------------------------------
        // امتیاز منفی تأخیر مستمری
        // چهار ماه اول بدون امتیاز
        // ---------------------------------------------------------

        private static int CalculatePensionDelayScore(
            int delayedMonths)
        {
            if (delayedMonths <= 4)
                return 0;

            return ((delayedMonths - 4) / 4) + 1;
        }

        private static bool IsPensionMonthSettled(
            decimal expected,
            decimal paid)
        {
            if (expected <= 0m)
                return true;

            decimal shortfall = expected - paid;

            decimal tolerance = Math.Min(
                200000m,
                expected * 0.2m
            );

            return paid >= expected ||
                   (shortfall > 0m &&
                    shortfall <= tolerance);
        }

        private static DateTime GetPersianMonthStart(
            DateTime date,
            PersianCalendar pc)
        {
            return pc.ToDateTime(
                pc.GetYear(date),
                pc.GetMonth(date),
                1,
                0,
                0,
                0,
                0);
        }

        private static DateTime GetNextPersianMonthStart(
            DateTime monthStart,
            PersianCalendar pc)
        {
            return pc.AddMonths(monthStart, 1).Date;
        }

        // ---------------------------------------------------------
        // محاسبه افزایش تأخیر نوبت
        // ---------------------------------------------------------

        public static int CalculateQueueDelayMonths(
            int delayedPensionMonths,
            int delayedInstallmentMonths,
            T_VamQueueSetting setting)
        {
            if (setting == null || !setting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات تأخیر نوبت هنوز تکمیل نشده است."
                );
            }

            if (delayedPensionMonths < 0 ||
                delayedInstallmentMonths < 0)
            {
                throw new ArgumentException(
                    "تعداد ماه‌های تأخیر نمی‌تواند منفی باشد."
                );
            }

            if (setting.PensionDelayUnitMonths <= 0 ||
                setting.InstallmentDelayUnitMonths <= 0)
            {
                throw new InvalidOperationException(
                    "واحد محاسبه تأخیر باید بزرگ‌تر از صفر باشد."
                );
            }

            if (setting.PensionQueueIncreaseMonths < 0 ||
                setting.InstallmentQueueIncreaseMonths < 0)
            {
                throw new InvalidOperationException(
                    "افزایش تأخیر نوبت نمی‌تواند منفی باشد."
                );
            }

            // مستمری:
            // چهار ماه اول بدون افزایش نوبت
            // از ماه پنجم، به ازای هر چهار ماه یک ماه افزایش
            int pensionUnits =
                delayedPensionMonths <=
                    setting.PensionDelayUnitMonths
                    ? 0
                    : (delayedPensionMonths - 1) /
                      setting.PensionDelayUnitMonths;

            int pensionDelay =
                pensionUnits *
                setting.PensionQueueIncreaseMonths;

            // اقساط:
            // به ازای هر سه ماه تأخیر، یک ماه افزایش
            int installmentDelay =
                (delayedInstallmentMonths /
                 setting.InstallmentDelayUnitMonths) *
                setting.InstallmentQueueIncreaseMonths;

            // سقف شش ماه مطابق محدودیت فعلی حفظ می‌شود.
            return Math.Min(
                6,
                pensionDelay + installmentDelay
            );
        }
    }
}

﻿using System;
using System.Linq;
using MVCSandoogh.Models;

namespace MVCSandoogh
{
    public static class VamPolicyHelper
    {
        public static decimal GetMinimumPension(
            SandooghModel db,
            DateTime targetDate)
        {
            var setting = db.MinimumPensionSettings
                .Where(x =>
                    x.EffectiveFrom <= targetDate.Date &&
                    (!x.EffectiveTo.HasValue ||
                     x.EffectiveTo.Value >= targetDate.Date))
                .OrderByDescending(x => x.EffectiveFrom)
                .FirstOrDefault();

            if (setting == null)
            {
                throw new InvalidOperationException(
                    "حداقل مستمری برای تاریخ موردنظر تعریف نشده است."
                );
            }

            return setting.MinimumAmount;
        }

        public static int CalculateQueueDelayMonths(
            int delayedPensionMonths,
            int delayedInstallmentMonths,
            T_VamQueueSetting setting)
        {
            if (setting == null || !setting.IsConfigured)
            {
                throw new InvalidOperationException(
                    "تنظیمات تأخیر نوبت هنوز تکمیل نشده است."
                );
            }

            if (delayedPensionMonths < 0 ||
                delayedInstallmentMonths < 0)
            {
                throw new ArgumentException(
                    "تعداد ماه‌های تأخیر نمی‌تواند منفی باشد."
                );
            }

            if (setting.PensionDelayUnitMonths <= 0 ||
                setting.InstallmentDelayUnitMonths <= 0)
            {
                throw new InvalidOperationException(
                    "واحد محاسبه تأخیر باید بزرگ‌تر از صفر باشد."
                );
            }

            if (setting.PensionQueueIncreaseMonths < 0 ||
                setting.InstallmentQueueIncreaseMonths < 0)
            {
                throw new InvalidOperationException(
                    "افزایش تأخیر نوبت نمی‌تواند منفی باشد."
                );
            }

            int pensionDelay =
                (delayedPensionMonths /
                 setting.PensionDelayUnitMonths) *
                setting.PensionQueueIncreaseMonths;

            int installmentDelay =
                (delayedInstallmentMonths /
                 setting.InstallmentDelayUnitMonths) *
                setting.InstallmentQueueIncreaseMonths;

            // سقف شش ماه مطابق محدودیت فعلی سیستم حفظ می‌شود.
            return Math.Min(6, pensionDelay + installmentDelay);
        }
    }
}
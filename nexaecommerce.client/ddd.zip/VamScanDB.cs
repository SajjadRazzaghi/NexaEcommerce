namespace MVCSandoogh
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("VamScanDB")]
    public partial class VamScanDB
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int id { get; set; }

        public int? IdRef { get; set; }

        [StringLength(50)]
        public string ScanDoc { get; set; }

        [Column(TypeName = "image")]
        public byte[] Scan { get; set; }
    }
}

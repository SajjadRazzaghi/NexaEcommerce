namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_Log
    {
        [Key]
        public long Log_Id { get; set; }

        [StringLength(950)]
        public string Log_Name { get; set; }

        [StringLength(4000)]
        public string Log_Description { get; set; }

        public DateTime? Log_Date { get; set; }

        [StringLength(100)]
        public string Log_User { get; set; }

        [StringLength(100)]
        public string Log_Type { get; set; }
    }
}

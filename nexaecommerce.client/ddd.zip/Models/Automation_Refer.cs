namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Automation_Refer
    {
        [Key]
        public long Refer_id { get; set; }

        public long? Refer_letter { get; set; }

        public long? Refer_ErjaDahande { get; set; }

        public long? Refer_ErjaGirande { get; set; }

        public DateTime? Refer_DateErja { get; set; }

        public virtual Automation_Letter Automation_Letter { get; set; }

        public virtual T_User T_User_ErjaDahande { get; set; }

        public virtual T_User T_UserErjaGirandeh { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCSandoogh.Models
{
    public class Users
    {
        public string Id { get; set; }

        public string UserName { get; set; }

        public string FullName { get; set; }

        public string EmailID { get; set; }
        public string Mobile { get; set; }

        public string LastName { get; set; }

    }
}
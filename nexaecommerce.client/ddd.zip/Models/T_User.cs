namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_User
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public T_User()
        {
            T_MostamaryMablagh = new HashSet<T_MostamaryMablagh>();
            ScanDB = new HashSet<ScanDB>();
            T_OzvCode = new HashSet<T_OzvCode>();
            Atomation_Girande = new HashSet<Atomation_Girande>();
            Automation_Letter = new HashSet<Automation_Letter>();
            Automation_Letter1 = new HashSet<Automation_Letter>();
            Automation_Refer = new HashSet<Automation_Refer>();
            Automation_Refer1 = new HashSet<Automation_Refer>();
        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<T_MostamaryMablagh> T_MostamaryMablagh { get; set; }
        [Key]
        public long User_ID { get; set; }

        [Required]
        [StringLength(200)]
        public string User_UserName { get; set; }

        [NotMapped]
        [StringLength(500)]
        public string User_Password { get; set; }
        [Required]
        [StringLength(500)]
        public string User_Firstname { get; set; }

        [Required]
        [StringLength(500)]
        public string User_lastname { get; set; }

        [Required]
        [StringLength(500)]
        public string User_Email { get; set; }

        [StringLength(500)]
        public string User_Mobile { get; set; }

        public int? User_OzvCdoe { get; set; }


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ScanDB> ScanDB { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<T_OzvCode> T_OzvCode { get; set; }
        public virtual T_OzvCode OzvCode { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Atomation_Girande> Atomation_Girande { get; set; }

      
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_Letter> Automation_Letter { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_Letter> Automation_Letter1 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_Letter> Automation_Letter2 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_Refer> Automation_Refer { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_Refer> Automation_Refer1 { get; set; }
    }
}

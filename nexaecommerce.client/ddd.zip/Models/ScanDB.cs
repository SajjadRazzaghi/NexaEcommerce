namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ScanDB")]
    public partial class ScanDB
    {
        public int id { get; set; }

        public int? IdRef { get; set; }

        [StringLength(50)]
        public string ScanDoc { get; set; }

        [StringLength(500)]
        public string ScanURL { get; set; }

        public DateTime? SanadSendDate { get; set; }

       
        public long? SendedUser { get; set; }

        public int? Scan_ScanType { get; set; }

        public virtual T_ScanType T_ScanType { get; set; }
        public virtual T_OzvCode T_OzvCode { get; set; }

        public virtual T_User T_User { get; set; }
    }
}

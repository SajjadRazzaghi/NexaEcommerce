namespace MVCSandoogh
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class bitpayorder
    {
        [Key]
        public double tranaction { get; set; }

        [StringLength(255)]
        public string date { get; set; }

        public double? mablagh { get; set; }

        public double? factor { get; set; }

        [StringLength(255)]
        public string type { get; set; }

        [StringLength(255)]
        public string name { get; set; }

        [StringLength(255)]
        public string email { get; set; }

        [StringLength(255)]
        public string description { get; set; }

        [StringLength(255)]
        public string card { get; set; }

        [StringLength(255)]
        public string statuse { get; set; }
    }
}

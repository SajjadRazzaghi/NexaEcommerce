namespace MVCSandoogh.Models
{
    using Extensions;
    using Models;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_VamCode
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public T_VamCode()
        {
            Vams = new HashSet<Vam>();
            VamNobats = new HashSet<VamNobat>();
        }

        public Guid? GUID { get; set; }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [StringLength(50)]
        public string VamName { get; set; }

        public double? DarsadKarmozd { get; set; }

        public int? TedadAgsat { get; set; }

        public int? TedadZamen { get; set; }

        public int? ModatEntezar { get; set; }

        public int? FaselehBaVam { get; set; }

        public int? NobatMojadad { get; set; }

        public int? AlarmTakhir { get; set; }

        public int? MablagVam { get; set; }

        public int? SagfVam { get; set; }

        public DateTime? EtebarDate { get; set; }

        public bool? KasreKarmozd { get; set; }

        public bool? Faal { get; set; }

        [StringLength(1)]
        public string VamBedGroup { get; set; }

        [StringLength(50)]
        public string VamBedKol { get; set; }

        [StringLength(50)]
        public string VamBedMoein { get; set; }

        [StringLength(50)]
        public string VamBesGroup { get; set; }

        [StringLength(50)]
        public string VamBesKol { get; set; }

        [StringLength(50)]
        public string VamBesMoein { get; set; }

        [StringLength(50)]
        public string VamBesTafsili { get; set; }

        [StringLength(50)]
        public string GestBedGroup { get; set; }

        [StringLength(50)]
        public string GestBedKol { get; set; }

        [StringLength(50)]
        public string GestBedMoein { get; set; }

        [StringLength(50)]
        public string GestBedTafsili { get; set; }

        [StringLength(50)]
        public string GestBesGroup { get; set; }

        [StringLength(50)]
        public string GestBesKol { get; set; }

        [StringLength(50)]
        public string GestBesMoein { get; set; }

       
        [StringLength(50)]
        public string KarmozdBesGroup { get; set; }

        [StringLength(50)]
        public string KarmozdBesKol { get; set; }

        [StringLength(50)]
        public string KarmozdBesMoein { get; set; }

        [StringLength(50)]
        public string KarmozdBesTafsili { get; set; }

        [StringLength(50)]
        public string DirkardBedGroup { get; set; }

        [StringLength(50)]
        public string DirkardBedKol { get; set; }

        [StringLength(50)]
        public string DirkardBedMoein { get; set; }

        [StringLength(50)]
        public string DirkardBedTafsili { get; set; }

        [StringLength(50)]
        public string DirkardBesGroup { get; set; }

        [StringLength(50)]
        public string DirkardBesKol { get; set; }

        [StringLength(50)]
        public string DirkardBesMoein { get; set; }

        [StringLength(50)]
        public string DirkardBesTafsili { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Vam> Vams { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<VamNobat> VamNobats { get; set; }
    }
}

namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Automation_Letter
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Automation_Letter()
        {
            Atomation_Girande = new HashSet<Atomation_Girande>();
            Automation_LetterScanDB_MainLetter = new HashSet<Automation_LetterScanDB>();
            Automation_LetterScanDB_Mortabet = new HashSet<Automation_LetterScanDB>();
            Automation_Refer = new HashSet<Automation_Refer>();
        }

        [Key]
        public long Letter_ID { get; set; }

        public int? Letter_Type { get; set; }

        public long? Letter_Gyrandeh { get; set; }

        [StringLength(1000)]
        public string Letter_Comment { get; set; }

        [StringLength(50)]
        public string Letter_Hour { get; set; }
        [StringLength(50)]
        public string Letter_Minute { get; set; }

        [StringLength(50)]
        public string Letter_Day { get; set; }

        public DateTime? Letter_MorakhasyAz { get; set; }
        public DateTime? Letter_MorakhasyTa { get; set; }
        public DateTime? Letter_TarikhTahie { get; set; }

        public DateTime? Letter_TarikhSabt { get; set; }

        public long? Letter_Ferestandeh { get; set; }

        public bool? Letter_MorakhasyTaeid { get; set; }
        [StringLength(1000)]
        public string Letter_Mozu { get; set; }

        [StringLength(500)]
        public string Letter_File { get; set; }

        public long? Letter_TaeidKonande { get; set; }
        public DateTime? Letter_DateTaeid { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Atomation_Girande> Atomation_Girande { get; set; }

        public virtual Automation_LetterType Automation_LetterType { get; set; }

        public virtual T_User T_User_Ferestandeh { get; set; }
        public virtual T_User T_User_TaeidKonande { get; set; }

        public virtual T_User T_User_Gyrandeh { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_LetterScanDB> Automation_LetterScanDB_MainLetter { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_LetterScanDB> Automation_LetterScanDB_Mortabet { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Automation_Refer> Automation_Refer { get; set; }
      
    }
}

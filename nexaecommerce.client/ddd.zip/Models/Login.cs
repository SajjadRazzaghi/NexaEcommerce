﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    public class Login
    {
        //[NotMapped]
        //public string returnurl;

        [Required(ErrorMessage = "لطفا پسورد را وارد نمائید")]
        [StringLength(100, ErrorMessage = "پسورد می بایست حداقل 6 کاراکتر داشته باشد", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string password { get; set; }

        [Required(ErrorMessage = "لطفا نام کاربری را وارد نمائید")]
        public string username { get; set; }
    }
}
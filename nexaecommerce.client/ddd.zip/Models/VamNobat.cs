namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Web.Mvc;

    [Table("VamNobat")]
    public partial class VamNobat
    {
        public VamNobat()
        {
            AllVamTypes = new List<SelectListItem>();
        }
        [NotMapped]
        public virtual List<SelectListItem> AllVamTypes { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? IdRefNoeVam { get; set; }

        public long? NobatNum { get; set; }
        public int? IdRefOzv { get; set; }

      
          public long? IdRefVam { get; set; }
        public bool? Mokool { get; set; }
        public DateTime NobatDate { get; set; }

        [StringLength(20)]
        public string DocNo { get; set; }

        public virtual T_VamCode T_VamCode { get; set; }
        public virtual T_OzvCode T_OzvCode { get; set; }

        public virtual Vam Vam { get; set; }
    }
}

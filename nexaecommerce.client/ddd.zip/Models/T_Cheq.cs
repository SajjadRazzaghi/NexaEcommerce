namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_Cheq
    {
        [Key]
        public long Cheq_ID { get; set; }

        public long? Cheq_Hesab { get; set; }

        public long? Cheq_Number { get; set; }

        [StringLength(50)]
        public string Cheq_Statuse { get; set; }

        public DateTime? Cheq_Sarresid { get; set; }

        public long? Cheq_ValueDigit { get; set; }
        [StringLength(500)]
        public string Cheq_ValueLiteral { get; set; }

        [StringLength(500)]
        public string Cheq_Vajh { get; set; }

        [StringLength(500)]
        public string Cheq_Babat { get; set; }


        [StringLength(500)]
        public string Cheq_SarresidHoroof { get; set; }
        
        public int? Cheq_Member { get; set; }

        public long? Cheq_Masarf { get; set; }

        public virtual T_BankAccount T_BankAccount { get; set; }

        public virtual T_CheqMasraf T_CheqMasraf { get; set; }

        public virtual T_OzvCode T_OzvCode { get; set; }
        public DateTime? Cheq_Sodoor { get;  set; }
    }
}

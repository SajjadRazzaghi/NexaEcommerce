namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_BankAccount
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public T_BankAccount()
        {
            T_Cheq = new HashSet<T_Cheq>();
        }

        [Key]
        public long BankAccount_ID { get; set; }

        [StringLength(50)]
        public string BankAccount_SHHesab { get; set; }

        [StringLength(500)]
        public string BankAccount_BankName { get; set; }

        [StringLength(200)]
        public string BankAccount_BranchName { get; set; }

        [StringLength(50)]
        public string BankAccount_BranchCode { get; set; }

        [StringLength(500)]
        public string BankAccount_Tel { get; set; }

        [StringLength(500)]
        public string BankAccount_Fax { get; set; }

        [StringLength(1000)]
        public string BankAccount_Address { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<T_Cheq> T_Cheq { get; set; }
    }
}

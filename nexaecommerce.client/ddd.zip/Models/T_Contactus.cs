﻿namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_Contactus
    {
        [Key]
        public long Contactus_ID { get; set; }

        [StringLength(4000)]
        [Required(ErrorMessage = "لطفا نام خانوادگی را وارد نمائید")]
        public string Contactus_LName { get; set; }

        [Required(ErrorMessage = "لطفا پیام خود را وارد نمائید")]
        [DataType(DataType.MultilineText)]
        [Column(TypeName = "ntext")]
        public string Contactus_Text { get; set; }

        [StringLength(300)]
        [Required(ErrorMessage = "لطفا نام  را وارد نمائید")]
        public string Contactus_FName { get; set; }

        [Required(ErrorMessage = "لطفا ایمیل را وارد نمائید")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "لطفا ایمیل معتبر وارد نمائید")]
        public string Contactus_Email { get; set; }
        [StringLength(1000)]
        [Required(ErrorMessage = "لطفا موبایل را وارد نمائید")]
        [RegularExpression(@"^((\+98-?)|0)?[0-9]{10}$", ErrorMessage = "شماره موبایل معتبر نیست.")]
        public string Contactus_Mobile { get; set; }
        public DateTime? Contactus_Date { get; set; }
    }
}

namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
      public partial class Acc_Group_F
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Acc_Group_F()
        {
            Acc_Kol = new HashSet<Acc_Kol>();
        }

        public int Code_Group { get; set; }

        [StringLength(100)]
        public string Comment { get; set; }

        public int NoHesab { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Group_Id { get; set; }

        public virtual T_AccountType T_AccountType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Acc_Kol> Acc_Kol { get; set; }
    }
}


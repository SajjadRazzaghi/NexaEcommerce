namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Acc_Year")]
    public partial class Acc_Year
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Year_ID { get; set; }


        public string Year_Name { get; set; }
        public string ShSanadEftetahie { get; set; }
        public string ShSanadEkhtetamieh { get; set; }



        public DateTime? Year_startdate { get; set; }
        public DateTime? Year_Enddate { get; set; }

        public bool? Year_Close { get; set; }
        public bool? Year_Isactive { get; set; }
        
    }
}

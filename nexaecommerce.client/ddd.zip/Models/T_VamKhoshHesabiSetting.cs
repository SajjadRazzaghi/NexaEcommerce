﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_VamKhoshHesabiSetting")]
    public class T_VamKhoshHesabiSetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Required]
        [Range(0, 100000)]
        public int MaxDelayedInstallments { get; set; }

        [Required]
        [Range(0, 100000)]
        public int MaxDelayedPensions { get; set; }

        [Required]
        [Range(typeof(decimal), "0", "100")]
        public decimal GoodPayerFeePercent { get; set; }

        [Required]
        [Range(typeof(decimal), "0", "100")]
        public decimal NormalPayerFeePercent { get; set; }

        public bool IsConfigured { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}
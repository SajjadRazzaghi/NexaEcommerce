namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Acc_Moein
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Acc_Moein()
        {
         
        }

        [StringLength(2)]
        public string Code_Group { get; set; }

        [StringLength(2)]
        public string Code_Kol { get; set; }

        [StringLength(3)]
        public string Code_Moein { get; set; }

        [StringLength(100)]
        public string Comment { get; set; }

        [Required]
        [StringLength(6)]
        public string Main_Code { get; set; }

        public int? Mahiat { get; set; }

     
        public int? Moein_KolId { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Moein_ID { get; set; }

        public virtual T_Mahiat T_Mahiat { get; set; }

        public virtual Acc_Kol Acc_Kol { get; set; }

      
    }
}

﻿namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Web.Mvc;

    [Table("Vam")]
    public partial class Vam
    {
       
        [NotMapped]
        public virtual List<SelectListItem> AllVamTypes { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Vam()
        {
            AllVamTypes = new List<SelectListItem>();
            G_M_Pays = new HashSet<G_M_Pays>();
            G_M_Payswait = new HashSet<G_M_Payswait>();

            VamNobats = new HashSet<VamNobat>();
            VamZamen = new HashSet<VamZaman>();
          
        }

        public virtual T_OzvCode T_OzvCode { get; set; }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Vam_Id { get; set; }

        public int? IdRefNoeVam { get; set; }

        public int? IdRefOzv { get; set; }

      
        public DateTime? VamDate { get; set; }

        public double? VamMablagKhales { get; set; }

        public double? Karmozd { get; set; }

        public int? TedadAgsat { get; set; }

      
        public DateTime? AvlinGestDate { get; set; }

        public double? GestMablag { get; set; }

        public int? SanadNo { get; set; }

        public int? SanadOkNo { get; set; }
        // درصد کارمزد اعمال‌شده در زمان اعطای وام
        public decimal? KarmozdDarsad { get; set; }

        // تعداد اقساط تأخیردار در زمان اعطای وام
        public int? TedadGhestTakhir { get; set; }

        // تعداد ماه‌های مستمری تأخیردار در زمان اعطای وام
        public int? TedadMostamariTakhir { get; set; }

        // وضعیت خوش‌حسابی در زمان اعطای وام
        public bool? KhoshHesab { get; set; }
        public bool EtmamVam { get; set; }

        public string Sanads { get; set; }

        [StringLength(2000)]
        public string Comment { get; set; }

        [StringLength(500)]
        public string CheckOzv { get; set; }

        [StringLength(500)]
        public string HesabNo { get; set; }

        [StringLength(500)]
        public string BankName { get; set; }

        [StringLength(500)]
        public string CheckVam { get; set; }

        [StringLength(500)]
        public string HesabNoVam { get; set; }

        public virtual T_VamCode T_VamCode { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<G_M_Pays> G_M_Pays { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<G_M_Payswait> G_M_Payswait { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<VamNobat> VamNobats { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<VamZaman> VamZamen { get; set; }

    
    }
}

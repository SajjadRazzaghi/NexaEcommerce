namespace MVCSandoogh.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext()
            : base("name=model1")
        {
        }

        public virtual DbSet<MemberRegistration> MemberRegistrations { get; set; }
        public virtual DbSet<SchemeMaster> SchemeMasters { get; set; }
    
        public virtual DbSet<T_Contactus> T_Contactus { get; set; }
    
        public virtual DbSet<T_Ostan> T_Ostan { get; set; }
      
        public virtual DbSet<T_User> T_User { get; set; }
     
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<webpages_Membership> webpages_Membership { get; set; }
        public virtual DbSet<webpages_OAuthMembership> webpages_OAuthMembership { get; set; }
        public virtual DbSet<webpages_Roles> webpages_Roles { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
           

            modelBuilder.Entity<webpages_Roles>()
                .HasMany(e => e.Users)
                .WithMany(e => e.webpages_Roles)
                .Map(m => m.ToTable("webpages_UsersInRoles").MapLeftKey("RoleId").MapRightKey("UserId"));
        }
    }
}

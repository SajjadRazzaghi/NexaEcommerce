namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_AccountType
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public T_AccountType()
        {
            Acc_Group_F = new HashSet<Acc_Group_F>();
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
       
        public int AccountType_ID { get; set; }

        [StringLength(50)]
        public string AccountType_Name { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Acc_Group_F> Acc_Group_F { get; set; }
    }
}

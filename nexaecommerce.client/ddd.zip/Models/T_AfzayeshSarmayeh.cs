namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_AfzayeshSarmayeh
    {
        [Key]
        public long AfzayeshSarmayeh_id { get; set; }

        public int? AfzayeshSarmayeh_Mablagh { get; set; }

        public int? AfzayeshSarmayeh_Afzayesheghabli { get; set; }
        public string AfzayeshSarmayeh_Tozihat { get; set; }
        public DateTime? AfzayeshSarmayeh_Date { get; set; }

        public int? AfzayeshSarmayeh_Idrefozvcode { get; set; }

        public virtual T_OzvCode T_OzvCode { get; set; }
    }
}

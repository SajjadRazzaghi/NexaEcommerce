namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Acc_Tafsili2
    {
        [StringLength(1000)]
        public string Tafsili2_Code { get; set; }/*1212*/

        [StringLength(1000)]
        public string Tafsili2_Comment { get; set; }

        [StringLength(20)]
        public string Tafsili2_MoeinCode { get; set; }
        
        public int? Tafsili2_Mahiat { get; set; }

        public int? Tafsili2_Tafsili1 { get; set; }
     

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Tafsili2_Id { get; set; }

        public virtual Acc_Tafsil1 Acc_Tafsil1 { get; set; }
        public virtual T_Mahiat T_Mahiat { get; set; }
    }
}

namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class AccSanad_B
    {
        [Key]
      
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        public int? Sanad_No { get; set; }

      
        public DateTime Date_S { get; set; }

        [StringLength(1)]
        public string Group { get; set; }

        [StringLength(3)]
        public string Kol { get; set; }

        [StringLength(3)]
        public string Moein { get; set; }

        [StringLength(50)]
        public string Tafsili { get; set; }

        public double? Bedhkar { get; set; }

        public double? Bestankar { get; set; }

        [StringLength(800)]
        public string Articl_Comment { get; set; }

        
              public bool? UserLock { get; set; }
        public bool Lock_Sanad { get; set; }

      
        public bool Ok_NotOk { get; set; }

        public int? Sanad_Tafsili1 { get; set; }

        public virtual Acc_Tafsil1 Acc_Tafsil1 { get; set; }
    }
}

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_MinimumPensionSetting")]
    public class MinimumPensionSetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public DateTime EffectiveFrom { get; set; }

        [Range(0, 999999999999)]
        public decimal MinimumAmount { get; set; }

        [StringLength(500)]
        public string Description { get; set; }
    }
}

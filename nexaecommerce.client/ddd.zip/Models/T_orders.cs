namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class T_orders
    {
        [Key]
        public long Orderid { get; set; }
        public long userid { get; set; }
        public bool finished { get; set; }
        public bool isghest { get; set; }

        public bool isafzayesh { get; set; }
        public long mablagh { get; set; }
        public int? id_get { get; set; }

        public DateTime? regdate { get; set; }
        public long? transact_id { get; set; }
        

    }
}

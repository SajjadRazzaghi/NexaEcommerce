﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_VamPolicySetting")]
    public class VamPolicySetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        // P: فاصله ماهانه محاسبه امتیاز منفی هر قسط وام
        // مثال: P=2 یعنی هر دو ماه و یک روز تأخیر، یک امتیاز منفی
        [Required]
        [Range(1, 120)]
        public int P_InstallmentDelayUnitMonths { get; set; }

        // Q: فاصله ماهانه محاسبه امتیاز منفی هر ماه مستمری
        // مثال: Q=2 یعنی هر دو ماه و یک روز تأخیر، یک امتیاز منفی
        [Required]
        [Range(1, 120)]
        public int Q_PensionDelayUnitMonths { get; set; }

        // R: حداکثر مجموع امتیاز منفی مجاز در اقساط
        // بیشتر از این مقدار باعث بدحساب شدن عضو می‌شود.
        [Required]
        [Range(0, 120)]
        public int R_MaxInstallmentNegativeScore { get; set; }

        // T: حداکثر مجموع امتیاز منفی مجاز در مستمری
        // بیشتر از این مقدار باعث بدحساب شدن عضو می‌شود.
        [Required]
        [Range(0, 120)]
        public int T_MaxPensionNegativeScore { get; set; }

        // درصد کارمزد عضو خوش‌حساب
        [Required]
        [Range(typeof(decimal), "0", "100")]
        public decimal K_GoodPayerFeePercent { get; set; }

        // درصد کارمزد عضو بدحساب یا فاقد سابقه کافی
        [Required]
        [Range(typeof(decimal), "0", "100")]
        public decimal J_OtherPayerFeePercent { get; set; }
    }
}

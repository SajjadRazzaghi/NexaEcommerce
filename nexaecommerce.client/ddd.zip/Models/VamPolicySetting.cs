using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_VamPolicySetting")]
    public class VamPolicySetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Range(0, 120)]
        public int N_DelayedInstallments { get; set; }

        [Range(0, 120)]
        public int M_DelayedPensions { get; set; }

        [Range(0, 100)]
        public decimal K_GoodPayerFeePercent { get; set; }

        [Range(0, 100)]
        public decimal J_OtherPayerFeePercent { get; set; }
    }
}

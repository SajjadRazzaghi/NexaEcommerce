﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_VamPolicySetting")]
    public class VamPolicySetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        // آستانه امتیاز منفی اقساط
        // رسیدن امتیاز به این حد یا پایین‌تر،
        // باعث غیرخوش‌حساب شدن عضو می‌شود.
        [Range(1, 120)]
        public int N_DelayedInstallments { get; set; }

        // آستانه امتیاز منفی مستمری
        [Range(1, 120)]
        public int M_DelayedPensions { get; set; }

        [Range(0, 100)]
        public decimal K_GoodPayerFeePercent { get; set; }

        [Range(0, 100)]
        public decimal J_OtherPayerFeePercent { get; set; }
    }
}

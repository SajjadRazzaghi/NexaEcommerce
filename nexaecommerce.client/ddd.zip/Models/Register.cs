﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSandoogh.Models
{
    public class Register
    {
       /* [Required(ErrorMessage = "لطفا حاصلجمع را وارد نمائید")]
        [Display(Name = "حاصلجمع")]
        public string Captcha { get; set; }
        */
        [Required(ErrorMessage = "لطفا نام و نام خانوادگی را وارد نمائید")]
        public string FullName { get; set; }


        [Required(ErrorMessage = "لطفا نام کاربری را وارد نمائید")]
      
        public string EmailID { get; set; }

        [Required(ErrorMessage = "لطفا  پسورد را وارد نمائید")]
        [StringLength(100, ErrorMessage = " {0} باید حداقل  {2} کاراکتر باشد", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "پسورد")]
        public string password { get; set; }
        

        [DataType(DataType.Password)]
        [Display(Name = "تکرار پسورد")]
        [Required(ErrorMessage = "لطفا تکرار پسورد را وارد نمائید")]
        [System.ComponentModel.DataAnnotations.Compare("password", ErrorMessage = "پسورد و تکرار آن یکی نیست.")]
        public string Confirmpassword { get; set; }
    

        [RegularExpression(@"^((\+98-?)|0)?[0-9]{10}$", ErrorMessage = "شماره موبایل معتبر نیست.")]
        public string Mobile { get; set; }

        public int IdOzvRef { get; set; }





    }
}
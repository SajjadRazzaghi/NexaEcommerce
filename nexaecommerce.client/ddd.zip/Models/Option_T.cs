namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Option_T
    {

     
        [StringLength(300)]
        public string C1 { get; set; }

        [StringLength(300)]
        public string C2 { get; set; }

        [StringLength(300)]
        public string C3 { get; set; }

        [StringLength(300)]
        public string C4 { get; set; }

        [StringLength(300)]
        public string E1 { get; set; }

        [StringLength(300)]
        public string E2 { get; set; }

        [StringLength(300)]
        public string E3 { get; set; }

        [StringLength(300)]
        public string E4 { get; set; }

        [StringLength(300)]
        public string M1 { get; set; }

        [StringLength(300)]
        public string M2 { get; set; }

        [StringLength(300)]
        public string M3 { get; set; }

        [StringLength(300)]
        public string M4 { get; set; }

        [Key]
        public int id { get; set; }
        public int? HadaksarSarmayeAvvalie { get; set; }
        public int? Hghjalase1 { get; set; }
        public int? Hghjalase2 { get; set; }
      
  }
}

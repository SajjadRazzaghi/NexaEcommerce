﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCSandoogh.Models
{
    public class T_HadaksarAfzayeshChangeDate
    {
        [Key]
        public long HadaksarAfzayeshChangeDate_ID { get; set; }

        public DateTime? HadaksarAfzayeshChangeDate_Datetime { get; set; }

        [StringLength(500)]
        public string HadaksarAfzayeshChangeDate_ModifiedUser { get; set; }

        [StringLength(500)]
        public string HadaksarAfzayeshChangeDate_Ghabli { get; set; }

        [StringLength(500)]
        public string HadaksarAfzayeshChangeDate_Jadid { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCSandoogh.Models
{
    public class ChangepasswordVM
    {
        [Required(ErrorMessage = "لطفا پسورد جدید را وارد نمائید")]
        [StringLength(100, ErrorMessage = "پسورد می بایست حداقل 6 کاراکتر داشته باشد", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New Password")]

        public string Newpassword { get; set; }

        [Required(ErrorMessage = "لطفا پسورد قبلی را وارد نمائید")]
        [DataType(DataType.Password)]
        [Display(Name = "Old password")]
        public string OldPassword { get; set; }

       
    }
}
﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_VamQueueSetting")]
    public class T_VamQueueSetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Range(1, 120)]
        public int MembershipMonthsBeforeDey1402 { get; set; }

        [Range(1, 120)]
        public int MembershipMonthsFromDey1402 { get; set; }

        [Range(1, 120)]
        public int PensionDelayUnitMonths { get; set; }

        [Range(0, 60)]
        public int PensionQueueIncreaseMonths { get; set; }

        [Range(1, 120)]
        public int InstallmentDelayUnitMonths { get; set; }

        [Range(0, 60)]
        public int InstallmentQueueIncreaseMonths { get; set; }

        public bool IsConfigured { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}
﻿
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_VamQueueSetting")]
    public class T_VamQueueSetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        // مدت عضویت لازم برای اعضای قبل از دی ۱۴۰۲
        [Required]
        [Range(1, 120)]
        public int MembershipMonthsBeforeDey1402 { get; set; }

        // مدت عضویت لازم برای اعضای دی ۱۴۰۲ به بعد
        [Required]
        [Range(1, 120)]
        public int MembershipMonthsFromDey1402 { get; set; }

        // M: مهلت اولیه تأخیر قسط وام بدون امتیاز منفی
        // نگاشت به ستون قدیمی دیتابیس برای حفظ اطلاعات قبلی
        [Required]
        [Range(1, 120)]
        [Column("InstallmentDelayUnitMonths")]
        public int M_InstallmentGraceMonths { get; set; }

        // N: مهلت اولیه تأخیر مستمری بدون امتیاز منفی
        // نگاشت به ستون قدیمی دیتابیس برای حفظ اطلاعات قبلی
        [Required]
        [Range(1, 120)]
        [Column("PensionDelayUnitMonths")]
        public int N_PensionGraceMonths { get; set; }

        // -----------------------------------------------------
        // فیلدهای قدیمی افزایش تأخیر صف
        // این فیلدها برای حفظ ستون‌های فعلی دیتابیس نگه داشته شده‌اند.
        // در الگوریتم جدید دیگر استفاده نمی‌شوند.
        // -----------------------------------------------------

     

        public bool IsConfigured { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}

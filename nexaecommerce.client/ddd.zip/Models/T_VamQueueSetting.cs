﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_VamQueueSetting")]
    public class T_VamQueueSetting
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        public int MembershipMonthsBeforeDey1402 { get; set; }

        public int MembershipMonthsFromDey1402 { get; set; }

        public int PensionDelayUnitMonths { get; set; }

        public int PensionQueueIncreaseMonths { get; set; }

        public int InstallmentDelayUnitMonths { get; set; }

        public int InstallmentQueueIncreaseMonths { get; set; }

        public bool IsConfigured { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}
namespace MVCSandoogh.Models
{
    using Extensions;
    using Models;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Web.Mvc;
  
    public partial class G_M_Payswait
    {
        [NotMapped]
        public virtual List<SelectListItem> AllVamTypes { get; set; }

        [NotMapped]
        public virtual List<SelectListItem> AllNahvePardakht { get; set; }

        public G_M_Payswait()
        {
            AllVamTypes = new List<SelectListItem>();
            AllNahvePardakht = new List<SelectListItem>();
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? Emtiaz { get; set; }
        public int? IdRefOzv { get; set; }

        public long? IdRefVam { get; set; }
        public int? IdRefNoeVam { get; set; }
        public int? TedadGest { get; set; }
        public int? statuse { get; set; }
        public int? TedadMostamari { get; set; }
        public double? TotGestMablag { get; set; }
        public double? MablaghharGhest { get; set; }
        public double? MablaghHarMostamary { get; set; }
        public double? TakhirMablag { get; set; }

        public double? MostamariMablag { get; set; }

        public double? TotMablag { get; set; }
        public bool? IsAfzayesh { get; set; }
        public double? AfzayeshMablagh { get; set; }

        public int? Nahveh_P { get; set; }

        [StringLength(20)]
        public string Fish_No { get; set; }

        public string Sanads { get; set; }
        public int? SanadNo { get; set; }

        public int? SanadOkNo { get; set; }

        [StringLength(250)]
        public string Comment { get; set; }

        public DateTime? PayDate { get; set; }

        public DateTime? TaeidDate { get; set; }
        public bool? IsTaeid { get; set; }
        public string TaeidKonandehUser { get; set; }
        public virtual Nahveh_P Nahveh_P1 { get; set; }

        public virtual T_OzvCode T_OzvCode { get; set; }

        public virtual Vam Vam { get; set; }
    }
}

namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Acc_Tafsil1
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Acc_Tafsil1()
        {
            Acc_Tafsili2 = new HashSet<Acc_Tafsili2>();
            AccSanad_B = new HashSet<AccSanad_B>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Tafsil1_ID { get; set; }

        [StringLength(500)]
        public string Tafsil1_Code { get; set; }

        [Required]
        [StringLength(1000)]
        public string Tafsil1_Comment { get; set; }

  
    

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Acc_Tafsili2> Acc_Tafsili2 { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<AccSanad_B> AccSanad_B { get; set; }
    }
}

namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Atomation_Girande
    {
        [Key]
        public int Girande_ID { get; set; }

        public long? Girande_Letter { get; set; }

        public long? Girande_User { get; set; }

        public virtual Automation_Letter Automation_Letter { get; set; }

        public virtual T_User T_User { get; set; }
    }
}

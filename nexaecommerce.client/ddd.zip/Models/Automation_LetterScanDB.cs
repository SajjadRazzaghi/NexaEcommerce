namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Automation_LetterScanDB
    {
      
        public int id { get; set; }

        public long? Letter_Id { get; set; }

      
        public long? Letter_Mortabet { get; set; }


        public virtual Automation_Letter Automation_Letter_MainLetter { get; set; }

        public virtual Automation_Letter Automation_Letter_Mortabet{ get; set; }
    }
}

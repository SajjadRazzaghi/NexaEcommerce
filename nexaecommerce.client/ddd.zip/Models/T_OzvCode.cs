namespace MVCSandoogh.Models
{
    using Extensions;
    using Models;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Web.Mvc;


    public partial class T_OzvCode
    {
        public T_OzvCode()
        {
            T_Cheq = new HashSet<T_Cheq>();
            G_M_Pays = new HashSet<G_M_Pays>();
            G_M_Payswait = new HashSet<G_M_Payswait>();

            Tasviehs = new HashSet<Tasvieh>();
            VamZamen = new HashSet<VamZaman>();
            T_MostamaryMablagh = new HashSet<T_MostamaryMablagh>();
            VamNobats = new HashSet<VamNobat>();
            Vams = new HashSet<Vam>();
            ScanDBs = new HashSet<ScanDB>();
            User = new HashSet<T_User>();
            T_AfzayeshSarmayeh = new HashSet<T_AfzayeshSarmayeh>();

        }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<T_MostamaryMablagh> T_MostamaryMablagh { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Vam> Vams { get; set; }
        public Guid? GUID { get; set; }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        public bool? Faal { get; set; }

        [StringLength(50)]
        public string LName { get; set; }
        
        [StringLength(50)]
        public string FName { get; set; }

        [StringLength(50)]
        public string FatherName { get; set; }

        public int? OzvCode_Jensiat { get; set; }

        [StringLength(12)]
        public string MelliCode { get; set; }

        [StringLength(12)]
        public string ShNo { get; set; }

        public int? OzvCode_ShCity { get; set; }

        public int? OzvCode_TavalodCity { get; set; }

        [StringLength(10)]
        public string SeriSh { get; set; }

        [StringLength(10)]
        public string SerialSh { get; set; }

        [StringLength(20)]
        public string parvanehNo { get; set; }

        [StringLength(20)]
        public string NezamNo { get; set; }

        [StringLength(20)]
        public string Tel { get; set; }

        [StringLength(20)]
        public string Mobile { get; set; }

        public string SH_Shaba { get; set; }
        [StringLength(150)]
        public string Address { get; set; }

        public int? IdVamRef { get; set; }

        public int? DarsadMandehVam { get; set; }
        public int? SumAfzayeshMostamary { get; set; }
        
        public int? ozvcode_Taahol { get; set; }
      
        public DateTime OzvDate { get; set; }
      
        public DateTime? TavalodDate { get; set; }

        public long? ModifiedUser { get; set; }
        [StringLength(1000)]
        public string Semat { get; set; }
        

        [StringLength(50)]
        public string afzayeshhenase { get; set; }
        

        [StringLength(50)]
        public string mostammarryshenase { get; set; }
        

        [StringLength(50)]
        public string ghestshenase { get; set; }
        
        public virtual CityCode CityCode { get; set; }

        public virtual CityCode CityCode1 { get; set; }

        public virtual T_Jensiat T_Jensiat { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<G_M_Payswait> G_M_Payswait { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<G_M_Pays> G_M_Pays { get; set; }

        public virtual T_User T_User { get; set; }

        public virtual Taahol Taahol { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Tasvieh> Tasviehs { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<VamZaman> VamZamen { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<VamNobat> VamNobats { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ScanDB> ScanDBs { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<T_User> User { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<T_Cheq> T_Cheq { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<T_AfzayeshSarmayeh> T_AfzayeshSarmayeh { get; set; }
    }
}

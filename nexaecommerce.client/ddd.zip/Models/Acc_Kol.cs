namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
  
    public partial class Acc_Kol
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Acc_Kol()
        {
            Acc_Moein = new HashSet<Acc_Moein>();
        }

        public int Code_Group { get; set; }

        [Required]
        [StringLength(2)]
        public string Code_Kol { get; set; }

        [StringLength(100)]
        public string Comment { get; set; }

        public int? Mahiat { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Kol_Id { get; set; }

        public virtual Acc_Group_F Acc_Group_F { get; set; }

        public virtual T_Mahiat T_Mahiat { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Acc_Moein> Acc_Moein { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSandoogh.Models
{
    [Table("T_MinMostamari")]
    public class T_MinMostamari
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public DateTime EffectiveFrom { get; set; }

        [Required]
        public decimal MinimumAmount { get; set; }

        public string Description { get; set; }
    }
}
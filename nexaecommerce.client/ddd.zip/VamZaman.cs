namespace MVCSandoogh.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class VamZaman
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? IdOzvRef { get; set; }

        public long? IdVamRef { get; set; }

        public bool? EtmamVam { get; set; }

        [StringLength(50)]
        public string CheckNo { get; set; }

        [StringLength(50)]
        public string BankName { get; set; }

        [StringLength(50)]
        public string HesabNo { get; set; }

        public double? Mablag { get; set; }

        [StringLength(250)]
        public string Comment { get; set; }

        public virtual T_OzvCode T_OzvCode { get; set; }

        public virtual Vam Vam { get; set; }
    }
}
